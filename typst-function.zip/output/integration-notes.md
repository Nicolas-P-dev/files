# Integration Notes

Every change needed in existing repo files to wire the PDF report system in.

---

## 1. `backend/agent/config.py` — Add Typst binary setting

Add this field to the `Settings` class, after the existing `uploads_dir` field:

```python
    typst_binary: str = "typst"  # path to typst binary, default assumes PATH
```

Env var: `APM_TYPST_BINARY`

---

## 2. `backend/agent/deps.py` — Add exports singletons

### 2a. Add imports at the top (after existing imports)

```python
from agent.export_store import ExportStore
```

### 2b. Add module-level globals (after `uploads_dir` declaration around line 33)

```python
templates_dir: Path | None = None
exports_dir: Path | None = None
export_store: ExportStore | None = None
```

### 2c. In `bootstrap()`, after `uploads_dir.mkdir(...)` (around line 74), add:

```python
    global templates_dir, exports_dir, export_store

    templates_dir = backend_dir / "templates"
    exports_dir = backend_dir / "exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    export_store = ExportStore(exports_dir)
```

Note: `templates_dir` and `exports_dir` must also be added to the `global` statement at line 60:

```python
    global agent_loop, orchestrator, registry, store
    global skills_dir, users_dir, uploads_dir
    global templates_dir, exports_dir, export_store  # <-- add this line
```

---

## 3. `backend/agent/internal_tools.py` — Register report tools

### 3a. Add import at the top (after existing imports, around line 13)

```python
from agent.report_tools import render_report, render_chart, list_report_templates, get_report_source
```

### 3b. Add to `INTERNAL_TOOLS` dict (at the end, before the closing `}`)

```python
    "render_report": render_report,
    "render_chart": render_chart,
    "list_report_templates": list_report_templates,
    "get_report_source": get_report_source,
```

The full dict will look like:

```python
INTERNAL_TOOLS: dict[str, Callable] = {
    "extract_document_text": extract_document_text,
    "extract_all_documents": extract_all_documents,
    "save_project_structure": save_project_structure,
    "load_project_structure": load_project_structure,
    "get_project_status": get_project_status,
    "open_panel": open_panel,
    "mark_items_deploying": mark_items_deploying,
    "deploy_to_jira": deploy_to_jira,
    "list_available_tools": list_available_tools,
    "call_mcp_tool": call_mcp_tool,
    "render_report": render_report,
    "render_chart": render_chart,
    "list_report_templates": list_report_templates,
    "get_report_source": get_report_source,
}
```

---

## 4. `backend/agent/routers/chat.py` — Emit `file` SSE events

The `render_report` and `render_chart` tools return JSON with `file_id`, `file_type`, `url`, `filename`. When a tool result contains these fields, emit a separate `file` SSE event so the frontend can attach the file to the current message.

In the `_stream()` generator, in the `case 'status'` block where `step == 'tool_result'`, add file event detection by checking the tool name:

```python
                if etype == "status" and event.get("step") == "tool_result":
                    for tool_name in (event.get("data", {}).get("tools") or []):
                        if tool_name in ("render_report", "render_chart"):
                            # The tool result text is JSON with file metadata
                            raw = (event.get("data", {}).get("previews") or [""])[0]
                            try:
                                fdata = json.loads(raw) if isinstance(raw, str) else raw
                                if isinstance(fdata, dict) and "file_id" in fdata:
                                    fe = {
                                        "type": "file",
                                        "file_id": fdata["file_id"],
                                        "file_type": fdata.get("file_type", "pdf"),
                                        "url": fdata.get("url", ""),
                                        "filename": fdata.get("filename", ""),
                                    }
                                    if fdata.get("pages") is not None:
                                        fe["pages"] = fdata["pages"]
                                    if fdata.get("typst_file_id"):
                                        fe["typst_file_id"] = fdata["typst_file_id"]
                                        fe["typst_url"] = fdata.get("typst_url", "")
                                    yield f"data: {json.dumps(fe)}\n\n"
                            except (json.JSONDecodeError, TypeError, IndexError):
                                pass
```

---

## 5. `frontend/src/hooks/useChat.js` — Handle `file` SSE events

### 5a. In the SSE event switch statement (around line 60), add a new case after the `case 'panel'` block:

```javascript
                        case 'file':
                            setMessages(prev => {
                                const updated = [...prev];
                                const last = updated[updated.length - 1];
                                if (last?.isStreaming || last?.role === 'assistant') {
                                    const files = last.files ? [...last.files] : [];
                                    const fileEntry = {
                                        file_id: event.file_id,
                                        file_type: event.file_type,
                                        url: event.url,
                                        filename: event.filename,
                                        pages: event.pages,
                                    };
                                    if (event.typst_file_id) {
                                        fileEntry.typst_file_id = event.typst_file_id;
                                        fileEntry.typst_url = event.typst_url;
                                    }
                                    files.push(fileEntry);
                                    updated[updated.length - 1] = { ...last, files };
                                }
                                return updated;
                            });
                            break;
```

---

## 6. `frontend/src/components/ChatView.jsx` — Render MessageAttachment

### 6a. Add import at top:

```javascript
import MessageAttachment from './MessageAttachment';
```

### 6b. The `ChatView` component needs an `onOpenPanel` prop. Update the destructured props:

```javascript
export default function ChatView({
    messages, isStreaming, streamingStatus, traceSteps, inputValue, onInputChange, onSend, onSuggestionClick,
    onOpenConnectedTools, onOpenPanel,
}) {
```

### 6c. After the message content rendering block (after the `</ReactMarkdown>` for non-error messages, around line 165), before the skill chips section, add:

```jsx
                                            {msg.files?.map((file) => (
                                                <MessageAttachment
                                                    key={file.file_id}
                                                    file={file}
                                                    onOpenPanel={onOpenPanel}
                                                />
                                            ))}
```

The exact location is inside the assistant message rendering, after `{msg.content ? ( ... ) : null}` and before the skill chips block `{!msg.isStreaming && (msg.skills?.length || msg.skill) && (`.

### 6d. In `App.jsx`, when rendering `<ChatView>`, pass the panel open handler:

```jsx
<ChatView
    // ... existing props ...
    onOpenPanel={(panelType, panelData) => {
        setActivePanel(panelType);
        setPanelData(panelData);
    }}
/>
```

---

## 7. `frontend/src/components/panelRegistry.js` — Register new panels

### 7a. Add imports at top:

```javascript
import ImageViewerPanel from './panels/ImageViewerPanel';
import PdfViewerPanel from './panels/PdfViewerPanel';
```

### 7b. Add entries to `PANEL_REGISTRY`:

```javascript
    'image-viewer': { component: ImageViewerPanel, title: 'Image Viewer' },
    'pdf-viewer': { component: PdfViewerPanel, title: 'PDF Report' },
```

---

## 8. `frontend/src/components/toolIconRegistry.jsx` — Add report tool icons

### 8a. Add the ReportIcon component (after the existing icon definitions, around line 63):

```javascript
const ReportIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 1h5.5L13 4.5V14a1 1 0 01-1 1H4a1 1 0 01-1-1V2a1 1 0 011-1z" stroke="#26890D" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M9 1v4h4" stroke="#26890D" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M5 8h6M5 10.5h4" stroke="#26890D" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
);
```

### 8b. Add entries to `INTERNAL_TOOL_ICONS` (around line 89):

```javascript
    render_report: ReportIcon,
    render_chart: ReportIcon,
    list_report_templates: InternalToolIcon,
```

### 8c. Add entries to `TOOL_LABELS` (around line 148):

```javascript
    render_report: 'Generate Report',
    render_chart: 'Render Chart',
    list_report_templates: 'List Templates',
```

---

## 9. Router wiring — `backend/agent/main.py`

### 9a. Add import (with other router imports):

```python
from agent.routers.exports import router as exports_router
```

### 9b. Register the router (with other `app.include_router` calls):

```python
app.include_router(exports_router, prefix="/api")
```

---

## 10. Frontend dependencies

Install `react-pdf`:

```bash
cd frontend && npm install react-pdf
```

---

## 11. Typst binary

Ensure `typst` is on PATH. Install options:

- Windows: `winget install Typst.Typst`
- macOS: `brew install typst`
- Linux: download from https://github.com/typst/typst/releases
- Docker: add to Dockerfile (see spec for instructions)

---

## 12. Fonts

Place Open Sans font files in `backend/templates/fonts/`:
- `OpenSans-Regular.ttf`
- `OpenSans-SemiBold.ttf`
- `OpenSans-Bold.ttf`

Download from Google Fonts: https://fonts.google.com/specimen/Open+Sans

---

## 13. File placement summary — COMPLETE (copy-replace)

All files below are ready to copy-replace. Modified existing repo files have all changes pre-applied.

### New files (copy into repo)

| Source (output/) | Destination (repo) |
|---|---|
| `backend/templates/` (entire tree) | `backend/templates/` |
| `backend/agent/export_store.py` | `backend/agent/export_store.py` |
| `backend/agent/report_tools.py` | `backend/agent/report_tools.py` |
| `backend/agent/composer_tools.py` | `backend/agent/composer_tools.py` |
| `backend/agent/dashboard_tools.py` | `backend/agent/dashboard_tools.py` |
| `backend/routers/exports.py` | `backend/agent/routers/exports.py` |
| `frontend/src/components/MessageAttachment.jsx` | `frontend/src/components/MessageAttachment.jsx` |
| `frontend/src/components/panels/ImageViewerPanel.jsx` | `frontend/src/components/panels/ImageViewerPanel.jsx` |
| `frontend/src/components/panels/PdfViewerPanel.jsx` | `frontend/src/components/panels/PdfViewerPanel.jsx` |
| `frontend/src/components/panels/ReportComposerPanel.jsx` | `frontend/src/components/panels/ReportComposerPanel.jsx` |
| `frontend/src/components/panels/composer/SectionPalette.jsx` | `frontend/src/components/panels/composer/SectionPalette.jsx` |
| `frontend/src/components/panels/composer/SectionOutline.jsx` | `frontend/src/components/panels/composer/SectionOutline.jsx` |
| `frontend/src/components/panels/composer/SectionConfig.jsx` | `frontend/src/components/panels/composer/SectionConfig.jsx` |
| `frontend/src/components/panels/DashboardPanel.jsx` | `frontend/src/components/panels/DashboardPanel.jsx` |
| `frontend/src/components/panels/dashboard/WidgetCard.jsx` | `frontend/src/components/panels/dashboard/WidgetCard.jsx` |
| `frontend/src/components/panels/dashboard/WidgetGrid.jsx` | `frontend/src/components/panels/dashboard/WidgetGrid.jsx` |
| `skills/default/report-generation.md` | `backend/skills/default/report-generation.md` |

### Modified existing files (copy-replace)

| Source (output/) | Destination (repo) | What changed |
|---|---|---|
| `backend/agent/config.py` | `backend/agent/config.py` | Added `typst_binary` setting |
| `backend/agent/deps.py` | `backend/agent/deps.py` | Added ExportStore import, `templates_dir`/`exports_dir`/`export_store` globals, bootstrap init |
| `backend/agent/internal_tools.py` | `backend/agent/internal_tools.py` | Added imports + 6 new tool registrations in INTERNAL_TOOLS dict |
| `backend/agent/routers/chat.py` | `backend/agent/routers/chat.py` | Added `_FILE_EVENT_TOOLS` set + `_emit_file_events()` for SSE file events (reports/charts/dashboard) |
| `frontend/src/hooks/useChat.js` | `frontend/src/hooks/useChat.js` | Added `case 'file':` handler in SSE switch (with typst fields) |
| `frontend/src/components/ChatView.jsx` | `frontend/src/components/ChatView.jsx` | Added `MessageAttachment` import/rendering + `onOpenPanel` prop |
| `frontend/src/components/panelRegistry.js` | `frontend/src/components/panelRegistry.js` | Added 4 panel registrations (image-viewer, pdf-viewer, report-composer, live-dashboard) |
| `frontend/src/components/toolIconRegistry.jsx` | `frontend/src/components/toolIconRegistry.jsx` | Added `ReportIcon` + 6 tool icon/label entries |
| `frontend/src/components/Sidebar.jsx` | `frontend/src/components/Sidebar.jsx` | Added Report Composer + Live Dashboard nav entries with MenuBookIcon/BarChartIcon |

| `backend/agent/main.py` | `backend/agent/main.py` | Added `exports_router` import + `app.include_router(exports_router, prefix="/api")` |
| `frontend/src/App.jsx` | `frontend/src/App.jsx` | Added `onOpenPanel` prop to ChatView + extended `withWorkspaceContext` for report-composer, live-dashboard, pdf-viewer panels |

---

## 14. Vite proxy (if not already present)

In `vite.config.js`, the existing `/api` proxy already covers the new `/api/sessions/{sid}/exports/{fid}` endpoint. No changes needed.

---

## 15. `backend/agent/internal_tools.py` — Register composer and dashboard tools

### 15a. Add imports:
```python
from agent.composer_tools import compose_report
from agent.dashboard_tools import render_dashboard
```

### 15b. Add to `INTERNAL_TOOLS` dict:
```python
    "compose_report": compose_report,
    "render_dashboard": render_dashboard,
```

---

## 16. `backend/agent/routers/chat.py` — Emit file events for new tools

Update the tool name check (from section 4) to include `compose_report` and `render_dashboard`:

```python
if tool_name in ("render_report", "render_chart", "compose_report", "render_dashboard"):
```

For `render_dashboard`, the tool result is a JSON array (not a single object). Each item with a `file_id` should emit a separate `file` SSE event.

---

## 17. `frontend/src/components/panelRegistry.js` — Register new panels

### 17a. Add imports:
```javascript
import ReportComposerPanel from './panels/ReportComposerPanel';
import DashboardPanel from './panels/DashboardPanel';
```

### 17b. Add entries to `PANEL_REGISTRY`:
```javascript
    'report-composer': { component: ReportComposerPanel, title: 'Report Composer' },
    'dashboard': { component: DashboardPanel, title: 'Live Dashboard' },
```

---

## 18. Sidebar navigation — Add Report Composer and Dashboard entries

In `frontend/src/components/Sidebar.jsx` (or wherever sidebar navigation items are defined), add two new entries:

```javascript
{ id: 'report-composer', label: 'Report Composer', icon: MenuBookIcon, panelType: 'report-composer' },
{ id: 'dashboard', label: 'Dashboard', icon: DashboardIcon, panelType: 'dashboard' },
```

When clicked, they should call `onOpenPanel(panelType, { sessionId })`.

---

## 19. File placement summary (new files)

| Source (output/) | Destination (repo) |
|---|---|
| `backend/agent/composer_tools.py` | `backend/agent/composer_tools.py` |
| `backend/agent/dashboard_tools.py` | `backend/agent/dashboard_tools.py` |
| `frontend/src/components/panels/ReportComposerPanel.jsx` | `frontend/src/components/panels/ReportComposerPanel.jsx` |
| `frontend/src/components/panels/composer/SectionPalette.jsx` | `frontend/src/components/panels/composer/SectionPalette.jsx` |
| `frontend/src/components/panels/composer/SectionOutline.jsx` | `frontend/src/components/panels/composer/SectionOutline.jsx` |
| `frontend/src/components/panels/composer/SectionConfig.jsx` | `frontend/src/components/panels/composer/SectionConfig.jsx` |
| `frontend/src/components/panels/DashboardPanel.jsx` | `frontend/src/components/panels/DashboardPanel.jsx` |
| `frontend/src/components/panels/dashboard/WidgetCard.jsx` | `frontend/src/components/panels/dashboard/WidgetCard.jsx` |
| `frontend/src/components/panels/dashboard/WidgetGrid.jsx` | `frontend/src/components/panels/dashboard/WidgetGrid.jsx` |

---

## 20. Chat-to-Panel integration

Both panels can be opened from chat via the AI agent:
- `open_panel('report-composer', {sessionId})` — opens the Report Composer
- `open_panel('dashboard', {sessionId, widgetDefs: [...]})` — opens Dashboard with widget definitions to render

The `compose_report` and `render_dashboard` tools are also directly callable from chat. When the AI calls these tools via chat, the SSE `file` events auto-display results. The panels also have their own direct UI controls for when users prefer clicking over typing.

---

## 21. Typst source code export

After report generation (via `compose_report`, `render_report`, or `render_chart`), users can access the raw Typst source:

- All three tools save the generated .typ source alongside the PDF/PNG and return `typst_file_id` + `typst_url`
- PdfViewerPanel shows a "Download .typ" button (code icon) when `typstUrl` is present in panel data
- `get_report_source` tool lets the AI retrieve and display Typst source directly in chat as a code block
- SSE `file` events include `typst_file_id` and `typst_url` so `MessageAttachment` can pass them to `PdfViewerPanel`
- Users can say "show me the typst code for that report" → AI calls `get_report_source(typst_file_id)` → returns source in a code block

**Flow:** tool result → SSE `file` event (with typst fields) → `useChat` stores in message files → `MessageAttachment` click → `onOpenPanel('pdf-viewer', {url, typstUrl})` → PdfViewerPanel shows download button.

---

## 22. Chat awareness of panel state (`withWorkspaceContext`)

The existing `withWorkspaceContext` pattern in `App.jsx` (used by `doc-review` to inject `doc_session_id` into chat context) is extended for report panels. This lets the AI know when a panel is open and offer contextual help.

### 22a. In `App.jsx`, extend the workspace context logic:

The existing pattern is:

```javascript
// Existing (doc-review):
if (activePanel === 'doc-review' && panelData?.session_id) {
    context.doc_session_id = panelData.session_id;
}
```

Add after it:

```javascript
// Report Composer — AI knows composer is open and can offer section suggestions
if (activePanel === 'report-composer') {
    context.active_panel = 'report-composer';
    if (panelData?.sessionId) {
        context.doc_session_id = panelData.sessionId;
    }
}

// Live Dashboard — AI knows dashboard is open and can add/refresh widgets
if (activePanel === 'dashboard') {
    context.active_panel = 'dashboard';
    if (panelData?.sessionId) {
        context.doc_session_id = panelData.sessionId;
    }
}

// PDF Viewer — AI knows a report is being viewed
if (activePanel === 'pdf-viewer') {
    context.active_panel = 'pdf-viewer';
    if (panelData?.typstUrl) {
        context.viewing_report_typst_url = panelData.typstUrl;
    }
}
```

### 22b. How it works

When any of these panels are open:
1. `App.jsx` merges `active_panel` (and related fields) into the chat `body.context` dict
2. `render_context_section(context)` in `prompt.py` appends a `## Request Context` block with `active_panel: "report-composer"` (etc.)
3. The AI sees this in its system prompt and can tailor responses:
   - **Composer open:** "I can help you add sections — try 'add a burndown chart' or 'what should I include for a sprint review?'"
   - **Dashboard open:** "Dashboard is live. I can add more widgets, refresh data, or generate a full report from this data."
   - **PDF Viewer open:** "Want me to show the Typst source code? I can also generate a different version of this report."

### 22c. No code changes needed in `prompt.py`

The existing `render_context_section()` already handles arbitrary context keys — it outputs one line per key with JSON for dict/list values. The `active_panel` key will appear automatically.

---

## 23. `backend/agent/internal_tools.py` — Register `get_report_source`

Already covered in section 3a above. The tool is registered alongside the other report tools.

### 23a. Add to tool icons (`toolIconRegistry.jsx`)

```javascript
    get_report_source: InternalToolIcon,
```

### 23b. Add to tool labels

```javascript
    get_report_source: 'View Report Source',
```

---

## 24. `backend/agent/routers/chat.py` — Include `get_report_source` in tool names

The `get_report_source` tool does NOT need file SSE events (it returns source text, not a file). No changes to the file event detection block needed.

However, if you want to show tool execution status in the chat trace, ensure `get_report_source` is not accidentally filtered out by any tool name whitelists in the trace rendering.
