import { useState, useRef, useCallback } from 'react';
import { authHeaders } from '../utils/api';

export default function useChat() {
    const [messages, setMessages] = useState([]);
    const [isStreaming, setIsStreaming] = useState(false);
    const [streamingStatus, setStreamingStatus] = useState('');
    const [traceSteps, setTraceSteps] = useState([]);
    const [currentSkill, setCurrentSkill] = useState(null);
    const [panelEvent, setPanelEvent] = useState(null);
    const abortRef = useRef(null);
    const traceAccumulatorRef = useRef([]);
    const onStreamCompleteRef = useRef(null);

    const sendMessage = useCallback(async (text, sessionId, userId = 'default', token = '', context = null) => {
        if (!text.trim() || isStreaming) return;

        setMessages(prev => [...prev, { role: 'user', content: text }]);
        setIsStreaming(true);
        setStreamingStatus('');
        setTraceSteps([]);
        traceAccumulatorRef.current = [];
        setCurrentSkill(null);
        setMessages(prev => [...prev, { role: 'assistant', content: '', isStreaming: true }]);

        const controller = new AbortController();
        abortRef.current = controller;
        let accumulated = '';

        try {
            const body = { message: text, session_id: sessionId, user_id: userId, token };
            if (context && Object.keys(context).length > 0) body.context = context;
            const response = await fetch('/api/chat/stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', ...authHeaders() },
                body: JSON.stringify(body),
                signal: controller.signal,
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';

                for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    let event;
                    try { event = JSON.parse(line.slice(6).trim()); }
                    catch { continue; }

                    switch (event.type) {
                        case 'token':
                            if (typeof event.content === 'string') {
                                accumulated += event.content;
                            }
                            setMessages(prev => {
                                const updated = [...prev];
                                const last = updated[updated.length - 1];
                                if (last?.isStreaming) updated[updated.length - 1] = { ...last, content: accumulated };
                                return updated;
                            });
                            break;

                        case 'status':
                            setStreamingStatus(event.message ?? '');
                            if (event.step === 'thinking' && accumulated) {
                                accumulated += '\n\n';
                                setMessages(prev => {
                                    const updated = [...prev];
                                    const last = updated[updated.length - 1];
                                    if (last?.isStreaming) updated[updated.length - 1] = { ...last, content: accumulated };
                                    return updated;
                                });
                            }
                            if (event.step != null) {
                                const stepPayload = { ...event, timestamp: Date.now() };
                                traceAccumulatorRef.current = [...traceAccumulatorRef.current, stepPayload];
                                setTraceSteps(prev => [...prev, stepPayload]);
                            }
                            break;

                        case 'routing': {
                            setStreamingStatus(event.message ?? '');
                            const routingPayload = { type: 'routing', step: 'routing', message: event.message, timestamp: Date.now() };
                            traceAccumulatorRef.current = [...traceAccumulatorRef.current, routingPayload];
                            setTraceSteps(prev => [...prev, routingPayload]);
                            break;
                        }

                        case 'skill_start': {
                            const task = event.task || event.skill;
                            const label = event.total > 1 ? `Step ${event.step}/${event.total}: ${task}` : task;
                            setStreamingStatus(label);
                            const startPayload = { type: 'skill_start', step: 'skill_start', skill: event.skill, name: event.name ?? null, skillStep: event.step, total: event.total, task, message: label, timestamp: Date.now() };
                            traceAccumulatorRef.current = [...traceAccumulatorRef.current, startPayload];
                            setTraceSteps(prev => [...prev, startPayload]);
                            break;
                        }

                        case 'skill_complete': {
                            const skillLabel = event.name || event.skill;
                            const completePayload = { type: 'skill_complete', step: 'skill_complete', skill: event.skill, name: event.name ?? null, skillStep: event.step, error: event.error ?? null, message: event.error ? `${skillLabel} failed` : `${skillLabel} complete`, timestamp: Date.now(), duration_ms: event.duration_ms ?? null };
                            traceAccumulatorRef.current = [...traceAccumulatorRef.current, completePayload];
                            setTraceSteps(prev => [...prev, completePayload]);
                            setStreamingStatus('');
                            break;
                        }

                        case 'done':
                            setCurrentSkill(event.skill ?? event.skills ?? null);
                            setMessages(prev => {
                                const updated = [...prev];
                                const last = updated[updated.length - 1];
                                if (last?.isStreaming) {
                                    const trace = [...traceAccumulatorRef.current];
                                    updated[updated.length - 1] = {
                                        ...last,
                                        isStreaming: false,
                                        skill: event.skill ?? null,
                                        skills: event.skills ?? null,
                                        trace,
                                        totalDurationMs: event.duration_ms,
                                    };
                                }
                                return updated;
                            });
                            break;

                        case 'panel':
                            setPanelEvent({ panelType: event.panel_type, data: event.data });
                            break;

                        case 'file':
                            setMessages(prev => {
                                const updated = [...prev];
                                const last = updated[updated.length - 1];
                                if (last?.isStreaming || last?.role === 'assistant') {
                                    const files = last.files ? [...last.files] : [];
                                    const fileEntry = {
                                        file_id: event.file_id,
                                        file_type: event.file_type,
                                        url: event.url,
                                        filename: event.filename,
                                        pages: event.pages,
                                    };
                                    if (event.typst_file_id) {
                                        fileEntry.typst_file_id = event.typst_file_id;
                                        fileEntry.typst_url = event.typst_url;
                                    }
                                    files.push(fileEntry);
                                    updated[updated.length - 1] = { ...last, files };
                                }
                                return updated;
                            });
                            break;

                        case 'error':
                            setMessages(prev => {
                                const updated = [...prev];
                                const last = updated[updated.length - 1];
                                if (last?.isStreaming) {
                                    updated[updated.length - 1] = {
                                        ...last,
                                        isStreaming: false,
                                        content: event.message || 'An error occurred.',
                                        isError: true,
                                        errorAction: event.action || null,
                                    };
                                }
                                return updated;
                            });
                            break;
                    }
                }
            }
        } catch (err) {
            if (err.name !== 'AbortError') {
                setMessages(prev => {
                    const updated = [...prev];
                    const last = updated[updated.length - 1];
                    if (last?.isStreaming) updated[updated.length - 1] = { ...last, isStreaming: false, content: `Connection error: ${err.message}`, isError: true };
                    return updated;
                });
            }
        } finally {
            setIsStreaming(false);
            setStreamingStatus('');
            abortRef.current = null;
            onStreamCompleteRef.current?.(sessionId);
        }
    }, [isStreaming]);

    const cancelStream = useCallback(() => {
        abortRef.current?.abort();
        setIsStreaming(false);
        setStreamingStatus('');
    }, []);

    const clearMessages = useCallback(() => {
        setMessages([]);
        setCurrentSkill(null);
        setPanelEvent(null);
    }, []);

    const loadMessages = useCallback((newMessages) => {
        setMessages(Array.isArray(newMessages) ? newMessages : []);
        setCurrentSkill(null);
        setPanelEvent(null);
    }, []);

    const setOnStreamComplete = useCallback((cb) => {
        onStreamCompleteRef.current = cb;
    }, []);

    return { messages, isStreaming, streamingStatus, traceSteps, currentSkill, panelEvent, sendMessage, cancelStream, clearMessages, loadMessages, setPanelEvent, setOnStreamComplete };
}
