/**
 * Central registry for tool icons and friendly display names.
 *
 * Maps tool name prefixes to SVG icons and individual tool names to
 * short labels. Add a new integration by dropping one entry in
 * TOOL_PROVIDERS and optionally adding specific labels in TOOL_LABELS.
 */

// -- Provider icons (keyed by tool name prefix) ---------------------------

const JiraIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.53 2c0 2.4 1.97 4.35 4.35 4.35h1.78v1.7c0 2.4 1.97 4.35 4.35 4.35V2.84A.84.84 0 0021.17 2H11.53z" fill="#2684FF" />
        <path d="M8.77 4.78c0 2.4 1.97 4.35 4.35 4.35h1.78v1.7c0 2.4 1.97 4.35 4.35 4.35V5.62a.84.84 0 00-.84-.84H8.77z" fill="#2684FF" />
        <path d="M6 7.56c0 2.4 1.97 4.35 4.35 4.35h1.78v1.7c0 2.4 1.97 4.35 4.35 4.35V8.4a.84.84 0 00-.84-.84H6z" fill="#2684FF" />
    </svg>
);

const ConfluenceIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M2.3 17.1c-.3.5-.6 1-.5 1.6.1.5.5.8 1 1l4.8 1.9c.5.2 1 .1 1.4-.2.4-.3.6-.8.5-1.3-.1-.3-.2-.6-.4-.9l-3.3-5.4c-.4-.7-1.3-.9-2-.5-.3.1-.5.4-.6.7l-.9 3.1z" fill="#0052CC" fillOpacity="0.8" />
        <path d="M21.7 6.9c.3-.5.6-1 .5-1.6-.1-.5-.5-.8-1-1L16.4 2.4c-.5-.2-1-.1-1.4.2-.4.3-.6.8-.5 1.3.1.3.2.6.4.9l3.3 5.4c.4.7 1.3.9 2 .5.3-.1.5-.4.6-.7l.9-3.1z" fill="#0052CC" />
    </svg>
);

const GraphIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="2" width="9" height="9" rx="1.5" fill="#F25022" />
        <rect x="13" y="2" width="9" height="9" rx="1.5" fill="#7FBA00" />
        <rect x="2" y="13" width="9" height="9" rx="1.5" fill="#00A4EF" />
        <rect x="13" y="13" width="9" height="9" rx="1.5" fill="#FFB900" />
    </svg>
);

const GitLabIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 21.35L18.27 15.3l1.18-3.63-2.36-7.26h-3.64L12 9.04l-1.45-4.63H6.91L4.55 11.67l1.18 3.63L12 21.35z" fill="#E24329" />
        <path d="M12 21.35l-6.27-6.05 1.18-3.63L12 21.35z" fill="#FC6D26" />
        <path d="M12 21.35l6.27-6.05-1.18-3.63L12 21.35z" fill="#FC6D26" />
    </svg>
);

const AzureDevOpsIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M3 7.5L9 4v16l-6-3.5v-9z" fill="#0078D4" />
        <path d="M21 6L9 4v4l8 2.5V18l4-2V6z" fill="#0078D4" />
        <path d="M9 8l8 2.5V18l-8-4V8z" fill="#005BA1" />
    </svg>
);

const DefaultToolIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M9.5 2.5L13.5 6.5L6 14H2V10L9.5 2.5Z" stroke="#999" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M11 4L12 5" stroke="#999" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
);

const InternalToolIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="8" cy="8" r="5.5" stroke="#26890D" strokeWidth="1.2" />
        <path d="M8 5.5V8L9.5 9.5" stroke="#26890D" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

const ReportIcon = ({ size = 14 }) => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 1h5.5L13 4.5V14a1 1 0 01-1 1H4a1 1 0 01-1-1V2a1 1 0 011-1z" stroke="#26890D" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M9 1v4h4" stroke="#26890D" strokeWidth="1.2" strokeLinejoin="round" />
        <path d="M5 8h6M5 10.5h4" stroke="#26890D" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
);

/**
 * Provider definitions. Each entry maps a tool name prefix to an icon
 * component and a display prefix used in the collapsed summary.
 *
 * To add a new integration (e.g. GitHub), add:
 *   { prefix: 'github_', icon: GitHubIcon, label: 'GitHub' }
 */
const TOOL_PROVIDERS = [
    { prefix: 'jira_', icon: JiraIcon, label: 'Jira' },
    { prefix: 'confluence_', icon: ConfluenceIcon, label: 'Confluence' },
    { prefix: 'graph_', icon: GraphIcon, label: 'Microsoft' },
    { prefix: 'outlook_', icon: GraphIcon, label: 'Outlook' },
    { prefix: 'onedrive_', icon: GraphIcon, label: 'OneDrive' },
    { prefix: 'teams_', icon: GraphIcon, label: 'Teams' },
    { prefix: 'sharepoint_', icon: GraphIcon, label: 'SharePoint' },
    { prefix: 'gitlab_', icon: GitLabIcon, label: 'GitLab' },
    { prefix: 'azdo_', icon: AzureDevOpsIcon, label: 'Azure DevOps' },
    { prefix: 'ado_', icon: AzureDevOpsIcon, label: 'Azure DevOps' },
];

/**
 * Internal tool icon overrides. Tools that aren't MCP-based but should
 * still have a distinct icon in the trace.
 */
const INTERNAL_TOOL_ICONS = {
    list_available_tools: InternalToolIcon,
    extract_document_text: InternalToolIcon,
    extract_all_documents: InternalToolIcon,
    save_project_structure: InternalToolIcon,
    load_project_structure: InternalToolIcon,
    get_project_status: InternalToolIcon,
    open_panel: InternalToolIcon,
    mark_items_deploying: InternalToolIcon,
    deploy_to_jira: JiraIcon,
    request_information: InternalToolIcon,
    render_report: ReportIcon,
    render_chart: ReportIcon,
    list_report_templates: InternalToolIcon,
    get_report_source: InternalToolIcon,
    compose_report: ReportIcon,
    render_dashboard: ReportIcon,
};

/**
 * Per-tool friendly labels. Shown instead of the raw tool name in the
 * trace UI. Falls back to formatName(toolName) if not listed here.
 */
const TOOL_LABELS = {
    // Jira
    jira_get_all_projects: 'Get Projects',
    jira_search: 'Search Issues',
    jira_get_issue: 'Get Issue Details',
    jira_get_project_issues: 'Project Issues',
    jira_get_agile_boards: 'Get Boards',
    jira_get_sprints_from_board: 'Get Sprints',
    jira_get_sprint_issues: 'Sprint Issues',
    jira_create_issue: 'Create Issue',
    jira_update_issue: 'Update Issue',
    jira_transition_issue: 'Transition Issue',
    jira_add_comment: 'Add Comment',
    jira_create_sprint: 'Create Sprint',
    jira_update_sprint: 'Update Sprint',
    jira_get_transitions: 'Get Transitions',
    jira_get_fields: 'Get Fields',
    jira_get_field_options: 'Get Field Options',
    jira_get_user: 'Get User',
    jira_search_users: 'Search Users',
    // Confluence
    confluence_search: 'Search Pages',
    confluence_get_page: 'Get Page',
    confluence_get_page_by_title: 'Get Page by Title',
    confluence_get_spaces: 'Get Spaces',
    confluence_get_space: 'Get Space',
    confluence_create_page: 'Create Page',
    confluence_update_page: 'Update Page',
    confluence_add_comment: 'Add Comment',
    confluence_get_attachments: 'Get Attachments',
    // Internal
    list_available_tools: 'Discovering Tools',
    call_mcp_tool: 'MCP Tool Call',
    extract_document_text: 'Extract Document',
    extract_all_documents: 'Extract All Documents',
    save_project_structure: 'Save Structure',
    load_project_structure: 'Load Structure',
    get_project_status: 'Project Status',
    open_panel: 'Open Panel',
    mark_items_deploying: 'Mark Deploying',
    deploy_to_jira: 'Deploy to Jira',
    request_information: 'Request Info',
    // Report tools
    render_report: 'Generate Report',
    render_chart: 'Render Chart',
    list_report_templates: 'List Templates',
    get_report_source: 'View Report Source',
    compose_report: 'Compose Report',
    render_dashboard: 'Render Dashboard',
};

// -- Public API -----------------------------------------------------------

/**
 * Get the icon component for a tool name.
 * Checks internal tools first, then prefix-based providers, then default.
 */
export function getToolIcon(toolName) {
    if (!toolName) return DefaultToolIcon;

    const InternalIcon = INTERNAL_TOOL_ICONS[toolName];
    if (InternalIcon) return InternalIcon;

    for (const provider of TOOL_PROVIDERS) {
        if (toolName.startsWith(provider.prefix)) {
            return provider.icon;
        }
    }

    return DefaultToolIcon;
}

/**
 * Get the friendly label for a tool name.
 * Returns the registered label or null (caller should fall back to formatName).
 */
export function getToolLabel(toolName) {
    return TOOL_LABELS[toolName] || null;
}

/**
 * Get the provider label for a tool name (e.g. "Jira", "Confluence").
 * Returns null if no provider matches.
 */
export function getToolProvider(toolName) {
    if (!toolName) return null;
    for (const provider of TOOL_PROVIDERS) {
        if (toolName.startsWith(provider.prefix)) {
            return provider.label;
        }
    }
    return null;
}

export { DefaultToolIcon, InternalToolIcon };
