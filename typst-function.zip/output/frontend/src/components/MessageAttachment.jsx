import React from 'react';
import { Box, Typography, IconButton } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

export default function MessageAttachment({ file, onOpenPanel }) {
    if (!file) return null;

    const { file_id, file_type, url, filename, pages } = file;

    const handleClick = () => {
        if (file_type === 'image') {
            onOpenPanel('image-viewer', { url, filename, file_id });
        } else if (file_type === 'pdf') {
            const panelData = { url, filename, file_id, pages };
            if (file.typst_url) {
                panelData.typstUrl = file.typst_url;
            }
            onOpenPanel('pdf-viewer', panelData);
        }
    };

    const handleDownload = (e) => {
        e.stopPropagation();
        const a = document.createElement('a');
        a.href = url + '?download=true';
        a.download = filename || 'download';
        a.click();
    };

    if (file_type === 'image') {
        return (
            <Box
                onClick={handleClick}
                sx={{
                    mt: 1.5,
                    cursor: 'pointer',
                    borderRadius: 2,
                    overflow: 'hidden',
                    border: '1px solid #E6E6E6',
                    position: 'relative',
                    '&:hover': { borderColor: '#26890D' },
                    '&:hover .download-btn': { opacity: 1 },
                }}
            >
                <img
                    src={url}
                    alt={filename || 'Chart'}
                    style={{
                        display: 'block',
                        maxWidth: 600,
                        width: '100%',
                        borderRadius: 8,
                    }}
                />
                <IconButton
                    className="download-btn"
                    onClick={handleDownload}
                    size="small"
                    sx={{
                        position: 'absolute',
                        top: 8,
                        right: 8,
                        bgcolor: 'rgba(255,255,255,0.9)',
                        opacity: 0,
                        transition: 'opacity 0.15s',
                        '&:hover': { bgcolor: 'white' },
                    }}
                >
                    <DownloadIcon sx={{ fontSize: 16 }} />
                </IconButton>
            </Box>
        );
    }

    if (file_type === 'pdf') {
        return (
            <Box
                onClick={handleClick}
                sx={{
                    mt: 1.5,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1.5,
                    p: 1.5,
                    border: '1px solid #E6E6E6',
                    borderRadius: 2,
                    cursor: 'pointer',
                    transition: 'all 0.15s',
                    '&:hover': { bgcolor: '#FAFAFA', borderColor: '#26890D' },
                }}
            >
                <PictureAsPdfIcon sx={{ fontSize: 32, color: '#DA291C' }} />
                <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography sx={{ fontSize: 13, fontWeight: 500, color: '#000' }}>
                        {filename || 'report.pdf'}
                    </Typography>
                    {pages != null && (
                        <Typography sx={{ fontSize: 11, color: '#97999B' }}>
                            {pages} {pages === 1 ? 'page' : 'pages'}
                        </Typography>
                    )}
                </Box>
                <IconButton onClick={handleDownload} size="small" sx={{ color: '#63666A' }}>
                    <DownloadIcon sx={{ fontSize: 18 }} />
                </IconButton>
            </Box>
        );
    }

    return null;
}
