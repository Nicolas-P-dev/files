import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Box, IconButton, Typography, TextField, Select, MenuItem, Tooltip } from '@mui/material';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import DownloadIcon from '@mui/icons-material/Download';
import CodeIcon from '@mui/icons-material/Code';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';

import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const ZOOM_OPTIONS = [
    { label: 'Fit Width', value: 'fit' },
    { label: '50%', value: 0.5 },
    { label: '75%', value: 0.75 },
    { label: '100%', value: 1.0 },
    { label: '125%', value: 1.25 },
    { label: '150%', value: 1.5 },
];

export default function PdfViewerPanel({ data }) {
    const [numPages, setNumPages] = useState(null);
    const [pageNumber, setPageNumber] = useState(1);
    const [zoom, setZoom] = useState('fit');
    const [containerWidth, setContainerWidth] = useState(null);
    const containerRef = useRef(null);

    if (!data?.url) {
        return (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                <Typography variant="body2" sx={{ color: '#63666A' }}>No PDF to display</Typography>
            </Box>
        );
    }

    const { url, filename } = data;

    const onDocumentLoadSuccess = useCallback(({ numPages: n }) => {
        setNumPages(n);
        setPageNumber(1);
    }, []);

    useEffect(() => {
        const el = containerRef.current;
        if (!el) return;
        const observer = new ResizeObserver(entries => {
            for (const entry of entries) {
                setContainerWidth(entry.contentRect.width);
            }
        });
        observer.observe(el);
        return () => observer.disconnect();
    }, []);

    const handleDownload = () => {
        const a = document.createElement('a');
        a.href = url + '?download=true';
        a.download = filename || 'report.pdf';
        a.click();
    };

    const handleDownloadTypst = () => {
        const a = document.createElement('a');
        a.href = data.typstUrl + '?download=true';
        a.download = filename ? filename.replace(/\.pdf$/, '.typ') : 'report.typ';
        a.click();
    };

    const goPrev = () => setPageNumber(p => Math.max(1, p - 1));
    const goNext = () => setPageNumber(p => Math.min(numPages || p, p + 1));

    const pageWidth = zoom === 'fit'
        ? (containerWidth ? containerWidth - 32 : undefined)
        : undefined;

    const pageScale = zoom !== 'fit' ? zoom : undefined;

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            {/* Toolbar */}
            <Box sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                px: 2,
                py: 1,
                borderBottom: '1px solid #E6E6E6',
                bgcolor: '#FAFAFA',
                flexShrink: 0,
                gap: 1,
            }}>
                {/* Page navigation */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <IconButton onClick={goPrev} disabled={pageNumber <= 1} size="small">
                        <NavigateBeforeIcon sx={{ fontSize: 20 }} />
                    </IconButton>
                    <TextField
                        value={pageNumber}
                        onChange={e => {
                            const v = parseInt(e.target.value, 10);
                            if (v >= 1 && v <= (numPages || 1)) setPageNumber(v);
                        }}
                        size="small"
                        type="number"
                        inputProps={{ min: 1, max: numPages || 1, style: { width: 36, textAlign: 'center', padding: '4px 0' } }}
                        sx={{ '& .MuiOutlinedInput-root': { height: 28 } }}
                    />
                    <Typography variant="body2" sx={{ color: '#63666A', whiteSpace: 'nowrap' }}>
                        of {numPages || '—'}
                    </Typography>
                    <IconButton onClick={goNext} disabled={pageNumber >= (numPages || 1)} size="small">
                        <NavigateNextIcon sx={{ fontSize: 20 }} />
                    </IconButton>
                </Box>

                {/* Zoom + download */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Select
                        value={zoom}
                        onChange={e => setZoom(e.target.value)}
                        size="small"
                        sx={{ height: 28, fontSize: '0.75rem', minWidth: 90 }}
                    >
                        {ZOOM_OPTIONS.map(z => (
                            <MenuItem key={z.value} value={z.value} sx={{ fontSize: '0.75rem' }}>
                                {z.label}
                            </MenuItem>
                        ))}
                    </Select>
                    {data.typstUrl && (
                        <Tooltip title="Download Typst Source">
                            <IconButton onClick={handleDownloadTypst} size="small" sx={{ color: '#63666A' }}>
                                <CodeIcon sx={{ fontSize: 18 }} />
                            </IconButton>
                        </Tooltip>
                    )}
                    <IconButton onClick={handleDownload} size="small" sx={{ color: '#63666A' }}>
                        <DownloadIcon sx={{ fontSize: 18 }} />
                    </IconButton>
                </Box>
            </Box>

            {/* PDF content */}
            <Box
                ref={containerRef}
                sx={{
                    flex: 1,
                    overflow: 'auto',
                    p: 2,
                    display: 'flex',
                    justifyContent: 'center',
                    bgcolor: '#F5F5F5',
                }}
            >
                <Document
                    file={url}
                    onLoadSuccess={onDocumentLoadSuccess}
                    loading={
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 8 }}>
                            <Typography variant="body2" sx={{ color: '#63666A' }}>Loading PDF…</Typography>
                        </Box>
                    }
                    error={
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 8 }}>
                            <Typography variant="body2" sx={{ color: '#DA291C' }}>Failed to load PDF</Typography>
                        </Box>
                    }
                >
                    <Page
                        pageNumber={pageNumber}
                        width={pageWidth}
                        scale={pageScale}
                        renderAnnotationLayer
                        renderTextLayer
                    />
                </Document>
            </Box>
        </Box>
    );
}
