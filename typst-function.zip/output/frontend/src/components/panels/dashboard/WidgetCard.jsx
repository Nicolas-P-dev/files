import React, { useState } from 'react';
import {
  Box,
  Card,
  Skeleton,
  Tooltip,
  Typography,
} from '@mui/material';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

const WidgetCard = ({ widget, baseUrl = '' }) => {
  const [loading, setLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  const hasError = Boolean(widget.error) || imageError;
  const errorMessage = widget.error || 'Failed to load widget image';

  const handleImageLoad = () => {
    setLoading(false);
  };

  const handleImageError = () => {
    setLoading(false);
    setImageError(true);
  };

  return (
    <Card
      elevation={0}
      sx={{
        position: 'relative',
        borderRadius: '8px',
        border: '1px solid #E6E6E6',
        backgroundColor: '#FFFFFF',
        overflow: 'hidden',
        transition: 'transform 0.2s ease, box-shadow 0.2s ease',
        cursor: 'default',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
        },
      }}
    >
      {/* Loading skeleton */}
      {loading && !hasError && (
        <Skeleton
          variant="rectangular"
          animation="wave"
          sx={{
            width: '100%',
            height: 200,
            bgcolor: '#F5F5F5',
          }}
        />
      )}

      {/* Error state */}
      {hasError && (
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            height: 200,
            backgroundColor: '#FFF5F5',
          }}
        >
          <Tooltip title={errorMessage} arrow placement="top">
            <ErrorOutlineIcon
              sx={{
                fontSize: 40,
                color: '#DA291C',
                cursor: 'help',
              }}
            />
          </Tooltip>
        </Box>
      )}

      {/* Widget image */}
      {!hasError && (
        <Box
          component="img"
          src={`${baseUrl}${widget.url}`}
          alt={widget.title || 'Dashboard widget'}
          onLoad={handleImageLoad}
          onError={handleImageError}
          sx={{
            display: loading ? 'none' : 'block',
            width: '100%',
            height: 'auto',
            objectFit: 'contain',
            opacity: loading ? 0 : 1,
            transition: 'opacity 0.3s ease',
          }}
        />
      )}

      {/* Title overlay */}
      {widget.title && (
        <Box
          sx={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            px: 1.5,
            py: 0.75,
            background: 'linear-gradient(transparent, rgba(0, 0, 0, 0.6))',
          }}
        >
          <Typography
            sx={{
              color: '#FFFFFF',
              fontSize: '11px',
              fontWeight: 500,
              lineHeight: 1.3,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {widget.title}
          </Typography>
        </Box>
      )}
    </Card>
  );
};

export default WidgetCard;
