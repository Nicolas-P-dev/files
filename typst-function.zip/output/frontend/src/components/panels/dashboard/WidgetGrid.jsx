import React from 'react';
import { Box, Typography } from '@mui/material';
import WidgetCard from './WidgetCard';

const WidgetGrid = ({ widgets = [], baseUrl = '' }) => {
  if (!widgets || widgets.length === 0) {
    return (
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 240,
          p: 4,
        }}
      >
        <Typography
          sx={{
            color: '#97999B',
            fontSize: '14px',
            fontWeight: 400,
          }}
        >
          No widgets to display
        </Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
        gap: '16px',
        p: 2,
      }}
    >
      {widgets.map((widget) => (
        <WidgetCard
          key={widget.widget_id || widget.file_id || `widget-${widgets.indexOf(widget)}`}
          widget={widget}
          baseUrl={baseUrl}
        />
      ))}
    </Box>
  );
};

export default WidgetGrid;
