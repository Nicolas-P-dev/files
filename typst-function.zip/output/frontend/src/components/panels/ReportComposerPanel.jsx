import React, { useReducer, useCallback, useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  IconButton,
  Collapse,
  Alert,
  CircularProgress,
  Divider,
} from '@mui/material';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import CloseIcon from '@mui/icons-material/Close';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import SectionPalette, { SECTION_TYPES, getIconComponent } from './composer/SectionPalette';
import SectionOutline from './composer/SectionOutline';
import SectionConfig from './composer/SectionConfig';

/* ------------------------------------------------------------------ */
/*  State management                                                   */
/* ------------------------------------------------------------------ */

const initialState = {
  sections: [],
  metadata: { title: '', subtitle: '', author: '', date: '' },
  configOpen: false,
  configSectionId: null,
  generating: false,
  error: null,
};

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_SECTION': {
      const sectionType = SECTION_TYPES.find((s) => s.type === action.sectionType);
      if (!sectionType) return state;
      const newSection = {
        id: crypto.randomUUID(),
        type: sectionType.type,
        title: sectionType.label,
        icon: sectionType.icon,
        data: {},
      };
      return { ...state, sections: [...state.sections, newSection] };
    }

    case 'REMOVE_SECTION':
      return {
        ...state,
        sections: state.sections.filter((s) => s.id !== action.id),
        configOpen: state.configSectionId === action.id ? false : state.configOpen,
        configSectionId: state.configSectionId === action.id ? null : state.configSectionId,
      };

    case 'REORDER': {
      const { fromIndex, toIndex } = action;
      const updated = [...state.sections];
      const [moved] = updated.splice(fromIndex, 1);
      updated.splice(toIndex, 0, moved);
      return { ...state, sections: updated };
    }

    case 'UPDATE_TITLE':
      return {
        ...state,
        sections: state.sections.map((s) =>
          s.id === action.id ? { ...s, title: action.title } : s
        ),
      };

    case 'UPDATE_SECTION_DATA':
      return {
        ...state,
        sections: state.sections.map((s) =>
          s.id === action.id ? { ...s, data: action.data } : s
        ),
      };

    case 'SET_METADATA':
      return { ...state, metadata: { ...state.metadata, [action.field]: action.value } };

    case 'SET_GENERATING':
      return { ...state, generating: action.value, error: null };

    case 'SET_ERROR':
      return { ...state, error: action.error, generating: false };

    case 'OPEN_CONFIG':
      return { ...state, configOpen: true, configSectionId: action.id };

    case 'CLOSE_CONFIG':
      return { ...state, configOpen: false, configSectionId: null };

    default:
      return state;
  }
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function ReportComposerPanel({ data, onOpenPanel }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { sections, metadata, configOpen, configSectionId, generating, error } = state;
  const [metadataExpanded, setMetadataExpanded] = useState(true);

  const sessionId = data?.sessionId || 'default';
  const configSection = sections.find((s) => s.id === configSectionId) || null;

  /* --- callbacks -------------------------------------------------- */

  const handleAddSection = useCallback((section) => {
    dispatch({ type: 'ADD_SECTION', sectionType: section.type });
  }, []);

  const handleRemove = useCallback((id) => {
    dispatch({ type: 'REMOVE_SECTION', id });
  }, []);

  const handleReorder = useCallback((fromIndex, toIndex) => {
    dispatch({ type: 'REORDER', fromIndex, toIndex });
  }, []);

  const handleUpdateTitle = useCallback((id, title) => {
    dispatch({ type: 'UPDATE_TITLE', id, title });
  }, []);

  const handleEdit = useCallback((id) => {
    dispatch({ type: 'OPEN_CONFIG', id });
  }, []);

  const handleConfigClose = useCallback(() => {
    dispatch({ type: 'CLOSE_CONFIG' });
  }, []);

  const handleConfigSave = useCallback((id, sectionData) => {
    dispatch({ type: 'UPDATE_SECTION_DATA', id, data: sectionData });
    dispatch({ type: 'CLOSE_CONFIG' });
  }, []);

  const handleMetadataChange = useCallback((field) => (e) => {
    dispatch({ type: 'SET_METADATA', field, value: e.target.value });
  }, []);

  const handleDismissError = useCallback(() => {
    dispatch({ type: 'SET_ERROR', error: null });
  }, []);

  const handleClose = useCallback(() => {
    if (onOpenPanel) {
      onOpenPanel(null);
    }
  }, [onOpenPanel]);

  /* --- generate report -------------------------------------------- */

  const handleGenerate = async () => {
    if (sections.length === 0) {
      dispatch({
        type: 'SET_ERROR',
        error: 'Add at least one section to generate a report.',
      });
      return;
    }

    dispatch({ type: 'SET_GENERATING', value: true });

    try {
      const sectionsPayload = sections.map((s) => ({
        id: s.id,
        type: s.type,
        title: s.title,
        icon: s.icon,
        data: s.data,
      }));

      const response = await fetch(
        `/api/sessions/${sessionId}/tools/compose_report`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            args: {
              sections: JSON.stringify(sectionsPayload),
              title: metadata.title,
              subtitle: metadata.subtitle,
              author: metadata.author,
              date: metadata.date,
            },
          }),
        }
      );

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText || `Server error (${response.status})`);
      }

      const result = await response.json();
      dispatch({ type: 'SET_GENERATING', value: false });

      if (onOpenPanel) {
        onOpenPanel('pdf-viewer', {
          url: result.url,
          filename: result.filename,
          typstUrl: result.typst_url,
        });
      }
    } catch (err) {
      dispatch({
        type: 'SET_ERROR',
        error: err.message || 'Failed to generate report.',
      });
    }
  };

  /* --- render ----------------------------------------------------- */

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        bgcolor: '#FFFFFF',
      }}
    >
      {/* ── Header ─────────────────────────────────────────────── */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          px: 2,
          py: 1.5,
          bgcolor: '#046A38',
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <MenuBookIcon sx={{ color: '#FFFFFF', fontSize: 20 }} />
          <Typography
            sx={{
              fontSize: 16,
              fontWeight: 700,
              color: '#FFFFFF',
              letterSpacing: '-0.2px',
            }}
          >
            Report Composer
          </Typography>
        </Box>
        <IconButton
          size="small"
          onClick={handleClose}
          sx={{
            color: '#FFFFFF',
            '&:hover': { bgcolor: 'rgba(255,255,255,0.15)' },
          }}
        >
          <CloseIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </Box>

      {/* ── Scrollable middle area ─────────────────────────────── */}
      <Box sx={{ flex: 1, overflow: 'auto' }}>
        {/* ── Metadata form ──────────────────────────────────── */}
        <Box sx={{ bgcolor: '#FAFAFA', borderBottom: '1px solid #E6E6E6' }}>
          <Box
            onClick={() => setMetadataExpanded((prev) => !prev)}
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              px: 2,
              py: 1,
              cursor: 'pointer',
              userSelect: 'none',
              transition: 'background-color 0.2s ease',
              '&:hover': { bgcolor: '#F0F0F0' },
            }}
          >
            <Typography
              sx={{
                fontSize: 12,
                fontWeight: 600,
                color: '#53565A',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
              }}
            >
              Report Metadata
            </Typography>
            <IconButton size="small" sx={{ color: '#97999B', p: 0.25 }}>
              {metadataExpanded ? (
                <KeyboardArrowUpIcon sx={{ fontSize: 18 }} />
              ) : (
                <KeyboardArrowDownIcon sx={{ fontSize: 18 }} />
              )}
            </IconButton>
          </Box>
          <Collapse in={metadataExpanded} timeout={200}>
            <Box
              sx={{
                px: 2,
                pb: 2,
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: 1.5,
              }}
            >
              <TextField
                label="Title"
                value={metadata.title}
                onChange={handleMetadataChange('title')}
                size="small"
                fullWidth
                sx={textFieldSx}
              />
              <TextField
                label="Subtitle"
                value={metadata.subtitle}
                onChange={handleMetadataChange('subtitle')}
                size="small"
                fullWidth
                sx={textFieldSx}
              />
              <TextField
                label="Author"
                value={metadata.author}
                onChange={handleMetadataChange('author')}
                size="small"
                fullWidth
                sx={textFieldSx}
              />
              <TextField
                label="Date"
                value={metadata.date}
                onChange={handleMetadataChange('date')}
                size="small"
                fullWidth
                sx={textFieldSx}
              />
            </Box>
          </Collapse>
        </Box>

        {/* ── Section Palette ────────────────────────────────── */}
        <Box sx={{ borderBottom: '1px solid #E6E6E6' }}>
          <SectionPalette onAddSection={handleAddSection} />
        </Box>

        {/* ── Divider: REPORT OUTLINE ────────────────────────── */}
        <Divider
          sx={{
            '&::before, &::after': { borderColor: '#E6E6E6' },
          }}
        >
          <Typography
            sx={{
              fontSize: 11,
              fontWeight: 600,
              color: '#53565A',
              textTransform: 'uppercase',
              letterSpacing: '0.8px',
              px: 1.5,
            }}
          >
            Report Outline
            {sections.length > 0 && (
              <Typography
                component="span"
                sx={{
                  fontSize: 11,
                  color: '#97999B',
                  fontWeight: 400,
                  ml: 0.75,
                }}
              >
                ({sections.length})
              </Typography>
            )}
          </Typography>
        </Divider>

        {/* ── Section Outline ────────────────────────────────── */}
        <Box
          sx={{
            '& > *': {
              transition: 'all 0.2s ease',
            },
          }}
        >
          <SectionOutline
            sections={sections}
            onReorder={handleReorder}
            onRemove={handleRemove}
            onEdit={handleEdit}
            onUpdateTitle={handleUpdateTitle}
          />
        </Box>
      </Box>

      {/* ── Fixed bottom bar ───────────────────────────────────── */}
      <Box
        sx={{
          p: 2,
          borderTop: '1px solid #E6E6E6',
          bgcolor: '#FAFAFA',
          flexShrink: 0,
        }}
      >
        {error && (
          <Alert
            severity="error"
            onClose={handleDismissError}
            sx={{
              mb: 1.5,
              '& .MuiAlert-message': { fontSize: 13 },
            }}
          >
            {error}
          </Alert>
        )}
        <Button
          variant="contained"
          fullWidth
          onClick={handleGenerate}
          disabled={generating || sections.length === 0}
          sx={{
            textTransform: 'none',
            fontWeight: 600,
            fontSize: 14,
            py: 1.25,
            bgcolor: '#86BC25',
            color: '#FFFFFF',
            '&:hover': { bgcolor: '#75a821' },
            '&.Mui-disabled': { bgcolor: '#BBBCBC', color: '#FFFFFF' },
            transition: 'background-color 0.2s ease',
            boxShadow: 'none',
            '&:active': { boxShadow: 'none' },
          }}
        >
          {generating ? (
            <>
              <CircularProgress
                size={16}
                sx={{ color: '#FFFFFF', mr: 1 }}
              />
              Generating...
            </>
          ) : (
            'Generate Report'
          )}
        </Button>
      </Box>

      {/* ── Section Config Drawer ──────────────────────────────── */}
      <SectionConfig
        open={configOpen}
        section={configSection}
        onClose={handleConfigClose}
        onSave={handleConfigSave}
      />
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Shared styles                                                      */
/* ------------------------------------------------------------------ */

const textFieldSx = {
  '& .MuiInputBase-root': {
    fontSize: 13,
    bgcolor: '#FFFFFF',
  },
  '& .MuiInputLabel-root': {
    fontSize: 13,
    color: '#97999B',
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': { borderColor: '#E6E6E6' },
    '&:hover fieldset': { borderColor: '#BBBCBC' },
    '&.Mui-focused fieldset': { borderColor: '#046A38' },
  },
};
