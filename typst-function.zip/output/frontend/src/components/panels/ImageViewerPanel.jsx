import React, { useState } from 'react';
import { Box, IconButton, ToggleButtonGroup, ToggleButton, Typography } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import FitScreenIcon from '@mui/icons-material/FitScreen';

const ZOOM_LEVELS = [
    { label: 'Fit', value: 'fit' },
    { label: '100%', value: 100 },
    { label: '150%', value: 150 },
    { label: '200%', value: 200 },
];

export default function ImageViewerPanel({ data }) {
    const [zoom, setZoom] = useState('fit');

    if (!data?.url) {
        return (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
                <Typography variant="body2" sx={{ color: '#63666A' }}>No image to display</Typography>
            </Box>
        );
    }

    const { url, filename } = data;

    const handleDownload = () => {
        const a = document.createElement('a');
        a.href = url + '?download=true';
        a.download = filename || 'chart.png';
        a.click();
    };

    const imgStyle = zoom === 'fit'
        ? { width: '100%', height: 'auto', display: 'block' }
        : { width: `${zoom}%`, height: 'auto', display: 'block' };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            {/* Toolbar */}
            <Box sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                px: 2,
                py: 1,
                borderBottom: '1px solid #E6E6E6',
                bgcolor: '#FAFAFA',
                flexShrink: 0,
            }}>
                <Typography variant="body2" sx={{ color: '#53565A', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', mr: 2 }}>
                    {filename || 'Image'}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ToggleButtonGroup
                        value={zoom}
                        exclusive
                        onChange={(_, val) => { if (val !== null) setZoom(val); }}
                        size="small"
                    >
                        {ZOOM_LEVELS.map(z => (
                            <ToggleButton
                                key={z.value}
                                value={z.value}
                                sx={{
                                    px: 1.5,
                                    py: 0.5,
                                    fontSize: '0.7rem',
                                    textTransform: 'none',
                                    '&.Mui-selected': { bgcolor: 'rgba(38,137,13,0.1)', color: '#26890D' },
                                }}
                            >
                                {z.value === 'fit' ? <FitScreenIcon sx={{ fontSize: 16 }} /> : z.label}
                            </ToggleButton>
                        ))}
                    </ToggleButtonGroup>
                    <IconButton onClick={handleDownload} size="small" sx={{ color: '#63666A' }}>
                        <DownloadIcon sx={{ fontSize: 18 }} />
                    </IconButton>
                </Box>
            </Box>

            {/* Image area */}
            <Box sx={{ flex: 1, overflow: 'auto', p: 2, display: 'flex', justifyContent: 'center' }}>
                <img src={url} alt={filename || 'Chart'} style={imgStyle} />
            </Box>
        </Box>
    );
}
