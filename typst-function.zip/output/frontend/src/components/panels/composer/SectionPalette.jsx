import React from 'react';
import { Box, Typography } from '@mui/material';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import DashboardIcon from '@mui/icons-material/Dashboard';
import BarChartIcon from '@mui/icons-material/BarChart';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import PieChartIcon from '@mui/icons-material/PieChart';
import TrendingDownIcon from '@mui/icons-material/TrendingDown';
import SpeedIcon from '@mui/icons-material/Speed';
import RadarIcon from '@mui/icons-material/Radar';
import StackedLineChartIcon from '@mui/icons-material/StackedLineChart';
import WaterfallChartIcon from '@mui/icons-material/WaterfallChart';
import GridOnIcon from '@mui/icons-material/GridOn';
import ViewTimelineIcon from '@mui/icons-material/ViewTimeline';
import TableChartIcon from '@mui/icons-material/TableChart';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import NotesIcon from '@mui/icons-material/Notes';

const ICON_MAP = {
  MenuBook: MenuBookIcon,
  Dashboard: DashboardIcon,
  BarChart: BarChartIcon,
  ShowChart: ShowChartIcon,
  PieChart: PieChartIcon,
  TrendingDown: TrendingDownIcon,
  Speed: SpeedIcon,
  Radar: RadarIcon,
  StackedLineChart: StackedLineChartIcon,
  Waterfall: WaterfallChartIcon,
  GridOn: GridOnIcon,
  ViewTimeline: ViewTimelineIcon,
  TableChart: TableChartIcon,
  Lightbulb: LightbulbIcon,
  Notes: NotesIcon,
};

export const SECTION_TYPES = [
  { type: 'cover-page', label: 'Cover Page', icon: 'MenuBook', category: 'Layout' },
  { type: 'kpi-row', label: 'KPI Cards', icon: 'Dashboard', category: 'Metrics' },
  { type: 'bar-chart', label: 'Bar Chart', icon: 'BarChart', category: 'Charts' },
  { type: 'grouped-bar-chart', label: 'Grouped Bar', icon: 'BarChart', category: 'Charts' },
  { type: 'line-chart', label: 'Line Chart', icon: 'ShowChart', category: 'Charts' },
  { type: 'pie-chart', label: 'Pie Chart', icon: 'PieChart', category: 'Charts' },
  { type: 'burndown-chart', label: 'Burndown', icon: 'TrendingDown', category: 'Charts' },
  { type: 'velocity-chart', label: 'Velocity', icon: 'Speed', category: 'Charts' },
  { type: 'radar-chart', label: 'Radar', icon: 'Radar', category: 'Charts' },
  { type: 'gauge-chart', label: 'Gauge', icon: 'Speed', category: 'Charts' },
  { type: 'cfd-chart', label: 'Cumulative Flow', icon: 'StackedLineChart', category: 'Charts' },
  { type: 'waterfall-chart', label: 'Waterfall', icon: 'Waterfall', category: 'Charts' },
  { type: 'risk-matrix', label: 'Risk Matrix', icon: 'GridOn', category: 'Risk' },
  { type: 'gantt-chart', label: 'Gantt', icon: 'ViewTimeline', category: 'Timeline' },
  { type: 'data-table', label: 'Data Table', icon: 'TableChart', category: 'Tables' },
  { type: 'key-takeaways', label: 'Key Takeaways', icon: 'Lightbulb', category: 'Narrative' },
  { type: 'text-section', label: 'Text Section', icon: 'Notes', category: 'Narrative' },
];

export function getIconComponent(iconName) {
  return ICON_MAP[iconName] || NotesIcon;
}

export default function SectionPalette({ onAddSection }) {
  // Group sections by category
  const grouped = SECTION_TYPES.reduce((acc, sec) => {
    if (!acc[sec.category]) acc[sec.category] = [];
    acc[sec.category].push(sec);
    return acc;
  }, {});

  const handleClick = (sec) => {
    onAddSection({ type: sec.type, title: sec.label, data: {} });
  };

  return (
    <Box sx={{ px: 1.5, py: 1 }}>
      {Object.entries(grouped).map(([category, items]) => (
        <Box key={category} sx={{ mb: 1.5 }}>
          <Typography
            sx={{
              fontSize: 10,
              fontWeight: 600,
              textTransform: 'uppercase',
              color: '#97999B',
              letterSpacing: '0.5px',
              mb: 0.5,
            }}
          >
            {category}
          </Typography>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '6px',
            }}
          >
            {items.map((sec) => {
              const IconComp = ICON_MAP[sec.icon] || NotesIcon;
              return (
                <Box
                  key={sec.type}
                  onClick={() => handleClick(sec)}
                  sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    bgcolor: '#fff',
                    border: '1px solid #E6E6E6',
                    borderRadius: '6px',
                    p: 1,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      borderColor: '#86BC25',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                    },
                  }}
                >
                  <IconComp sx={{ fontSize: 20, color: '#53565A', mb: 0.5 }} />
                  <Typography
                    sx={{
                      fontSize: 10,
                      color: '#53565A',
                      textAlign: 'center',
                      lineHeight: 1.2,
                      fontWeight: 500,
                    }}
                  >
                    {sec.label}
                  </Typography>
                </Box>
              );
            })}
          </Box>
        </Box>
      ))}
    </Box>
  );
}
