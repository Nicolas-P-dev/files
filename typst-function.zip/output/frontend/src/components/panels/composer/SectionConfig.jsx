import React, { useState, useEffect } from 'react';
import {
  Drawer,
  Box,
  Typography,
  TextField,
  Button,
  IconButton,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { getIconComponent } from './SectionPalette';
import { SECTION_TYPES } from './SectionPalette';

const JSON_PLACEHOLDERS = {
  'bar-chart': `{
  "labels": ["Sprint 1", "Sprint 2", "Sprint 3"],
  "values": [12, 19, 8],
  "xlabel": "Sprint",
  "ylabel": "Story Points"
}`,
  'grouped-bar-chart': `{
  "labels": ["Q1", "Q2", "Q3"],
  "series": [
    { "name": "Plan", "values": [10, 15, 12] },
    { "name": "Actual", "values": [8, 14, 13] }
  ]
}`,
  'line-chart': `{
  "labels": ["Jan", "Feb", "Mar", "Apr"],
  "series": [
    { "name": "Velocity", "values": [20, 25, 22, 30] }
  ]
}`,
  'pie-chart': `{
  "labels": ["Done", "In Progress", "To Do"],
  "values": [45, 30, 25]
}`,
  'burndown-chart': `{
  "labels": ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5"],
  "ideal": [50, 40, 30, 20, 10],
  "actual": [50, 42, 35, 28, 15]
}`,
  'velocity-chart': `{
  "sprints": ["Sprint 1", "Sprint 2", "Sprint 3"],
  "committed": [30, 35, 28],
  "completed": [25, 33, 28]
}`,
  'radar-chart': `{
  "axes": ["Quality", "Speed", "Cost", "Scope", "Risk"],
  "series": [
    { "name": "Current", "values": [4, 3, 2, 5, 3] },
    { "name": "Target", "values": [5, 4, 3, 4, 2] }
  ]
}`,
  'cfd-chart': `{
  "dates": ["Week 1", "Week 2", "Week 3"],
  "series": [
    { "name": "Done", "values": [5, 15, 30] },
    { "name": "In Progress", "values": [10, 12, 8] },
    { "name": "To Do", "values": [35, 23, 12] }
  ]
}`,
  'waterfall-chart': `{
  "labels": ["Start", "Revenue", "Costs", "Tax", "End"],
  "values": [100, 50, -30, -10, 110],
  "types": ["total", "increase", "decrease", "decrease", "total"]
}`,
  'gantt-chart': `{
  "tasks": [
    { "name": "Planning", "start": "2025-01-01", "end": "2025-01-15", "progress": 100 },
    { "name": "Development", "start": "2025-01-10", "end": "2025-02-15", "progress": 60 },
    { "name": "Testing", "start": "2025-02-10", "end": "2025-03-01", "progress": 20 }
  ]
}`,
  'risk-matrix': `{
  "risks": [
    { "name": "Data breach", "likelihood": 3, "impact": 5, "category": "Security" },
    { "name": "Scope creep", "likelihood": 4, "impact": 3, "category": "Project" },
    { "name": "Key staff leave", "likelihood": 2, "impact": 4, "category": "Resource" }
  ]
}`,
  'data-table': `Headers (comma-separated) and rows provided separately below.`,
};

function KpiConfig({ data, onChange }) {
  const cards = data.cards || [];

  const addCard = () => {
    onChange({
      ...data,
      cards: [...cards, { label: '', value: '', trend: 0, color: 'auto' }],
    });
  };

  const updateCard = (index, field, value) => {
    const updated = cards.map((c, i) =>
      i === index ? { ...c, [field]: value } : c
    );
    onChange({ ...data, cards: updated });
  };

  const removeCard = (index) => {
    onChange({ ...data, cards: cards.filter((_, i) => i !== index) });
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {cards.map((card, i) => (
        <Box
          key={i}
          sx={{
            p: 1.5,
            border: '1px solid #E6E6E6',
            borderRadius: '6px',
            bgcolor: '#fff',
            position: 'relative',
          }}
        >
          <IconButton
            onClick={() => removeCard(i)}
            size="small"
            sx={{ position: 'absolute', top: 4, right: 4, color: '#97999B', '&:hover': { color: '#DA291C' } }}
          >
            <DeleteOutlineIcon sx={{ fontSize: 14 }} />
          </IconButton>
          <Typography sx={{ fontSize: 10, color: '#97999B', mb: 1, fontWeight: 600 }}>
            KPI Card {i + 1}
          </Typography>
          <TextField
            label="Label"
            value={card.label}
            onChange={(e) => updateCard(i, 'label', e.target.value)}
            size="small"
            fullWidth
            sx={{ mb: 1 }}
          />
          <TextField
            label="Value"
            value={card.value}
            onChange={(e) => updateCard(i, 'value', e.target.value)}
            size="small"
            fullWidth
            sx={{ mb: 1 }}
          />
          <Box sx={{ display: 'flex', gap: 1 }}>
            <TextField
              label="Trend (%)"
              value={card.trend}
              onChange={(e) => updateCard(i, 'trend', e.target.value)}
              size="small"
              type="number"
              sx={{ flex: 1 }}
            />
            <FormControl size="small" sx={{ flex: 1 }}>
              <InputLabel>Color</InputLabel>
              <Select
                value={card.color}
                label="Color"
                onChange={(e) => updateCard(i, 'color', e.target.value)}
              >
                <MenuItem value="auto">Auto</MenuItem>
                <MenuItem value="green">Green</MenuItem>
                <MenuItem value="orange">Orange</MenuItem>
                <MenuItem value="red">Red</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </Box>
      ))}
      <Button
        startIcon={<AddIcon />}
        onClick={addCard}
        size="small"
        sx={{ color: '#046A38', textTransform: 'none', alignSelf: 'flex-start' }}
      >
        Add KPI Card
      </Button>
    </Box>
  );
}

function GaugeConfig({ data, onChange }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
      <TextField
        label="Label"
        value={data.label || ''}
        onChange={(e) => onChange({ ...data, label: e.target.value })}
        size="small"
        fullWidth
      />
      <TextField
        label="Value"
        value={data.value ?? ''}
        onChange={(e) => onChange({ ...data, value: parseFloat(e.target.value) || 0 })}
        size="small"
        type="number"
        fullWidth
      />
      <TextField
        label="Max"
        value={data.max ?? ''}
        onChange={(e) => onChange({ ...data, max: parseFloat(e.target.value) || 100 })}
        size="small"
        type="number"
        fullWidth
      />
    </Box>
  );
}

function DataTableConfig({ data, onChange }) {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
      <TextField
        label="Headers (comma-separated)"
        value={data.headers || ''}
        onChange={(e) => onChange({ ...data, headers: e.target.value })}
        size="small"
        fullWidth
        placeholder="Name, Status, Priority, Owner"
      />
      <TextField
        label="Rows (JSON array of arrays)"
        value={data.rows || ''}
        onChange={(e) => onChange({ ...data, rows: e.target.value })}
        size="small"
        fullWidth
        multiline
        minRows={4}
        placeholder={`[
  ["Task A", "Done", "High", "Alice"],
  ["Task B", "In Progress", "Medium", "Bob"]
]`}
        inputProps={{ style: { fontFamily: 'Consolas, monospace', fontSize: 12 } }}
      />
    </Box>
  );
}

function TextConfig({ data, onChange, label, placeholder }) {
  return (
    <TextField
      label={label}
      value={data.content || ''}
      onChange={(e) => onChange({ ...data, content: e.target.value })}
      size="small"
      fullWidth
      multiline
      minRows={6}
      placeholder={placeholder}
    />
  );
}

function JsonConfig({ data, onChange, placeholder }) {
  const [jsonStr, setJsonStr] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      try {
        setJsonStr(JSON.stringify(data, null, 2));
      } catch {
        setJsonStr('');
      }
    }
  }, [data]);

  const handleBlur = () => {
    if (!jsonStr.trim()) {
      setError('');
      onChange({});
      return;
    }
    try {
      const parsed = JSON.parse(jsonStr);
      setError('');
      onChange(parsed);
    } catch (e) {
      setError('Invalid JSON: ' + e.message);
    }
  };

  return (
    <TextField
      label="Data (JSON)"
      value={jsonStr}
      onChange={(e) => setJsonStr(e.target.value)}
      onBlur={handleBlur}
      size="small"
      fullWidth
      multiline
      minRows={8}
      placeholder={placeholder}
      error={!!error}
      helperText={error}
      inputProps={{ style: { fontFamily: 'Consolas, monospace', fontSize: 12 } }}
    />
  );
}

function renderConfigBody(section, localData, setLocalData) {
  const sectionType = section?.type;

  switch (sectionType) {
    case 'cover-page':
      return (
        <Typography sx={{ fontSize: 13, color: '#97999B', fontStyle: 'italic' }}>
          This section uses the report metadata (title, subtitle, author, date). No additional configuration needed.
        </Typography>
      );

    case 'kpi-row':
      return <KpiConfig data={localData} onChange={setLocalData} />;

    case 'gauge-chart':
      return <GaugeConfig data={localData} onChange={setLocalData} />;

    case 'data-table':
      return <DataTableConfig data={localData} onChange={setLocalData} />;

    case 'key-takeaways':
      return (
        <TextConfig
          data={localData}
          onChange={setLocalData}
          label="Key Takeaways"
          placeholder="Enter one takeaway per line:&#10;&#10;Project is on track for Q2 delivery&#10;Budget utilisation at 78%&#10;3 critical risks require mitigation"
        />
      );

    case 'text-section':
      return (
        <TextConfig
          data={localData}
          onChange={setLocalData}
          label="Content"
          placeholder="Enter the text content for this section..."
        />
      );

    default:
      return (
        <JsonConfig
          data={localData}
          onChange={setLocalData}
          placeholder={JSON_PLACEHOLDERS[sectionType] || '{\n  \n}'}
        />
      );
  }
}

export default function SectionConfig({ open, section, onClose, onSave }) {
  const [localData, setLocalData] = useState({});

  useEffect(() => {
    if (section) {
      setLocalData(section.data ? { ...section.data } : {});
    }
  }, [section]);

  const handleApply = () => {
    if (!section) return;
    onSave(section.id, localData);
  };

  const sectionMeta = SECTION_TYPES.find((s) => s.type === section?.type);
  const IconComp = getIconComponent(sectionMeta?.icon || '');

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      sx={{
        '& .MuiDrawer-paper': {
          width: 380,
          display: 'flex',
          flexDirection: 'column',
        },
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1.5,
          px: 2,
          py: 1.5,
          bgcolor: '#046A38',
          color: '#fff',
          flexShrink: 0,
        }}
      >
        <IconComp sx={{ fontSize: 20 }} />
        <Typography sx={{ fontSize: 14, fontWeight: 600, flex: 1 }}>
          {sectionMeta?.label || 'Configure Section'}
        </Typography>
        <IconButton onClick={onClose} size="small" sx={{ color: '#fff' }}>
          <CloseIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </Box>

      {/* Body */}
      <Box
        sx={{
          flex: 1,
          overflow: 'auto',
          p: 2,
          bgcolor: '#FAFAFA',
        }}
      >
        {section && renderConfigBody(section, localData, setLocalData)}
      </Box>

      {/* Footer */}
      <Box
        sx={{
          display: 'flex',
          gap: 1,
          p: 2,
          borderTop: '1px solid #E6E6E6',
          flexShrink: 0,
        }}
      >
        <Button
          variant="outlined"
          onClick={onClose}
          fullWidth
          sx={{
            textTransform: 'none',
            color: '#53565A',
            borderColor: '#BBBCBC',
            '&:hover': { borderColor: '#97999B', bgcolor: '#F5F5F5' },
          }}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleApply}
          fullWidth
          sx={{
            textTransform: 'none',
            bgcolor: '#86BC25',
            color: '#fff',
            '&:hover': { bgcolor: '#75a821' },
          }}
        >
          Apply
        </Button>
      </Box>
    </Drawer>
  );
}
