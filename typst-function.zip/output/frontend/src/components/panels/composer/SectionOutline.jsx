import React, { useState, useRef } from 'react';
import { Box, Typography, IconButton, TextField } from '@mui/material';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import SettingsIcon from '@mui/icons-material/Settings';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { getIconComponent } from './SectionPalette';

export default function SectionOutline({ sections, onReorder, onRemove, onEdit, onUpdateTitle }) {
  const [dragIndex, setDragIndex] = useState(null);
  const [dropTarget, setDropTarget] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState('');
  const dragItem = useRef(null);

  if (!sections || sections.length === 0) {
    return (
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          py: 6,
          px: 3,
        }}
      >
        <Typography
          variant="body2"
          sx={{ color: '#97999B', textAlign: 'center', fontSize: 12, lineHeight: 1.6 }}
        >
          Add sections from the palette above to build your report
        </Typography>
      </Box>
    );
  }

  const handleDragStart = (e, index) => {
    dragItem.current = index;
    setDragIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDropTarget(index);
  };

  const handleDragLeave = () => {
    setDropTarget(null);
  };

  const handleDrop = (e, toIndex) => {
    e.preventDefault();
    const fromIndex = dragItem.current;
    if (fromIndex !== null && fromIndex !== toIndex) {
      onReorder(fromIndex, toIndex);
    }
    setDragIndex(null);
    setDropTarget(null);
    dragItem.current = null;
  };

  const handleDragEnd = () => {
    setDragIndex(null);
    setDropTarget(null);
    dragItem.current = null;
  };

  const startEditing = (section) => {
    setEditingId(section.id);
    setEditValue(section.title);
  };

  const finishEditing = (id) => {
    if (editValue.trim()) {
      onUpdateTitle(id, editValue.trim());
    }
    setEditingId(null);
    setEditValue('');
  };

  const handleEditKeyDown = (e, id) => {
    if (e.key === 'Enter') {
      finishEditing(id);
    } else if (e.key === 'Escape') {
      setEditingId(null);
      setEditValue('');
    }
  };

  return (
    <Box sx={{ px: 1.5, py: 1 }}>
      {sections.map((section, index) => {
        const IconComp = getIconComponent(section.icon || '');
        const isDragging = dragIndex === index;
        const isDropTarget = dropTarget === index;

        return (
          <Box
            key={section.id}
            draggable
            onDragStart={(e) => handleDragStart(e, index)}
            onDragOver={(e) => handleDragOver(e, index)}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, index)}
            onDragEnd={handleDragEnd}
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 0.5,
              bgcolor: index % 2 === 0 ? '#fff' : '#FCFCFC',
              border: '1px solid #E6E6E6',
              borderRadius: '6px',
              p: 1,
              mb: 0.5,
              opacity: isDragging ? 0.5 : 1,
              borderTop: isDropTarget ? '2px solid #86BC25' : '2px solid transparent',
              transition: 'opacity 0.2s ease, border-color 0.2s ease',
              cursor: 'grab',
              '&:active': { cursor: 'grabbing' },
            }}
          >
            <DragIndicatorIcon sx={{ fontSize: 16, color: '#BBBCBC', flexShrink: 0 }} />
            <IconComp sx={{ fontSize: 16, color: '#97999B', flexShrink: 0 }} />

            {editingId === section.id ? (
              <TextField
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onBlur={() => finishEditing(section.id)}
                onKeyDown={(e) => handleEditKeyDown(e, section.id)}
                autoFocus
                size="small"
                variant="standard"
                sx={{
                  flex: 1,
                  '& .MuiInputBase-input': { fontSize: 12, py: 0.25, px: 0.5 },
                }}
              />
            ) : (
              <Typography
                onDoubleClick={() => startEditing(section)}
                sx={{
                  flex: 1,
                  fontSize: 12,
                  color: '#53565A',
                  fontWeight: 500,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  cursor: 'text',
                  userSelect: 'none',
                }}
              >
                {section.title}
              </Typography>
            )}

            <IconButton
              onClick={() => onEdit(section.id)}
              size="small"
              sx={{
                p: 0.25,
                color: '#97999B',
                transition: 'color 0.2s ease',
                '&:hover': { color: '#046A38' },
              }}
            >
              <SettingsIcon sx={{ fontSize: 15 }} />
            </IconButton>
            <IconButton
              onClick={() => onRemove(section.id)}
              size="small"
              sx={{
                p: 0.25,
                color: '#97999B',
                transition: 'color 0.2s ease',
                '&:hover': { color: '#DA291C' },
              }}
            >
              <DeleteOutlineIcon sx={{ fontSize: 15 }} />
            </IconButton>
          </Box>
        );
      })}
    </Box>
  );
}
