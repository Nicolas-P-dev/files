import React, { useState, useEffect, useCallback } from 'react';
import {
  Alert,
  Box,
  IconButton,
  LinearProgress,
  Tooltip,
  Typography,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import RefreshIcon from '@mui/icons-material/Refresh';
import CloseIcon from '@mui/icons-material/Close';
import WidgetGrid from './dashboard/WidgetGrid';

const DashboardPanel = ({ data = {}, onOpenPanel }) => {
  const [widgets, setWidgets] = useState(data.widgets || []);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const sessionId = data.sessionId;
  const widgetDefs = data.widgetDefs;

  const renderDashboard = useCallback(async () => {
    if (!sessionId || !widgetDefs) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`/api/sessions/${sessionId}/tools/render_dashboard`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ args: { widgets: JSON.stringify(widgetDefs) } }),
      });

      if (!res.ok) {
        throw new Error(`Server responded with ${res.status}: ${res.statusText}`);
      }

      const result = await res.json();

      if (result.error) {
        throw new Error(result.error);
      }

      // render_dashboard returns an array directly
      const widgetResults = Array.isArray(result) ? result : (result.widgets || []);
      setWidgets(widgetResults);
    } catch (err) {
      setError(err.message || 'Failed to render dashboard widgets');
    } finally {
      setLoading(false);
    }
  }, [sessionId, widgetDefs]);

  useEffect(() => {
    if (data.widgets && data.widgets.length > 0) {
      setWidgets(data.widgets);
    } else if (widgetDefs && widgetDefs.length > 0) {
      renderDashboard();
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleRefresh = () => {
    renderDashboard();
  };

  const handleDismissError = () => {
    setError(null);
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        backgroundColor: '#FAFAFA',
        borderRadius: '8px',
        overflow: 'hidden',
        border: '1px solid #E6E6E6',
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          px: 2,
          py: 1.5,
          backgroundColor: '#046A38',
          color: '#FFFFFF',
          minHeight: 48,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <DashboardIcon sx={{ fontSize: 20 }} />
          <Typography
            sx={{
              fontSize: '14px',
              fontWeight: 600,
              letterSpacing: '0.02em',
            }}
          >
            Live Dashboard
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          <Tooltip title="Refresh dashboard" arrow>
            <IconButton
              onClick={handleRefresh}
              disabled={loading}
              size="small"
              sx={{
                color: '#FFFFFF',
                transition: 'opacity 0.2s ease',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.15)',
                },
                '&.Mui-disabled': {
                  color: 'rgba(255, 255, 255, 0.4)',
                },
              }}
            >
              <RefreshIcon
                sx={{
                  fontSize: 20,
                  animation: loading ? 'spin 1s linear infinite' : 'none',
                  '@keyframes spin': {
                    '0%': { transform: 'rotate(0deg)' },
                    '100%': { transform: 'rotate(360deg)' },
                  },
                }}
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="Close panel" arrow>
            <IconButton
              onClick={() => onOpenPanel && onOpenPanel(null)}
              size="small"
              sx={{
                color: '#FFFFFF',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.15)',
                },
              }}
            >
              <CloseIcon sx={{ fontSize: 20 }} />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Loading progress */}
      {loading && (
        <LinearProgress
          sx={{
            height: 3,
            '& .MuiLinearProgress-bar': {
              backgroundColor: '#046A38',
            },
            backgroundColor: 'rgba(4, 106, 56, 0.15)',
          }}
        />
      )}

      {/* Error alert */}
      {error && (
        <Alert
          severity="error"
          action={
            <IconButton
              size="small"
              color="inherit"
              onClick={handleDismissError}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          }
          sx={{
            mx: 2,
            mt: 2,
            borderRadius: '6px',
            border: '1px solid #DA291C',
            '& .MuiAlert-icon': {
              color: '#DA291C',
            },
            '& .MuiAlert-message': {
              color: '#53565A',
              fontSize: '13px',
            },
          }}
        >
          {error}
        </Alert>
      )}

      {/* Widget grid body */}
      <Box
        sx={{
          flex: 1,
          overflowY: 'auto',
          transition: 'opacity 0.2s ease',
        }}
      >
        {!loading && widgets.length === 0 && !error ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              minHeight: 300,
              gap: 1.5,
            }}
          >
            <DashboardIcon sx={{ fontSize: 48, color: '#E6E6E6' }} />
            <Typography
              sx={{
                color: '#97999B',
                fontSize: '14px',
                fontWeight: 400,
              }}
            >
              No dashboard widgets available
            </Typography>
          </Box>
        ) : (
          <WidgetGrid widgets={widgets} baseUrl="" />
        )}
      </Box>
    </Box>
  );
};

export default DashboardPanel;
