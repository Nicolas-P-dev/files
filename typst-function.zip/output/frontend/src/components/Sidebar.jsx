import React from 'react';
import {
    Box, Typography, List, ListItem, ListItemButton, ListItemIcon,
    ListItemText, Divider, IconButton, Chip,
} from '@mui/material';
import logoImage from '../assets/logo.png';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import FolderIcon from '@mui/icons-material/Folder';
import PeopleIcon from '@mui/icons-material/People';
import CalculateIcon from '@mui/icons-material/Calculate';
import EmailIcon from '@mui/icons-material/Email';
import SettingsIcon from '@mui/icons-material/Settings';
import HelpIcon from '@mui/icons-material/Help';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ChatIcon from '@mui/icons-material/Chat';
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import BarChartIcon from '@mui/icons-material/BarChart';

const NAV_ITEMS = [
    { id: 'doc-review', label: 'Upload Requirements', icon: PictureAsPdfIcon },
    { id: 'dashboard', label: 'Dashboard', icon: DashboardIcon },
    { id: 'projects', label: 'Projects', icon: FolderIcon },
    { id: 'team', label: 'Team', icon: PeopleIcon },
    { id: 'effort', label: 'Resource Planning', icon: CalculateIcon },
    { id: 'messages', label: 'Messages', icon: EmailIcon, disabled: true },
    { id: 'report-composer', label: 'Report Composer', icon: MenuBookIcon, panelType: 'report-composer' },
    { id: 'live-dashboard', label: 'Live Dashboard', icon: BarChartIcon, panelType: 'live-dashboard' },
];

function formatSessionTitle(session, { activeSessionId, activeChatMessages } = {}) {
    if (activeSessionId && session.session_id === activeSessionId && session.title === 'New Chat' && activeChatMessages?.length) {
        const firstUser = activeChatMessages.find(m => m.role === 'user');
        if (firstUser?.content) {
            const t = firstUser.content.trim();
            return t.length > 35 ? t.slice(0, 35) + '…' : t || 'New Chat';
        }
    }
    if (session.title) return session.title.length > 35 ? session.title.slice(0, 35) + '…' : session.title;
    return session.session_id?.slice(0, 20) || 'Chat';
}

export default function Sidebar({
    activePanel,
    onPanelOpen,
    onPanelClose,
    sessions,
    activeSessionId,
    onNewChat,
    onSwitchSession,
    onDeleteSession,
    currentUserEmail,
    currentUser,
    onLogout,
    agentHealthy,
    activeChatMessages,
}) {
    const handleNavClick = (id) => {
        const item = NAV_ITEMS.find(n => n.id === id);
        const panelType = item?.panelType || id;
        if (activePanel === panelType) {
            onPanelClose();
        } else {
            const data = id === 'doc-review'
                ? { session_id: activeSessionId }
                : (item?.panelType ? { sessionId: activeSessionId } : null);
            onPanelOpen(panelType, data);
        }
    };

    return (
        <Box sx={{
            width: 240,
            minWidth: 200,
            height: '100%',
            bgcolor: '#000',
            color: '#fff',
            display: 'flex',
            flexDirection: 'column',
            flexShrink: 0,
            overflow: 'hidden',
        }}>
            {/* Logo + Title */}
            <Box sx={{ pt: 4, mb: 2 }}>
                <Box
                    component="img"
                    src={logoImage}
                    alt="Assistant Project Manager"
                    sx={{ width: 120, height: 'auto', display: 'block', ml: 4, mb: 2 }}
                />
                <Typography variant="h6" sx={{ fontWeight: 600, color: 'white', ml: 4 }}>
                    Assistant Project Manager
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: 4, mt: 1 }}>
                    <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
                        Status:
                    </Typography>
                    <Chip
                        label={agentHealthy ? 'Connected' : 'Disconnected'}
                        size="small"
                        sx={{
                            bgcolor: agentHealthy ? 'rgba(38,137,13,0.15)' : 'rgba(218,41,28,0.15)',
                            color: agentHealthy ? '#86BC25' : '#DA291C',
                            fontWeight: 600, fontSize: '0.7rem', height: 22,
                        }}
                    />
                </Box>
            </Box>

            <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />


            {/* Navigation */}
            <List sx={{ px: 1, pt: 1 }}>
                {NAV_ITEMS.map(item => {
                    const Icon = item.icon;
                    const panelType = item.panelType || item.id;
                    const selected = activePanel === panelType;
                    return (
                        <ListItem key={item.id} disablePadding sx={{ mb: 0.25 }}>
                            <ListItemButton
                                selected={selected}
                                disabled={item.disabled}
                                onClick={() => handleNavClick(item.id)}
                                sx={{
                                    borderRadius: 1, py: 0.75,
                                    '&.Mui-selected': {
                                        bgcolor: 'rgba(38,137,13,0.15)',
                                        '& .MuiListItemIcon-root': { color: '#26890D' },
                                    },
                                    '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
                                    '&.Mui-disabled': { opacity: 0.35 },
                                }}
                            >
                                <ListItemIcon sx={{ color: selected ? '#26890D' : '#fff', minWidth: 40 }}>
                                    <Icon />
                                </ListItemIcon>
                                <ListItemText primary={item.label} />
                            </ListItemButton>
                        </ListItem>
                    );
                })}
            </List>

            <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)', mx: 1.5, my: 1 }} />

            {/* New Chat */}
            <Box sx={{ px: 1.5, pb: 1 }}>
                <ListItemButton
                    onClick={onNewChat}
                    sx={{
                        borderRadius: 1,
                        border: '1px solid rgba(38,137,13,0.4)',
                        justifyContent: 'center', py: 0.75,
                        '&:hover': { bgcolor: 'rgba(38,137,13,0.1)' },
                    }}
                >
                    <AddIcon fontSize="small" sx={{ color: '#26890D', mr: 1 }} />
                    <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 600 }}>
                        New Chat
                    </Typography>
                </ListItemButton>
            </Box>

            {/* Sessions */}
            <Box sx={{
                flex: 1,
                overflowY: 'auto',
                px: 1,
                scrollbarWidth: 'none',
                '&::-webkit-scrollbar': {
                    display: 'none',
                },
                msOverflowStyle: 'none',
            }}>
                {sessions.map(session => (
                    <ListItem
                        key={session.session_id}
                        disablePadding
                        secondaryAction={
                            <IconButton
                                size="small"
                                onClick={(e) => { e.stopPropagation(); onDeleteSession(session.session_id); }}
                                sx={{ color: '#63666A', opacity: 0, '.MuiListItem-root:hover &': { opacity: 1 } }}
                            >
                                <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                        }
                        sx={{ '&:hover .MuiIconButton-root': { opacity: 1 } }}
                    >
                        <ListItemButton
                            selected={activeSessionId === session.session_id}
                            onClick={() => onSwitchSession(session.session_id)}
                            sx={{
                                borderRadius: 1, py: 0.5, pr: 5,
                                '&.Mui-selected': {
                                    bgcolor: 'rgba(38,137,13,0.15)',
                                    '& .MuiListItemIcon-root': { color: '#26890D' },
                                },
                                '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
                            }}
                        >
                            <ListItemIcon sx={{ color: activeSessionId === session.session_id ? '#26890D' : '#fff', minWidth: 32 }}>
                                <ChatIcon sx={{ fontSize: 16 }} />
                            </ListItemIcon>
                            <ListItemText
                                primary={formatSessionTitle(session, { activeSessionId, activeChatMessages })}
                                primaryTypographyProps={{ fontSize: '0.8rem', noWrap: true, color: '#fff' }}
                            />
                        </ListItemButton>
                    </ListItem>
                ))}
            </Box>

            {/* Account */}
            {currentUserEmail && (
                <Box sx={{ px: 2, pb: 1.5 }}>
                    <ListItemButton
                        onClick={() => {
                            if (activePanel === 'account') {
                                onPanelClose();
                                return;
                            }
                            onPanelOpen('account', {
                                email: currentUserEmail,
                                onLogout,
                                isDemo: !!currentUser?.is_demo,
                            });
                        }}
                        sx={{
                            borderRadius: 1,
                            bgcolor: activePanel === 'account' ? 'rgba(38,137,13,0.2)' : 'rgba(38, 137, 13, 0.1)',
                            border: '1px solid rgba(38, 137, 13, 0.3)',
                            '&:hover': { bgcolor: 'rgba(38,137,13,0.2)' },
                        }}
                    >
                        <ListItemIcon sx={{ color: '#86BC25', minWidth: 32 }}>
                            <PeopleIcon sx={{ fontSize: 18 }} />
                        </ListItemIcon>
                        <ListItemText
                            primary={currentUserEmail}
                            primaryTypographyProps={{ fontSize: '0.8rem', noWrap: true, color: '#86BC25' }}
                        />
                    </ListItemButton>
                </Box>
            )}

            {/* Bottom Actions */}
            <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />
            <List sx={{ px: 1, py: 0.5 }}>
                <ListItem disablePadding>
                    <ListItemButton onClick={() => handleNavClick('tools')} sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
                        <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><ElectricBoltIcon /></ListItemIcon>
                        <ListItemText primary="Connected Tools" primaryTypographyProps={{ fontSize: '0.875rem' }} />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton onClick={() => handleNavClick('settings')} sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
                        <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><SettingsIcon /></ListItemIcon>
                        <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: '0.875rem' }} />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
                        <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><HelpIcon /></ListItemIcon>
                        <ListItemText primary="Help & Support" primaryTypographyProps={{ fontSize: '0.875rem' }} />
                    </ListItemButton>
                </ListItem>
            </List>
        </Box>
    );
}
