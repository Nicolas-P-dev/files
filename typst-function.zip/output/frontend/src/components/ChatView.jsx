import React, { useState, useRef, useEffect } from 'react';
import {
    Box, Typography, TextField, IconButton, InputAdornment,
    CircularProgress, Link, Chip, Button,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import CheckCircleOutline from '@mui/icons-material/CheckCircleOutline';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeSanitize from 'rehype-sanitize';
import AgentTrace from './AgentTrace';
import MessageAttachment from './MessageAttachment';

const markdownComponents = {
    p: ({ children }) => <Typography variant="body2" sx={{ lineHeight: 1.6, mb: 0.5, '&:last-child': { mb: 0 } }}>{children}</Typography>,
    strong: ({ children }) => <strong>{children}</strong>,
    em: ({ children }) => <em>{children}</em>,
    ul: ({ children }) => <ul style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ul>,
    ol: ({ children }) => <ol style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ol>,
    li: ({ children }) => <li><Typography variant="body2" component="span" sx={{ lineHeight: 1.6 }}>{children}</Typography></li>,
    a: ({ href, children }) => (
        <Link href={href} target="_blank" rel="noopener noreferrer" sx={{
            wordBreak: 'break-all', color: '#26890D', textDecoration: 'underline',
            fontWeight: 500, '&:hover': { color: '#046A38' },
        }}>{children}</Link>
    ),
    code: ({ inline, children }) => inline ? (
        <span style={{
            background: 'rgba(0,0,0,0.06)', borderRadius: 3, padding: '0.05rem 0.2rem',
            fontSize: '0.85em',
        }}>{children}</span>
    ) : (
        <pre style={{
            whiteSpace: 'pre-wrap', wordWrap: 'break-word', margin: '0.5rem 0',
            padding: '0.5rem', borderRadius: 6, background: 'rgba(0,0,0,0.04)', overflow: 'auto',
        }}><code style={{ fontFamily: "'Roboto Mono', monospace", fontSize: '0.85em' }}>{children}</code></pre>
    ),
    h1: ({ children }) => <Typography variant="h6" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
    h2: ({ children }) => <Typography variant="subtitle1" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
    h3: ({ children }) => <Typography variant="subtitle2" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
    table: ({ children }) => <div style={{ overflowX: 'auto', margin: '0.5rem 0' }}><table style={{ borderCollapse: 'collapse', width: '100%', border: '1px solid #E6E6E6' }}>{children}</table></div>,
    thead: ({ children }) => <thead style={{ backgroundColor: '#F5F5F5' }}>{children}</thead>,
    th: ({ children }) => <th style={{ textAlign: 'left', borderBottom: '2px solid #E6E6E6', padding: '8px 12px', fontWeight: 600 }}>{children}</th>,
    td: ({ children }) => <td style={{ borderBottom: '1px solid #E6E6E6', padding: '8px 12px', verticalAlign: 'top' }}>{children}</td>,
    blockquote: ({ children }) => <blockquote style={{ borderLeft: '3px solid #E6E6E6', margin: '0.5rem 0', padding: '0.25rem 0.75rem', color: '#63666A' }}>{children}</blockquote>,
    hr: () => <hr style={{ border: 'none', borderTop: '1px solid #E6E6E6', margin: '8px 0' }} />,
};

const SUGGESTIONS = [
    'Show me my Jira projects',
    'What tasks are in progress?',
    'Create a new task for API review',
    'Give me a sprint status update',
];

function WelcomeScreen({ onSuggestionClick }) {
    return (
        <Box sx={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', height: '100%', textAlign: 'center', px: 3,
        }}>
            <Typography variant="h6" sx={{ color: '#000', mb: 1, fontWeight: 500 }}>
                Welcome to the Assistant Project Manager
            </Typography>
            <Typography variant="body2" sx={{ color: '#53565A', lineHeight: 1.6, mb: 3 }}>
                I can help you manage projects, update tasks, and streamline your workflow.
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, maxWidth: 480, width: '100%' }}>
                {SUGGESTIONS.map(text => (
                    <Box key={text} onClick={() => onSuggestionClick(text)} sx={{
                        p: 2, borderRadius: 2, border: '1px solid #E6E6E6', bgcolor: 'white', cursor: 'pointer',
                        transition: 'all 0.15s',
                        '&:hover': { borderColor: '#26890D', bgcolor: 'rgba(38,137,13,0.03)' },
                    }}>
                        <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 500 }}>{text}</Typography>
                    </Box>
                ))}
            </Box>
        </Box>
    );
}

export default function ChatView({
    messages, isStreaming, streamingStatus, traceSteps, inputValue, onInputChange, onSend, onSuggestionClick,
    onOpenConnectedTools, onOpenPanel,
}) {
    const endRef = useRef(null);

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isStreaming, traceSteps]);

    const handleKeyDown = (e) => {
        if (e.isComposing || e.keyCode === 229) return;
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (inputValue.trim() && !isStreaming) onSend();
        }
    };

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
            {/* Messages */}
            <Box sx={{ flex: 1, overflowY: 'auto', px: 2, py: 2, bgcolor: '#F5F5F5', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
                {messages.length === 0 ? <WelcomeScreen onSuggestionClick={onSuggestionClick} /> : (
                    <>
                        {messages.map((msg, i) => {
                            const isUser = msg.role === 'user';
                            const isSystem = msg.role === 'system';

                            return (
                                <Box key={i} className={`message ${msg.role}`} sx={{
                                    alignSelf: isUser ? 'flex-end' : isSystem ? 'center' : 'flex-start',
                                    maxWidth: isSystem ? '70%' : '85%',
                                    p: isSystem ? 1.5 : 2,
                                    borderRadius: isSystem ? 2 : 3,
                                    mb: 1.5,
                                    wordBreak: 'break-word',
                                    overflowWrap: 'break-word',
                                }}>
                                    {isUser ? (
                                        <Typography variant="body2" component="div" sx={{ lineHeight: 1.6 }}>{msg.content}</Typography>
                                    ) : (
                                        <>
                                            {msg.isStreaming && (
                                                <AgentTrace steps={traceSteps ?? []} isComplete={false} liveStatus={streamingStatus} />
                                            )}
                                            {!msg.isStreaming && (() => {
                                                const trace = msg.trace ?? [];
                                                const hasMeaningfulTrace = trace.some(
                                                    (s) =>
                                                        s.step === 'tool_call' ||
                                                        s.step === 'skill_start' ||
                                                        (s.step === 'routing' && s.skill),
                                                );
                                                return trace.length > 0 && hasMeaningfulTrace ? (
                                                    <AgentTrace steps={trace} isComplete totalDurationMs={msg.totalDurationMs} />
                                                ) : null;
                                            })()}
                                            {msg.content ? (
                                                msg.isError ? (
                                                    <Box sx={{
                                                        p: 1.5,
                                                        borderRadius: 2,
                                                        bgcolor: 'rgba(218,41,28,0.06)',
                                                        border: '1px solid rgba(218,41,28,0.25)',
                                                    }}>
                                                        <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSanitize]} components={markdownComponents}>
                                                            {msg.content}
                                                        </ReactMarkdown>
                                                        {msg.errorAction === 'open_connected_tools' && onOpenConnectedTools ? (
                                                            <Button
                                                                variant="contained"
                                                                size="small"
                                                                onClick={onOpenConnectedTools}
                                                                sx={{ mt: 1.5, bgcolor: '#26890D', '&:hover': { bgcolor: '#046A38' } }}
                                                            >
                                                                Open Connected Tools
                                                            </Button>
                                                        ) : null}
                                                    </Box>
                                                ) : (
                                                    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSanitize]} components={markdownComponents}>
                                                        {msg.content}
                                                    </ReactMarkdown>
                                                )
                                            ) : null}
                                            {msg.files?.map((file) => (
                                                <MessageAttachment
                                                    key={file.file_id}
                                                    file={file}
                                                    onOpenPanel={onOpenPanel}
                                                />
                                            ))}
                                            {!msg.isStreaming && (msg.skills?.length || msg.skill) && (
                                                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1.5, alignItems: 'center' }}>
                                                    {(msg.skills ?? (msg.skill ? [msg.skill] : [])).map((s) => (
                                                        <Chip
                                                            key={s}
                                                            icon={<CheckCircleOutline sx={{ fontSize: 14, color: '#26890D' }} />}
                                                            label={s}
                                                            size="small"
                                                            sx={{
                                                                height: 22,
                                                                fontSize: '0.7rem',
                                                                fontWeight: 600,
                                                                bgcolor: 'rgba(38,137,13,0.08)',
                                                                color: '#26890D',
                                                                border: '1px solid rgba(38,137,13,0.25)',
                                                                '& .MuiChip-icon': { ml: 0.5, mr: 0 },
                                                            }}
                                                        />
                                                    ))}
                                                </Box>
                                            )}
                                        </>
                                    )}
                                </Box>
                            );
                        })}

                        <div ref={endRef} />
                    </>
                )}
            </Box>

            {/* Input - exact v1 styling */}
            <Box sx={{ px: 2, py: 2, bgcolor: 'white', borderTop: '1px solid #E6E6E6' }}>
                <TextField
                    fullWidth variant="outlined" placeholder="Type your message..."
                    value={inputValue} onChange={(e) => onInputChange(e.target.value)}
                    onKeyDown={handleKeyDown} disabled={isStreaming}
                    multiline maxRows={4} size="small"
                    InputProps={{
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton onClick={onSend} disabled={!inputValue.trim() || isStreaming} edge="end"
                                    sx={{ color: '#26890D', '&:hover': { bgcolor: 'rgba(38,137,13,0.08)' }, '&.Mui-disabled': { color: '#D0D0CE' } }}>
                                    {isStreaming ? <CircularProgress size={20} sx={{ color: '#26890D' }} /> : <SendIcon />}
                                </IconButton>
                            </InputAdornment>
                        ),
                        sx: {
                            borderRadius: 2,
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#26890D', borderWidth: 2 },
                            '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#26890D' },
                        },
                    }}
                />
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Typography variant="caption" sx={{ color: '#A5ADBA' }}>Press Enter to send · Shift+Enter for new line</Typography>
                    {isStreaming && <Typography variant="caption" sx={{ color: '#26890D' }}>Processing...</Typography>}
                </Box>
            </Box>
        </Box>
    );
}
