import KanbanPanel from './panels/KanbanPanel';
import ProjectsPanel from './panels/ProjectsPanel';
import TeamPanel from './panels/TeamPanel';
import EffortPanel from './panels/EffortPanel';
import PdfPanel from './panels/PdfPanel';
import SettingsPanel from './panels/SettingsPanel';
import ConnectedToolsPanel from './panels/ConnectedToolsPanel';
import AccountPanel from './panels/AccountPanel';
import PlaceholderPanel from './panels/PlaceholderPanel';
import DocReviewPanel from './panels/DocReviewPanel';
import ImageViewerPanel from './panels/ImageViewerPanel';
import PdfViewerPanel from './panels/PdfViewerPanel';
import ReportComposerPanel from './panels/ReportComposerPanel';
import DashboardPanel from './panels/DashboardPanel';

const PANEL_REGISTRY = {
    dashboard: { component: KanbanPanel, title: 'Sprint Board' },
    projects: { component: ProjectsPanel, title: 'Projects Overview' },
    team: { component: TeamPanel, title: 'Team Management' },
    effort: { component: EffortPanel, title: 'Resource Planning' },
    'pdf-upload': { component: PdfPanel, title: 'Requirements Extraction' },
    settings: { component: SettingsPanel, title: 'Settings' },
    tools: { component: ConnectedToolsPanel, title: 'Connected Tools' },
    account: { component: AccountPanel, title: 'Account' },
    messages: { component: PlaceholderPanel, title: 'Messages' },
    'doc-review': { component: DocReviewPanel, title: 'Project Breakdown Review' },
    kanban: { component: KanbanPanel, title: 'Sprint Board' },
    table: { component: PlaceholderPanel, title: 'Data Table' },
    chart: { component: PlaceholderPanel, title: 'Chart' },
    custom: { component: PlaceholderPanel, title: 'Agent View' },
    'image-viewer': { component: ImageViewerPanel, title: 'Image Viewer' },
    'pdf-viewer': { component: PdfViewerPanel, title: 'PDF Report' },
    'report-composer': { component: ReportComposerPanel, title: 'Report Composer' },
    'live-dashboard': { component: DashboardPanel, title: 'Live Dashboard' },
};

export default PANEL_REGISTRY;
