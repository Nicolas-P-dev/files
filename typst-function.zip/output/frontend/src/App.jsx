import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Box } from '@mui/material';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import RightPanel from './components/RightPanel';
import LoginPanel from './components/auth/LoginPanel';
import useChat from './hooks/useChat';
import useSessions from './hooks/useSessions';
import useHealthCheck from './hooks/useHealthCheck';
import useCurrentUser from './hooks/useCurrentUser';
import { apiFetch, withUserId, getResolvedChatUserId } from './utils/api';

export default function App() {
    const [showLogin, setShowLogin] = useState(true);
    const [authChecking, setAuthChecking] = useState(true);
    const [currentUser, setCurrentUser] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [activePanel, setActivePanel] = useState(null);
    const [panelData, setPanelData] = useState(null);
    const activeSessionIdRef = useRef(null);

    const {
        sessions, activeSessionId, createSession, switchSession,
        deleteSession, refreshSessions, pinSession, resetSessions,
    } = useSessions();

    const {
        messages, isStreaming, streamingStatus, traceSteps, currentSkill,
        panelEvent, sendMessage, cancelStream, clearMessages, loadMessages, setPanelEvent, setOnStreamComplete,
    } = useChat();

    const { tools, agentHealthy } = useHealthCheck();

    useEffect(() => {
        activeSessionIdRef.current = activeSessionId;
    }, [activeSessionId]);

    useEffect(() => {
        if (authChecking || showLogin) return;
        refreshSessions();
    }, [authChecking, showLogin, refreshSessions]);

    useEffect(() => {
        setOnStreamComplete(async (sessionId) => {
            await refreshSessions();
            if (activeSessionIdRef.current !== sessionId) return;
            try {
                const resp = await apiFetch(withUserId(`/api/sessions/${sessionId}/messages`), { cache: 'no-store' });
                if (resp.ok) {
                    const { messages: sessionMessages } = await resp.json();
                    loadMessages(sessionMessages);
                }
            } catch { /* keep current messages */ }
        });
        return () => setOnStreamComplete(null);
    }, [refreshSessions, loadMessages, setOnStreamComplete]);

    const ensureSession = useCallback(() => {
        if (!activeSessionId) return createSession();
        return activeSessionId;
    }, [activeSessionId, createSession]);

    const withWorkspaceContext = useCallback((explicitContext = null) => {
        const context = { ...explicitContext };

        // Doc review — existing pattern
        if (activePanel === 'doc-review' && panelData?.session_id) {
            context.doc_session_id = panelData.session_id;
        }

        // Report Composer — AI knows composer is open and can offer section suggestions
        if (activePanel === 'report-composer') {
            context.active_panel = 'report-composer';
            if (panelData?.sessionId) {
                context.doc_session_id = panelData.sessionId;
            }
        }

        // Live Dashboard — AI knows dashboard is open and can add/refresh widgets
        if (activePanel === 'live-dashboard') {
            context.active_panel = 'live-dashboard';
            if (panelData?.sessionId) {
                context.doc_session_id = panelData.sessionId;
            }
        }

        // PDF Viewer — AI knows a report is being viewed
        if (activePanel === 'pdf-viewer') {
            context.active_panel = 'pdf-viewer';
            if (panelData?.typstUrl) {
                context.viewing_report_typst_url = panelData.typstUrl;
            }
        }

        return Object.keys(context).length > 0 ? context : null;
    }, [activePanel, panelData]);

    const handleSend = useCallback(() => {
        const text = inputValue.trim();
        if (!text) return;
        const sessionId = ensureSession();
        pinSession(sessionId, text);

        const userId = getResolvedChatUserId(currentUser);
        const token = localStorage.getItem('apm_jira_token') || '';
        sendMessage(text, sessionId, userId, token, withWorkspaceContext());
        setInputValue('');
        setTimeout(() => refreshSessions(), 1000);
    }, [inputValue, ensureSession, pinSession, sendMessage, refreshSessions, currentUser, withWorkspaceContext]);

    const handleNewChat = useCallback(async () => {
        await refreshSessions();
        createSession();
        clearMessages();
        setInputValue('');
    }, [createSession, clearMessages, refreshSessions]);

    const handleSwitchSession = useCallback(async (sessionId) => {
        await refreshSessions();
        switchSession(sessionId);
        if (activePanel === 'doc-review') {
            setPanelData({ session_id: sessionId });
        }
        try {
            const resp = await apiFetch(withUserId(`/api/sessions/${sessionId}/messages`), { cache: 'no-store' });
            if (resp.ok) {
                const { messages: sessionMessages } = await resp.json();
                loadMessages(sessionMessages);
            } else {
                loadMessages([]);
            }
        } catch {
            loadMessages([]);
        }
    }, [switchSession, loadMessages, refreshSessions, activePanel]);

    const handleDeleteSession = useCallback((sessionId) => {
        deleteSession(sessionId);
        if (sessionId === activeSessionId) clearMessages();
    }, [deleteSession, activeSessionId, clearMessages]);

    const handleSuggestionClick = useCallback((text) => {
        setInputValue(text);
        const sessionId = ensureSession();
        pinSession(sessionId, text);

        const userId = getResolvedChatUserId(currentUser);
        const token = localStorage.getItem('apm_jira_token') || '';
        sendMessage(text, sessionId, userId, token, withWorkspaceContext());
        setTimeout(() => refreshSessions(), 1000);
    }, [ensureSession, pinSession, sendMessage, refreshSessions, currentUser, withWorkspaceContext]);

    const handlePanelOpen = useCallback((panelType, data = null) => {
        setActivePanel(panelType);
        let sessionId = activeSessionId;
        if (panelType === 'doc-review' && !sessionId) {
            sessionId = createSession();
        }
        const effective = panelType === 'doc-review'
            ? { ...(data || {}), session_id: sessionId }
            : data;
        setPanelData(effective);
    }, [activeSessionId, createSession]);

    const handlePanelClose = useCallback(() => {
        setActivePanel(null);
        setPanelData(null);
    }, []);

    const handleLogout = useCallback(() => {
        const accessToken = localStorage.getItem('apm_access_token') || '';
        if (accessToken) {
            fetch('/api/auth/logout', {
                method: 'POST',
                headers: { Authorization: `Bearer ${accessToken}` },
            }).catch(() => { });
        }

        localStorage.removeItem('apm_access_token');
        localStorage.removeItem('apm_user_id');
        localStorage.removeItem('apm_user_email');
        sessionStorage.removeItem('apm_user_id');
        setCurrentUser(null);
        setActivePanel(null);
        setPanelData(null);
        clearMessages();
        resetSessions();
        setShowLogin(true);
    }, [clearMessages, resetSessions]);

    useEffect(() => {
        if (panelEvent) {
            const stamped = { ...panelEvent.data, updated_at: Date.now() };
            if (panelEvent.panelType === 'doc-review' && !stamped.session_id) {
                stamped.session_id = panelData?.session_id ?? activeSessionId;
            }
            if (activePanel === panelEvent.panelType) {
                setPanelData(stamped);
            } else {
                setActivePanel(panelEvent.panelType);
                setPanelData(stamped);
            }
            setPanelEvent(null);
        }
    }, [panelEvent, setPanelEvent, activePanel, panelData, activeSessionId]);

    useEffect(() => {
        const restoreAuth = async () => {
            const accessToken = localStorage.getItem('apm_access_token');
            if (!accessToken) {
                setShowLogin(true);
                setAuthChecking(false);
                return;
            }

            try {
                const resp = await fetch('/api/auth/me', {
                    headers: { Authorization: `Bearer ${accessToken}` },
                });
                if (!resp.ok) {
                    throw new Error('Session is invalid.');
                }

                const data = await resp.json();
                const user = data?.user || null;
                if (!user) {
                    throw new Error('User profile missing.');
                }

                localStorage.setItem('apm_user_id', user.id || 'default');
                localStorage.setItem('apm_user_email', user.email || '');
                sessionStorage.setItem('apm_user_id', user.id || 'default');
                setCurrentUser(user);
                setShowLogin(false);
            } catch {
                localStorage.removeItem('apm_access_token');
                localStorage.removeItem('apm_user_id');
                localStorage.removeItem('apm_user_email');
                sessionStorage.removeItem('apm_user_id');
                setCurrentUser(null);
                setShowLogin(true);
            } finally {
                setAuthChecking(false);
            }
        };

        restoreAuth();
    }, []);

    if (authChecking) {
        return <Box sx={{ height: '100vh', bgcolor: '#f5f7f9' }} />;
    }

    if (showLogin) {
        return <LoginPanel onEnterApp={(user) => {
            setCurrentUser(user || null);
            setShowLogin(false);
        }} />;
    }

    return (
        <Box sx={{ height: '100vh', display: 'flex', overflow: 'hidden' }}>
            <Sidebar
                activePanel={activePanel}
                onPanelOpen={handlePanelOpen}
                onPanelClose={handlePanelClose}
                sessions={sessions}
                activeSessionId={activeSessionId}
                onNewChat={handleNewChat}
                onSwitchSession={handleSwitchSession}
                onDeleteSession={handleDeleteSession}
                currentUserEmail={currentUser?.email || localStorage.getItem('apm_user_email') || null}
                currentUser={currentUser}
                onLogout={handleLogout}
                agentHealthy={agentHealthy}
                activeChatMessages={messages}
            />

            <Box sx={{
                flex: activePanel ? '0 0 35%' : '1 1 100%',
                minWidth: 320,
                maxWidth: activePanel ? '40%' : '100%',
                transition: 'flex 0.2s ease, max-width 0.2s ease',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                borderRight: activePanel ? '1px solid #E6E6E6' : 'none',
            }}>
                <ChatView
                    messages={messages}
                    isStreaming={isStreaming}
                    streamingStatus={streamingStatus}
                    traceSteps={traceSteps}
                    inputValue={inputValue}
                    onInputChange={setInputValue}
                    onSend={handleSend}
                    onSuggestionClick={handleSuggestionClick}
                    onOpenConnectedTools={() => handlePanelOpen('tools')}
                    onOpenPanel={(panelType, panelData) => {
                        setActivePanel(panelType);
                        setPanelData(panelData);
                    }}
                />
            </Box>

            {activePanel && (
                <Box sx={{
                    flex: '1 1 65%',
                    minWidth: 500,
                    overflow: 'hidden',
                }}>
                    <RightPanel
                        panelType={activePanel}
                        data={panelData}
                        onClose={handlePanelClose}
                        onSendMessage={(msg, context = null) => {
                            setInputValue(msg);
                            const sessionId = ensureSession();
                            pinSession(sessionId, msg);
                            const userId = getResolvedChatUserId(currentUser);
                            const token = localStorage.getItem('apm_jira_token') || '';
                            sendMessage(msg, sessionId, userId, token, withWorkspaceContext(context));
                        }}
                        traceSteps={traceSteps}
                        isStreaming={isStreaming}
                    />
                </Box>
            )}
        </Box>
    );
}
