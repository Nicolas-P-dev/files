// Release Notes Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "version": "string (e.g. 'v2.1.0')",
//   "release_date": "string",
//   "environment": "string (e.g. 'Production')",
//   "release_type": "string (e.g. 'Minor Release')",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "total_features": number,
//   "total_bug_fixes": number,
//   "total_known_issues": number,
//   "breaking_changes": number,
//   "features": [{"epic": "string", "key": "string", "summary": "string", "type": "Feature|Enhancement"}],
//   "bug_fixes": [{"key": "string", "summary": "string", "severity": "Critical|High|Medium|Low", "reported_by": "string"}],
//   "known_issues": [{"key": "string", "summary": "string", "severity": "string", "workaround": "string"}],
//   "breaking_changes_list": [{"description": "string", "migration_steps": "string"}],
//   "deployment_notes": "string",
//   "rollback_plan": "string",
//   "testing_summary": "string"
// }

#import "../lib/brand.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Release Notes",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
  project-id: data.at("version", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

#pagebreak(weak: true)
// Release Summary
= Release Summary

#section-intro[
  Release notes for #text(weight: "semibold", data.at("project_name", default: "the project")) version #text(weight: "semibold", data.at("version", default: "N/A")). This document summarizes all changes, known issues, and deployment guidance included in this release.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Version",
    data.at("version", default: "—"),
  ),
  kpi-card(
    "Features",
    str(data.at("total_features", default: 0)),
    color: if data.at("total_features", default: 0) > 0 { "green" } else { auto },
  ),
  kpi-card(
    "Bug Fixes",
    str(data.at("total_bug_fixes", default: 0)),
    color: if data.at("total_bug_fixes", default: 0) > 0 { "green" } else { auto },
  ),
  kpi-card(
    "Known Issues",
    str(data.at("total_known_issues", default: 0)),
    color: if data.at("total_known_issues", default: 0) > 0 { "orange" } else { "green" },
  ),
)

#v(4mm)

#kpi-row(
  kpi-card(
    "Breaking Changes",
    str(data.at("breaking_changes", default: 0)),
    color: if data.at("breaking_changes", default: 0) > 0 { "red" } else { "green" },
  ),
)

#pagebreak(weak: true)
// Release Details
= Release Details

#section-intro[
  Environment, release type, and scheduling details for this release.
]

#callout(accent: brand-blue, bg: brand-blue-1.lighten(60%))[
  #grid(
    columns: (auto, 1fr),
    column-gutter: 12pt,
    row-gutter: 8pt,
    text(size: 9pt, weight: "semibold", fill: brand-blue-dark, "Environment:"),
    text(size: 9pt, fill: brand-black, data.at("environment", default: "—")),
    text(size: 9pt, weight: "semibold", fill: brand-blue-dark, "Release Type:"),
    text(size: 9pt, fill: brand-black, data.at("release_type", default: "—")),
    text(size: 9pt, weight: "semibold", fill: brand-blue-dark, "Release Date:"),
    text(size: 9pt, fill: brand-black, data.at("release_date", default: "—")),
    text(size: 9pt, weight: "semibold", fill: brand-blue-dark, "Version:"),
    text(size: 9pt, fill: brand-black, data.at("version", default: "—")),
  )
]

#pagebreak(weak: true)
// Features
= Features

#if data.at("features", default: ()).len() > 0 {
  section-intro[#str(data.features.len()) feature(s) and enhancement(s) included in this release.]
  data-table(
    headers: ("Epic", "Key", "Summary", "Type"),
    rows: data.features.map(f => (
      f.at("epic", default: "—"),
      f.at("key", default: "—"),
      f.at("summary", default: ""),
      f.at("type", default: "Feature"),
    )),
  )
} else {
  callout[No new features or enhancements are included in this release.]
}

#pagebreak(weak: true)
// Bug Fixes
= Bug Fixes

#if data.at("bug_fixes", default: ()).len() > 0 {
  section-intro[#str(data.bug_fixes.len()) bug fix(es) included in this release.]
  data-table(
    headers: ("Key", "Summary", "Severity", "Reported By"),
    rows: data.bug_fixes.map(b => (
      b.at("key", default: "—"),
      b.at("summary", default: ""),
      b.at("severity", default: "Medium"),
      b.at("reported_by", default: "—"),
    )),
    status-col: 2,
  )
} else {
  callout[No bug fixes are included in this release.]
}

#pagebreak(weak: true)
// Known Issues
= Known Issues

#if data.at("known_issues", default: ()).len() > 0 {
  section-intro[#str(data.known_issues.len()) known issue(s) identified for this release. Workarounds are provided where available.]
  data-table(
    headers: ("Key", "Summary", "Severity", "Workaround"),
    rows: data.known_issues.map(k => (
      k.at("key", default: "—"),
      k.at("summary", default: ""),
      k.at("severity", default: "—"),
      k.at("workaround", default: "None"),
    )),
    status-col: 2,
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No known issues identified for this release.")
}

#pagebreak(weak: true)
// Breaking Changes
= Breaking Changes

#if data.at("breaking_changes_list", default: ()).len() > 0 {
  section-intro[#str(data.breaking_changes_list.len()) breaking change(s) in this release. Please review migration steps carefully before upgrading.]
  data-table(
    headers: ("Description", "Migration Steps"),
    rows: data.breaking_changes_list.map(bc => (
      bc.at("description", default: ""),
      bc.at("migration_steps", default: "—"),
    )),
  )
} else {
  callout[No breaking changes in this release. Upgrade is fully backward-compatible.]
}

#pagebreak(weak: true)
// Deployment & Rollback
= Deployment & Rollback

#section-intro[
  Deployment instructions and rollback procedures for this release.
]

#if data.at("deployment_notes", default: "") != "" {
  [== Deployment Notes]
  v(2mm)
  callout[#text(size: 9pt, data.at("deployment_notes", default: ""))]
  v(6mm)
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No deployment notes provided.")
  v(6mm)
}

#if data.at("rollback_plan", default: "") != "" {
  [== Rollback Plan]
  v(2mm)
  callout(accent: brand-orange, bg: brand-orange.lighten(88%))[#text(size: 9pt, data.at("rollback_plan", default: ""))]
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No rollback plan provided.")
}

#pagebreak(weak: true)
// Testing Summary
= Testing Summary

#section-intro[
  Overview of testing activities conducted for this release.
]

#if data.at("testing_summary", default: "") != "" {
  text(size: 9pt, fill: brand-black, data.at("testing_summary", default: ""))
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No testing summary available.")
}
