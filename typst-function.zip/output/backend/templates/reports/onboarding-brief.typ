// Project Onboarding Brief
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "overview_text": "string (1-2 paragraph project description)",
//   "project_start_date": "string",
//   "target_end_date": "string",
//   "methodology": "string (e.g. 'Agile Scrum')",
//   "key_takeaways": ["string", ...],
//   "milestones": [{"milestone": "string", "date": "string", "status": "Complete|On Track|At Risk|Not Started"}],
//   "team_contacts": [{"name": "string", "role": "string", "email": "string", "responsibility": "string"}],
//   "architecture_notes": "string (text description of technical architecture)",
//   "tech_stack": [{"category": "string", "technologies": "string"}],
//   "resources": [{"name": "string", "url": "string", "description": "string"}],
//   "glossary": [{"term": "string", "definition": "string"}],
//   "current_sprint_summary": "string",
//   "ways_of_working": ["string", ...]
// }

#import "../lib/brand.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Project Onboarding Brief",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Project Overview
= Project Overview

#section-intro[
  High-level summary of #text(weight: "semibold", data.at("project_name", default: "the project")) to help new team members get up to speed quickly. Review the key facts, timeline, and methodology below.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#callout[
  #text(size: 9pt, fill: brand-black, data.at("overview_text", default: text(fill: brand-gray-mid, style: "italic", "No overview text provided.")))
]

#v(6mm)

#kpi-row(
  kpi-card(
    "Project Start",
    data.at("project_start_date", default: "—"),
  ),
  kpi-card(
    "Target End",
    data.at("target_end_date", default: "—"),
  ),
  kpi-card(
    "Methodology",
    data.at("methodology", default: "—"),
  ),
)

#pagebreak(weak: true)
// Key Milestones
= Key Milestones

#if data.at("milestones", default: ()).len() > 0 {
  section-intro[Key delivery milestones and their current status.]
  data-table(
    headers: ("Milestone", "Date", "Status"),
    rows: data.at("milestones", default: ()).map(m => (
      m.at("milestone", default: "—"),
      m.at("date", default: ""),
      m.at("status", default: "Not Started"),
    )),
    status-col: 2,
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No milestones defined.")
}

#pagebreak(weak: true)
// Team Contacts
= Team Contacts

#if data.at("team_contacts", default: ()).len() > 0 {
  section-intro[Primary contacts and their areas of responsibility.]
  data-table(
    headers: ("Name", "Role", "Email", "Responsibility"),
    rows: data.at("team_contacts", default: ()).map(c => (
      c.at("name", default: "—"),
      c.at("role", default: ""),
      c.at("email", default: ""),
      c.at("responsibility", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No team contacts provided.")
}

#pagebreak(weak: true)
// Technical Architecture
= Technical Architecture

#section-intro[
  Overview of the system architecture and technology choices underpinning the project.
]

#callout[
  #text(size: 9pt, fill: brand-black, data.at("architecture_notes", default: text(fill: brand-gray-mid, style: "italic", "No architecture notes provided.")))
]

#v(6mm)

#if data.at("tech_stack", default: ()).len() > 0 {
  [== Technology Stack]
  data-table(
    headers: ("Category", "Technologies"),
    rows: data.at("tech_stack", default: ()).map(t => (
      t.at("category", default: "—"),
      t.at("technologies", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No technology stack defined.")
}

#pagebreak(weak: true)
// Ways of Working
= Ways of Working

#if data.at("ways_of_working", default: ()).len() > 0 {
  section-intro[Team norms and practices that guide how we collaborate and deliver.]
  callout[
    #for item in data.at("ways_of_working", default: ()) {
      grid(
        columns: (14pt, 1fr),
        column-gutter: 4pt,
        text(size: 9pt, fill: brand-green-4, "•"),
        text(size: 9pt, fill: brand-black, item),
      )
      v(3pt)
    }
  ]
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No ways of working documented.")
}

#pagebreak(weak: true)
// Key Resources & Links
= Key Resources & Links

#if data.at("resources", default: ()).len() > 0 {
  section-intro[Important links and reference materials for the project.]
  data-table(
    headers: ("Name", "URL", "Description"),
    rows: data.at("resources", default: ()).map(r => (
      r.at("name", default: "—"),
      r.at("url", default: ""),
      r.at("description", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No resources listed.")
}

#pagebreak(weak: true)
// Glossary
= Glossary

#if data.at("glossary", default: ()).len() > 0 {
  section-intro[Common terms and acronyms used across the project.]
  data-table(
    headers: ("Term", "Definition"),
    rows: data.at("glossary", default: ()).map(g => (
      g.at("term", default: "—"),
      g.at("definition", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No glossary entries.")
}

#pagebreak(weak: true)
// Current Sprint
= Current Sprint

#section-intro[
  Summary of the active sprint to orient new joiners on immediate priorities.
]

#text(size: 9pt, fill: brand-black, data.at("current_sprint_summary", default: text(fill: brand-gray-mid, style: "italic", "No sprint summary available.")))
