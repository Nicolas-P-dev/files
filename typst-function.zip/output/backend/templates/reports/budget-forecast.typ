// Budget & Forecast Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "total_budget": number,
//   "total_spent": number,
//   "remaining": number,
//   "eac": number (estimate at completion),
//   "variance_pct": number,
//   "budget_status": "On Track|At Risk|Over Budget",
//   "by_category": [{"category": "string", "budgeted": number, "actual": number}, ...],
//   "monthly_burn": [{"month": "string", "planned": number, "actual": number}, ...],
//   "forecast": [{"month": "string", "planned": number, "actual": number, "variance": number}, ...],
//   "cost_breakdown": [{"category": "string", "amount": number}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#let fmt-currency(n) = {
  if n >= 1000 {
    "$" + str(calc.round(n / 1000, digits: 1)) + "k"
  } else {
    "$" + str(n)
  }
}

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Budget & Forecast Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Budget Overview
= Budget Overview

#section-intro[
  Financial summary for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Key budget metrics, spend trajectory, and forecast variance are summarized below.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Total Budget",
    fmt-currency(data.at("total_budget", default: 0)),
  ),
  kpi-card(
    "Total Spent",
    fmt-currency(data.at("total_spent", default: 0)),
  ),
  kpi-card(
    "Remaining",
    fmt-currency(data.at("remaining", default: 0)),
    color: if data.at("remaining", default: 0) > 0 { "green" } else { "red" },
  ),
  kpi-card(
    "EAC",
    fmt-currency(data.at("eac", default: 0)),
    sub-label: "Estimate at Completion",
  ),
  kpi-card(
    "Variance",
    str(data.at("variance_pct", default: 0)) + "%",
    color: if data.at("variance_pct", default: 0) <= 5.0 { "green" } else if data.at("variance_pct", default: 0) <= 10.0 { "orange" } else { "red" },
  ),
)

#v(6mm)

#callout[
  *Budget Status:* #status-badge(data.at("budget_status", default: "On Track"))
]

#pagebreak(weak: true)
// Budget vs Actual by Category
= Budget vs Actual by Category

#section-intro[
  Comparison of budgeted versus actual spend across project cost categories. The variance column highlights over- or under-spend per category.
]

#if data.at("by_category", default: ()).len() > 0 {
  data-table(
    headers: ("Category", "Budgeted", "Actual", "Variance"),
    rows: data.by_category.map(c => (
      c.at("category", default: "—"),
      fmt-currency(c.at("budgeted", default: 0)),
      fmt-currency(c.at("actual", default: 0)),
      fmt-currency(c.at("actual", default: 0) - c.at("budgeted", default: 0)),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No category data available.")
}

#pagebreak(weak: true)
// Monthly Burn Rate
= Monthly Burn Rate

#section-intro[
  Planned versus actual monthly expenditure over the reporting period. Divergence from the planned line may indicate scope changes, delays, or accelerated spend.
]

#if data.at("monthly_burn", default: ()).len() > 0 {
  line-chart(
    title: "Monthly Burn — Planned vs Actual",
    data: (
      ("Planned", data.monthly_burn.enumerate().map(((i, m)) => (i, m.at("planned", default: 0)))),
      ("Actual", data.monthly_burn.enumerate().map(((i, m)) => (i, m.at("actual", default: 0)))),
    ),
    width: 14cm,
    height: 6cm,
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No monthly burn data available.")
}

#pagebreak(weak: true)
// Forecast Table
= Forecast

#section-intro[
  Month-by-month forecast showing planned spend, actual spend, and variance. Negative variance indicates under-spend; positive indicates over-spend.
]

#if data.at("forecast", default: ()).len() > 0 {
  data-table(
    headers: ("Month", "Planned", "Actual", "Variance"),
    rows: data.forecast.map(f => (
      f.at("month", default: "—"),
      fmt-currency(f.at("planned", default: 0)),
      fmt-currency(f.at("actual", default: 0)),
      fmt-currency(f.at("variance", default: 0)),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No forecast data available.")
}

#pagebreak(weak: true)
// Cost Breakdown
= Cost Breakdown

#section-intro[
  Proportional distribution of total spend across cost categories.
]

#if data.at("cost_breakdown", default: ()).len() > 0 {
  pie-chart(
    title: "Cost Breakdown by Category",
    data: data.cost_breakdown.map(c => (c.at("category", default: "Unknown"), c.at("amount", default: 0))),
    width: 8cm,
    height: 8cm,
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No cost breakdown data available.")
}
