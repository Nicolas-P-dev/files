// Risk Register Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "total_risks": number,
//   "high_risks": number,
//   "medium_risks": number,
//   "low_risks": number,
//   "mitigated_count": number,
//   "risks": [
//     {
//       "id": "string",
//       "description": "string",
//       "category": "Technical|Schedule|Resource|External|Financial",
//       "likelihood": number (1-5),
//       "impact": number (1-5),
//       "score": number,
//       "owner": "string",
//       "mitigation": "string",
//       "status": "Open|Mitigated|Closed|Accepted",
//       "due_date": "string",
//       "label": "string (short 2-3 word label for matrix)"
//     }
//   ],
//   "risk_trend": [{"period": "string", "high": number, "medium": number, "low": number}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Risk Register Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// ── Risk Overview ──────────────────────────────────────────────────
= Risk Overview

#section-intro[
  This report provides a comprehensive view of all identified risks for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Risks are assessed by likelihood and impact, and tracked through mitigation to closure.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Total Risks",
    str(data.at("total_risks", default: 0)),
  ),
  kpi-card(
    "High Risks",
    str(data.at("high_risks", default: 0)),
    color: "red",
  ),
  kpi-card(
    "Medium Risks",
    str(data.at("medium_risks", default: 0)),
    color: "orange",
  ),
  kpi-card(
    "Low Risks",
    str(data.at("low_risks", default: 0)),
    color: "green",
  ),
  kpi-card(
    "Mitigated",
    str(data.at("mitigated_count", default: 0)),
    color: "green",
  ),
)

#pagebreak(weak: true)
// ── Risk Matrix ────────────────────────────────────────────────────
= Risk Matrix

#section-intro[
  The risk matrix plots all open and accepted risks by likelihood (vertical) and impact (horizontal). Higher scores appear in darker cells, indicating greater urgency for mitigation action.
]

#v(4mm)

#risk-matrix(
  risks: data.at("risks", default: ()).filter(r =>
    r.at("status", default: "") == "Open" or r.at("status", default: "") == "Accepted"
  ).map(r => (
    name: r.at("label", default: r.at("id", default: "")),
    likelihood: r.at("likelihood", default: 1),
    impact: r.at("impact", default: 1),
  )),
)

#pagebreak(weak: true)
// ── Risk Trend ─────────────────────────────────────────────────────
= Risk Trend

#section-intro[
  Trend of risk counts by severity over recent periods. A declining high-risk count indicates improving project risk posture.
]

#v(4mm)

#if data.at("risk_trend", default: ()).len() > 0 {
  line-chart(
    title: "Risk Count Trend",
    data: (
      ("High", data.risk_trend.enumerate().map(((i, t)) => (i, t.at("high", default: 0)))),
      ("Medium", data.risk_trend.enumerate().map(((i, t)) => (i, t.at("medium", default: 0)))),
      ("Low", data.risk_trend.enumerate().map(((i, t)) => (i, t.at("low", default: 0)))),
    ),
    width: 14cm,
    height: 6cm,
    colors: (brand-red, brand-orange, brand-green-4),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No risk trend data available.")
}

#pagebreak(weak: true)
// ── Full Risk Register ─────────────────────────────────────────────
= Full Risk Register

#section-intro[
  Complete listing of all #str(data.at("risks", default: ()).len()) identified risks with likelihood, impact, ownership, and mitigation details.
]

#v(4mm)

#if data.at("risks", default: ()).len() > 0 {
  status-table(
    headers: ("ID", "Description", "Category", "L", "I", "Score", "Owner", "Mitigation", "Status", "Due Date"),
    rows: data.risks.map(r => (
      r.at("id", default: "—"),
      r.at("description", default: ""),
      r.at("category", default: ""),
      str(r.at("likelihood", default: 0)),
      str(r.at("impact", default: 0)),
      str(r.at("score", default: 0)),
      r.at("owner", default: "Unassigned"),
      r.at("mitigation", default: ""),
      r.at("status", default: "Open"),
      r.at("due_date", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No risks identified.")
}
