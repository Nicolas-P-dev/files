// Portfolio Dashboard — Executive overview of all projects in a portfolio
// Expected data schema (JSON):
// {
//   "portfolio_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...],
//   "total_projects": number,
//   "on_track_count": number,
//   "at_risk_count": number,
//   "off_track_count": number,
//   "projects": [
//     {
//       "name": "string",
//       "key": "string",
//       "status": "Green|Amber|Red",
//       "health_pct": number,
//       "velocity": number,
//       "velocity_trend": number,
//       "blocker_count": number,
//       "next_milestone": "string",
//       "next_milestone_date": "string",
//       "budget_status": "On Track|At Risk|Over Budget",
//       "pm": "string"
//     }
//   ],
//   "portfolio_risks": [{"project": "string", "risk": "string", "impact": "High|Medium|Low", "status": "Open|Mitigated"}],
//   "upcoming_milestones": [{"project": "string", "milestone": "string", "date": "string", "status": "On Track|At Risk|Complete"}]
// }

#import "../lib/brand.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("portfolio_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Portfolio Dashboard",
  subtitle: data.at("portfolio_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// ── Portfolio Summary ─────────────────────────────────────────
= Portfolio Summary

#section-intro[
  Executive overview of #text(weight: "semibold", data.at("portfolio_name", default: "the portfolio")) as of #data.at("report_date", default: "today").
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#{
  let total = data.at("total_projects", default: 0)
  let on-track = data.at("on_track_count", default: 0)
  let at-risk = data.at("at_risk_count", default: 0)
  let off-track = data.at("off_track_count", default: 0)

  kpi-row(
    kpi-card(
      "Total Projects",
      str(total),
      color: auto,
    ),
    kpi-card(
      "On Track",
      str(on-track),
      color: "green",
    ),
    kpi-card(
      "At Risk",
      str(at-risk),
      color: "orange",
    ),
    kpi-card(
      "Off Track",
      str(off-track),
      color: "red",
    ),
  )
}

#v(6mm)

#pagebreak(weak: true)

// ── Project Status Overview ───────────────────────────────────
= Project Status Overview

#section-intro[
  Detailed status of each project within the portfolio, including health, velocity, blockers, and budget tracking.
]

#{
  let projects = data.at("projects", default: ())
  if projects.len() > 0 {
    let rows = projects.map(p => {
      let status = p.at("status", default: "—")
      let vel = p.at("velocity", default: 0)
      let trend = p.at("velocity_trend", default: 0)
      let trend-arrow = if trend > 0 {
        "▲" + str(trend) + "%"
      } else if trend < 0 {
        "▼" + str(calc.abs(trend)) + "%"
      } else {
        "—"
      }
      let vel-str = str(vel) + " " + trend-arrow
      (
        p.at("name", default: "—"),
        p.at("pm", default: "—"),
        status,
        str(p.at("health_pct", default: 0)) + "%",
        vel-str,
        str(p.at("blocker_count", default: 0)),
        p.at("budget_status", default: "—"),
        p.at("next_milestone", default: "—") + " (" + p.at("next_milestone_date", default: "—") + ")",
      )
    })

    // Use data-table with manual status badge rendering for Status column (index 2)
    data-table(
      headers: ("Project", "PM", "Status", "Health", "Velocity", "Blockers", "Budget", "Next Milestone"),
      rows: rows,
      status-col: 2,
    )
  } else {
    text(size: 9pt, fill: brand-gray-mid, style: "italic", "No projects found in this portfolio.")
  }
}

#v(6mm)

#pagebreak(weak: true)

// ── Cross-Project Risks ───────────────────────────────────────
= Cross-Project Risks

#if data.at("portfolio_risks", default: ()).len() > 0 {
  section-intro[#str(data.portfolio_risks.len()) portfolio-level risk(s) requiring executive attention.]
  status-table(
    headers: ("Project", "Risk", "Impact", "Status"),
    rows: data.portfolio_risks.map(r => (
      r.at("project", default: "—"),
      r.at("risk", default: "—"),
      r.at("impact", default: "—"),
      r.at("status", default: "Open"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No cross-project risks identified.")
}

#v(6mm)

#pagebreak(weak: true)

// ── Upcoming Milestones ───────────────────────────────────────
= Upcoming Milestones

#if data.at("upcoming_milestones", default: ()).len() > 0 {
  section-intro[Key milestones across the portfolio and their current tracking status.]
  status-table(
    headers: ("Project", "Milestone", "Date", "Status"),
    rows: data.upcoming_milestones.map(m => (
      m.at("project", default: "—"),
      m.at("milestone", default: "—"),
      m.at("date", default: "—"),
      m.at("status", default: "—"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No upcoming milestones defined.")
}
