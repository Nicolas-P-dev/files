// Stakeholder & RACI Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...] (optional — executive summary bullets),
//   "team_size": number,
//   "roles_breakdown": [{"role": "string", "count": number}, ...],
//   "team_members": [{"name": "string", "role": "string", "organization": "string", "email": "string", "allocation_pct": number}, ...],
//   "raci_matrix": {
//     "activities": ["string", ...],
//     "stakeholders": ["string", ...],
//     "matrix": [["R|A|C|I|", ...], ...]
//   },
//   "communication_plan": [{"audience": "string", "method": "string", "frequency": "string", "owner": "string", "purpose": "string"}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Stakeholder & RACI Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

#pagebreak(weak: true)
// Team Overview
= Team Overview

#section-intro[
  Overview of team composition for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). This section highlights team size, role distribution, and key takeaways.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Team Size",
    str(data.at("team_size", default: 0)),
  ),
)

#v(6mm)

#if data.at("roles_breakdown", default: ()).len() > 0 {
  [== Roles Breakdown]
  section-intro[Distribution of team members across functional roles.]
  pie-chart(
    title: "",
    data: data.roles_breakdown.map(r => (r.at("role", default: "Unknown"), r.at("count", default: 0))),
    width: 12cm,
    height: 10cm,
  )
}

#pagebreak(weak: true)
// Team Roster
= Team Roster

#section-intro[
  Complete list of team members, their roles, organizations, and allocation percentages.
]

#if data.at("team_members", default: ()).len() > 0 {
  data-table(
    headers: ("Name", "Role", "Organization", "Email", "Allocation %"),
    rows: data.team_members.map(m => (
      m.at("name", default: "—"),
      m.at("role", default: "—"),
      m.at("organization", default: "—"),
      m.at("email", default: "—"),
      str(m.at("allocation_pct", default: 0)) + "%",
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No team members listed.")
}

#pagebreak(weak: true)
// RACI Matrix
= RACI Matrix

#section-intro[
  Responsibility Assignment Matrix mapping activities to stakeholders. R = Responsible, A = Accountable, C = Consulted, I = Informed.
]

#if data.at("raci_matrix", default: none) != none {
  let raci = data.raci_matrix
  let activities = raci.at("activities", default: ())
  let stakeholders = raci.at("stakeholders", default: ())
  let matrix = raci.at("matrix", default: ())

  // Color code RACI cells
  let raci-color(val) = {
    if val == "R" { brand-green-primary }
    else if val == "A" { brand-green-deep }
    else if val == "C" { status-at-risk }
    else if val == "I" { brand-gray-mid }
    else { white }
  }

  let raci-fg(val) = {
    if val == "R" { brand-black }
    else if val == "A" { brand-white }
    else if val == "C" { brand-black }
    else if val == "I" { brand-white }
    else { brand-black }
  }

  let n-cols = stakeholders.len() + 1

  table(
    columns: (2fr, ..stakeholders.map(_ => 1fr)),
    stroke: 0.5pt + brand-gray-200,
    inset: (x: 8pt, y: 6pt),
    // Header row
    table.cell(fill: brand-black, text(size: 8pt, weight: "semibold", fill: brand-white, "Activity")),
    ..stakeholders.map(s =>
      table.cell(fill: brand-black, text(size: 8pt, weight: "semibold", fill: brand-white, s))
    ),
    // Data rows
    ..activities.enumerate().map(((ri, activity)) => {
      let row-cells = matrix.at(ri, default: ())
      (
        table.cell(
          fill: if calc.rem(ri, 2) == 0 { brand-white } else { brand-gray-light },
          text(size: 8pt, fill: brand-black, activity),
        ),
        ..stakeholders.enumerate().map(((ci, _stakeholder)) => {
          let val = row-cells.at(ci, default: "")
          table.cell(
            fill: if val != "" { raci-color(val).lighten(70%) } else { if calc.rem(ri, 2) == 0 { brand-white } else { brand-gray-light } },
            align(center, {
              if val != "" {
                box(
                  fill: raci-color(val),
                  radius: 3pt,
                  inset: (x: 6pt, y: 3pt),
                  text(size: 8pt, weight: "bold", fill: raci-fg(val), val),
                )
              }
            }),
          )
        }),
      )
    }).flatten(),
  )

  v(4mm)

  // Legend
  callout[
    #grid(
      columns: (auto, auto, auto, auto),
      column-gutter: 16pt,
      row-gutter: 6pt,
      box(fill: brand-green-primary, radius: 3pt, inset: (x: 6pt, y: 3pt), text(size: 8pt, weight: "bold", fill: brand-black, "R")),
      text(size: 8pt, fill: brand-gray-dark, "Responsible — does the work"),
      box(fill: brand-green-deep, radius: 3pt, inset: (x: 6pt, y: 3pt), text(size: 8pt, weight: "bold", fill: brand-white, "A")),
      text(size: 8pt, fill: brand-gray-dark, "Accountable — owns the outcome"),
      box(fill: status-at-risk, radius: 3pt, inset: (x: 6pt, y: 3pt), text(size: 8pt, weight: "bold", fill: brand-black, "C")),
      text(size: 8pt, fill: brand-gray-dark, "Consulted — provides input"),
      box(fill: brand-gray-mid, radius: 3pt, inset: (x: 6pt, y: 3pt), text(size: 8pt, weight: "bold", fill: brand-white, "I")),
      text(size: 8pt, fill: brand-gray-dark, "Informed — kept in the loop"),
    )
  ]
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No RACI matrix data available.")
}

#pagebreak(weak: true)
// Communication Plan
= Communication Plan

#section-intro[
  Planned communication touchpoints, their frequency, and intended audience. Ensures all stakeholders receive timely and relevant project updates.
]

#if data.at("communication_plan", default: ()).len() > 0 {
  data-table(
    headers: ("Audience", "Method", "Frequency", "Owner", "Purpose"),
    rows: data.communication_plan.map(c => (
      c.at("audience", default: "—"),
      c.at("method", default: "—"),
      c.at("frequency", default: "—"),
      c.at("owner", default: "—"),
      c.at("purpose", default: "—"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No communication plan defined.")
}
