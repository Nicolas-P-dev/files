// Steering Committee Executive 1-Pager
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "overall_status": "Green|Amber|Red",
//   "overall_status_summary": "string (1-2 sentence executive summary)",
//   "key_takeaways": ["string", ...],
//   "kpis": {
//     "budget_status": "On Track|At Risk|Over Budget",
//     "budget_variance_pct": number,
//     "schedule_status": "On Track|At Risk|Delayed",
//     "schedule_variance_days": number,
//     "scope_status": "Stable|Minor Changes|Major Changes",
//     "quality_status": "Good|Acceptable|Poor"
//   },
//   "top_risks": [{"description": "string", "impact": "High|Medium|Low", "likelihood": "High|Medium|Low", "mitigation": "string", "status": "Open|Mitigated"}],
//   "decisions_needed": [{"description": "string", "deadline": "string", "impact": "string", "recommended_action": "string"}],
//   "next_milestones": [{"milestone": "string", "date": "string", "status": "On Track|At Risk|Complete", "owner": "string"}],
//   "accomplishments": ["string", ...]
// }

#import "../lib/brand.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Steering Committee Brief",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// ── Executive Status ────────────────────────────────────────────
= Executive Status

#section-intro[
  Overall project status for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today").
]

#{
  let status = data.at("overall_status", default: "Green")
  let accent = if lower(status) == "green" { brand-green-primary }
               else if lower(status) == "amber" { status-at-risk }
               else if lower(status) == "red" { status-off-track }
               else { brand-gray-mid }
  let bg = if lower(status) == "green" { brand-green-pale }
           else if lower(status) == "amber" { brand-orange.lighten(85%) }
           else if lower(status) == "red" { brand-red.lighten(88%) }
           else { brand-gray-light }
  callout(accent: accent, bg: bg)[
    #grid(
      columns: (auto, 1fr),
      column-gutter: 14pt,
      align: (center + horizon, left + horizon),
      box(
        width: 48pt,
        height: 48pt,
        radius: 24pt,
        fill: accent,
        align(center + horizon, text(size: 18pt, weight: "bold", fill: brand-white, upper(status))),
      ),
      block({
        text(size: 12pt, weight: "bold", fill: accent, "Overall Status: " + status)
        v(4pt)
        text(size: 9pt, fill: brand-black, data.at("overall_status_summary", default: ""))
      }),
    )
  ]
}

#v(6mm)

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

// ── Key Performance Indicators ──────────────────────────────────
= Key Performance Indicators

#section-intro[
  Summary of budget, schedule, scope, and quality health indicators.
]

#{
  let kpis = data.at("kpis", default: (:))

  let budget-color = {
    let s = lower(kpis.at("budget_status", default: ""))
    if s == "on track" { "green" } else if s == "at risk" { "orange" } else { "red" }
  }
  let schedule-color = {
    let s = lower(kpis.at("schedule_status", default: ""))
    if s == "on track" { "green" } else if s == "at risk" { "orange" } else { "red" }
  }
  let scope-color = {
    let s = lower(kpis.at("scope_status", default: ""))
    if s == "stable" { "green" } else if s == "minor changes" { "orange" } else { "red" }
  }
  let quality-color = {
    let s = lower(kpis.at("quality_status", default: ""))
    if s == "good" { "green" } else if s == "acceptable" { "orange" } else { "red" }
  }

  kpi-row(
    kpi-card(
      "Budget",
      kpis.at("budget_status", default: "—"),
      sub-label: if kpis.at("budget_variance_pct", default: none) != none { str(kpis.at("budget_variance_pct", default: 0)) + "% variance" },
      color: budget-color,
    ),
    kpi-card(
      "Schedule",
      kpis.at("schedule_status", default: "—"),
      sub-label: if kpis.at("schedule_variance_days", default: none) != none { str(kpis.at("schedule_variance_days", default: 0)) + " days variance" },
      color: schedule-color,
    ),
    kpi-card(
      "Scope",
      kpis.at("scope_status", default: "—"),
      color: scope-color,
    ),
    kpi-card(
      "Quality",
      kpis.at("quality_status", default: "—"),
      color: quality-color,
    ),
  )
}

#v(6mm)

// ── Key Accomplishments ─────────────────────────────────────────
= Key Accomplishments

#if data.at("accomplishments", default: ()).len() > 0 {
  callout[
    #for item in data.accomplishments {
      grid(
        columns: (14pt, 1fr),
        column-gutter: 4pt,
        text(size: 9pt, fill: brand-green-4, "✓"),
        text(size: 9pt, fill: brand-black, item),
      )
      v(3pt)
    }
  ]
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No accomplishments recorded for this period.")
}

#v(6mm)

// ── Top Risks ───────────────────────────────────────────────────
= Top Risks

#if data.at("top_risks", default: ()).len() > 0 {
  section-intro[#str(data.top_risks.len()) risk(s) requiring steering committee awareness.]
  status-table(
    headers: ("Description", "Impact", "Likelihood", "Mitigation", "Status"),
    rows: data.top_risks.map(r => (
      r.at("description", default: "—"),
      r.at("impact", default: "—"),
      r.at("likelihood", default: "—"),
      r.at("mitigation", default: "—"),
      r.at("status", default: "Open"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No risks escalated to steering committee level.")
}

#v(6mm)

// ── Decisions Required ──────────────────────────────────────────
= Decisions Required

#if data.at("decisions_needed", default: ()).len() > 0 {
  callout(accent: brand-orange, bg: brand-orange.lighten(90%))[
    #text(size: 9pt, weight: "semibold", fill: brand-orange, "⚠ " + str(data.decisions_needed.len()) + " decision(s) require steering committee input.")
  ]
  v(4mm)
  data-table(
    headers: ("Description", "Deadline", "Impact", "Recommended Action"),
    rows: data.decisions_needed.map(d => (
      d.at("description", default: "—"),
      d.at("deadline", default: "—"),
      d.at("impact", default: "—"),
      d.at("recommended_action", default: "—"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No decisions pending at this time.")
}

#v(6mm)

// ── Next Milestones ─────────────────────────────────────────────
= Next Milestones

#if data.at("next_milestones", default: ()).len() > 0 {
  section-intro[Upcoming milestones and their current tracking status.]
  status-table(
    headers: ("Milestone", "Date", "Status", "Owner"),
    rows: data.next_milestones.map(m => (
      m.at("milestone", default: "—"),
      m.at("date", default: "—"),
      m.at("status", default: "—"),
      m.at("owner", default: "—"),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No upcoming milestones defined.")
}
