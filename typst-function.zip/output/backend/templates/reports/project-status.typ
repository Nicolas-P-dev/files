// Project Status Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "project_key": "string",
//   "report_date": "string",
//   "author": "string",
//   "open_issues": number,
//   "issue_trend": number (percentage, positive = increasing),
//   "sprint_health": "string (e.g. '85%')",
//   "sprint_status_color": "green|orange|red",
//   "velocity": number,
//   "velocity_trend": number (percentage),
//   "blocker_count": number,
//   "current_sprint": "string",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "burndown": [{"day": "string", "remaining": number}, ...],
//   "blockers": [{"key": "string", "summary": "string", "assignee": "string", "status": "string", "days_blocked": number}, ...],
//   "issues_by_status": [{"status": "string", "count": number}, ...],
//   "issues_by_type": [{"type": "string", "count": number}, ...],
//   "timeline": [{"name": "string", "start": "YYYY-MM-DD", "end": "YYYY-MM-DD", "status": "string", "progress": number}, ...],
//   "recent_completions": [{"key": "string", "summary": "string", "completed_date": "string"}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/gantt.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Project Status Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
  project-id: data.at("project_key", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Executive Summary
= Executive Summary

#section-intro[
  This report provides a snapshot of project health for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Key metrics, active blockers, and timeline progress are summarized below.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Open Issues",
    str(data.at("open_issues", default: 0)),
    trend: data.at("issue_trend", default: none),
  ),
  kpi-card(
    "Sprint Health",
    data.at("sprint_health", default: "—"),
    color: data.at("sprint_status_color", default: auto),
  ),
  kpi-card(
    "Velocity",
    str(data.at("velocity", default: 0)) + " SP",
    trend: data.at("velocity_trend", default: none),
  ),
  kpi-card(
    "Blockers",
    str(data.at("blocker_count", default: 0)),
    color: if data.at("blocker_count", default: 0) > 0 { "red" } else { "green" },
  ),
)

#v(6mm)

#if data.at("issues_by_status", default: ()).len() > 0 {
  [== Issues by Status]
  section-intro[Distribution of open issues across workflow states.]
  bar-chart(
    title: "",
    data: data.issues_by_status.map(i => (i.at("status", default: "Unknown"), i.at("count", default: 0))),
    width: 14cm,
    height: 6cm,
  )
}

#pagebreak(weak: true)
// Sprint Progress
= Sprint Progress

#section-intro[
  Burndown chart for #text(weight: "semibold", data.at("current_sprint", default: "the current sprint")). The dashed line shows ideal progress; deviations indicate scope changes or velocity shifts.
]

#burndown-chart(
  data: data.at("burndown", default: ()).map(b => (b.at("day", default: ""), b.at("remaining", default: 0))),
  sprint-name: data.at("current_sprint", default: ""),
)

#pagebreak(weak: true)
// Blockers
= Current Blockers

#if data.at("blockers", default: ()).len() > 0 {
  section-intro[#str(data.blockers.len()) active blocker(s) requiring attention. Items are ordered by days blocked.]
  status-table(
    headers: ("Key", "Summary", "Assignee", "Status", "Days Blocked"),
    rows: data.blockers.map(b => (
      b.at("key", default: "—"),
      b.at("summary", default: ""),
      b.at("assignee", default: "Unassigned"),
      b.at("status", default: "Blocked"),
      str(b.at("days_blocked", default: 0)),
    )),
  )
} else {
  callout[No active blockers identified. All work items are progressing as expected.]
}

// Recent Completions
= Recent Completions

#if data.at("recent_completions", default: ()).len() > 0 {
  section-intro[#str(data.recent_completions.len()) item(s) completed recently.]
  data-table(
    headers: ("Key", "Summary", "Completed"),
    rows: data.recent_completions.map(r => (
      r.at("key", default: "—"),
      r.at("summary", default: ""),
      r.at("completed_date", default: ""),
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No recent completions.")
}

#pagebreak(weak: true)
// Timeline
= Project Timeline

#section-intro[
  Gantt chart showing workstream progress. Bar fill indicates completion percentage; color indicates status.
]

#if data.at("timeline", default: ()).len() > 0 {
  gantt-chart(tasks: data.timeline)
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No timeline data available.")
}
