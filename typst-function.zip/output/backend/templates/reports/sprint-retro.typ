// Sprint Retrospective Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "sprint_name": "string",
//   "sprint_dates": "string (e.g. 'Mar 10 – Mar 21, 2026')",
//   "velocity": number,
//   "completion_rate": number (percentage),
//   "carry_over_points": number,
//   "committed_points": number,
//   "completed_points": number,
//   "team_size": number,
//   "sentiment_score": number (1-5 scale),
//   "key_takeaways": ["string", ...],
//   "went_well": ["string", ...],
//   "didnt_go_well": ["string", ...],
//   "action_items": [{"action": "string", "owner": "string", "due_date": "string", "status": "open|in-progress|done"}, ...],
//   "previous_actions": [{"action": "string", "owner": "string", "status": "done|carried-over", "outcome": "string"}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Sprint Retrospective",
  subtitle: data.at("sprint_name", default: "") + " — " + data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Sprint Summary
= Sprint Summary

#section-intro[
  Retrospective summary for #text(weight: "semibold", data.at("sprint_name", default: "the sprint")) (#data.at("sprint_dates", default: "")). The team committed #str(data.at("committed_points", default: 0)) story points and completed #str(data.at("completed_points", default: 0)).
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(4mm)
}

#kpi-row(
  kpi-card(
    "Sprint",
    data.at("sprint_name", default: "—"),
  ),
  kpi-card(
    "Velocity",
    str(data.at("velocity", default: 0)) + " SP",
    color: "green",
  ),
  kpi-card(
    "Completion",
    str(data.at("completion_rate", default: 0)) + "%",
    color: if data.at("completion_rate", default: 0) >= 80 { "on-track" } else if data.at("completion_rate", default: 0) >= 60 { "at-risk" } else { "off-track" },
  ),
  kpi-card(
    "Sentiment",
    str(data.at("sentiment_score", default: 0)) + " / 5",
    color: if data.at("sentiment_score", default: 0) >= 4 { "on-track" } else if data.at("sentiment_score", default: 0) >= 3 { "at-risk" } else { "off-track" },
  ),
  kpi-card(
    "Carry-over",
    str(data.at("carry_over_points", default: 0)) + " SP",
    color: if data.at("carry_over_points", default: 0) <= 3 { "green" } else { "orange" },
  ),
)

#v(4mm)

// What Went Well
= What Went Well

#if data.at("went_well", default: ()).len() > 0 {
  section-intro[Items the team identified as positive outcomes during this sprint.]
  callout(accent: status-on-track, bg: brand-green-pale, {
    text(size: 10pt, weight: "semibold", fill: brand-green-deep, "WHAT WENT WELL")
    v(6pt)
    for item in data.at("went_well", default: ()) {
      grid(
        columns: (14pt, 1fr),
        column-gutter: 4pt,
        text(size: 9pt, fill: brand-green-4, "•"),
        text(size: 9pt, fill: brand-black, item),
      )
      v(3pt)
    }
  })
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No items recorded.")
}

#v(4mm)

// What Didn't Go Well
= What Didn't Go Well

#if data.at("didnt_go_well", default: ()).len() > 0 {
  section-intro[Areas the team identified for improvement.]
  callout(accent: status-at-risk, bg: brand-orange.lighten(90%), {
    text(size: 10pt, weight: "semibold", fill: status-off-track, "WHAT DIDN'T GO WELL")
    v(6pt)
    for item in data.at("didnt_go_well", default: ()) {
      grid(
        columns: (14pt, 1fr),
        column-gutter: 4pt,
        text(size: 9pt, fill: status-at-risk, "•"),
        text(size: 9pt, fill: brand-black, item),
      )
      v(3pt)
    }
  })
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No items recorded.")
}

#pagebreak(weak: true)
// Action Items
= Action Items

#if data.at("action_items", default: ()).len() > 0 {
  section-intro[Actions agreed upon during the retrospective to address improvement areas.]
  data-table(
    headers: ("Action", "Owner", "Due Date", "Status"),
    status-col: 3,
    rows: data.at("action_items", default: ()).map(a => (
      a.at("action", default: "—"),
      a.at("owner", default: "Unassigned"),
      a.at("due_date", default: "—"),
      a.at("status", default: "open"),
    )),
  )
} else {
  callout[No action items recorded for this retrospective.]
}

#v(4mm)

// Previous Action Items
= Previous Action Items

#if data.at("previous_actions", default: ()).len() > 0 {
  section-intro[Follow-up on action items from the previous retrospective.]
  data-table(
    headers: ("Action", "Owner", "Status", "Outcome"),
    status-col: 2,
    rows: data.at("previous_actions", default: ()).map(a => (
      a.at("action", default: "—"),
      a.at("owner", default: "Unassigned"),
      a.at("status", default: "—"),
      a.at("outcome", default: ""),
    )),
  )
} else {
  callout[No previous action items to follow up on.]
}

#v(4mm)

// Team Sentiment
= Team Sentiment

#section-intro[
  The team sentiment score reflects overall morale and satisfaction collected during the retrospective.
]

#{
  let score = data.at("sentiment_score", default: 0)
  let meaning = if score >= 5 { "Excellent — the team feels highly motivated and aligned." } else if score >= 4 { "Good — the team is generally positive with minor concerns." } else if score >= 3 { "Neutral — the team has mixed feelings; some areas need attention." } else if score >= 2 { "Low — the team is experiencing frustration or disengagement." } else { "Critical — significant morale issues require immediate action." }
  let accent = if score >= 4 { status-on-track } else if score >= 3 { status-at-risk } else { status-off-track }

  callout(accent: accent, bg: if score >= 4 { brand-green-pale } else if score >= 3 { brand-orange.lighten(90%) } else { brand-red.lighten(92%) }, {
    text(size: 10pt, weight: "semibold", fill: accent, "SENTIMENT: " + str(score) + " / 5")
    v(6pt)
    text(size: 9pt, fill: brand-black, meaning)
    v(4pt)
    text(size: 8pt, fill: brand-gray-mid, "Team size: " + str(data.at("team_size", default: 0)) + " members")
  })
}
