// Quality Metrics / Testing Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...],
//   "total_tests": number,
//   "pass_rate": number (percentage),
//   "defect_count": number,
//   "escaped_defects": number,
//   "test_execution": [{"status": "Passed|Failed|Skipped|Blocked", "count": number}, ...],
//   "defects_by_severity": [{"severity": "Critical|High|Medium|Low", "count": number}, ...],
//   "defect_trend": [{"period": "string", "opened": number, "closed": number}, ...],
//   "coverage_by_module": [{"module": "string", "total_tests": number, "passed": number, "failed": number, "coverage_pct": number}, ...],
//   "open_defects": [{"key": "string", "summary": "string", "severity": "string", "assignee": "string", "age_days": number, "status": "string"}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Quality Metrics Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Quality Overview
= Quality Overview

#section-intro[
  This report summarises testing outcomes and defect metrics for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Key quality indicators, test execution results, and open defect details are presented below.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Total Tests",
    str(data.at("total_tests", default: 0)),
  ),
  kpi-card(
    "Pass Rate",
    str(data.at("pass_rate", default: 0)) + "%",
    color: if data.at("pass_rate", default: 0) >= 95 { "green" } else if data.at("pass_rate", default: 0) >= 85 { "orange" } else { "red" },
  ),
  kpi-card(
    "Defect Count",
    str(data.at("defect_count", default: 0)),
  ),
  kpi-card(
    "Escaped Defects",
    str(data.at("escaped_defects", default: 0)),
    color: if data.at("escaped_defects", default: 0) > 0 { "red" } else { "green" },
  ),
)

#pagebreak(weak: true)
// Test Execution
= Test Execution

#section-intro[
  Breakdown of test execution results by status. A healthy project targets >95% pass rate with minimal blocked or skipped tests.
]

#if data.at("test_execution", default: ()).len() > 0 {
  pie-chart(
    title: "Test Execution Results",
    data: data.test_execution.map(t => (t.at("status", default: "Unknown"), t.at("count", default: 0))),
    width: 12cm,
    height: 10cm,
    colors: (status-on-track, status-off-track, brand-gray-mid, status-at-risk),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No test execution data available.")
}

#pagebreak(weak: true)
// Defect Analysis
= Defect Analysis

#section-intro[
  Distribution of defects by severity. Critical and high severity defects should be prioritised for resolution.
]

#if data.at("defects_by_severity", default: ()).len() > 0 {
  bar-chart(
    title: "Defects by Severity",
    data: data.defects_by_severity.map(d => (d.at("severity", default: "Unknown"), d.at("count", default: 0))),
    width: 14cm,
    height: 6cm,
    colors: (brand-red, brand-red.lighten(20%), brand-red.lighten(40%), brand-red.lighten(60%)),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No defect severity data available.")
}

#pagebreak(weak: true)
// Defect Trend
= Defect Trend

#section-intro[
  Trend of defects opened versus closed over recent periods. A converging trend indicates the team is resolving defects faster than they are being raised.
]

#if data.at("defect_trend", default: ()).len() > 0 {
  line-chart(
    title: "Defect Trend — Opened vs Closed",
    data: (
      ("Opened", data.defect_trend.enumerate().map(((i, d)) => (i, d.at("opened", default: 0)))),
      ("Closed", data.defect_trend.enumerate().map(((i, d)) => (i, d.at("closed", default: 0)))),
    ),
    width: 14cm,
    height: 6cm,
    colors: (brand-red, brand-green-4),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No defect trend data available.")
}

#pagebreak(weak: true)
// Coverage by Module
= Coverage by Module

#section-intro[
  Test coverage and pass rates broken down by module. Modules with low coverage or high failure rates may require additional testing effort.
]

#if data.at("coverage_by_module", default: ()).len() > 0 {
  data-table(
    headers: ("Module", "Total Tests", "Passed", "Failed", "Coverage %"),
    rows: data.coverage_by_module.map(m => (
      m.at("module", default: "—"),
      str(m.at("total_tests", default: 0)),
      str(m.at("passed", default: 0)),
      str(m.at("failed", default: 0)),
      str(m.at("coverage_pct", default: 0)) + "%",
    )),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No module coverage data available.")
}

#pagebreak(weak: true)
// Open Defects
= Open Defects

#if data.at("open_defects", default: ()).len() > 0 {
  section-intro[#str(data.open_defects.len()) open defect(s) requiring attention. Items are ordered by severity and age.]
  status-table(
    headers: ("Key", "Summary", "Severity", "Assignee", "Age (Days)", "Status"),
    rows: data.open_defects.map(d => (
      d.at("key", default: "—"),
      d.at("summary", default: ""),
      d.at("severity", default: "—"),
      d.at("assignee", default: "Unassigned"),
      str(d.at("age_days", default: 0)),
      d.at("status", default: "Open"),
    )),
  )
} else {
  callout[No open defects. All identified issues have been resolved.]
}
