// Sprint Health Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "current_sprint": "string",
//   "sprint_goal": "string",
//   "days_remaining": number,
//   "total_days": number,
//   "committed_points": number,
//   "completed_points": number,
//   "remaining_points": number,
//   "scope_change": number (added/removed points mid-sprint),
//   "completion_rate": number (percentage),
//   "sprint_status": "on-track|at-risk|off-track",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "burndown": [{"day": "string", "remaining": number}, ...],
//   "velocity_history": [{"sprint": "string", "completed": number}, ...],
//   "issues_summary": {"total": number, "done": number, "in_progress": number, "todo": number, "blocked": number},
//   "carry_over": [{"key": "string", "summary": "string", "points": number, "reason": "string"}, ...],
//   "blockers": [{"key": "string", "summary": "string", "assignee": "string", "days_blocked": number}, ...],
//   "by_assignee": [{"name": "string", "total": number, "done": number}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Sprint Health Report",
  subtitle: data.at("current_sprint", default: "") + " — " + data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Sprint Overview
= Sprint Overview

#section-intro[
  Health summary for #text(weight: "semibold", data.at("current_sprint", default: "the current sprint")) as of #data.at("report_date", default: "today"). #str(data.at("days_remaining", default: 0)) days remaining of #str(data.at("total_days", default: 0)) total.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(4mm)
}

#kpi-row(
  kpi-card(
    "Sprint",
    data.at("current_sprint", default: "—"),
  ),
  kpi-card(
    "Days Remaining",
    str(data.at("days_remaining", default: 0)) + " / " + str(data.at("total_days", default: 0)),
    color: if data.at("days_remaining", default: 0) <= 2 { "orange" } else { "green" },
  ),
  kpi-card(
    "Completion",
    str(data.at("completion_rate", default: 0)) + "%",
    color: data.at("sprint_status", default: "green"),
  ),
  kpi-card(
    "Scope Change",
    if data.at("scope_change", default: 0) >= 0 { "+" + str(data.at("scope_change", default: 0)) + " SP" } else { str(data.at("scope_change", default: 0)) + " SP" },
    color: if data.at("scope_change", default: 0) > 0 { "orange" } else { "green" },
  ),
)

#v(4mm)

#if data.at("sprint_goal", default: "") != "" {
  callout(accent: brand-green-deep, bg: brand-teal-1, {
    text(size: 9pt, weight: "semibold", fill: brand-green-deep, "SPRINT GOAL")
    v(4pt)
    text(size: 10pt, fill: brand-black, data.at("sprint_goal", default: ""))
  })
}

// Points
= Story Points

#section-intro[Points committed, completed, and remaining for this sprint.]

#kpi-row(
  kpi-card("Committed", str(data.at("committed_points", default: 0)) + " SP"),
  kpi-card("Completed", str(data.at("completed_points", default: 0)) + " SP", color: "green"),
  kpi-card("Remaining", str(data.at("remaining_points", default: 0)) + " SP"),
)

#v(4mm)

// Issue Summary
#if data.at("issues_summary", default: none) != none {
  let iss = data.issues_summary
  bar-chart(
    title: "Issues by Status",
    data: (
      ("Done", iss.at("done", default: 0)),
      ("In Progress", iss.at("in_progress", default: 0)),
      ("To Do", iss.at("todo", default: 0)),
      ("Blocked", iss.at("blocked", default: 0)),
    ),
    width: 14cm,
    height: 5cm,
    colors: (status-on-track, status-at-risk, status-not-started, status-off-track),
  )
}

#pagebreak(weak: true)
// Burndown
= Burndown

#section-intro[Sprint burndown showing actual progress against the ideal line. Deviations indicate scope changes, blockers, or velocity shifts.]

#burndown-chart(
  data: data.at("burndown", default: ()).map(b => (b.at("day", default: ""), b.at("remaining", default: 0))),
  sprint-name: data.at("current_sprint", default: ""),
  total: data.at("committed_points", default: auto),
)

// Velocity Trend
= Velocity Trend

#section-intro[Completed story points across recent sprints. A consistent or rising trend indicates healthy team throughput.]

#if data.at("velocity_history", default: ()).len() > 0 {
  velocity-chart(
    data: data.velocity_history.map(v => (v.at("sprint", default: ""), v.at("completed", default: 0))),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No velocity history available.")
}

// Assignee Breakdown
= Work Distribution

#section-intro[Story point allocation and completion by team member.]

#if data.at("by_assignee", default: ()).len() > 0 {
  data-table(
    headers: ("Assignee", "Total Points", "Completed", "Remaining"),
    rows: {
      let rows = data.by_assignee.map(a => {
        let total = a.at("total", default: 0)
        let done = a.at("done", default: 0)
        (
          a.at("name", default: "—"),
          str(total),
          str(done),
          str(total - done),
        )
      })
      // Add total row
      let sum-total = data.by_assignee.map(a => a.at("total", default: 0)).sum()
      let sum-done = data.by_assignee.map(a => a.at("done", default: 0)).sum()
      rows + (
        (
          text(weight: "semibold", "TOTAL"),
          text(weight: "semibold", str(sum-total)),
          text(weight: "semibold", str(sum-done)),
          text(weight: "semibold", str(sum-total - sum-done)),
        ),
      )
    },
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No assignee data available.")
}

#pagebreak(weak: true)
// Blockers
= Blockers

#if data.at("blockers", default: ()).len() > 0 {
  section-intro[#str(data.blockers.len()) active blocker(s) requiring immediate attention.]
  data-table(
    headers: ("Key", "Summary", "Assignee", "Days Blocked"),
    rows: data.blockers.map(b => (
      b.at("key", default: "—"),
      b.at("summary", default: ""),
      b.at("assignee", default: "Unassigned"),
      str(b.at("days_blocked", default: 0)),
    )),
  )
} else {
  callout[No active blockers. All work items are progressing as expected.]
}

// Carry-over Risk
= Carry-over Risk

#if data.at("carry_over", default: ()).len() > 0 {
  section-intro[These items may not complete this sprint and risk carrying into the next.]
  data-table(
    headers: ("Key", "Summary", "Points", "Risk Reason"),
    rows: data.carry_over.map(c => (
      c.at("key", default: "—"),
      c.at("summary", default: ""),
      str(c.at("points", default: 0)),
      c.at("reason", default: ""),
    )),
  )
} else {
  callout[No carry-over risk items identified. Sprint scope is on track for completion.]
}
