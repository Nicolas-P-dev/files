// Change Request Summary Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "total_crs": number,
//   "approved_count": number,
//   "pending_count": number,
//   "rejected_count": number,
//   "change_requests": [
//     {
//       "id": "string",
//       "title": "string",
//       "requestor": "string",
//       "category": "Scope|Schedule|Budget|Technical",
//       "impact": "High|Medium|Low",
//       "effort_days": number,
//       "status": "Approved|Pending|Rejected|Under Review",
//       "decision_date": "string",
//       "description": "string"
//     }
//   ],
//   "impact_summary": {
//     "schedule_impact_days": number,
//     "budget_impact_pct": number,
//     "scope_change_description": "string"
//   }
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Change Request Summary",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Change Request Summary
= Change Request Summary

#section-intro[
  Overview of all change requests for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). This section highlights volume, approval status, and key decisions.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Total CRs",
    str(data.at("total_crs", default: 0)),
  ),
  kpi-card(
    "Approved",
    str(data.at("approved_count", default: 0)),
    color: "green",
  ),
  kpi-card(
    "Pending",
    str(data.at("pending_count", default: 0)),
    color: "orange",
  ),
  kpi-card(
    "Rejected",
    str(data.at("rejected_count", default: 0)),
    color: "red",
  ),
)

#v(6mm)

// Impact Summary
= Impact Summary

#section-intro[
  Aggregate impact of approved and pending change requests on schedule, budget, and scope.
]

#{
  let impact = data.at("impact_summary", default: (:))
  let sched = impact.at("schedule_impact_days", default: 0)
  let budget = impact.at("budget_impact_pct", default: 0)
  let scope-desc = impact.at("scope_change_description", default: "")

  if sched != 0 or budget != 0 or scope-desc != "" {
    callout(accent: brand-blue, bg: brand-blue-1.lighten(60%), {
      text(size: 10pt, weight: "bold", fill: brand-blue-dark, "IMPACT OVERVIEW")
      v(6pt)
      grid(
        columns: (auto, 1fr),
        column-gutter: 8pt,
        row-gutter: 8pt,
        text(size: 9pt, weight: "semibold", fill: brand-gray-dark, "Schedule Impact:"),
        text(size: 9pt, fill: brand-black, if sched > 0 { "+" + str(sched) + " days" } else if sched < 0 { str(sched) + " days" } else { "No change" }),
        text(size: 9pt, weight: "semibold", fill: brand-gray-dark, "Budget Impact:"),
        text(size: 9pt, fill: brand-black, if budget > 0 { "+" + str(budget) + "%" } else if budget < 0 { str(budget) + "%" } else { "No change" }),
        text(size: 9pt, weight: "semibold", fill: brand-gray-dark, "Scope Changes:"),
        text(size: 9pt, fill: brand-black, if scope-desc != "" { scope-desc } else { "None identified" }),
      )
    })
  } else {
    callout[No impact data available. Impact assessment is pending completion of change request reviews.]
  }
}

#pagebreak(weak: true)
// Change Requests
= Change Requests

#if data.at("change_requests", default: ()).len() > 0 {
  section-intro[#str(data.change_requests.len()) change request(s) recorded. The table below shows all requests with their current status and key details.]
  status-table(
    headers: ("ID", "Title", "Requestor", "Category", "Impact", "Effort (days)", "Status", "Decision Date"),
    rows: data.change_requests.map(cr => (
      cr.at("id", default: "—"),
      cr.at("title", default: ""),
      cr.at("requestor", default: "—"),
      cr.at("category", default: "—"),
      cr.at("impact", default: "—"),
      str(cr.at("effort_days", default: 0)),
      cr.at("status", default: "—"),
      cr.at("decision_date", default: "—"),
    )),
  )
} else {
  callout[No change requests have been submitted for this project.]
}
