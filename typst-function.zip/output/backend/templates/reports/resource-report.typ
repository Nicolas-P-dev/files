// Resource Allocation Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "team_size": number,
//   "avg_utilization": number (percentage),
//   "over_allocated_count": number,
//   "under_utilized_count": number,
//   "team_members": [
//     {"name": "string", "role": "string", "allocation_pct": number, "utilized_pct": number, "assigned_points": number, "completed_points": number}
//   ],
//   "allocation_by_role": [{"role": "string", "count": number}, ...],
//   "utilization_trend": [{"period": "string", "target_pct": number, "actual_pct": number}, ...],
//   "capacity_forecast": [{"sprint": "string", "available_points": number, "planned_points": number}, ...]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "Resource Allocation Report",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// Overview
= Resource Overview

#section-intro[
  Resource allocation and utilization summary for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Team capacity and workload distribution are detailed below.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(4mm)
}

#kpi-row(
  kpi-card(
    "Team Size",
    str(data.at("team_size", default: 0)),
  ),
  kpi-card(
    "Avg Utilization",
    str(data.at("avg_utilization", default: 0)) + "%",
    color: if data.at("avg_utilization", default: 0) >= 80 { "green" } else if data.at("avg_utilization", default: 0) >= 60 { "orange" } else { "red" },
  ),
  kpi-card(
    "Over-Allocated",
    str(data.at("over_allocated_count", default: 0)),
    color: if data.at("over_allocated_count", default: 0) > 0 { "red" } else { "green" },
  ),
  kpi-card(
    "Under-Utilized",
    str(data.at("under_utilized_count", default: 0)),
    color: if data.at("under_utilized_count", default: 0) > 2 { "orange" } else { "green" },
  ),
)

#v(6mm)

// Allocation by Role
= Allocation by Role

#if data.at("allocation_by_role", default: ()).len() > 0 {
  bar-chart(
    title: "",
    data: data.allocation_by_role.map(r => (r.at("role", default: ""), r.at("count", default: 0))),
    width: 14cm,
    height: 6cm,
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No role allocation data available.")
}

#pagebreak(weak: true)
// Team Member Breakdown
= Team Member Breakdown

#if data.at("team_members", default: ()).len() > 0 {
  data-table(
    headers: ("Name", "Role", "Allocation", "Utilization", "Points (Done / Assigned)"),
    rows: data.team_members.map(m => {
      let alloc = m.at("allocation_pct", default: 0)
      let util = m.at("utilized_pct", default: 0)
      let assigned = m.at("assigned_points", default: 0)
      let completed = m.at("completed_points", default: 0)
      (
        m.at("name", default: "—"),
        m.at("role", default: ""),
        str(alloc) + "%",
        str(util) + "%",
        str(completed) + " / " + str(assigned),
      )
    }),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No team member data available.")
}

#pagebreak(weak: true)
// Utilization Trend
= Utilization Trend

#if data.at("utilization_trend", default: ()).len() > 0 {
  line-chart(
    title: "",
    data: (
      ("Target", data.utilization_trend.enumerate().map(((i, t)) => (i, t.at("target_pct", default: 80)))),
      ("Actual", data.utilization_trend.enumerate().map(((i, t)) => (i, t.at("actual_pct", default: 0)))),
    ),
    width: 14cm,
    height: 6cm,
    colors: (brand-gray-mid, brand-green-primary),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No utilization trend data available.")
}

#v(8mm)

// Capacity Forecast
= Capacity Forecast

#if data.at("capacity_forecast", default: ()).len() > 0 {
  let forecasts = data.capacity_forecast
  data-table(
    headers: ("Sprint", "Available Points", "Planned Points", "Delta"),
    rows: forecasts.map(f => {
      let avail = f.at("available_points", default: 0)
      let planned = f.at("planned_points", default: 0)
      let delta = avail - planned
      (
        f.at("sprint", default: ""),
        str(avail),
        str(planned),
        if delta >= 0 { "+" + str(delta) } else { str(delta) },
      )
    }),
  )
} else {
  text(size: 9pt, fill: brand-gray-mid, style: "italic", "No capacity forecast data available.")
}
