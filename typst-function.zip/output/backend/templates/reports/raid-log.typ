// RAID Log Report
// Expected data schema (JSON):
// {
//   "project_name": "string",
//   "report_date": "string",
//   "author": "string",
//   "key_takeaways": ["string", ...] (optional — auto-generated executive bullets),
//   "risk_count": number,
//   "assumption_count": number,
//   "issue_count": number,
//   "dependency_count": number,
//   "risks": [{"id": "string", "description": "string", "likelihood": "High|Medium|Low", "impact": "High|Medium|Low", "owner": "string", "mitigation": "string", "status": "Open|Mitigated|Closed"}],
//   "assumptions": [{"id": "string", "description": "string", "owner": "string", "validation_date": "string", "status": "Valid|Invalid|Unvalidated"}],
//   "issues": [{"id": "string", "description": "string", "priority": "Critical|High|Medium|Low", "owner": "string", "raised_date": "string", "target_date": "string", "status": "Open|In Progress|Resolved"}],
//   "dependencies": [{"id": "string", "description": "string", "type": "Internal|External", "owner": "string", "required_date": "string", "status": "On Track|At Risk|Resolved|Blocked"}]
// }

#import "../lib/brand.typ": *
#import "../lib/charts.typ": *
#import "../lib/tables.typ": *
#import "../lib/kpis.typ": *
#import "../lib/layout.typ": *

#let data = json("data.json")

#show: brand-page.with(project-name: data.at("project_name", default: none), draft: data.at("draft", default: false))

// Cover
#cover-page(
  title: "RAID Log",
  subtitle: data.at("project_name", default: ""),
  date: data.at("report_date", default: ""),
  author: data.at("author", default: ""),
)

// Table of Contents
#outline(title: "Contents", depth: 2)

// RAID Summary
= RAID Summary

#section-intro[
  This report presents the consolidated Risks, Assumptions, Issues, and Dependencies (RAID) log for #text(weight: "semibold", data.at("project_name", default: "the project")) as of #data.at("report_date", default: "today"). Use this log to track and manage items that may affect project delivery.
]

#if data.at("key_takeaways", default: ()).len() > 0 {
  key-takeaways(data.key_takeaways)
  v(6mm)
}

#kpi-row(
  kpi-card(
    "Risks",
    str(data.at("risk_count", default: 0)),
    color: if data.at("risk_count", default: 0) > 3 { "red" } else if data.at("risk_count", default: 0) > 0 { "orange" } else { "green" },
  ),
  kpi-card(
    "Assumptions",
    str(data.at("assumption_count", default: 0)),
    color: if data.at("assumption_count", default: 0) > 5 { "orange" } else { auto },
  ),
  kpi-card(
    "Issues",
    str(data.at("issue_count", default: 0)),
    color: if data.at("issue_count", default: 0) > 3 { "red" } else if data.at("issue_count", default: 0) > 0 { "orange" } else { "green" },
  ),
  kpi-card(
    "Dependencies",
    str(data.at("dependency_count", default: 0)),
    color: if data.at("dependency_count", default: 0) > 4 { "orange" } else { auto },
  ),
)

#pagebreak(weak: true)
// Risks
= Risks

#if data.at("risks", default: ()).len() > 0 {
  section-intro[#str(data.risks.len()) risk(s) currently tracked. Open and high-impact risks should be reviewed each steering committee.]
  status-table(
    headers: ("ID", "Description", "Likelihood", "Impact", "Owner", "Mitigation", "Status"),
    rows: data.risks.map(r => (
      r.at("id", default: "—"),
      r.at("description", default: ""),
      r.at("likelihood", default: "—"),
      r.at("impact", default: "—"),
      r.at("owner", default: "Unassigned"),
      r.at("mitigation", default: ""),
      r.at("status", default: "Open"),
    )),
  )
} else {
  callout[No risks have been identified at this time.]
}

#pagebreak(weak: true)
// Assumptions
= Assumptions

#if data.at("assumptions", default: ()).len() > 0 {
  section-intro[#str(data.assumptions.len()) assumption(s) recorded. Assumptions should be validated regularly to avoid becoming risks.]
  data-table(
    headers: ("ID", "Description", "Owner", "Validation Date", "Status"),
    rows: data.assumptions.map(a => (
      a.at("id", default: "—"),
      a.at("description", default: ""),
      a.at("owner", default: "Unassigned"),
      a.at("validation_date", default: "—"),
      a.at("status", default: "Unvalidated"),
    )),
  )
} else {
  callout[No assumptions have been recorded at this time.]
}

#pagebreak(weak: true)
// Issues
= Issues

#if data.at("issues", default: ()).len() > 0 {
  section-intro[#str(data.issues.len()) issue(s) logged. Critical and high-priority items require immediate escalation and resolution.]
  status-table(
    headers: ("ID", "Description", "Priority", "Owner", "Raised", "Target Date", "Status"),
    rows: data.issues.map(i => (
      i.at("id", default: "—"),
      i.at("description", default: ""),
      i.at("priority", default: "—"),
      i.at("owner", default: "Unassigned"),
      i.at("raised_date", default: "—"),
      i.at("target_date", default: "—"),
      i.at("status", default: "Open"),
    )),
  )
} else {
  callout[No issues have been raised at this time.]
}

#pagebreak(weak: true)
// Dependencies
= Dependencies

#if data.at("dependencies", default: ()).len() > 0 {
  section-intro[#str(data.dependencies.len()) dependency/dependencies tracked. Blocked or at-risk dependencies may delay downstream deliverables.]
  status-table(
    headers: ("ID", "Description", "Type", "Owner", "Required Date", "Status"),
    rows: data.dependencies.map(d => (
      d.at("id", default: "—"),
      d.at("description", default: ""),
      d.at("type", default: "—"),
      d.at("owner", default: "Unassigned"),
      d.at("required_date", default: "—"),
      d.at("status", default: "On Track"),
    )),
  )
} else {
  callout[No dependencies have been identified at this time.]
}
