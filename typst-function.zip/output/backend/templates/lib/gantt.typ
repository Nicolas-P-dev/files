// Gantt chart rendering using cetz.
// Uses custom drawing rather than timeliney for more control over branding.

#import "@preview/cetz:0.4.0"
#import "brand.typ": *

// Parse a date string "YYYY-MM-DD" into a day-of-year offset from a base date
#let parse-date(date-str) = {
  let parts = date-str.split("-")
  let y = int(parts.at(0))
  let m = int(parts.at(1))
  let d = int(parts.at(2))
  // Simple day count from year start
  let days-in-month = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  let total = d
  for i in range(m - 1) {
    total = total + days-in-month.at(i)
  }
  (year: y, month: m, day: d, ordinal: total + y * 365)
}

// Gantt chart
// tasks: array of dictionaries with keys:
//   name: string, start: "YYYY-MM-DD", end: "YYYY-MM-DD",
//   status: "on-track"|"at-risk"|"off-track"|"complete"|"not-started",
//   progress: 0.0-1.0 (optional)
// title: chart title
#let gantt-chart(
  tasks: (),
  title: "Project Timeline",
  width: 16cm,
  height: auto,
) = {
  if tasks.len() == 0 { return }

  if title != "" {
    align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
    v(4mm)
  }

  let row-h = 0.8
  let label-w = 5.0
  let chart-h = if height == auto { tasks.len() * (row-h + 0.3) + 1.5 } else { height / 1cm }
  let chart-w = width / 1cm - label-w

  // Find date range
  let all-starts = tasks.map(t => parse-date(t.at("start")).ordinal)
  let all-ends = tasks.map(t => parse-date(t.at("end")).ordinal)
  let min-day = calc.min(..all-starts)
  let max-day = calc.max(..all-ends)
  let span = max-day - min-day
  if span == 0 { span = 1 }

  let status-color(s) = {
    let l = lower(s)
    if l in ("on-track", "on track", "active") { status-on-track }
    else if l in ("at-risk", "at risk") { status-at-risk }
    else if l in ("off-track", "off track", "blocked") { status-off-track }
    else if l in ("complete", "completed", "done") { status-complete }
    else { status-not-started }
  }

  // Date labels for first and last dates
  let first-date = parse-date(tasks.at(0).at("start"))
  let last-task = tasks.at(tasks.len() - 1)
  let last-date = parse-date(last-task.at("end"))
  let month-names = ("", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

  align(center, cetz.canvas(length: 1cm, {
    import cetz.draw: *

    // Date header labels
    let n-cols = calc.min(span, 12)
    for i in range(n-cols + 1) {
      let x = label-w + chart-w * i / n-cols
      let day-offset = min-day + span * i / n-cols
      // Show column date markers at top
      if calc.rem(i, calc.max(1, int(n-cols / 6))) == 0 or i == n-cols {
        let frac = i / n-cols
        let approx-day = first-date.day + int(frac * span)
        let approx-month = first-date.month + int(approx-day / 30)
        let m-idx = calc.min(calc.max(calc.rem(approx-month - 1, 12) + 1, 1), 12)
        content((x, 0.5), text(size: 6pt, fill: brand-gray-mid, month-names.at(m-idx) + " " + str(first-date.year)))
      }
      line((x, 0), (x, -chart-h + 1), stroke: 0.3pt + brand-gray-200)
    }

    // Task bars
    for (i, task) in tasks.enumerate() {
      let y = -(i * (row-h + 0.3)) - 0.3
      let s = parse-date(task.at("start")).ordinal
      let e = parse-date(task.at("end")).ordinal
      let x-start = label-w + chart-w * (s - min-day) / span
      let x-end = label-w + chart-w * (e - min-day) / span
      let clr = status-color(task.at("status", default: "not-started"))
      let progress = task.at("progress", default: 0.0)

      // Label
      content((label-w - 0.3, y - row-h / 2), anchor: "east",
        text(size: 8pt, fill: brand-black, task.at("name", default: "")),
      )

      // Background bar
      rect(
        (x-start, y),
        (x-end, y - row-h),
        fill: clr.lighten(70%),
        radius: 3pt,
        stroke: 0.5pt + clr.lighten(30%),
      )

      // Progress fill
      if progress > 0 {
        let fill-end = x-start + (x-end - x-start) * progress
        rect(
          (x-start, y),
          (fill-end, y - row-h),
          fill: clr,
          radius: 3pt,
          stroke: none,
        )
      }
    }

    // Legend
    let ly = -chart-h + 0.3
    let legend-items = (
      ("Complete", status-complete),
      ("On Track", status-on-track),
      ("At Risk", status-at-risk),
      ("Off Track", status-off-track),
      ("Not Started", status-not-started),
    )
    let lx = label-w
    for (label, clr) in legend-items {
      rect((lx, ly), (lx + 0.4, ly + 0.3), fill: clr, radius: 2pt, stroke: none)
      content((lx + 0.6, ly + 0.15), anchor: "west", text(size: 6pt, fill: brand-gray-dark, label))
      lx = lx + 2.2
    }
  }))
}
