// Deloitte brand constants — every template imports this module.
// All hex values sourced from the official Deloitte Brand Space palette.

// ── Primary palette ──────────────────────────────────────────────
#let brand-black = rgb("#000000")           // Deloitte Black (Pantone Black)
#let brand-dark-gray = rgb("#222222")       // Deloitte Dark Gray
#let brand-white = rgb("#FFFFFF")

// Greens (official Deloitte green family)
#let brand-green-primary = rgb("#86BC25")   // Deloitte Green (Pantone 368) — the brand green
#let brand-green-bright = rgb("#0DF200")    // Deloitte Bright Green (Pantone 2286)
#let brand-green-pale = rgb("#F1F6E4")      // Deloitte Pale Green
#let brand-green-mid = rgb("#3C8F2A")       // Deloitte Mid Green (Pantone 368)
#let brand-green-deep = rgb("#046A38")      // Deloitte Deep Green (Pantone 349)
#let brand-green-dark = rgb("#1C3D26")      // Deloitte Dark Green (Pantone 2411)
#let brand-green-1 = rgb("#E3E48D")         // Green 1 (Pantone 587)
#let brand-green-2 = rgb("#C4D600")         // Green 2 (Pantone 382)
#let brand-green-4 = rgb("#43B02A")         // Green 4 (Pantone 361)
#let brand-green-5 = rgb("#009A44")         // Green 5 (Pantone 347)

// Blues (official)
#let brand-blue = rgb("#0076A8")            // Blue 4 (Pantone 7690)
#let brand-blue-1 = rgb("#A0DCFF")          // Blue 1 (Pantone 291)
#let brand-blue-2 = rgb("#62B5E5")          // Blue 2 (Pantone 2915)
#let brand-blue-3 = rgb("#00A3E0")          // Blue 3 (Pantone 299)
#let brand-blue-dark = rgb("#005587")       // Blue 5 (Pantone 7692)
#let brand-blue-6 = rgb("#012169")          // Blue 6 (Pantone 280)
#let brand-blue-accessible = rgb("#007CB0") // Blue 8 / Accessible Blue

// Teals (official)
#let brand-teal = rgb("#0097A9")            // Teal 5 (Pantone 7711)
#let brand-teal-1 = rgb("#DDEFE8")          // Teal 1 (Pantone 566)
#let brand-teal-2 = rgb("#9DD4CF")          // Teal 2 (Pantone 564)
#let brand-teal-3 = rgb("#6FC2B4")          // Teal 3 (Pantone 7465)
#let brand-teal-4 = rgb("#00ABAB")          // Teal 4 (Pantone 326)
#let brand-teal-6 = rgb("#007680")          // Teal 6 (Pantone 7714)
#let brand-teal-accessible = rgb("#0D8390") // Teal 8 / Accessible Teal

// Grays — Cool Gray series (official)
#let brand-gray-light = rgb("#E6E6E6")      // Deloitte Light Gray
#let brand-gray-200 = rgb("#E6E6E6")        // alias
#let brand-gray-300 = rgb("#D0D0CE")        // Cool Gray 2
#let brand-gray-4 = rgb("#BBBCBC")          // Cool Gray 4
#let brand-gray-6 = rgb("#A7A8AA")          // Cool Gray 6
#let brand-gray-mid = rgb("#97999B")        // Cool Gray 7
#let brand-gray-9 = rgb("#75787B")          // Cool Gray 9
#let brand-gray-700 = rgb("#63666A")        // Cool Gray 10
#let brand-gray-dark = rgb("#53565A")       // Cool Gray 11

// ── Secondary palette (functional — use sparingly) ───────────────
#let brand-red = rgb("#DA291C")             // Red (Pantone 485)
#let brand-orange = rgb("#ED8B00")          // Orange (Pantone 144)
#let brand-yellow = rgb("#FFCD00")          // Yellow (Pantone 116)

// ── Status colors (derived from official palette) ────────────────
#let status-on-track = rgb("#43B02A")       // Green 4
#let status-at-risk = rgb("#ED8B00")        // Orange (Pantone 144)
#let status-off-track = rgb("#DA291C")      // Red (Pantone 485)
#let status-not-started = rgb("#97999B")    // Cool Gray 7
#let status-complete = rgb("#009A44")       // Green 5

// ── App accent (matches frontend theme.js — not an official brand color) ──
#let app-green = rgb("#26890D")

// ── Chart palette (ordered for visual distinction across series) ──
#let chart-palette = (
  brand-green-primary,       // #86BC25 — Deloitte Green
  brand-blue,                // #0076A8 — Blue 4
  brand-teal-4,              // #00ABAB — Teal 4
  brand-green-4,             // #43B02A — Green 4
  brand-blue-2,              // #62B5E5 — Blue 2
  brand-orange,              // #ED8B00 — Orange
  brand-teal,                // #0097A9 — Teal 5
  brand-blue-dark,           // #005587 — Blue 5
)

// Standard page setup for branded reports
// draft: if true, adds a diagonal "DRAFT" watermark to all pages
#let brand-page(project-name: none, draft: false, body) = {
  set text(font: "Open Sans", size: 10pt, fill: brand-black)
  set par(leading: 0.65em)
  set heading(numbering: none)
  show heading.where(level: 1): it => {
    v(8mm)
    block(inset: (left: 10pt), stroke: (left: 4pt + brand-green-primary), {
      text(size: 16pt, weight: "bold", fill: brand-green-deep, it.body)
    })
    v(4mm)
    line(length: 100%, stroke: 0.5pt + brand-gray-200)
    v(4mm)
  }
  show heading.where(level: 2): it => {
    v(5mm)
    block(inset: (left: 8pt), stroke: (left: 3pt + brand-green-4), {
      text(size: 13pt, weight: "semibold", fill: brand-black, it.body)
    })
    v(3mm)
  }
  show heading.where(level: 3): it => {
    v(3mm)
    text(size: 11pt, weight: "semibold", fill: brand-gray-dark, it.body)
    v(2mm)
  }
  set page(
    paper: "a4",
    margin: (top: 25mm, bottom: 30mm, left: 20mm, right: 20mm),
    header: context {
      if counter(page).get().first() > 1 {
        grid(
          columns: (1fr, auto),
          align: (left + horizon, right + horizon),
          text(size: 8pt, fill: brand-gray-mid, if project-name != none { project-name } else { "Assistant Project Manager" }),
          text(size: 8pt, fill: brand-green-deep, weight: "semibold", "Deloitte"),
        )
        v(2mm)
        line(length: 100%, stroke: 0.5pt + brand-gray-200)
      }
    },
    footer: context {
      line(length: 100%, stroke: 0.5pt + brand-gray-200)
      v(2mm)
      grid(
        columns: (1fr, auto),
        align: (left + horizon, right + horizon),
        text(size: 7pt, fill: brand-gray-mid, "Confidential — For internal use only"),
        text(size: 8pt, fill: brand-gray-mid,
          "Page " + str(counter(page).get().first()) + " of " + str(counter(page).final().first())
        ),
      )
    },
  )
  if draft {
    set page(background: {
      place(center + horizon,
        rotate(-45deg,
          text(size: 72pt, fill: rgb("#00000008"), weight: "bold", "DRAFT"),
        ),
      )
    })
  }
  body
}

// Chart page setup (compact, no header/footer, for PNG output)
#let chart-page(width: 20cm, height: 12cm, body) = {
  set text(font: "Open Sans", size: 10pt, fill: brand-black)
  set page(width: width, height: height, margin: 1cm)
  body
}

// Callout box — highlighted block for narrative context
// accent: left-border color (default brand-green-primary)
#let callout(body, accent: brand-green-primary, bg: brand-green-pale) = {
  block(
    width: 100%,
    fill: bg,
    radius: 4pt,
    inset: 12pt,
    stroke: (left: 4pt + accent),
    body,
  )
}

// Key takeaways block — executive summary bullets
#let key-takeaways(items) = {
  block(
    width: 100%,
    fill: brand-green-pale,
    radius: 6pt,
    inset: (x: 16pt, y: 14pt),
    stroke: (left: 5pt + brand-green-deep),
    {
      text(size: 10pt, weight: "bold", fill: brand-green-deep, "KEY TAKEAWAYS")
      v(6pt)
      for item in items {
        grid(
          columns: (14pt, 1fr),
          column-gutter: 4pt,
          text(size: 9pt, fill: brand-green-4, "•"),
          text(size: 9pt, fill: brand-black, item),
        )
        v(3pt)
      }
    },
  )
}

// Section intro text — brief narrative before charts/tables
#let section-intro(body) = {
  text(size: 9pt, fill: brand-gray-dark, style: "italic", body)
  v(4mm)
}
