// Branded table rendering with status badges.

#import "brand.typ": *

// Status badge — colored pill using official Deloitte palette tints
#let status-badge(label) = {
  let bg = brand-gray-light
  let fg = brand-gray-dark
  let l = lower(label)
  if l in ("on track", "on-track", "done", "completed", "closed") {
    bg = brand-green-pale              // #F1F6E4 — Deloitte Pale Green
    fg = status-on-track               // #43B02A — Green 4
  } else if l in ("at risk", "at-risk", "in progress", "in-progress", "active") {
    bg = brand-orange.lighten(85%)     // tint of Orange (Pantone 144)
    fg = status-at-risk                // #ED8B00 — Orange
  } else if l in ("off track", "off-track", "blocked", "overdue", "critical") {
    bg = brand-red.lighten(88%)        // tint of Red (Pantone 485)
    fg = status-off-track              // #DA291C — Red
  } else if l in ("not started", "not-started", "pending", "to do", "todo") {
    bg = brand-teal-1                  // #DDEFE8 — Teal 1
    fg = status-not-started            // #97999B — Cool Gray 7
  }
  box(
    fill: bg,
    radius: 3pt,
    inset: (x: 6pt, y: 3pt),
    text(size: 8pt, weight: "semibold", fill: fg, label),
  )
}

// Branded data table
// headers: array of column header strings
// rows: array of arrays (each row is an array of cell strings)
// status-col: optional index of column to render as status badges (-1 to disable)
// compact: reduce padding for dense data
#let data-table(
  headers: (),
  rows: (),
  status-col: -1,
  compact: false,
) = {
  let cell-pad = if compact { (x: 6pt, y: 4pt) } else { (x: 10pt, y: 7pt) }
  let font-size = if compact { 8pt } else { 9pt }
  let n-cols = headers.len()

  table(
    columns: n-cols * (1fr,),
    stroke: none,
    inset: cell-pad,
    // Header row
    ..headers.map(h =>
      table.cell(
        fill: brand-black,
        text(size: font-size, weight: "semibold", fill: brand-white, h),
      )
    ),
    // Data rows
    ..rows.enumerate().map(((i, row)) =>
      row.enumerate().map(((j, cell)) => {
        let bg = if calc.rem(i, 2) == 0 { brand-white } else { brand-gray-light }
        table.cell(
          fill: bg,
          if j == status-col {
            status-badge(cell)
          } else {
            text(size: font-size, fill: brand-black, cell)
          },
        )
      })
    ).flatten(),
  )
}

// Simple status table — convenience wrapper with auto status detection
#let status-table(
  headers: (),
  rows: (),
) = {
  let s-col = -1
  for (i, h) in headers.enumerate() {
    if lower(h) == "status" {
      s-col = i
    }
  }
  data-table(headers: headers, rows: rows, status-col: s-col)
}

// Progress bar — inline bar showing value/max ratio
// Returns a box suitable for use inside table cells or inline
#let progress-bar(
  value,
  max,
  width: 4cm,
  height: 8pt,
  color: auto,
  show-label: true,
) = {
  let ratio = if max > 0 { calc.min(value / max, 1.0) } else { 0 }
  let clr = if color == auto {
    if ratio >= 0.8 { status-on-track }
    else if ratio >= 0.5 { status-at-risk }
    else { status-off-track }
  } else { color }

  box(width: width, {
    // Background track
    box(
      width: 100%,
      height: height,
      radius: height / 2,
      fill: brand-gray-200,
      clip: true,
      {
        place(left, rect(
          width: ratio * 100%,
          height: 100%,
          fill: clr,
          radius: height / 2,
        ))
      },
    )
    if show-label {
      h(4pt)
      text(size: 7pt, fill: brand-gray-dark, str(value) + " / " + str(max))
    }
  })
}
