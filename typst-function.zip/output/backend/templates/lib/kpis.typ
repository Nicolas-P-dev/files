// KPI card layouts for executive dashboards.

#import "brand.typ": *

// Single KPI card
#let kpi-card(
  label,
  value,
  trend: none,
  color: auto,
  sub-label: none,
) = {
  let accent = if color == auto { brand-green-deep } else if color == "red" { brand-red } else if color == "orange" { brand-orange } else if color == "green" { brand-green-4 } else if color == "on-track" { status-on-track } else if color == "at-risk" { status-at-risk } else if color == "off-track" { status-off-track } else { brand-green-deep }

  box(
    width: 100%,
    fill: brand-white,
    radius: 6pt,
    stroke: 0.5pt + brand-gray-200,
    inset: (x: 14pt, y: 12pt),
    {
      text(size: 8pt, fill: brand-gray-mid, weight: "semibold", upper(label))
      v(4pt)
      text(size: 24pt, weight: "bold", fill: accent, value)
      if trend != none {
        h(6pt)
        let arrow = if type(trend) == str {
          trend
        } else if trend > 0 {
          "▲ " + str(trend) + "%"
        } else if trend < 0 {
          "▼ " + str(calc.abs(trend)) + "%"
        } else {
          "— 0%"
        }
        let t-color = if type(trend) != str {
          if trend > 0 { status-on-track } else if trend < 0 { status-off-track } else { brand-gray-mid }
        } else { brand-gray-mid }
        text(size: 9pt, weight: "semibold", fill: t-color, arrow)
      }
      if sub-label != none {
        v(2pt)
        text(size: 8pt, fill: brand-gray-mid, sub-label)
      }
    },
  )
}

// Row of KPI cards in a grid
#let kpi-row(..cards) = {
  let items = cards.pos()
  let n = items.len()
  if n == 0 { return }
  grid(
    columns: n * (1fr,),
    column-gutter: 10pt,
    ..items,
  )
}

// Traffic light indicator
#let traffic-light(status) = {
  let clr = brand-gray-mid
  let l = if type(status) == str { lower(status) } else { "" }
  if l in ("green", "on track", "on-track", "good") { clr = status-on-track }
  else if l in ("amber", "yellow", "at risk", "at-risk", "warning") { clr = status-at-risk }
  else if l in ("red", "off track", "off-track", "critical", "blocked") { clr = status-off-track }
  box(
    width: 12pt,
    height: 12pt,
    radius: 6pt,
    fill: clr,
  )
}
