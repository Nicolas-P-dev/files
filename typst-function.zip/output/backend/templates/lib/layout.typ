// Page layout functions: cover page, section breaks.

#import "brand.typ": *

// Cover page
#let cover-page(
  title: "Report",
  subtitle: "",
  date: "",
  author: "",
  project-id: "",
  version: "",
  distribution: "",
  logo: none,
) = {
  set page(margin: 0pt, header: none, footer: none)
  // Black banner at top
  place(top + left, rect(
    width: 100%,
    height: 40%,
    fill: brand-black,
  ))
  // Green accent bar
  place(top + left, dy: 39.5%, rect(
    width: 100%,
    height: 0.8%,
    fill: brand-green-primary,
  ))
  // Logo (top-right of black banner)
  place(top + right, dx: -40pt, dy: 5%,
    image("../assets/deloitte-logo.svg", width: 120pt),
  )
  // Title block
  place(top + left, dx: 40pt, dy: 15%,
    block(width: 70%, {
      text(size: 32pt, weight: "bold", fill: brand-white, title)
      if subtitle != "" {
        v(8pt)
        text(size: 16pt, fill: brand-green-primary, subtitle)
      }
    }),
  )
  // Meta block
  place(bottom + left, dx: 40pt, dy: -15%,
    block({
      if date != "" {
        text(size: 11pt, fill: brand-gray-dark, date)
        v(4pt)
      }
      if author != "" {
        text(size: 11pt, fill: brand-gray-dark, "Prepared by: " + author)
        v(4pt)
      }
      if project-id != "" {
        text(size: 9pt, fill: brand-gray-mid, "Project: " + project-id)
        v(3pt)
      }
      if version != "" {
        text(size: 9pt, fill: brand-gray-mid, "Version: " + version)
        v(3pt)
      }
      if distribution != "" {
        text(size: 9pt, fill: brand-gray-mid, "Distribution: " + distribution)
        v(3pt)
      }
      v(8pt)
      text(size: 14pt, weight: "bold", fill: brand-green-deep, "Deloitte")
      v(2pt)
      text(size: 9pt, fill: brand-gray-mid, "Assistant Project Manager")
    }),
  )
  // Confidential notice
  place(bottom + left, dx: 40pt, dy: -5%,
    text(size: 7pt, fill: brand-gray-mid, "Confidential — For internal use only"),
  )
  pagebreak()
}

// Section break page
#let section-break(title) = {
  pagebreak()
  v(30%)
  align(center, {
    text(size: 28pt, weight: "bold", fill: brand-green-deep, title)
    v(4mm)
    line(length: 30%, stroke: 2pt + brand-green-primary)
  })
  pagebreak()
}

// Watermark — call this before page content to add a diagonal watermark
// text-content: e.g. "DRAFT", "CONFIDENTIAL"
#let watermark(text-content) = {
  set page(background: {
    place(center + horizon,
      rotate(-45deg,
        text(
          size: 72pt,
          fill: rgb("#00000008"),
          weight: "bold",
          upper(text-content),
        ),
      ),
    )
  })
}
