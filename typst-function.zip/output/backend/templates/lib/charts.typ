// Chart rendering functions using cetz and cetz-plot.
// Each function produces a branded chart.

#import "@preview/cetz:0.4.0"
#import "@preview/cetz-plot:0.1.1": plot, chart
#import "brand.typ": *

// Bar chart — vertical bars from array of (label, value) tuples
#let bar-chart(
  data: (),
  title: "",
  width: 14cm,
  height: 7cm,
  colors: auto,
  horizontal: false,
) = {
  let clrs = if colors == auto { chart-palette } else { colors }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm
      let n = data.len()
      if n == 0 { return }

      let max-val = calc.max(..data.map(d => d.at(1)))
      if max-val == 0 { max-val = 1 }

      let bar-w = calc.min(w / n * 0.6, 2.0)
      let gap = w / n

      // Y axis
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      // X axis
      line((0, 0), (w, 0), stroke: 0.5pt + brand-gray-300)

      // Grid lines
      for i in range(1, 6) {
        let y = h * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.3, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(max-val * i / 5, digits: 1))))
      }

      // Bars
      for (i, item) in data.enumerate() {
        let label = item.at(0)
        let val = item.at(1)
        let x = gap * (i + 0.5)
        let bar-h = h * val / max-val
        let clr = clrs.at(calc.rem(i, clrs.len()))

        rect(
          (x - bar-w / 2, 0),
          (x + bar-w / 2, bar-h),
          fill: clr,
          stroke: none,
        )
        content((x, -0.5), text(size: 7pt, fill: brand-gray-dark, label))
        content((x, bar-h + 0.3), text(size: 7pt, weight: "semibold", fill: brand-gray-dark, str(val)))
      }
    }))
  })
}

// Grouped bar chart — multiple series side-by-side per category
// data: array of (series-name, array-of-(label, value))
// Example: (("Budgeted", (("Dev", 100), ("QA", 50))), ("Actual", (("Dev", 90), ("QA", 60))))
#let grouped-bar-chart(
  data: (),
  title: "",
  width: 13cm,
  height: 7cm,
  colors: auto,
) = {
  let clrs = if colors == auto { chart-palette } else { colors }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    let n-series = data.len()
    if n-series == 0 { return }

    // Collect category labels from first series
    let categories = data.at(0).at(1).map(d => d.at(0))
    let n-cats = categories.len()
    if n-cats == 0 { return }

    // Find max value across all series
    let all-vals = data.map(s => s.at(1).map(d => d.at(1))).fold((), (acc, v) => acc + v)
    let max-val = calc.max(..all-vals)
    if max-val == 0 { max-val = 1 }

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm

      let group-w = w / n-cats
      let bar-w = calc.min(group-w * 0.7 / n-series, 1.5)

      // Axes
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      line((0, 0), (w, 0), stroke: 0.5pt + brand-gray-300)

      // Grid
      for i in range(1, 6) {
        let y = h * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.5, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(max-val * i / 5, digits: 1))))
      }

      // Bars
      for (ci, cat) in categories.enumerate() {
        let group-x = group-w * (ci + 0.5)
        let start-x = group-x - (n-series * bar-w) / 2

        for (si, series) in data.enumerate() {
          let val = series.at(1).at(ci).at(1)
          let x = start-x + bar-w * (si + 0.5)
          let bar-h = h * val / max-val
          let clr = clrs.at(calc.rem(si, clrs.len()))

          rect(
            (x - bar-w / 2, 0),
            (x + bar-w / 2, bar-h),
            fill: clr,
            stroke: none,
          )
          content((x, bar-h + 0.3), text(size: 6pt, weight: "semibold", fill: brand-gray-dark, str(val)))
        }

        // Category label
        content((group-x, -0.5), text(size: 7pt, fill: brand-gray-dark, cat))
      }

      // Legend
      for (si, series) in data.enumerate() {
        let name = series.at(0)
        let clr = clrs.at(calc.rem(si, clrs.len()))
        let lx = w + 0.5
        let ly = h - si * 0.7
        rect((lx, ly - 0.15), (lx + 0.3, ly + 0.15), fill: clr, stroke: none)
        content((lx + 0.5, ly), anchor: "west", text(size: 7pt, fill: brand-gray-dark, name))
      }
    }))
  })
}

// Line chart — array of series, each series is (name, array-of-(x, y))
#let line-chart(
  data: (),
  title: "",
  width: 13cm,
  height: 7cm,
  colors: auto,
  x-labels: auto,
) = {
  let clrs = if colors == auto { chart-palette } else { colors }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm

      // Find ranges across all series
      let all-points = data.map(s => s.at(1)).fold((), (acc, pts) => acc + pts)
      let max-y = if all-points.len() > 0 { calc.max(..all-points.map(p => p.at(1))) } else { 1 }
      if max-y == 0 { max-y = 1 }
      let max-x = if all-points.len() > 0 { calc.max(..all-points.map(p => p.at(0))) } else { 1 }
      if max-x == 0 { max-x = 1 }

      // Axes
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      line((0, 0), (w, 0), stroke: 0.5pt + brand-gray-300)

      // Grid
      for i in range(1, 6) {
        let y = h * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.5, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(max-y * i / 5, digits: 1))))
      }

      // Series
      for (si, series) in data.enumerate() {
        let name = series.at(0)
        let points = series.at(1)
        let clr = clrs.at(calc.rem(si, clrs.len()))

        let coords = points.map(p => (w * p.at(0) / max-x, h * p.at(1) / max-y))

        for i in range(coords.len() - 1) {
          line(coords.at(i), coords.at(i + 1), stroke: 2pt + clr)
        }
        for pt in coords {
          circle(pt, radius: 0.12, fill: clr, stroke: none)
        }
      }

      // Legend
      if data.len() > 1 {
        for (si, series) in data.enumerate() {
          let name = series.at(0)
          let clr = clrs.at(calc.rem(si, clrs.len()))
          let lx = w + 0.5
          let ly = h - si * 0.7
          rect((lx, ly - 0.15), (lx + 0.3, ly + 0.15), fill: clr, stroke: none)
          content((lx + 0.5, ly), anchor: "west", text(size: 7pt, fill: brand-gray-dark, name))
        }
      }

      // X-axis labels
      if x-labels != auto and x-labels.len() > 0 {
        for (i, label) in x-labels.enumerate() {
          let x = w * (i + 1) / max-x
          content((x, -0.5), text(size: 7pt, fill: brand-gray-dark, label))
        }
      }
    }))
  })
}

// Pie chart — array of (label, value) tuples
#let pie-chart(
  data: (),
  title: "",
  width: 12cm,
  height: 10cm,
  colors: auto,
  donut: false,
) = {
  let clrs = if colors == auto { chart-palette } else { colors }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    let total = data.map(d => d.at(1)).sum()
    if total == 0 { total = 1 }

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let cx = 0
      let cy = 0
      let r = 3.5
      let inner-r = if donut { r * 0.55 } else { 0 }
      let angle = 0deg

      for (i, item) in data.enumerate() {
        let label = item.at(0)
        let val = item.at(1)
        let sweep = 360deg * val / total
        let clr = clrs.at(calc.rem(i, clrs.len()))

        let mid-angle = angle + sweep / 2

        // Wedge using arc
        arc((cx, cy), start: angle, delta: sweep, radius: r, mode: "PIE", fill: clr, stroke: 0.5pt + white, anchor: "origin")

        // Label
        let lx = cx + (r + 0.8) * calc.cos(mid-angle)
        let ly = cy + (r + 0.8) * calc.sin(mid-angle)
        content((lx, ly), text(size: 7pt, fill: brand-gray-dark, label + " (" + str(calc.round(val / total * 100, digits: 0)) + "%)"))

        angle = angle + sweep
      }

      // Donut hole: single white circle on top of all wedges
      if donut {
        circle((cx, cy), radius: inner-r + 0.02, fill: white, stroke: none)
      }
    }))
  })
}

// Burndown chart — shows actual vs ideal burndown
// data: array of (day-label, remaining-points)
// total: total points at sprint start
#let burndown-chart(
  data: (),
  title: "Sprint Burndown",
  sprint-name: "",
  total: auto,
  width: 14cm,
  height: 7cm,
) = {
  let total-pts = if total == auto {
    if data.len() > 0 { data.at(0).at(1) } else { 0 }
  } else { total }

  let display-title = if sprint-name != "" { title + " — " + sprint-name } else { title }

  block(breakable: false, {
    align(center, text(size: 13pt, weight: "semibold", fill: brand-black, display-title))
    v(4mm)

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm
      let n = data.len()
      if n == 0 { return }

      let max-y = total-pts
      if max-y == 0 { max-y = 1 }

      // Axes
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      line((0, 0), (w, 0), stroke: 0.5pt + brand-gray-300)

      // Grid
      for i in range(1, 6) {
        let y = h * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.5, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(max-y * i / 5, digits: 0))))
      }

      // Ideal line (straight from top-left to bottom-right)
      line((0, h), (w, 0), stroke: (dash: "dashed", paint: brand-gray-mid, thickness: 1.5pt))

      // Actual burndown line
      let coords = ()
      for (i, item) in data.enumerate() {
        let x = w * i / (n - 1)
        let y = h * item.at(1) / max-y
        coords.push((x, y))
      }

      for i in range(coords.len() - 1) {
        line(coords.at(i), coords.at(i + 1), stroke: 2pt + brand-green-4)
      }
      for pt in coords {
        circle(pt, radius: 0.12, fill: brand-green-4, stroke: none)
      }

      // X labels
      for (i, item) in data.enumerate() {
        let x = w * i / (n - 1)
        content((x, -0.5), text(size: 7pt, fill: brand-gray-dark, item.at(0)))
      }

      // Legend
      line((w - 4, h - 0.3), (w - 3.5, h - 0.3), stroke: (dash: "dashed", paint: brand-gray-mid, thickness: 1.5pt))
      content((w - 3.3, h - 0.3), anchor: "west", text(size: 7pt, fill: brand-gray-mid, "Ideal"))
      line((w - 4, h - 0.9), (w - 3.5, h - 0.9), stroke: 2pt + brand-green-4)
      content((w - 3.3, h - 0.9), anchor: "west", text(size: 7pt, fill: brand-green-4, "Actual"))
    }))
  })
}

// Velocity chart — bar chart of story points per sprint
// data: array of (sprint-name, completed-points)
#let velocity-chart(
  data: (),
  title: "Sprint Velocity",
  width: 16cm,
  height: 8cm,
) = {
  bar-chart(
    data: data,
    title: title,
    width: width,
    height: height,
    colors: (brand-green-primary, brand-green-4),
  )
}

// Risk matrix — 5×5 grid (likelihood × impact) with risk items plotted
// risks: array of dicts with keys: name, likelihood (1-5), impact (1-5)
// Cells are colored green (low) → amber (medium) → red (high) based on risk score
#let risk-matrix(
  risks: (),
  title: "Risk Matrix",
  width: 14cm,
) = {
  if title != "" {
    align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
    v(4mm)
  }

  let cell-size = width / 7  // 5 data cols + 1 label col + spacing
  let labels-likelihood = ("Very Low", "Low", "Medium", "High", "Very High")
  let labels-impact = ("Very Low", "Low", "Medium", "High", "Very High")

  // Risk score color: likelihood × impact
  let score-color(l, i) = {
    let score = l * i
    if score <= 4 { status-on-track.lighten(60%) }
    else if score <= 9 { status-on-track.lighten(30%) }
    else if score <= 14 { status-at-risk.lighten(40%) }
    else if score <= 19 { status-at-risk.lighten(10%) }
    else { status-off-track.lighten(20%) }
  }

  // Find risks in each cell
  let cell-risks(l, i) = {
    risks.filter(r => r.at("likelihood", default: 0) == l and r.at("impact", default: 0) == i)
  }

  align(center, {
    // Impact label
    text(size: 8pt, weight: "semibold", fill: brand-gray-dark, "IMPACT →")
    v(2mm)

    grid(
      columns: (auto, ..range(5).map(_ => 1fr)),
      column-gutter: 2pt,
      row-gutter: 2pt,

      // Header row (impact labels)
      [],
      ..labels-impact.map(l => align(center, text(size: 7pt, fill: brand-gray-dark, l))),

      // Data rows (likelihood 5 → 1, top to bottom)
      ..range(5).rev().map(li => {
        let likelihood = li + 1
        (
          // Row label
          align(right + horizon, box(inset: (right: 4pt),
            text(size: 7pt, fill: brand-gray-dark, labels-likelihood.at(li))
          )),
          // Cells
          ..range(5).map(ii => {
            let impact = ii + 1
            let items = cell-risks(likelihood, impact)
            box(
              width: 100%,
              height: 2.5em,
              fill: score-color(likelihood, impact),
              radius: 3pt,
              inset: 2pt,
              align(center + horizon, {
                for item in items {
                  text(size: 6pt, weight: "semibold", fill: brand-black, item.at("name", default: ""))
                  linebreak()
                }
              }),
            )
          }),
        )
      }).flatten(),
    )

    v(2mm)
    // Likelihood label
    align(left, text(size: 8pt, weight: "semibold", fill: brand-gray-dark, "↑ LIKELIHOOD"))
  })
}

// Radar / Spider chart — radial plot of multiple dimensions
// data: array of (label, value) tuples where value is 0-100 (percentage of max)
// Renders a filled polygon on a radial grid
#let radar-chart(
  data: (),
  title: "",
  width: 12cm,
  colors: auto,
  max-value: 100,
) = {
  let clrs = if colors == auto { (brand-green-primary,) } else { colors }

  if title != "" {
    align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
    v(4mm)
  }

  let n = data.len()
  if n < 3 { return }

  align(center, cetz.canvas(length: 1cm, {
    import cetz.draw: *

    let r = width / 2 / 1cm - 1.0
    let cx = 0
    let cy = 0

    // Grid rings (5 levels)
    for level in range(1, 6) {
      let lr = r * level / 5
      let ring-pts = range(n).map(i => {
        let angle = 90deg - 360deg * i / n
        (cx + lr * calc.cos(angle), cy + lr * calc.sin(angle))
      })
      for i in range(n) {
        let next = calc.rem(i + 1, n)
        line(ring-pts.at(i), ring-pts.at(next), stroke: 0.3pt + brand-gray-200)
      }
    }

    // Axis lines from center to each vertex
    for i in range(n) {
      let angle = 90deg - 360deg * i / n
      let ex = cx + r * calc.cos(angle)
      let ey = cy + r * calc.sin(angle)
      line((cx, cy), (ex, ey), stroke: 0.5pt + brand-gray-300)

      // Label
      let lx = cx + (r + 0.7) * calc.cos(angle)
      let ly = cy + (r + 0.7) * calc.sin(angle)
      content((lx, ly), text(size: 7pt, fill: brand-gray-dark, data.at(i).at(0)))
    }

    // Data polygon
    let clr = clrs.at(0)
    let pts = range(n).map(i => {
      let val = calc.min(data.at(i).at(1), max-value)
      let pr = r * val / max-value
      let angle = 90deg - 360deg * i / n
      (cx + pr * calc.cos(angle), cy + pr * calc.sin(angle))
    })

    // Fill polygon
    for i in range(n) {
      let next = calc.rem(i + 1, n)
      // Draw filled triangle from center to each edge
      line((cx, cy), pts.at(i), pts.at(next), fill: clr.lighten(70%), stroke: none, close: true)
    }
    // Outline
    for i in range(n) {
      let next = calc.rem(i + 1, n)
      line(pts.at(i), pts.at(next), stroke: 2pt + clr)
    }
    // Data points
    for pt in pts {
      circle(pt, radius: 0.12, fill: clr, stroke: 1pt + white)
    }

    // Value labels
    for i in range(n) {
      let val = data.at(i).at(1)
      let angle = 90deg - 360deg * i / n
      let vr = r * calc.min(val, max-value) / max-value + 0.4
      let vx = cx + vr * calc.cos(angle)
      let vy = cy + vr * calc.sin(angle)
      content((vx, vy), text(size: 6pt, weight: "semibold", fill: clr, str(val)))
    }
  }))
}

// Gauge chart — semicircular speedometer for a single metric
// value: current value (0 to max)
// max: maximum value (default 100)
// label: text label below the value
#let gauge-chart(
  value: 0,
  max: 100,
  label: "",
  title: "",
  width: 8cm,
  color: auto,
) = {
  if title != "" {
    align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
    v(4mm)
  }

  let ratio = if max > 0 { calc.min(value / max, 1.0) } else { 0 }
  let clr = if color == auto {
    if ratio >= 0.8 { status-on-track }
    else if ratio >= 0.5 { status-at-risk }
    else { status-off-track }
  } else if color == "green" { status-on-track }
  else if color == "orange" { status-at-risk }
  else if color == "red" { status-off-track }
  else { brand-green-primary }

  align(center, cetz.canvas(length: 1cm, {
    import cetz.draw: *

    let r = width / 2 / 1cm - 0.5
    let cx = 0
    let cy = 0
    let inner-r = r * 0.65

    // Background arc (light gray)
    arc((cx, cy), start: 180deg, delta: 180deg, radius: r, mode: "PIE", fill: brand-gray-200, stroke: none, anchor: "origin")
    // Inner white circle to create donut shape
    circle((cx, cy), radius: inner-r, fill: white, stroke: none)

    // Value arc
    let sweep = 180deg * ratio
    if sweep > 0deg {
      arc((cx, cy), start: 180deg, delta: sweep, radius: r, mode: "PIE", fill: clr, stroke: none, anchor: "origin")
      circle((cx, cy), radius: inner-r + 0.02, fill: white, stroke: none)
    }

    // Tick marks
    for i in range(11) {
      let frac = i / 10
      let angle = 180deg + 180deg * frac
      let tx1 = cx + (r + 0.15) * calc.cos(angle)
      let ty1 = cy + (r + 0.15) * calc.sin(angle)
      let tx2 = cx + (r + 0.35) * calc.cos(angle)
      let ty2 = cy + (r + 0.35) * calc.sin(angle)
      line((tx1, ty1), (tx2, ty2), stroke: 0.5pt + brand-gray-300)
      if calc.rem(i, 2) == 0 {
        let lx = cx + (r + 0.6) * calc.cos(angle)
        let ly = cy + (r + 0.6) * calc.sin(angle)
        content((lx, ly), text(size: 6pt, fill: brand-gray-mid, str(calc.round(max * frac, digits: 0))))
      }
    }

    // Needle
    let needle-angle = 180deg + 180deg * ratio
    let nx = cx + (inner-r + 0.1) * calc.cos(needle-angle)
    let ny = cy + (inner-r + 0.1) * calc.sin(needle-angle)
    line((cx, cy), (nx, ny), stroke: 2pt + brand-black)
    circle((cx, cy), radius: 0.15, fill: brand-black, stroke: none)

    // Center value text
    content((cx, cy - 0.6), text(size: 20pt, weight: "bold", fill: clr, str(value)))
    if label != "" {
      content((cx, cy - 1.2), text(size: 9pt, fill: brand-gray-dark, label))
    }
  }))
}

// Cumulative Flow Diagram — stacked area chart showing work states over time
// data: array of (state-name, array-of-(period-index, count))
// States should be ordered bottom-to-top (e.g., Done, In Progress, To Do)
#let cfd-chart(
  data: (),
  title: "Cumulative Flow",
  width: 13cm,
  height: 7cm,
  colors: auto,
  x-labels: (),
) = {
  let clrs = if colors == auto { chart-palette } else { colors }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    let n-series = data.len()
    if n-series == 0 { return }

    // Get number of periods from first series
    let periods = data.at(0).at(1).len()
    if periods == 0 { return }

    // Compute stacked values: for each period, cumulate series values
    let stacked = ()
    for pi in range(periods) {
      let running = 0
      let col = ()
      for si in range(n-series) {
        let val = data.at(si).at(1).at(pi).at(1)
        running = running + val
        col.push(running)
      }
      stacked.push(col)
    }

    let max-val = calc.max(..stacked.map(col => col.last()))
    if max-val == 0 { max-val = 1 }

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm

      // Axes
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      line((0, 0), (w, 0), stroke: 0.5pt + brand-gray-300)

      // Grid
      for i in range(1, 6) {
        let y = h * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.5, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(max-val * i / 5, digits: 0))))
      }

      // Draw stacked areas top-to-bottom so lower series paint over upper
      for si in range(n-series - 1, -1, step: -1) {
        let clr = clrs.at(calc.rem(si, clrs.len()))

        // Upper boundary of this series
        let upper = ()
        for pi in range(periods) {
          let x = w * pi / (periods - 1)
          let y = h * stacked.at(pi).at(si) / max-val
          upper.push((x, y))
        }

        // Lower boundary (previous series top, or zero line)
        let lower = ()
        for pi in range(periods) {
          let x = w * pi / (periods - 1)
          let y = if si > 0 { h * stacked.at(pi).at(si - 1) / max-val } else { 0 }
          lower.push((x, y))
        }

        // Fill polygon: upper path forward, lower path backward
        let poly = upper + lower.rev()
        if poly.len() >= 3 {
          line(..poly, fill: clr.lighten(40%), stroke: none, close: true)
        }

        // Upper edge line
        for i in range(upper.len() - 1) {
          line(upper.at(i), upper.at(i + 1), stroke: 1.5pt + clr)
        }
      }

      // X labels
      if x-labels.len() > 0 {
        for (i, label) in x-labels.enumerate() {
          if i < periods {
            let x = w * i / (periods - 1)
            content((x, -0.5), text(size: 7pt, fill: brand-gray-dark, label))
          }
        }
      }

      // Legend
      for (si, series) in data.enumerate() {
        let name = series.at(0)
        let clr = clrs.at(calc.rem(si, clrs.len()))
        let lx = w + 0.5
        let ly = h - si * 0.7
        rect((lx, ly - 0.15), (lx + 0.3, ly + 0.15), fill: clr, stroke: none)
        content((lx + 0.5, ly), anchor: "west", text(size: 7pt, fill: brand-gray-dark, name))
      }
    }))
  })
}

// Waterfall chart — shows how values build up or break down step-by-step
// data: array of (label, value) tuples. Positive values go up, negative go down.
// The last item is treated as the total (drawn from zero).
#let waterfall-chart(
  data: (),
  title: "",
  width: 14cm,
  height: 7cm,
  positive-color: auto,
  negative-color: auto,
  total-color: auto,
) = {
  let pos-clr = if positive-color == auto { status-on-track } else { positive-color }
  let neg-clr = if negative-color == auto { status-off-track } else { negative-color }
  let tot-clr = if total-color == auto { brand-green-deep } else { total-color }

  block(breakable: false, {
    if title != "" {
      align(center, text(size: 13pt, weight: "semibold", fill: brand-black, title))
      v(4mm)
    }

    let n = data.len()
    if n == 0 { return }

    // Compute running totals
    let running = ()
    let cumulative = 0
    for (i, item) in data.enumerate() {
      let val = item.at(1)
      if i == n - 1 {
        // Last item is total — draw from zero
        running.push((start: 0, end: val))
      } else {
        let start = cumulative
        cumulative = cumulative + val
        running.push((start: start, end: cumulative))
      }
    }

    // Find range
    let all-vals = running.map(r => (r.start, r.end)).fold((), (acc, v) => acc + (v.at(0), v.at(1)))
    let min-val = calc.min(0, calc.min(..all-vals))
    let max-val = calc.max(..all-vals)
    if max-val == min-val { max-val = min-val + 1 }
    let range-val = max-val - min-val

    align(center, cetz.canvas(length: 1cm, {
      import cetz.draw: *

      let w = width / 1cm
      let h = height / 1cm
      let gap = w / n
      let bar-w = calc.min(gap * 0.6, 2.0)

      // Axes
      line((0, 0), (0, h), stroke: 0.5pt + brand-gray-300)
      let zero-y = h * (0 - min-val) / range-val
      line((0, zero-y), (w, zero-y), stroke: 0.5pt + brand-gray-300)

      // Grid
      for i in range(1, 6) {
        let y = h * i / 5
        let grid-val = min-val + range-val * i / 5
        line((0, y), (w, y), stroke: 0.3pt + brand-gray-200)
        content((-0.5, y), text(size: 7pt, fill: brand-gray-mid, str(calc.round(grid-val, digits: 0))))
      }

      // Bars
      for (i, item) in data.enumerate() {
        let label = item.at(0)
        let val = item.at(1)
        let r = running.at(i)
        let x = gap * (i + 0.5)

        let y-start = h * (r.start - min-val) / range-val
        let y-end = h * (r.end - min-val) / range-val

        let clr = if i == n - 1 { tot-clr }
          else if val >= 0 { pos-clr }
          else { neg-clr }

        rect(
          (x - bar-w / 2, y-start),
          (x + bar-w / 2, y-end),
          fill: clr,
          stroke: none,
        )

        // Connector line to next bar (except last)
        if i < n - 1 {
          let next-x = gap * (i + 1.5)
          line(
            (x + bar-w / 2, y-end),
            (next-x - bar-w / 2, y-end),
            stroke: (dash: "dashed", paint: brand-gray-300, thickness: 0.5pt),
          )
        }

        // Value label
        let label-y = if y-end > y-start { y-end + 0.3 } else { y-end - 0.3 }
        let prefix = if i < n - 1 and val > 0 { "+" } else { "" }
        content((x, label-y), text(size: 7pt, weight: "semibold", fill: brand-gray-dark, prefix + str(val)))

        // X label
        content((x, -0.5), text(size: 7pt, fill: brand-gray-dark, label))
      }
    }))
  })
}
