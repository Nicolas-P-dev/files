"""Application config. Only file that reads env vars. Everything else gets injected."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "APM Agent"
    app_version: str = "0.1.0"
    port: int = 8080
    log_level: str = "info"

    llm_base_url: str = ""
    llm_api_key: str = ""
    llm_deployment: str = "gpt-4o"
    llm_fast_deployment: str = "gpt-5-nano"
    llm_api_version: str = "2025-01-01-preview"
    llm_temperature: float = 1.0
    llm_max_tokens: int = 16384

    api_key: str = ""
    sessions_dir: str = ""

    doc_intelligence_endpoint: str = ""
    doc_intelligence_key: str = ""
    uploads_dir: str = ""

    typst_binary: str = "typst"  # path to typst binary, default assumes PATH

    # Optional Jira field overrides — leave empty to auto-discover at runtime.
    # Set APM_JIRA_STORY_POINTS_FIELD to skip SP field probing (e.g. customfield_10035).
    jira_story_points_field: str = ""
    jira_epic_type: str = "Epic"
    jira_story_type: str = "Story"
    jira_task_type: str = "Sub-task"

    model_config = {
        "env_prefix": "APM_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }


settings = Settings()
