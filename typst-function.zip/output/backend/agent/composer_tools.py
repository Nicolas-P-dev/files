"""Compose multi-section reports dynamically from user-selected sections.

Follows the same pattern as report_tools.py: async functions with
``.schema``, ``.max_result_chars``, and optional ``_context`` injection.
"""

import io
import json
import logging
import shutil
import tempfile
import uuid
from pathlib import Path

import agent.deps as deps
from agent.report_tools import (
    _compile_typst,
    _escape_typst_string,
    _resolve_session_id,
)

logger = logging.getLogger(__name__)


def _escape_typst_markup(s: str) -> str:
    """Escape characters that have special meaning in Typst markup mode."""
    for ch in ("#", "*", "_", "`", "$", "@", "<", ">", "\\"):
        s = s.replace(ch, f"\\{ch}")
    return s


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------
# Each builder takes (idx: int, section: dict) and returns a Typst code string.
# The section's data is accessed via data.at("sections").at(IDX).at("data").


def _build_cover_page(idx: int, section: dict) -> str:
    """Emit cover page and table of contents."""
    return (
        '#cover-page(title: data.at("title"), '
        'subtitle: data.at("subtitle"), '
        'date: data.at("date"), '
        'author: data.at("author"))\n'
        '#outline(title: "Contents", depth: 2)\n'
    )


def _build_kpi_row(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#kpi-row(..data.at("sections").at({idx}).at("data").at("cards").map(c => '
        f'kpi-card(c.at("label"), c.at("value"), '
        f'trend: c.at("trend", default: none), '
        f'color: c.at("color", default: auto))))\n'
    )


def _build_bar_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#bar-chart(title: "", data: data.at("sections").at({idx}).at("data").at("items").map(d => (d.at(0), d.at(1))))\n'
        f'#pagebreak()\n'
    )


def _build_grouped_bar_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#grouped-bar-chart(title: "", data: data.at("sections").at({idx}).at("data").at("series"))\n'
        f'#pagebreak()\n'
    )


def _build_line_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#line-chart(title: "", data: data.at("sections").at({idx}).at("data").at("series"))\n'
        f'#pagebreak()\n'
    )


def _build_pie_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#pie-chart(title: "", data: data.at("sections").at({idx}).at("data").at("items").map(d => (d.at(0), d.at(1))))\n'
        f'#pagebreak()\n'
    )


def _build_burndown_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#burndown-chart(data: data.at("sections").at({idx}).at("data").at("points").map(b => (b.at("day"), b.at("remaining"))))\n'
        f'#pagebreak()\n'
    )


def _build_velocity_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#velocity-chart(data: data.at("sections").at({idx}).at("data").at("sprints").map(v => (v.at(0), v.at(1))))\n'
        f'#pagebreak()\n'
    )


def _build_radar_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#radar-chart(title: "", data: data.at("sections").at({idx}).at("data").at("dimensions").map(d => (d.at(0), d.at(1))))\n'
        f'#pagebreak()\n'
    )


def _build_gauge_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#{{let g = data.at("sections").at({idx}).at("data")\n'
        f'gauge-chart(value: g.at("value", default: 0), '
        f'max: g.at("max", default: 100), '
        f'label: g.at("label", default: ""))}}\n'
        f'#pagebreak()\n'
    )


def _build_cfd_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#cfd-chart(title: "", data: data.at("sections").at({idx}).at("data").at("series"))\n'
        f'#pagebreak()\n'
    )


def _build_waterfall_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#waterfall-chart(title: "", data: data.at("sections").at({idx}).at("data").at("items").map(d => (d.at(0), d.at(1))))\n'
        f'#pagebreak()\n'
    )


def _build_risk_matrix(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#risk-matrix(risks: data.at("sections").at({idx}).at("data").at("risks"))\n'
        f'#pagebreak()\n'
    )


def _build_gantt_chart(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#gantt-chart(tasks: data.at("sections").at({idx}).at("data").at("tasks"))\n'
        f'#pagebreak()\n'
    )


def _build_data_table(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#data-table(headers: data.at("sections").at({idx}).at("data").at("headers"), '
        f'rows: data.at("sections").at({idx}).at("data").at("rows"))\n'
    )


def _build_key_takeaways(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#key-takeaways(data.at("sections").at({idx}).at("data").at("items"))\n'
    )


def _build_text_section(idx: int, section: dict) -> str:
    title = _escape_typst_markup(section.get("title", ""))
    return (
        f'= {title}\n'
        f'#v(4mm)\n'
        f'#section-intro[#data.at("sections").at({idx}).at("data").at("text")]\n'
    )


_SECTION_BUILDERS: dict[str, object] = {
    "cover-page": _build_cover_page,
    "kpi-row": _build_kpi_row,
    "bar-chart": _build_bar_chart,
    "grouped-bar-chart": _build_grouped_bar_chart,
    "line-chart": _build_line_chart,
    "pie-chart": _build_pie_chart,
    "burndown-chart": _build_burndown_chart,
    "velocity-chart": _build_velocity_chart,
    "radar-chart": _build_radar_chart,
    "gauge-chart": _build_gauge_chart,
    "cfd-chart": _build_cfd_chart,
    "waterfall-chart": _build_waterfall_chart,
    "risk-matrix": _build_risk_matrix,
    "gantt-chart": _build_gantt_chart,
    "data-table": _build_data_table,
    "key-takeaways": _build_key_takeaways,
    "text-section": _build_text_section,
}


# ---------------------------------------------------------------------------
# Typst source builder
# ---------------------------------------------------------------------------


def _build_composed_typ(
    sections_list: list[dict],
) -> str:
    """Generate a complete .typ file string from section definitions."""
    lines: list[str] = [
        '#import "../lib/brand.typ": *',
        '#import "../lib/charts.typ": *',
        '#import "../lib/tables.typ": *',
        '#import "../lib/kpis.typ": *',
        '#import "../lib/gantt.typ": *',
        '#import "../lib/layout.typ": *',
        "",
        '#let data = json("data.json")',
        '#show: brand-page.with(project-name: data.at("title", default: none), draft: data.at("draft", default: false))',
        "",
    ]

    for idx, section in enumerate(sections_list):
        section_type = section.get("type", "")
        builder = _SECTION_BUILDERS.get(section_type)
        if builder is None:
            logger.warning("Unknown section type '%s' at index %d — skipping", section_type, idx)
            continue
        lines.append(builder(idx, section))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main tool
# ---------------------------------------------------------------------------


async def compose_report(
    sections: str,
    title: str = "Custom Report",
    subtitle: str = "",
    author: str = "",
    date: str = "",
    session_id: str = "",
    _context: dict | None = None,
) -> str:
    """Dynamically build a Typst report from user-selected sections, compile to PDF, and return a file reference.

    sections: JSON string — array of section definitions, each with {type, title, data}.
    title / subtitle / author / date: report metadata for the cover page.
    Returns a JSON file reference. The PDF appears as a file attachment in chat.
    """
    sid = _resolve_session_id(session_id, _context)
    if not sid:
        return json.dumps({"error": "No session_id provided"})

    templates_dir = deps.templates_dir
    if templates_dir is None:
        return json.dumps({"error": "templates_dir not initialised"})

    # Parse sections JSON
    try:
        sections_list: list[dict] = json.loads(sections)
    except json.JSONDecodeError as exc:
        return json.dumps({"error": f"Invalid sections JSON: {exc}"})

    if not isinstance(sections_list, list):
        return json.dumps({"error": "sections must be a JSON array"})

    workdir: Path | None = None
    try:
        # Build .typ source
        typ_content = _build_composed_typ(sections_list)

        # Build data.json payload
        data_payload = json.dumps(
            {
                "title": title,
                "subtitle": subtitle,
                "author": author,
                "date": date,
                "sections": sections_list,
            },
            ensure_ascii=False,
        )

        # Create isolated workdir — copy lib/, assets/, fonts/
        workdir = Path(tempfile.mkdtemp(prefix="typst_compose_"))
        for subdir in ("lib", "assets", "fonts"):
            src = templates_dir / subdir
            if src.exists():
                shutil.copytree(src, workdir / subdir, dirs_exist_ok=True)

        # Write generated .typ + data.json into reports/ subdirectory
        reports_sub = workdir / "reports"
        reports_sub.mkdir(parents=True, exist_ok=True)

        typ_file = reports_sub / "composed-report.typ"
        typ_file.write_text(typ_content, encoding="utf-8")
        (reports_sub / "data.json").write_text(data_payload, encoding="utf-8")

        # Compile
        file_id = str(uuid.uuid4())
        output_path = workdir / f"{file_id}.pdf"
        font_path = workdir / "fonts"
        _compile_typst(
            typ_file,
            output_path,
            font_path if font_path.exists() else None,
            root_path=workdir,
        )

        pdf_bytes = output_path.read_bytes()

        # Save PDF to ExportStore
        await deps.export_store.save(sid, file_id, pdf_bytes, "pdf")

        # Save .typ source to ExportStore
        typst_file_id = str(uuid.uuid4())
        await deps.export_store.save(sid, typst_file_id, typ_content.encode("utf-8"), "typ")

        # Count pages
        page_count = None
        try:
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(pdf_bytes))
            page_count = len(reader.pages)
        except Exception:
            pass  # pypdf may not be installed

        result: dict = {
            "session_id": sid,
            "file_id": file_id,
            "file_type": "pdf",
            "url": f"/api/sessions/{sid}/exports/{file_id}",
            "filename": "composed-report.pdf",
            "typst_file_id": typst_file_id,
            "typst_url": f"/api/sessions/{sid}/exports/{typst_file_id}",
        }
        if page_count is not None:
            result["pages"] = page_count
        return json.dumps(result)

    except RuntimeError as exc:
        logger.error("compose_report failed: %s", exc)
        stderr = str(exc)
        if len(stderr) > 2000:
            stderr = "..." + stderr[-2000:]
        return json.dumps({"error": "Typst compilation failed", "stderr": stderr})
    finally:
        if workdir and workdir.exists():
            shutil.rmtree(workdir, ignore_errors=True)


compose_report.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "sections": {
            "type": "string",
            "description": (
                "JSON string: array of section definitions. Each object has "
                '"type" (e.g. "cover-page", "kpi-row", "bar-chart", "line-chart", '
                '"pie-chart", "grouped-bar-chart", "burndown-chart", "velocity-chart", '
                '"radar-chart", "gauge-chart", "cfd-chart", "waterfall-chart", '
                '"risk-matrix", "gantt-chart", "data-table", "key-takeaways", '
                '"text-section"), "title" (section heading), and "data" (dict with '
                "type-specific fields)."
            ),
        },
        "title": {
            "type": "string",
            "description": "Report title (default: 'Custom Report').",
        },
        "subtitle": {
            "type": "string",
            "description": "Report subtitle.",
        },
        "author": {
            "type": "string",
            "description": "Report author name.",
        },
        "date": {
            "type": "string",
            "description": "Report date string.",
        },
        "session_id": {
            "type": "string",
            "description": "Session ID for storage. Usually from context.",
        },
    },
    "required": ["sections"],
}
compose_report.max_result_chars = 5000  # type: ignore[attr-defined]
