import logging
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

from agent.config import settings
from agent.health import router as health_router
from agent.middleware import AuthMiddleware, UserIdentityMiddleware, RequestContextMiddleware
import agent.deps as deps
from agent.auth.router import router as auth_router
from agent.routers.chat import router as chat_router
from agent.routers.documents import router as documents_router, register_exception_handlers
from agent.routers.sessions import router as sessions_router
from agent.routers.skills import router as skills_router
from agent.routers.exports import router as exports_router

logger = logging.getLogger(__name__)
_BACKEND_DIR = Path(__file__).parent.parent.resolve()


@asynccontextmanager
async def lifespan(app: FastAPI):
    n = deps.bootstrap(_BACKEND_DIR)
    deps.store.load_all()
    logger.info("APM started -- v%s, %d skills, servers: %s", settings.app_version, n, deps.registry.server_ids)
    yield
    await deps.registry.shutdown_pool()
    await deps.agent_loop.close()
    logger.info("APM shutdown.")


app = FastAPI(
    title=settings.app_name, version=settings.app_version,
    docs_url="/docs", redoc_url=None, lifespan=lifespan,
)
FastAPIInstrumentor.instrument_app(app)
register_exception_handlers(app)

app.add_middleware(RequestContextMiddleware)
app.add_middleware(UserIdentityMiddleware)
app.add_middleware(AuthMiddleware, api_key=settings.api_key)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

app.include_router(health_router)
app.include_router(auth_router)
app.include_router(chat_router, prefix="/api")
app.include_router(sessions_router, prefix="/api")
app.include_router(documents_router, prefix="/api")
app.include_router(skills_router, prefix="/api")
app.include_router(exports_router, prefix="/api")

if (_dev := _BACKEND_DIR / "tools" / "dev-chat").exists():
    app.mount("/dev-chat", StaticFiles(directory=str(_dev), html=True), name="dev-chat")
if (_dist := _BACKEND_DIR.parent / "frontend" / "dist").exists():
    app.mount("/", StaticFiles(directory=str(_dist), html=True), name="frontend")
