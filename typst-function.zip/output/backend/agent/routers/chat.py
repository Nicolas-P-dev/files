"""Chat endpoints -- thin wrappers around the orchestrator."""

import asyncio
import json
import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

import agent.deps as deps
from agent.internal_tools import drain_panel_events, _panel_events_var, _panel_queue_var

router = APIRouter()
logger = logging.getLogger(__name__)

_AGENT_DONE = object()
_PANEL_POLL_S = 0.1

_FILE_EVENT_TOOLS = frozenset({
    "render_report", "render_chart", "compose_report", "render_dashboard",
})


def _resolve_user_id(request: Request, body: dict) -> str:
    """Return the trusted user ID from the JWT, falling back to the body field."""
    return getattr(request.state, "user_id", None) or body.get("user_id", "default")


def _resolve_jira_context(user_id: str, body_token: str) -> tuple[str, dict | None, str]:
    """Return (jira_token, jira_data_dict, user_email) for the given user.

    If the request body already carries an explicit token, use it.
    Otherwise look up the stored OAuth token (refreshing if needed).
    """
    token = body_token
    if not token:
        token = deps.ensure_jira_access_token(user_id)

    jira_data = deps.resolve_user_jira_data(user_id)
    user_email = deps.resolve_email_from_user_id(user_id) or user_id
    return token, jira_data, user_email


@router.post("/chat")
async def chat(request: Request):
    body = await request.json()
    message = body.get("message", "").strip()
    user_id = _resolve_user_id(request, body)
    session_id = body.get("session_id") or user_id

    if not message:
        return JSONResponse({"error": "No message provided"}, status_code=400)

    token, jira_data, user_email = _resolve_jira_context(
        user_id, str(body.get("token", "")).strip(),
    )

    ctx: dict = dict(body.get("context") or {})
    ctx.pop("mcp_extra_headers", None)
    if user_id:
        ctx["user_id"] = user_id
    if token:
        ctx["user_token"] = token
    xh = deps.mcp_http_extra_headers(jira_data)
    if xh:
        ctx["mcp_extra_headers"] = xh
    result = await deps.orchestrator.handle_sync(
        message, token, user_id,
        context=ctx or None,
        user_jira_data=jira_data,
        user_key=user_email,
    )
    session = deps.store.get_or_create(session_id, user_id)
    session.add_exchange(message, result.get("response", ""))
    await deps.store.save(session)
    return result


@router.post("/chat/stream")
async def chat_stream(request: Request):
    body = await request.json()
    message = body.get("message", "").strip()
    user_id = _resolve_user_id(request, body)
    session_id = body.get("session_id") or user_id
    if not message:
        return JSONResponse({"error": "No message provided"}, status_code=400)

    logger.info("chat/stream: user=%s session=%s", user_id, session_id)

    token, jira_data, user_email = _resolve_jira_context(
        user_id, str(body.get("token", "")).strip(),
    )

    ctx: dict = dict(body.get("context") or {})
    ctx.pop("mcp_extra_headers", None)
    if user_id:
        ctx["user_id"] = user_id
    if token:
        ctx["user_token"] = token
    xh = deps.mcp_http_extra_headers(jira_data)
    if xh:
        ctx["mcp_extra_headers"] = xh

    session = deps.store.get_or_create(session_id, user_id)

    async def _stream():
        panel_queue: asyncio.Queue = asyncio.Queue()
        _panel_queue_var.set(panel_queue)
        _panel_events_var.set([])

        response_parts: list[str] = []
        trace_events: list[dict] = []

        agent_queue: asyncio.Queue = asyncio.Queue()

        async def _pump_agent() -> None:
            try:
                async for event in deps.orchestrator.handle_stream(
                    message, token, user_id,
                    context=ctx or None,
                    user_jira_data=jira_data,
                    user_key=user_email,
                ):
                    await agent_queue.put(event)
            finally:
                await agent_queue.put(_AGENT_DONE)

        pump_task = asyncio.create_task(_pump_agent())

        def _sse_panel(pe: dict) -> str:
            return (
                f"data: {json.dumps({'type': 'panel', 'panel_type': pe['panel_type'], 'data': pe['data']})}\n\n"
            )

        def _emit_file_events(event: dict):
            """Extract file metadata from tool results and yield SSE file events."""
            lines = []
            for tool_name in (event.get("data", {}).get("tools") or []):
                if tool_name not in _FILE_EVENT_TOOLS:
                    continue
                raw = (event.get("data", {}).get("previews") or [""])[0]
                try:
                    fdata = json.loads(raw) if isinstance(raw, str) else raw
                except (json.JSONDecodeError, TypeError):
                    continue

                # render_dashboard returns a list of widget results
                items = fdata if isinstance(fdata, list) else [fdata] if isinstance(fdata, dict) else []
                for item in items:
                    if not isinstance(item, dict) or "file_id" not in item:
                        continue
                    fe = {
                        "type": "file",
                        "file_id": item["file_id"],
                        "file_type": item.get("file_type", "pdf"),
                        "url": item.get("url", ""),
                        "filename": item.get("filename", ""),
                    }
                    if item.get("pages") is not None:
                        fe["pages"] = item["pages"]
                    if item.get("typst_file_id"):
                        fe["typst_file_id"] = item["typst_file_id"]
                        fe["typst_url"] = item.get("typst_url", "")
                    lines.append(f"data: {json.dumps(fe)}\n\n")
            return lines

        agent_fut = asyncio.ensure_future(agent_queue.get())
        try:
            while True:
                while not panel_queue.empty():
                    yield _sse_panel(panel_queue.get_nowait())

                done_set, _ = await asyncio.wait({agent_fut}, timeout=_PANEL_POLL_S)

                if not done_set:
                    continue

                event = agent_fut.result()
                if event is _AGENT_DONE:
                    break

                etype = event.get("type")
                if etype == "token":
                    response_parts.append(event["content"])
                elif etype not in ("done", "token"):
                    if not (etype == "status" and event.get("step") is None):
                        trace_events.append(event)

                yield f"data: {json.dumps(event)}\n\n"

                # Emit file events for report/chart tool results
                if etype == "status" and event.get("step") == "tool_result":
                    for file_line in _emit_file_events(event):
                        yield file_line

                while not panel_queue.empty():
                    yield _sse_panel(panel_queue.get_nowait())

                agent_fut = asyncio.ensure_future(agent_queue.get())

        finally:
            agent_fut.cancel()
            pump_task.cancel()
            while not panel_queue.empty():
                yield _sse_panel(panel_queue.get_nowait())
            for pe in drain_panel_events():
                yield _sse_panel(pe)

            session.add_exchange(message, "".join(response_parts), trace=trace_events)
            logger.info(
                "chat/stream: persisting session %s (user=%s, messages=%d)",
                session_id, user_id, len(session.messages),
            )
            await deps.store.save(session)

    return StreamingResponse(_stream(), media_type="text/event-stream")
