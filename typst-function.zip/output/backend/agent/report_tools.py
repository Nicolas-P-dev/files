"""Internal tools for report/chart generation via Typst.

Follows the same pattern as internal_tools.py: async functions with
``.schema``, ``.max_result_chars``, and optional ``_context`` injection.
"""

import io
import json
import logging
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

import agent.deps as deps
from agent.config import settings

logger = logging.getLogger(__name__)


def _resolve_session_id(session_id: str, _context: dict | None) -> str:
    """Pick the best session ID from explicit arg or context."""
    if session_id:
        return session_id
    if _context:
        return _context.get("doc_session_id", "") or _context.get("session_id", "")
    return ""


def _compile_typst(
    typ_path: Path,
    output_path: Path,
    font_path: Path | None = None,
    root_path: Path | None = None,
) -> None:
    """Run ``typst compile`` as a subprocess."""
    binary = settings.typst_binary or "typst"
    cmd: list[str] = [binary, "compile"]
    # --root is required so templates can resolve ../lib/ relative imports
    if root_path:
        cmd.extend(["--root", str(root_path)])
    if font_path and font_path.exists():
        cmd.extend(["--font-path", str(font_path)])
    if output_path.suffix == ".png":
        cmd.extend(["--ppi", "288"])
    cmd.extend([str(typ_path), str(output_path)])

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(f"Typst compilation failed:\n{result.stderr.strip()}")


def _prepare_workdir(template_path: Path, data_json: str) -> Path:
    """Create an isolated temp directory with template files and data.

    Copies the entire ``templates/`` tree (lib/, assets/, fonts/) so that
    relative imports in templates resolve correctly, then writes the
    data.json file alongside the report template.
    """
    templates_dir = deps.templates_dir
    if templates_dir is None:
        raise RuntimeError("templates_dir not initialised in deps")

    workdir = Path(tempfile.mkdtemp(prefix="typst_"))

    # Copy lib/, assets/, fonts/ into workdir
    for subdir in ("lib", "assets", "fonts"):
        src = templates_dir / subdir
        if src.exists():
            shutil.copytree(src, workdir / subdir, dirs_exist_ok=True)

    # Copy the template itself (preserving subdirectory structure)
    rel = template_path.relative_to(templates_dir)
    dest = workdir / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_path, dest)

    # Write data.json next to the template
    (dest.parent / "data.json").write_text(data_json, encoding="utf-8")

    return workdir


async def render_report(
    template_name: str,
    data: str,
    session_id: str = "",
    _context: dict | None = None,
) -> str:
    """Render a Typst template with data to a branded PDF report.

    Call list_report_templates first to see available templates.
    The data argument is a JSON string matching the template's expected schema.
    Returns a file reference. The PDF appears as a file attachment in chat.
    User clicks it to open the full PDF viewer in the side panel.
    """
    sid = _resolve_session_id(session_id, _context)
    if not sid:
        return json.dumps({"error": "No session_id provided"})

    templates_dir = deps.templates_dir
    if templates_dir is None:
        return json.dumps({"error": "templates_dir not initialised"})

    # Validate template name to prevent path traversal
    if not re.match(r'^[a-zA-Z0-9_-]+$', template_name):
        return json.dumps({"error": "Invalid template name. Use only letters, numbers, hyphens, underscores."})

    template_path = (templates_dir / "reports" / f"{template_name}.typ").resolve()
    reports_dir = (templates_dir / "reports").resolve()
    if not str(template_path).startswith(str(reports_dir)):
        return json.dumps({"error": "Invalid template name"})

    if not template_path.exists():
        available = [p.stem for p in reports_dir.glob("*.typ")]
        return json.dumps({"error": f"Template '{template_name}' not found. Available: {available}"})

    # Validate JSON
    try:
        json.loads(data)
    except json.JSONDecodeError as exc:
        return json.dumps({"error": f"Invalid JSON data: {exc}"})

    workdir: Path | None = None
    try:
        workdir = _prepare_workdir(template_path, data)
        rel = template_path.relative_to(templates_dir)
        typ_file = workdir / rel
        file_id = str(uuid.uuid4())
        output_path = workdir / f"{file_id}.pdf"

        font_path = workdir / "fonts"
        _compile_typst(typ_file, output_path, font_path if font_path.exists() else None, root_path=workdir)

        pdf_bytes = output_path.read_bytes()
        await deps.export_store.save(sid, file_id, pdf_bytes, "pdf")

        # Save .typ source alongside the PDF for export
        typst_file_id = str(uuid.uuid4())
        typ_source = typ_file.read_text(encoding="utf-8")
        data_source = (typ_file.parent / "data.json").read_text(encoding="utf-8")
        # Bundle template + data as a combined source reference
        combined_source = f"// Template: {template_name}.typ\n{typ_source}\n\n// --- data.json ---\n// {data_source}\n"
        await deps.export_store.save(sid, typst_file_id, combined_source.encode("utf-8"), "typ")

        # Count pages
        page_count = None
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(pdf_bytes))
            page_count = len(reader.pages)
        except Exception:
            pass  # pypdf may not be installed

        result: dict = {
            "file_id": file_id,
            "file_type": "pdf",
            "session_id": sid,
            "url": f"/api/sessions/{sid}/exports/{file_id}",
            "filename": f"{template_name}.pdf",
            "typst_file_id": typst_file_id,
            "typst_url": f"/api/sessions/{sid}/exports/{typst_file_id}",
        }
        if page_count is not None:
            result["pages"] = page_count
        return json.dumps(result)

    except RuntimeError as exc:
        logger.error("render_report failed: %s", exc)
        stderr = str(exc)
        if len(stderr) > 2000:
            stderr = "..." + stderr[-2000:]
        return json.dumps({"error": "Typst compilation failed", "stderr": stderr, "template": template_name})
    finally:
        if workdir and workdir.exists():
            shutil.rmtree(workdir, ignore_errors=True)


render_report.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "template_name": {
            "type": "string",
            "description": "Template name (e.g. 'project-status', 'sprint-health'). Call list_report_templates to see options.",
        },
        "data": {
            "type": "string",
            "description": "JSON string of report data matching the template's expected schema.",
        },
        "session_id": {
            "type": "string",
            "description": "Session ID for storage. Usually from context.",
        },
    },
    "required": ["template_name", "data"],
}
render_report.max_result_chars = 5000  # type: ignore[attr-defined]


# Chart type → Typst function name mapping
_CHART_FUNCTIONS: dict[str, str] = {
    "bar": "bar-chart",
    "grouped-bar": "grouped-bar-chart",
    "line": "line-chart",
    "pie": "pie-chart",
    "burndown": "burndown-chart",
    "velocity": "velocity-chart",
    "gantt": "gantt-chart",
    "radar": "radar-chart",
    "gauge": "gauge-chart",
    "cfd": "cfd-chart",
    "waterfall": "waterfall-chart",
}


def _escape_typst_string(s: str) -> str:
    """Escape characters for use inside a Typst double-quoted string."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _build_chart_typ(chart_type: str, title: str) -> str:
    """Generate a minimal .typ file for a standalone chart."""
    fn = _CHART_FUNCTIONS.get(chart_type)
    if fn is None:
        raise ValueError(f"Unknown chart type '{chart_type}'. Available: {list(_CHART_FUNCTIONS.keys())}")

    imports = '#import "lib/brand.typ": *\n#import "lib/charts.typ": *\n'
    if chart_type == "gantt":
        imports += '#import "lib/gantt.typ": *\n'

    page_setup = '#set page(width: 20cm, height: 12cm, margin: 1cm)\n'
    page_setup += '#set text(font: "Open Sans", size: 10pt)\n\n'

    title_arg = f'  title: "{_escape_typst_string(title)}",\n' if title else ""

    if chart_type == "gantt":
        call = f"#{fn}(\n{title_arg}  tasks: json(\"data.json\"),\n)"
    elif chart_type in ("burndown",):
        call = f"#{fn}(\n{title_arg}  data: json(\"data.json\").map(b => (b.at(\"day\"), b.at(\"remaining\"))),\n)"
    elif chart_type == "velocity":
        call = f"#{fn}(\n{title_arg}  data: json(\"data.json\").map(v => (v.at(0), v.at(1))),\n)"
    elif chart_type in ("line", "grouped-bar", "cfd"):
        call = f"#{fn}(\n{title_arg}  data: json(\"data.json\"),\n)"
    elif chart_type == "gauge":
        # Gauge expects: {"value": number, "max": number, "label": string}
        call = f'#{{let d = json("data.json")\n{fn}(\n{title_arg}  value: d.at("value", default: 0),\n  max: d.at("max", default: 100),\n  label: d.at("label", default: ""),\n)}}'
    elif chart_type == "waterfall":
        call = f"#{fn}(\n{title_arg}  data: json(\"data.json\").map(d => (d.at(0), d.at(1))),\n)"
    else:
        call = f"#{fn}(\n{title_arg}  data: json(\"data.json\").map(d => (d.at(0), d.at(1))),\n)"

    return imports + page_setup + call


async def render_chart(
    chart_type: str,
    data: str,
    title: str = "",
    session_id: str = "",
    _context: dict | None = None,
) -> str:
    """Render a standalone chart as a PNG image. Appears inline in chat.

    chart_type: bar, line, pie, burndown, velocity, gantt
    data: JSON string of chart data points
    title: chart title
    Returns a file reference with an image URL for inline display.
    """
    sid = _resolve_session_id(session_id, _context)
    if not sid:
        return json.dumps({"error": "No session_id provided"})

    templates_dir = deps.templates_dir
    if templates_dir is None:
        return json.dumps({"error": "templates_dir not initialised"})

    try:
        json.loads(data)
    except json.JSONDecodeError as exc:
        return json.dumps({"error": f"Invalid JSON data: {exc}"})

    workdir: Path | None = None
    try:
        typ_content = _build_chart_typ(chart_type, title)

        workdir = Path(tempfile.mkdtemp(prefix="typst_chart_"))
        for subdir in ("lib", "assets", "fonts"):
            src = templates_dir / subdir
            if src.exists():
                shutil.copytree(src, workdir / subdir, dirs_exist_ok=True)

        typ_file = workdir / "chart.typ"
        typ_file.write_text(typ_content, encoding="utf-8")
        (workdir / "data.json").write_text(data, encoding="utf-8")

        file_id = str(uuid.uuid4())
        output_path = workdir / f"{file_id}.png"

        font_path = workdir / "fonts"
        _compile_typst(typ_file, output_path, font_path if font_path.exists() else None, root_path=workdir)

        png_bytes = output_path.read_bytes()
        await deps.export_store.save(sid, file_id, png_bytes, "png")

        # Save .typ source for chart export
        typst_file_id = str(uuid.uuid4())
        await deps.export_store.save(sid, typst_file_id, typ_content.encode("utf-8"), "typ")

        slug = chart_type + ("-chart" if "chart" not in chart_type else "")
        return json.dumps({
            "file_id": file_id,
            "file_type": "image",
            "session_id": sid,
            "url": f"/api/sessions/{sid}/exports/{file_id}",
            "filename": f"{slug}.png",
            "typst_file_id": typst_file_id,
            "typst_url": f"/api/sessions/{sid}/exports/{typst_file_id}",
        })

    except (ValueError, RuntimeError) as exc:
        logger.error("render_chart failed: %s", exc)
        return json.dumps({"error": str(exc)})
    finally:
        if workdir and workdir.exists():
            shutil.rmtree(workdir, ignore_errors=True)


render_chart.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "chart_type": {
            "type": "string",
            "description": "Chart type: bar, grouped-bar, line, pie, burndown, velocity, gantt, radar, gauge, cfd, waterfall",
            "enum": ["bar", "grouped-bar", "line", "pie", "burndown", "velocity", "gantt", "radar", "gauge", "cfd", "waterfall"],
        },
        "data": {
            "type": "string",
            "description": "JSON string of chart data. Format depends on chart_type.",
        },
        "title": {
            "type": "string",
            "description": "Chart title (optional).",
        },
        "session_id": {
            "type": "string",
            "description": "Session ID for storage. Usually from context.",
        },
    },
    "required": ["chart_type", "data"],
}
render_chart.max_result_chars = 5000  # type: ignore[attr-defined]


async def list_report_templates(_context: dict | None = None) -> str:
    """List available report templates and their expected data schemas."""
    templates_dir = deps.templates_dir
    if templates_dir is None:
        return json.dumps({"error": "templates_dir not initialised"})

    reports_dir = templates_dir / "reports"
    if not reports_dir.exists():
        return json.dumps({"templates": []})

    templates: list[dict[str, str]] = []
    for path in sorted(reports_dir.glob("*.typ")):
        schema_lines: list[str] = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                if line.startswith("//"):
                    schema_lines.append(line.lstrip("/ ").rstrip())
                elif schema_lines:
                    break
        templates.append({
            "name": path.stem,
            "schema_description": "\n".join(schema_lines),
        })

    chart_types = list(_CHART_FUNCTIONS.keys())

    return json.dumps({
        "templates": templates,
        "chart_types": chart_types,
    })


list_report_templates.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {},
    "required": [],
}
list_report_templates.max_result_chars = 10000  # type: ignore[attr-defined]


async def get_report_source(
    file_id: str,
    session_id: str = "",
    _context: dict | None = None,
) -> str:
    """Retrieve the Typst source code for a previously generated report or chart.

    Use the typst_file_id from a render_report, render_chart, or compose_report result.
    Returns the raw .typ source so the user can view, copy, or modify it.
    """
    sid = _resolve_session_id(session_id, _context)
    if not sid:
        return json.dumps({"error": "No session_id provided"})

    try:
        result = await deps.export_store.get(sid, file_id)
        if result is None:
            return json.dumps({"error": f"Source file '{file_id}' not found"})
        source_bytes, _ext = result
        source_text = source_bytes.decode("utf-8")
        return json.dumps({
            "file_id": file_id,
            "source": source_text,
        })
    except Exception as exc:
        logger.error("get_report_source failed: %s", exc)
        return json.dumps({"error": str(exc)})


get_report_source.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "file_id": {
            "type": "string",
            "description": "The typst_file_id from a render_report, render_chart, or compose_report result.",
        },
        "session_id": {
            "type": "string",
            "description": "Session ID for storage. Usually from context.",
        },
    },
    "required": ["file_id"],
}
get_report_source.max_result_chars = 30000  # type: ignore[attr-defined]
