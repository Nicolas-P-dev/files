"""Session-scoped file store for generated exports (PDFs and PNGs)."""

import shutil
from pathlib import Path


class ExportStore:
    """Local filesystem store for generated report/chart files.

    Files are stored as ``{base_dir}/{session_id}/{file_id}.{ext}``.
    Structured so a future S3 backend only needs to replace these methods.
    """

    def __init__(self, base_dir: Path) -> None:
        self._base = base_dir

    async def save(self, session_id: str, file_id: str, data: bytes, ext: str = "pdf") -> str:
        """Persist file bytes and return the stored path."""
        path = self._base / session_id / f"{file_id}.{ext}"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return str(path)

    async def get(self, session_id: str, file_id: str) -> tuple[bytes, str] | None:
        """Return ``(data, extension)`` or ``None`` if not found."""
        session_dir = self._base / session_id
        if not session_dir.exists():
            return None
        for path in session_dir.glob(f"{file_id}.*"):
            return path.read_bytes(), path.suffix.lstrip(".")
        return None

    async def delete_session(self, session_id: str) -> None:
        """Remove all exports for a session."""
        session_dir = self._base / session_id
        if session_dir.exists():
            shutil.rmtree(session_dir)
