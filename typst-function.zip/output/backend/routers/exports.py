"""Serve generated export files (PDFs, PNGs)."""

import logging

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse, Response

import agent.deps as deps

router = APIRouter()
logger = logging.getLogger(__name__)

_CONTENT_TYPES: dict[str, str] = {
    "pdf": "application/pdf",
    "png": "image/png",
    "typ": "text/plain; charset=utf-8",
}


@router.get("/sessions/{session_id}/exports/{file_id}")
async def get_export(session_id: str, file_id: str, download: bool = Query(False)):
    """Serve a generated export file."""
    if deps.export_store is None:
        return JSONResponse({"error": "Export store not initialised"}, status_code=500)

    result = await deps.export_store.get(session_id, file_id)
    if result is None:
        return JSONResponse({"error": "File not found"}, status_code=404)

    data, ext = result
    content_type = _CONTENT_TYPES.get(ext, "application/octet-stream")
    disposition = "attachment" if download else "inline"
    filename = f"{file_id}.{ext}"

    return Response(
        content=data,
        media_type=content_type,
        headers={
            "Content-Disposition": f'{disposition}; filename="{filename}"',
            "Cache-Control": "private, max-age=3600",
        },
    )


@router.post("/sessions/{session_id}/tools/{tool_name}")
async def invoke_tool(session_id: str, tool_name: str, request: Request):
    """Direct tool invocation for panel UIs (no chat/SSE flow)."""
    # Whitelist of allowed tools
    allowed = {"compose_report", "render_dashboard", "render_chart"}
    if tool_name not in allowed:
        return JSONResponse({"error": f"Tool '{tool_name}' not available for direct invocation"}, status_code=400)

    body = await request.json()
    args = body.get("args", {})

    # Inject session_id and build context
    args["session_id"] = session_id
    context = {"session_id": session_id, "doc_session_id": session_id}
    args["_context"] = context

    # Import and call the tool
    try:
        if tool_name == "compose_report":
            from agent.composer_tools import compose_report
            result = await compose_report(**args)
        elif tool_name == "render_dashboard":
            from agent.dashboard_tools import render_dashboard
            result = await render_dashboard(**args)
        elif tool_name == "render_chart":
            from agent.report_tools import render_chart
            result = await render_chart(**args)
        else:
            return JSONResponse({"error": "Unknown tool"}, status_code=400)

        import json
        return JSONResponse(json.loads(result))
    except Exception as exc:
        logger.error("Tool invocation failed: %s", exc)
        return JSONResponse({"error": str(exc)}, status_code=500)
