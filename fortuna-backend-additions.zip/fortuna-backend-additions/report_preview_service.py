"""
FORTUNA Report Preview Service
==============================
Service to generate preview data from actual Excel reports or agent logs.
"""

from typing import Optional, Dict, Any, List
from datetime import datetime
import json
import os

# Optional: Import openpyxl for Excel reading
try:
    from openpyxl import load_workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


class ReportPreviewService:
    """
    Service to generate report preview data for frontend visualization.
    Can read from actual Excel files or generate from agent logs.
    """
    
    def __init__(self, reports_dir: str = "./reports"):
        """
        Initialize preview service.
        
        Args:
            reports_dir: Directory where generated reports are stored
        """
        self.reports_dir = reports_dir
    
    def get_preview(self, debtor_id: Optional[str] = None, 
                   agent_logs: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Get report preview data.
        
        Priority:
        1. Try to read from actual Excel file
        2. Generate from agent logs if available
        3. Return demo data
        
        Args:
            debtor_id: Current debtor ID
            agent_logs: Agent extraction logs
            
        Returns:
            Dict with sheets data for preview
        """
        # Try to load from Excel file
        if debtor_id and OPENPYXL_AVAILABLE:
            excel_preview = self._load_from_excel(debtor_id)
            if excel_preview:
                return excel_preview
        
        # Try to generate from agent logs
        if agent_logs:
            logs_preview = self._generate_from_logs(agent_logs, debtor_id)
            if logs_preview:
                return logs_preview
        
        # Return demo data
        return self._get_demo_data(debtor_id)
    
    def _load_from_excel(self, debtor_id: str) -> Optional[Dict[str, Any]]:
        """Load preview data from actual Excel file."""
        try:
            # Look for the report file
            possible_paths = [
                os.path.join(self.reports_dir, f"{debtor_id}_Filled_Template.xlsx"),
                os.path.join(self.reports_dir, f"{debtor_id}_Report.xlsx"),
                os.path.join(self.reports_dir, f"{debtor_id}.xlsx"),
            ]
            
            excel_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    excel_path = path
                    break
            
            if not excel_path:
                return None
            
            wb = load_workbook(excel_path, data_only=True)
            sheets = []
            
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                
                # Get headers from first row
                headers = []
                data = []
                
                for row_idx, row in enumerate(ws.iter_rows(values_only=True)):
                    if row_idx == 0:
                        headers = [str(cell) if cell else "" for cell in row]
                    else:
                        data.append([str(cell) if cell else "" for cell in row])
                
                sheets.append({
                    "name": sheet_name,
                    "headers": headers,
                    "data": data
                })
            
            return {
                "sheets": sheets,
                "debtor": debtor_id,
                "generated_at": datetime.now().isoformat(),
                "source": "excel_file"
            }
            
        except Exception as e:
            print(f"Error loading Excel: {e}")
            return None
    
    def _generate_from_logs(self, agent_logs: Dict, 
                           debtor_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Generate preview from agent extraction logs."""
        try:
            sheets = []
            
            # Process each major category in agent logs
            if "Balance Sheet" in agent_logs or any(k in agent_logs for k in ["Assets", "Liabilities", "Equity"]):
                balance_sheet = self._extract_balance_sheet(agent_logs)
                if balance_sheet:
                    sheets.append(balance_sheet)
            
            if "Profit & Loss" in agent_logs or "P&L" in agent_logs or "Income Statement" in agent_logs:
                pnl = self._extract_pnl(agent_logs)
                if pnl:
                    sheets.append(pnl)
            
            if "Cash Flow" in agent_logs or any(k in agent_logs for k in ["Operating", "Investing", "Financing"]):
                cashflow = self._extract_cashflow(agent_logs)
                if cashflow:
                    sheets.append(cashflow)
            
            if sheets:
                return {
                    "sheets": sheets,
                    "debtor": debtor_id,
                    "generated_at": datetime.now().isoformat(),
                    "source": "agent_logs"
                }
            
            return None
            
        except Exception as e:
            print(f"Error generating from logs: {e}")
            return None
    
    def _extract_balance_sheet(self, logs: Dict) -> Optional[Dict]:
        """Extract balance sheet data from logs."""
        try:
            headers = ["Field", "2023", "2022", "2021", "Source", "Page"]
            data = []
            
            # Helper to extract value info
            def add_field(name: str, field_data: Any, indent: int = 0):
                prefix = "  " * indent
                if isinstance(field_data, dict):
                    value = field_data.get("Value", field_data.get("value", ""))
                    sources = field_data.get("Sources", field_data.get("sources", []))
                    pages = field_data.get("Page Numbers", field_data.get("page_numbers", []))
                    
                    source_str = sources[0] if sources else ""
                    page_str = str(pages[0]) if pages else ""
                    
                    data.append([prefix + name, str(value), "", "", source_str, page_str])
                else:
                    data.append([prefix + name, str(field_data), "", "", "", ""])
            
            # Process Assets
            assets = logs.get("Assets", logs.get("Balance Sheet", {}).get("Assets", {}))
            if assets:
                data.append(["ASSETS", "", "", "", "", ""])
                
                non_current = assets.get("Non-Current Assets", assets.get("non_current_assets", {}))
                if non_current:
                    data.append(["Non-Current Assets", "", "", "", "", ""])
                    for field, value in non_current.items():
                        add_field(field, value, 1)
                
                current = assets.get("Current Assets", assets.get("current_assets", {}))
                if current:
                    data.append(["Current Assets", "", "", "", "", ""])
                    for field, value in current.items():
                        add_field(field, value, 1)
            
            # Process Liabilities
            liabilities = logs.get("Liabilities", logs.get("Balance Sheet", {}).get("Liabilities", {}))
            if liabilities:
                data.append(["", "", "", "", "", ""])
                data.append(["LIABILITIES", "", "", "", "", ""])
                
                for section, items in liabilities.items():
                    data.append([section, "", "", "", "", ""])
                    if isinstance(items, dict):
                        for field, value in items.items():
                            add_field(field, value, 1)
            
            # Process Equity
            equity = logs.get("Equity", logs.get("Balance Sheet", {}).get("Equity", {}))
            if equity:
                data.append(["", "", "", "", "", ""])
                data.append(["EQUITY", "", "", "", "", ""])
                for field, value in equity.items():
                    add_field(field, value, 1)
            
            if len(data) > 1:
                return {
                    "name": "Balance Sheet",
                    "headers": headers,
                    "data": data
                }
            
            return None
            
        except Exception as e:
            print(f"Error extracting balance sheet: {e}")
            return None
    
    def _extract_pnl(self, logs: Dict) -> Optional[Dict]:
        """Extract P&L data from logs."""
        try:
            headers = ["Field", "2023", "2022", "2021", "Source", "Page"]
            data = []
            
            pnl = logs.get("Profit & Loss", logs.get("P&L", logs.get("Income Statement", {})))
            
            if pnl:
                for field, value in pnl.items():
                    if isinstance(value, dict):
                        val = value.get("Value", value.get("value", ""))
                        sources = value.get("Sources", value.get("sources", []))
                        pages = value.get("Page Numbers", value.get("page_numbers", []))
                        
                        source_str = sources[0] if sources else ""
                        page_str = str(pages[0]) if pages else ""
                        
                        data.append([field, str(val), "", "", source_str, page_str])
                    else:
                        data.append([field, str(value), "", "", "", ""])
            
            if data:
                return {
                    "name": "Profit & Loss",
                    "headers": headers,
                    "data": data
                }
            
            return None
            
        except Exception as e:
            print(f"Error extracting P&L: {e}")
            return None
    
    def _extract_cashflow(self, logs: Dict) -> Optional[Dict]:
        """Extract cash flow data from logs."""
        try:
            headers = ["Field", "2023", "2022", "2021", "Source", "Page"]
            data = []
            
            cashflow = logs.get("Cash Flow", logs.get("Cash Flows", {}))
            
            sections = ["Operating Activities", "Investing Activities", "Financing Activities"]
            
            for section in sections:
                section_data = cashflow.get(section, {})
                if section_data:
                    data.append([section, "", "", "", "", ""])
                    for field, value in section_data.items():
                        if isinstance(value, dict):
                            val = value.get("Value", value.get("value", ""))
                            sources = value.get("Sources", value.get("sources", []))
                            pages = value.get("Page Numbers", value.get("page_numbers", []))
                            
                            source_str = sources[0] if sources else ""
                            page_str = str(pages[0]) if pages else ""
                            
                            data.append(["  " + field, str(val), "", "", source_str, page_str])
                        else:
                            data.append(["  " + field, str(value), "", "", "", ""])
                    data.append(["", "", "", "", "", ""])
            
            if len(data) > 3:
                return {
                    "name": "Cash Flow",
                    "headers": headers,
                    "data": data
                }
            
            return None
            
        except Exception as e:
            print(f"Error extracting cash flow: {e}")
            return None
    
    def _get_demo_data(self, debtor_id: Optional[str] = None) -> Dict[str, Any]:
        """Return demo preview data."""
        return {
            "sheets": [
                {
                    "name": "Balance Sheet",
                    "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
                    "data": [
                        ["ASSETS", "", "", "", "", ""],
                        ["Non-Current Assets", "", "", "", "", ""],
                        ["Property, Plant & Equipment", "12,450,000", "11,890,000", "10,234,000", "Annual Report", "24"],
                        ["Intangible Assets", "3,200,000", "3,450,000", "3,100,000", "Annual Report", "25"],
                        ["Long-term Investments", "5,600,000", "4,800,000", "4,200,000", "Annual Report", "26"],
                        ["", "", "", "", "", ""],
                        ["Current Assets", "", "", "", "", ""],
                        ["Cash & Equivalents", "8,900,000", "7,200,000", "6,500,000", "Annual Report", "28"],
                        ["Trade Receivables", "4,500,000", "4,100,000", "3,800,000", "Annual Report", "29"],
                        ["Inventories", "2,300,000", "2,100,000", "1,900,000", "Annual Report", "30"],
                        ["Total Assets", "36,950,000", "33,540,000", "29,734,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["LIABILITIES", "", "", "", "", ""],
                        ["Non-Current Liabilities", "", "", "", "", ""],
                        ["Long-term Debt", "8,000,000", "9,500,000", "8,200,000", "Annual Report", "32"],
                        ["Deferred Tax Liabilities", "1,200,000", "1,100,000", "950,000", "Annual Report", "33"],
                        ["", "", "", "", "", ""],
                        ["Current Liabilities", "", "", "", "", ""],
                        ["Trade Payables", "3,400,000", "3,100,000", "2,800,000", "Annual Report", "35"],
                        ["Short-term Borrowings", "2,000,000", "2,500,000", "2,200,000", "Annual Report", "35"],
                        ["Total Liabilities", "14,600,000", "16,200,000", "14,150,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["EQUITY", "", "", "", "", ""],
                        ["Share Capital", "10,000,000", "10,000,000", "10,000,000", "Annual Report", "38"],
                        ["Retained Earnings", "12,350,000", "7,340,000", "5,584,000", "Annual Report", "38"],
                        ["Total Equity", "22,350,000", "17,340,000", "15,584,000", "Calculated", "-"],
                    ]
                },
                {
                    "name": "Profit & Loss",
                    "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
                    "data": [
                        ["Revenue", "45,000,000", "42,000,000", "38,500,000", "Annual Report", "12"],
                        ["Cost of Sales", "-28,000,000", "-26,500,000", "-24,200,000", "Annual Report", "12"],
                        ["Gross Profit", "17,000,000", "15,500,000", "14,300,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Operating Expenses", "-8,500,000", "-8,100,000", "-7,800,000", "Annual Report", "14"],
                        ["Operating Profit", "8,500,000", "7,400,000", "6,500,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Finance Costs", "-800,000", "-950,000", "-850,000", "Annual Report", "16"],
                        ["Profit Before Tax", "7,700,000", "6,450,000", "5,650,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Income Tax", "-2,310,000", "-1,935,000", "-1,695,000", "Annual Report", "18"],
                        ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "Calculated", "-"],
                    ]
                },
                {
                    "name": "Cash Flow",
                    "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
                    "data": [
                        ["Operating Activities", "", "", "", "", ""],
                        ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "P&L", "-"],
                        ["Depreciation", "1,200,000", "1,100,000", "980,000", "Annual Report", "42"],
                        ["Changes in Working Capital", "-450,000", "-320,000", "-280,000", "Annual Report", "43"],
                        ["Cash from Operations", "6,140,000", "5,295,000", "4,655,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Investing Activities", "", "", "", "", ""],
                        ["Capital Expenditure", "-1,760,000", "-2,756,000", "-1,500,000", "Annual Report", "45"],
                        ["Acquisitions", "0", "0", "-500,000", "Annual Report", "45"],
                        ["Cash from Investing", "-1,760,000", "-2,756,000", "-2,000,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Financing Activities", "", "", "", "", ""],
                        ["Debt Repayment", "-1,500,000", "-1,200,000", "-1,000,000", "Annual Report", "47"],
                        ["Dividends Paid", "-380,000", "-539,000", "-355,000", "Annual Report", "48"],
                        ["Cash from Financing", "-1,880,000", "-1,739,000", "-1,355,000", "Calculated", "-"],
                        ["", "", "", "", "", ""],
                        ["Net Change in Cash", "2,500,000", "800,000", "1,300,000", "Calculated", "-"],
                    ]
                }
            ],
            "debtor": debtor_id,
            "generated_at": datetime.now().isoformat(),
            "source": "demo_data"
        }


# Singleton instance
_preview_service: Optional[ReportPreviewService] = None


def get_preview_service(reports_dir: str = "./reports") -> ReportPreviewService:
    """Get or create preview service instance."""
    global _preview_service
    if _preview_service is None:
        _preview_service = ReportPreviewService(reports_dir=reports_dir)
    return _preview_service
