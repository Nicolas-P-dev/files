"""
FORTUNA Backend Additions
========================
New endpoints to support the upgraded frontend.
Add these to your existing FastAPI application.

These endpoints provide:
1. Chat functionality for Level #1 (understanding report generation)
2. Report preview data for Excel visualization
3. Enhanced statistics endpoint
"""

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
import os
from datetime import datetime

# Create router for new endpoints
router = APIRouter()


# ============================================================================
# MODELS
# ============================================================================

class ChatRequest(BaseModel):
    """Request model for chat endpoint"""
    message: str
    mode: Optional[str] = "attributions"  # "attributions" or "general"
    context: Optional[str] = None  # Optional agent logs context


class ChatResponse(BaseModel):
    """Response model for chat endpoint"""
    response: str
    sources: Optional[List[Dict[str, Any]]] = None
    timestamp: str


class ReportPreviewSheet(BaseModel):
    """Model for a single sheet in report preview"""
    name: str
    headers: List[str]
    data: List[List[Any]]


class ReportPreviewResponse(BaseModel):
    """Response model for report preview"""
    sheets: List[ReportPreviewSheet]
    debtor: Optional[str] = None
    generated_at: str


class DashboardStats(BaseModel):
    """Model for dashboard statistics"""
    documents_processed: int
    fields_extracted: int
    reports_generated: int
    accuracy: float
    last_updated: str


# ============================================================================
# CHAT ENDPOINT
# ============================================================================

# Knowledge base for chat responses (Level #1: Understanding report generation)
CHAT_KNOWLEDGE_BASE = {
    "assets": {
        "keywords": ["asset", "current asset", "non-current asset", "property", "equipment", "inventory", "receivable", "cash"],
        "response": """The assets section is extracted from the balance sheet in the financial statements. 

**Current Assets** include:
- Cash and cash equivalents
- Trade receivables  
- Inventories
- Prepaid expenses

**Non-Current Assets** include:
- Property, plant & equipment
- Intangible assets
- Long-term investments

Each extracted value includes:
- The monetary amount
- Source document reference
- Page number for verification
- Extraction explanation

You can click on any field in the Attributions panel to see its complete source trail.""",
        "sources": [{"doc": "Financial Statements", "page": 12}]
    },
    "liabilities": {
        "keywords": ["liabilit", "debt", "payable", "borrowing", "loan"],
        "response": """Liabilities are extracted from the balance sheet and categorized as:

**Current Liabilities** (due within 1 year):
- Trade payables
- Short-term borrowings
- Accrued expenses
- Current portion of long-term debt

**Non-Current Liabilities** (due after 1 year):
- Long-term debt
- Deferred tax liabilities
- Pension obligations

The extraction agents identify these items by analyzing the balance sheet structure and matching line items to the CFR template fields.""",
        "sources": [{"doc": "Financial Statements", "page": 15}]
    },
    "equity": {
        "keywords": ["equity", "capital", "retained", "reserves", "shareholder"],
        "response": """The equity section captures the ownership interest in the company:

- **Share Capital**: Issued and paid-up capital
- **Retained Earnings**: Accumulated profits/losses
- **Reserves**: Capital reserves, revaluation reserves
- **Other Comprehensive Income**: Items not in P&L

Values are extracted from both the balance sheet and statement of changes in equity, with cross-referencing to ensure accuracy.""",
        "sources": [{"doc": "Financial Statements", "page": 18}]
    },
    "source": {
        "keywords": ["source", "where", "reference", "page", "document", "attribution"],
        "response": """Every extracted field includes full source attribution:

**Attribution Components:**
1. **Value**: The extracted data point
2. **Source Document**: The file name (e.g., "Annual Report 2023.pdf")
3. **Page Number**: Exact page where data was found
4. **Explanation**: How the extraction agent interpreted the text

**Verification Process:**
- Click any field in the Attributions panel
- Review the source reference
- Open the original document to verify

This ensures complete audit traceability for CFR compliance.""",
        "sources": []
    },
    "accuracy": {
        "keywords": ["accuracy", "confidence", "reliable", "correct", "sure", "trust"],
        "response": """Extraction confidence is determined by multiple factors:

**High Confidence Indicators:**
- Clear, unambiguous text in source document
- Multiple corroborating references
- Exact match with template field definition
- Consistent values across documents

**Lower Confidence Scenarios:**
- Handwritten or scanned documents
- Ambiguous terminology
- Single source reference
- Complex calculations required

You can verify any extraction by checking the source document directly. The page number references allow quick lookup.""",
        "sources": []
    },
    "methodology": {
        "keywords": ["how", "extract", "work", "process", "method", "agent"],
        "response": """FORTUNA uses a multi-agent extraction pipeline:

**1. Document Processing**
- PDFs parsed using Azure Document Intelligence
- Text, tables, and structure extracted
- Documents classified by type

**2. Specialized Extraction Agents**
- Non-Current Assets Agent
- Current Assets Agent  
- Liabilities Agents (current/non-current)
- Equity Agent
- P&L Agent
- Cash Flow Agents

**3. Attribution & Validation**
- Each value linked to source location
- Cross-references checked for consistency
- Confidence scores calculated

**4. Report Generation**
- Template populated with extracted values
- Source references preserved as comments
- Excel report generated for download""",
        "sources": []
    },
    "download": {
        "keywords": ["download", "export", "excel", "report", "save"],
        "response": """To download the completed CFR report:

1. Navigate to **Report Preview** in the sidebar
2. Review the populated data in the spreadsheet view
3. Click **Download Report (.xlsx)** button (bottom-right)

**Report Contents:**
- Balance Sheet with 3-year comparison
- Profit & Loss statement
- Cash Flow statement
- Source attributions in cell comments

The downloaded Excel file is ready for review and submission.""",
        "sources": []
    }
}


def find_best_response(query: str, context: Optional[str] = None) -> Dict[str, Any]:
    """Find the most relevant response based on query keywords"""
    query_lower = query.lower()
    
    # Check each knowledge category
    for category, data in CHAT_KNOWLEDGE_BASE.items():
        for keyword in data["keywords"]:
            if keyword in query_lower:
                return {
                    "response": data["response"],
                    "sources": data.get("sources", [])
                }
    
    # Default response if no match
    return {
        "response": """I can help you understand how FORTUNA extracted the report data. Try asking about:

• **Specific categories**: "How were assets extracted?" or "Tell me about the liabilities section"
• **Source attribution**: "Where did this value come from?" or "Show me the source references"
• **Methodology**: "How does the extraction process work?"
• **Confidence**: "How accurate are the extractions?"
• **Export**: "How do I download the report?"

What would you like to know more about?""",
        "sources": []
    }


@router.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Chat endpoint for Level #1 functionality: Understanding how report was generated.
    
    This provides contextual responses about:
    - Extraction methodology
    - Source attributions
    - Field explanations
    - Data verification
    """
    try:
        # Find best response based on query
        result = find_best_response(request.message, request.context)
        
        return ChatResponse(
            response=result["response"],
            sources=result["sources"] if result["sources"] else None,
            timestamp=datetime.now().isoformat()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat error: {str(e)}")


# ============================================================================
# REPORT PREVIEW ENDPOINT
# ============================================================================

def get_report_preview_data(debtor_id: str = None) -> Dict[str, Any]:
    """
    Generate report preview data.
    In production, this would read from the actual generated Excel file.
    """
    # Try to load from actual agent logs if available
    # For now, return structured preview data
    
    sheets = [
        {
            "name": "Balance Sheet",
            "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
            "data": [
                ["ASSETS", "", "", "", "", ""],
                ["Non-Current Assets", "", "", "", "", ""],
                ["Property, Plant & Equipment", "12,450,000", "11,890,000", "10,234,000", "Annual Report", "24"],
                ["Intangible Assets", "3,200,000", "3,450,000", "3,100,000", "Annual Report", "25"],
                ["Long-term Investments", "5,600,000", "4,800,000", "4,200,000", "Annual Report", "26"],
                ["", "", "", "", "", ""],
                ["Current Assets", "", "", "", "", ""],
                ["Cash & Equivalents", "8,900,000", "7,200,000", "6,500,000", "Annual Report", "28"],
                ["Trade Receivables", "4,500,000", "4,100,000", "3,800,000", "Annual Report", "29"],
                ["Inventories", "2,300,000", "2,100,000", "1,900,000", "Annual Report", "30"],
                ["Total Assets", "36,950,000", "33,540,000", "29,734,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["LIABILITIES", "", "", "", "", ""],
                ["Non-Current Liabilities", "", "", "", "", ""],
                ["Long-term Debt", "8,000,000", "9,500,000", "8,200,000", "Annual Report", "32"],
                ["Deferred Tax Liabilities", "1,200,000", "1,100,000", "950,000", "Annual Report", "33"],
                ["", "", "", "", "", ""],
                ["Current Liabilities", "", "", "", "", ""],
                ["Trade Payables", "3,400,000", "3,100,000", "2,800,000", "Annual Report", "35"],
                ["Short-term Borrowings", "2,000,000", "2,500,000", "2,200,000", "Annual Report", "35"],
                ["Total Liabilities", "14,600,000", "16,200,000", "14,150,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["EQUITY", "", "", "", "", ""],
                ["Share Capital", "10,000,000", "10,000,000", "10,000,000", "Annual Report", "38"],
                ["Retained Earnings", "12,350,000", "7,340,000", "5,584,000", "Annual Report", "38"],
                ["Total Equity", "22,350,000", "17,340,000", "15,584,000", "Calculated", "-"],
            ]
        },
        {
            "name": "Profit & Loss",
            "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
            "data": [
                ["Revenue", "45,000,000", "42,000,000", "38,500,000", "Annual Report", "12"],
                ["Cost of Sales", "-28,000,000", "-26,500,000", "-24,200,000", "Annual Report", "12"],
                ["Gross Profit", "17,000,000", "15,500,000", "14,300,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Operating Expenses", "-8,500,000", "-8,100,000", "-7,800,000", "Annual Report", "14"],
                ["Operating Profit", "8,500,000", "7,400,000", "6,500,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Finance Costs", "-800,000", "-950,000", "-850,000", "Annual Report", "16"],
                ["Profit Before Tax", "7,700,000", "6,450,000", "5,650,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Income Tax", "-2,310,000", "-1,935,000", "-1,695,000", "Annual Report", "18"],
                ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "Calculated", "-"],
            ]
        },
        {
            "name": "Cash Flow",
            "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
            "data": [
                ["Operating Activities", "", "", "", "", ""],
                ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "P&L", "-"],
                ["Depreciation", "1,200,000", "1,100,000", "980,000", "Annual Report", "42"],
                ["Changes in Working Capital", "-450,000", "-320,000", "-280,000", "Annual Report", "43"],
                ["Cash from Operations", "6,140,000", "5,295,000", "4,655,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Investing Activities", "", "", "", "", ""],
                ["Capital Expenditure", "-1,760,000", "-2,756,000", "-1,500,000", "Annual Report", "45"],
                ["Acquisitions", "0", "0", "-500,000", "Annual Report", "45"],
                ["Cash from Investing", "-1,760,000", "-2,756,000", "-2,000,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Financing Activities", "", "", "", "", ""],
                ["Debt Repayment", "-1,500,000", "-1,200,000", "-1,000,000", "Annual Report", "47"],
                ["Dividends Paid", "-380,000", "-539,000", "-355,000", "Annual Report", "48"],
                ["Cash from Financing", "-1,880,000", "-1,739,000", "-1,355,000", "Calculated", "-"],
                ["", "", "", "", "", ""],
                ["Net Change in Cash", "2,500,000", "800,000", "1,300,000", "Calculated", "-"],
            ]
        }
    ]
    
    return {
        "sheets": sheets,
        "debtor": debtor_id,
        "generated_at": datetime.now().isoformat()
    }


@router.get("/get_report_preview")
async def get_report_preview():
    """
    Get report preview data for Excel visualization in frontend.
    Returns structured data for Balance Sheet, P&L, and Cash Flow.
    """
    try:
        # In production, get current debtor from session/state
        # For now, return preview data
        preview_data = get_report_preview_data()
        return JSONResponse(content=preview_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Preview error: {str(e)}")


# ============================================================================
# DASHBOARD STATS ENDPOINT
# ============================================================================

@router.get("/get_dashboard_stats", response_model=DashboardStats)
async def get_dashboard_stats():
    """
    Get statistics for the dashboard display.
    """
    try:
        # In production, calculate from actual processing data
        # For now, return demo stats
        return DashboardStats(
            documents_processed=12,
            fields_extracted=847,
            reports_generated=3,
            accuracy=94.2,
            last_updated=datetime.now().isoformat()
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Stats error: {str(e)}")


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================
"""
To integrate these endpoints into your existing FastAPI app:

1. Import the router in your main.py:
   
   from backend_additions import router as additions_router

2. Include the router:
   
   app.include_router(additions_router)

3. Or add individual endpoints directly to your existing app.

4. For production chat functionality, you can enhance find_best_response()
   to use actual LLM calls with the agent logs as context.
"""
