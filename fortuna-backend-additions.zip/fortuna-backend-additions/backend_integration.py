"""
FORTUNA Backend Integration
===========================
This file shows how to integrate the new endpoints into your existing FastAPI application.

Copy the relevant parts to your main.py or create a new router file.
"""

from fastapi import FastAPI, APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import json
import os

# Import the services
from chat_service import get_chat_service, FortunaChat
from report_preview_service import get_preview_service, ReportPreviewService

# ============================================================================
# MODELS
# ============================================================================

class ChatRequest(BaseModel):
    message: str
    mode: Optional[str] = "attributions"
    context: Optional[str] = None


class ChatResponse(BaseModel):
    response: str
    sources: Optional[List[Dict[str, Any]]] = None
    timestamp: str


# ============================================================================
# CREATE ROUTER
# ============================================================================

# Create a router for the new endpoints
router = APIRouter(tags=["Frontend Support"])

# Initialize services
chat_service = get_chat_service(use_llm=False)  # Set to True if Azure OpenAI is configured
preview_service = get_preview_service(reports_dir="./reports")

# Store for current debtor and agent logs (in production, use proper state management)
_app_state = {
    "current_debtor": None,
    "agent_logs": {}
}


# ============================================================================
# CHAT ENDPOINT
# ============================================================================

@router.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    """
    Chat endpoint for Level #1: Understanding how the report was generated.
    
    Provides contextual responses about:
    - Extraction methodology
    - Source attributions  
    - Field explanations
    - Data verification
    """
    try:
        # Parse context if provided
        agent_logs = None
        if request.context:
            try:
                agent_logs = json.loads(request.context)
            except:
                pass
        
        # Get response from chat service
        result = chat_service.get_response(request.message, agent_logs)
        
        return ChatResponse(
            response=result["response"],
            sources=result.get("sources"),
            timestamp=result["timestamp"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat error: {str(e)}")


# ============================================================================
# REPORT PREVIEW ENDPOINT
# ============================================================================

@router.get("/get_report_preview")
async def get_report_preview():
    """
    Get report preview data for Excel visualization.
    
    Returns structured data with sheets for:
    - Balance Sheet
    - Profit & Loss
    - Cash Flow
    """
    try:
        debtor_id = _app_state.get("current_debtor")
        agent_logs = _app_state.get("agent_logs", {})
        
        preview_data = preview_service.get_preview(
            debtor_id=debtor_id,
            agent_logs=agent_logs
        )
        
        return JSONResponse(content=preview_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Preview error: {str(e)}")


# ============================================================================
# DASHBOARD STATS ENDPOINT
# ============================================================================

@router.get("/get_dashboard_stats")
async def get_dashboard_stats():
    """
    Get statistics for the dashboard.
    """
    try:
        agent_logs = _app_state.get("agent_logs", {})
        
        # Calculate stats from agent logs
        fields_count = count_fields(agent_logs)
        
        return {
            "documents_processed": 12,  # TODO: Track actual count
            "fields_extracted": fields_count or 847,
            "reports_generated": 3,  # TODO: Track actual count
            "accuracy": 94.2,  # TODO: Calculate actual accuracy
            "last_updated": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Stats error: {str(e)}")


def count_fields(data: dict, count: int = 0) -> int:
    """Recursively count fields in nested dict."""
    if not isinstance(data, dict):
        return count
    
    for key, value in data.items():
        if isinstance(value, dict):
            if "Value" in value or "value" in value:
                count += 1
            else:
                count = count_fields(value, count)
        elif not isinstance(value, (dict, list)):
            count += 1
    
    return count


# ============================================================================
# STATE MANAGEMENT HELPERS
# ============================================================================

def set_current_debtor(debtor_id: str):
    """Update current debtor in app state."""
    _app_state["current_debtor"] = debtor_id


def set_agent_logs(logs: dict):
    """Update agent logs in app state."""
    _app_state["agent_logs"] = logs


def get_current_debtor() -> Optional[str]:
    """Get current debtor from app state."""
    return _app_state.get("current_debtor")


def get_agent_logs() -> dict:
    """Get agent logs from app state."""
    return _app_state.get("agent_logs", {})


# ============================================================================
# INTEGRATION EXAMPLE
# ============================================================================

def create_app_with_new_endpoints():
    """
    Example of creating a FastAPI app with the new endpoints.
    
    In your existing app, just do:
    
        from backend_integration import router
        app.include_router(router)
    """
    app = FastAPI(
        title="FORTUNA API",
        description="AI-powered Credit File Review automation",
        version="1.0.0"
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include the new router
    app.include_router(router)
    
    return app


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================
"""
INTEGRATION STEPS:
==================

1. Copy these files to your backend directory:
   - chat_service.py
   - report_preview_service.py
   - backend_integration.py (this file)

2. In your existing main.py, add:

   from backend_integration import router as frontend_router
   from backend_integration import set_current_debtor, set_agent_logs
   
   app.include_router(frontend_router)

3. Update your existing endpoints to sync state:

   # In your set_debtor endpoint:
   @app.post("/set_debtor/{debtor_id}")
   async def set_debtor(debtor_id: str):
       # ... existing logic ...
       set_current_debtor(debtor_id)  # Add this
       return {"status": "ok"}
   
   # In your get_agent_logs endpoint (after fetching):
   @app.get("/get_agent_logs")
   async def get_agent_logs_endpoint():
       logs = fetch_logs_from_somewhere()
       set_agent_logs(logs)  # Add this to cache
       return logs

4. For LLM-powered chat (optional):
   
   Set environment variables:
   - AZURE_OPENAI_DEPLOYMENT=your-deployment-name
   - AZURE_OPENAI_API_VERSION=2024-02-15-preview
   - AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
   - AZURE_OPENAI_API_KEY=your-api-key
   
   Then change:
   chat_service = get_chat_service(use_llm=True)

5. Test the endpoints:
   
   curl http://localhost:8000/chat -X POST \\
     -H "Content-Type: application/json" \\
     -d '{"message": "How were assets extracted?"}'
   
   curl http://localhost:8000/get_report_preview
   
   curl http://localhost:8000/get_dashboard_stats
"""


if __name__ == "__main__":
    # For testing standalone
    import uvicorn
    app = create_app_with_new_endpoints()
    uvicorn.run(app, host="0.0.0.0", port=8001)
