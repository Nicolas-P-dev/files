# FORTUNA Backend Additions

New backend endpoints to support the upgraded frontend.

## Files

| File | Description |
|------|-------------|
| `backend_integration.py` | Main integration file with FastAPI router |
| `chat_service.py` | Chat service for Level #1 Q&A |
| `report_preview_service.py` | Report preview data generation |
| `new_endpoints.py` | Alternative standalone endpoints file |

## New Endpoints

### 1. Chat Endpoint
**POST** `/chat`

Level #1 functionality: Helps users understand how the report was generated.

```json
// Request
{
  "message": "How were assets extracted?",
  "mode": "attributions",
  "context": "{...optional agent logs...}"
}

// Response
{
  "response": "The assets section is extracted from...",
  "sources": [{"doc": "Annual Report", "page": 12}],
  "timestamp": "2024-01-15T10:30:00"
}
```

**Supported Topics:**
- Assets extraction (current/non-current)
- Liabilities extraction
- Equity extraction
- P&L extraction
- Cash flow extraction
- Source attributions
- Extraction methodology
- Accuracy/confidence
- Download/export

### 2. Report Preview Endpoint
**GET** `/get_report_preview`

Returns structured data for Excel spreadsheet visualization.

```json
// Response
{
  "sheets": [
    {
      "name": "Balance Sheet",
      "headers": ["Field", "2023", "2022", "2021", "Source", "Page"],
      "data": [
        ["ASSETS", "", "", "", "", ""],
        ["Property, Plant & Equipment", "12,450,000", "11,890,000", "10,234,000", "Annual Report", "24"],
        ...
      ]
    },
    {
      "name": "Profit & Loss",
      ...
    },
    {
      "name": "Cash Flow",
      ...
    }
  ],
  "debtor": "1234567_Demo Debtor",
  "generated_at": "2024-01-15T10:30:00",
  "source": "agent_logs"
}
```

**Data Sources (Priority Order):**
1. Actual Excel file (if exists)
2. Generated from agent logs
3. Demo data (fallback)

### 3. Dashboard Stats Endpoint
**GET** `/get_dashboard_stats`

Returns statistics for the dashboard display.

```json
// Response
{
  "documents_processed": 12,
  "fields_extracted": 847,
  "reports_generated": 3,
  "accuracy": 94.2,
  "last_updated": "2024-01-15T10:30:00"
}
```

## Integration

### Quick Integration

Add to your existing `main.py`:

```python
from backend_integration import router as frontend_router

# Include the new router
app.include_router(frontend_router)
```

### Full Integration

```python
from fastapi import FastAPI
from backend_integration import router as frontend_router
from backend_integration import set_current_debtor, set_agent_logs

app = FastAPI()

# Include new endpoints
app.include_router(frontend_router)

# Sync state when debtor changes
@app.post("/your_existing_set_debtor_endpoint")
async def set_debtor(debtor_id: str):
    # Your existing logic...
    set_current_debtor(debtor_id)  # ADD THIS
    return {"status": "ok"}

# Sync state when logs are fetched
@app.get("/get_agent_logs") 
async def get_agent_logs():
    logs = your_fetch_logs_function()
    set_agent_logs(logs)  # ADD THIS
    return logs
```

## LLM Integration (Optional)

For enhanced chat responses using Azure OpenAI:

1. Set environment variables:
```bash
export AZURE_OPENAI_DEPLOYMENT=gpt-4
export AZURE_OPENAI_API_VERSION=2024-02-15-preview
export AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/
export AZURE_OPENAI_API_KEY=your-api-key
```

2. Enable LLM in `backend_integration.py`:
```python
chat_service = get_chat_service(use_llm=True)
```

Without LLM, the chat service uses rule-based responses that cover common questions about the extraction process.

## Testing

### Test Chat Endpoint
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "How were assets extracted?"}'
```

### Test Report Preview
```bash
curl http://localhost:8000/get_report_preview
```

### Test Dashboard Stats
```bash
curl http://localhost:8000/get_dashboard_stats
```

## Dependencies

Required (already in your project):
- fastapi
- pydantic

Optional:
- langchain-openai (for LLM chat)
- openpyxl (for reading actual Excel files)

```bash
pip install langchain-openai openpyxl
```

## Notes

- Chat responses are designed for **Level #1** only (understanding report generation)
- Level #2 (modifying output) is not implemented yet
- Preview data gracefully falls back to demo data if no actual data exists
- All endpoints handle errors gracefully with appropriate HTTP status codes
