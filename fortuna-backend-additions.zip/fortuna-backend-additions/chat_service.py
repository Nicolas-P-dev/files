"""
FORTUNA Chat Service
====================
Enhanced chat service with optional LLM integration for Level #1 functionality.
This can use Azure OpenAI or fall back to rule-based responses.
"""

from typing import Optional, Dict, Any, List
from datetime import datetime
import json
import os

# Optional: Import Azure OpenAI if available
try:
    from langchain_openai import AzureChatOpenAI
    from langchain_core.messages import HumanMessage, SystemMessage
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False


class FortunaChat:
    """
    Chat service for FORTUNA Level #1 functionality.
    Helps users understand how the report was generated.
    """
    
    def __init__(self, use_llm: bool = False):
        """
        Initialize chat service.
        
        Args:
            use_llm: Whether to use LLM for responses (requires Azure OpenAI config)
        """
        self.use_llm = use_llm and LANGCHAIN_AVAILABLE
        self.llm = None
        
        if self.use_llm:
            try:
                self.llm = AzureChatOpenAI(
                    deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                    temperature=0.3,
                    max_tokens=1000
                )
            except Exception as e:
                print(f"Failed to initialize LLM: {e}")
                self.use_llm = False
        
        # System prompt for LLM
        self.system_prompt = """You are FORTUNA, an AI assistant helping auditors understand Credit File Review (CFR) report extractions.

Your role is Level #1 support: Helping users understand how the report was generated.

Key responsibilities:
1. Explain where specific field values came from (source documents, page numbers)
2. Describe the extraction methodology for different sections (assets, liabilities, equity, P&L, cash flow)
3. Help users verify extractions by pointing them to source references
4. Explain confidence levels and how to validate data

Guidelines:
- Be concise and professional
- Always reference source documents and page numbers when discussing specific values
- Explain extraction methodology in clear terms
- Guide users to the Attributions panel for detailed source trails
- Do not make up data - only reference what's in the provided context

If you don't have specific information about a query, guide the user to check the Attributions panel or source documents directly."""

        # Knowledge base for rule-based responses
        self.knowledge_base = {
            "assets": {
                "keywords": ["asset", "current asset", "non-current asset", "property", "equipment", "inventory", "receivable", "cash"],
                "response": """The assets section is extracted from the balance sheet in the financial statements.

**Current Assets** (short-term, typically < 1 year):
• Cash and cash equivalents
• Trade receivables
• Inventories
• Prepaid expenses

**Non-Current Assets** (long-term):
• Property, plant & equipment
• Intangible assets
• Long-term investments
• Deferred tax assets

Each field shows:
• **Value**: The extracted amount
• **Source**: Document name
• **Page**: Exact page number
• **Explanation**: How it was extracted

Click any field in Attributions to see the full source trail."""
            },
            "liabilities": {
                "keywords": ["liabilit", "debt", "payable", "borrowing", "loan", "creditor"],
                "response": """Liabilities are extracted and categorized from the balance sheet:

**Current Liabilities** (due within 1 year):
• Trade payables
• Short-term borrowings
• Accrued expenses
• Tax payables
• Current portion of long-term debt

**Non-Current Liabilities** (due after 1 year):
• Long-term debt/bonds
• Deferred tax liabilities
• Pension obligations
• Lease liabilities

The extraction agents match line items to CFR template fields based on:
• Standard accounting terminology
• Balance sheet structure analysis
• Cross-referencing with notes to accounts"""
            },
            "equity": {
                "keywords": ["equity", "capital", "retained", "reserves", "shareholder", "share"],
                "response": """The equity section captures ownership interest:

**Components Extracted:**
• Share capital (issued and paid-up)
• Share premium
• Retained earnings (accumulated profits/losses)
• Revaluation reserves
• Other reserves
• Non-controlling interests

**Source Documents:**
• Balance sheet equity section
• Statement of changes in equity
• Notes to accounts

Values are cross-referenced across documents for accuracy."""
            },
            "pnl": {
                "keywords": ["profit", "loss", "revenue", "income", "expense", "cost", "p&l", "earnings"],
                "response": """The Profit & Loss extraction covers:

**Revenue Section:**
• Total revenue/sales
• Revenue breakdown by segment (if available)

**Expenses:**
• Cost of sales/goods sold
• Operating expenses
• Administrative expenses
• Finance costs

**Profit Metrics:**
• Gross profit
• Operating profit (EBIT)
• Profit before tax
• Net profit

Each line item references the specific page in the income statement or notes."""
            },
            "cashflow": {
                "keywords": ["cash flow", "cashflow", "operating", "investing", "financing", "cash"],
                "response": """Cash flow statement extraction includes three sections:

**Operating Activities:**
• Net profit adjustments
• Working capital changes
• Non-cash items (depreciation, amortization)

**Investing Activities:**
• Capital expenditure
• Acquisitions/disposals
• Investment purchases/sales

**Financing Activities:**
• Debt proceeds/repayments
• Dividend payments
• Share issuance/buybacks

The agents reconcile cash flow with balance sheet movements."""
            },
            "source": {
                "keywords": ["source", "where", "reference", "page", "document", "attribution", "from"],
                "response": """Every extracted value includes complete source attribution:

**Attribution Details:**
1. **Value**: The extracted data point
2. **Source Document**: File name (e.g., "Annual Report 2023.pdf")
3. **Page Number**: Exact page location
4. **Explanation**: Extraction reasoning

**How to Verify:**
1. Find the field in the Attributions panel
2. Expand to see source details
3. Click the document reference to view original
4. Check the specific page number

This ensures full audit traceability for CFR compliance."""
            },
            "accuracy": {
                "keywords": ["accuracy", "confidence", "reliable", "correct", "sure", "trust", "verify"],
                "response": """Extraction accuracy depends on several factors:

**High Confidence Indicators:**
✓ Clear, digital source documents
✓ Standard accounting formats
✓ Multiple corroborating references
✓ Exact terminology match

**Lower Confidence Scenarios:**
• Scanned/OCR documents
• Non-standard layouts
• Ambiguous terminology
• Single source reference

**Verification Steps:**
1. Check the confidence indicator (if shown)
2. Review source page reference
3. Compare with original document
4. Cross-check related fields

When in doubt, always verify against the source document."""
            },
            "methodology": {
                "keywords": ["how", "extract", "work", "process", "method", "agent", "pipeline"],
                "response": """FORTUNA uses a multi-stage extraction pipeline:

**Stage 1: Document Processing**
• PDF parsing (Azure Document Intelligence)
• Text and table extraction
• Document structure analysis
• Classification by document type

**Stage 2: Specialized Extraction Agents**
• Non-Current Assets Agent
• Current Assets Agent
• Current Liabilities Agent
• Non-Current Liabilities Agent
• Equity Agent
• P&L Agent
• Cash Flow Agents (Operating, Investing, Financing)

**Stage 3: Attribution & Validation**
• Link each value to source location
• Cross-reference consistency checks
• Confidence scoring
• Error flagging

**Stage 4: Report Generation**
• Populate CFR template
• Add source comments
• Generate downloadable Excel"""
            },
            "download": {
                "keywords": ["download", "export", "excel", "report", "save", "file"],
                "response": """To download the completed CFR report:

**Steps:**
1. Go to **Report Preview** in the sidebar
2. Review the populated spreadsheet
3. Click **Download Report (.xlsx)** (bottom-right)

**Report Contents:**
• Balance Sheet (3-year comparison)
• Profit & Loss statement
• Cash Flow statement
• All source attributions as cell comments

**File Format:**
Standard Excel (.xlsx) format, ready for review and submission.

**Tip:** The downloaded file preserves source references in cell comments - hover over cells to see attribution details."""
            }
        }
    
    def get_response(self, query: str, agent_logs: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Get chat response for user query.
        
        Args:
            query: User's question
            agent_logs: Optional agent logs context for enhanced responses
            
        Returns:
            Dict with response text and optional sources
        """
        if self.use_llm and self.llm:
            return self._get_llm_response(query, agent_logs)
        else:
            return self._get_rule_based_response(query)
    
    def _get_llm_response(self, query: str, agent_logs: Optional[Dict] = None) -> Dict[str, Any]:
        """Get response using LLM with agent logs context."""
        try:
            # Build context from agent logs
            context = ""
            if agent_logs:
                context = f"\n\nCurrent extraction data (for reference):\n{json.dumps(agent_logs, indent=2)[:3000]}"
            
            messages = [
                SystemMessage(content=self.system_prompt + context),
                HumanMessage(content=query)
            ]
            
            response = self.llm.invoke(messages)
            
            return {
                "response": response.content,
                "sources": None,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            print(f"LLM error, falling back to rules: {e}")
            return self._get_rule_based_response(query)
    
    def _get_rule_based_response(self, query: str) -> Dict[str, Any]:
        """Get response using rule-based matching."""
        query_lower = query.lower()
        
        # Find best matching category
        for category, data in self.knowledge_base.items():
            for keyword in data["keywords"]:
                if keyword in query_lower:
                    return {
                        "response": data["response"],
                        "sources": data.get("sources"),
                        "timestamp": datetime.now().isoformat()
                    }
        
        # Default response
        return {
            "response": """I can help you understand how FORTUNA extracted the report data.

**Try asking about:**
• **Categories**: "How were assets extracted?" or "Explain the liabilities section"
• **Sources**: "Where did this value come from?" or "Show me source references"
• **Process**: "How does extraction work?" or "What agents are used?"
• **Verification**: "How accurate are the extractions?"
• **Export**: "How do I download the report?"

You can also explore the **Attributions** panel directly - click any field to see its complete source trail with document references and page numbers.

What would you like to know more about?""",
            "sources": None,
            "timestamp": datetime.now().isoformat()
        }


# Singleton instance
_chat_service: Optional[FortunaChat] = None


def get_chat_service(use_llm: bool = False) -> FortunaChat:
    """Get or create chat service instance."""
    global _chat_service
    if _chat_service is None:
        _chat_service = FortunaChat(use_llm=use_llm)
    return _chat_service
