# APM Agent

AI-assisted project management agent. Skills-based architecture with MCP tool integration.

## Structure

```
apm-agent/
├── backend/
│   ├── agent/              # Python package
│   │   ├── main.py         # FastAPI app, wires config into framework
│   │   ├── config.py       # APM_ prefixed env config (only config reader)
│   │   ├── agent_loop.py   # LLM + tool execution loop with streaming
│   │   ├── skill_loader.py # Loads .md skills with YAML frontmatter
│   │   ├── skill_router.py # LLM-based intent → skill classification
│   │   ├── telemetry.py    # OpenTelemetry setup
│   │   ├── middleware.py   # Auth + request context
│   │   ├── health.py       # Health endpoints
│   │   ├── mcp/
│   │   │   ├── hybrid_client.py  # JSON-RPC over HTTP
│   │   │   └── registry.py       # Multi-server tool discovery
│   │   └── llm/
│   │       └── client.py         # OpenAI-compatible wrapper
│   ├── skills/
│   │   ├── default/        # Skill definitions
│   │   └── users/          # Per-user preference overrides
│   ├── config/
│   │   └── mcp_servers.yaml
│   └── tools/
│       └── dev-chat/       # Browser test frontend
├── frontend/               # Dedicated UI (build to dist/)
└── Dockerfile
```

## Quick Start

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
cp ../.env.example ../.env    # fill in credentials

uvicorn agent.main:app --port 8080 --reload
```

Dev chat: http://localhost:8080/dev-chat

## API

- `POST /api/chat` — `{"message": "...", "token": "optional"}`
- `POST /api/chat/stream` — SSE: token, status, done, error events
- `GET /api/skills` — list skills
- `GET /health` — health check
- `GET /health/mcp` — MCP server status

## Architecture

Framework files (portable between repos, no config imports):
`agent_loop.py`, `skill_loader.py`, `skill_router.py`, `mcp/*`, `llm/*`, `telemetry.py`

Application files (repo-specific):
`config.py`, `main.py`, `middleware.py`, skills, mcp_servers.yaml

## Adding Skills

Drop a `.md` file in `backend/skills/default/`:

```yaml
---
name: My Skill
description: What this skill does
mcp_servers:
  - mcp-jira
tags: [read]
---
Instructions for the LLM...
```

## Adding MCP Servers

Edit `backend/config/mcp_servers.yaml`:

```yaml
servers:
  my-server:
    url: ${APM_MY_SERVER_URL}
    headers:
      Authorization: Bearer ${APM_MY_TOKEN}
    timeout: 30
```

Reference the server ID in your skill's `mcp_servers` list.
