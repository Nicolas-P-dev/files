# APM Frontend

Dedicated frontend. Built files go into `dist/` — FastAPI serves them at `/`.

## API

- `POST /api/chat` — `{"message": "...", "token": "optional"}`
- `POST /api/chat/stream` — SSE stream of token/status/done events
- `GET /api/skills` — list available skills
- `GET /health` — health check
