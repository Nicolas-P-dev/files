#!/bin/sh
exec uvicorn agent.main:app --host 0.0.0.0 --port "${APM_PORT:-8080}"
