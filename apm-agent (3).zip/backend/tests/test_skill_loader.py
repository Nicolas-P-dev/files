from pathlib import Path
from agent.skill_loader import load_skills, _parse_skill_file

SKILLS_DIR = Path(__file__).parent.parent / "skills" / "default"


def test_load_skills():
    skills = load_skills(SKILLS_DIR)
    assert len(skills) >= 4
    ids = {s.id for s in skills}
    assert "project-status" in ids
    assert "task-management" in ids


def test_skill_has_frontmatter():
    skills = load_skills(SKILLS_DIR)
    status = next(s for s in skills if s.id == "project-status")
    assert status.name == "Project Status"
    assert "mcp-jira" in status.mcp_servers
    assert status.description
    assert status.content


def test_parse_no_frontmatter(tmp_path):
    f = tmp_path / "bare.md"
    f.write_text("Just some instructions.")
    skill = _parse_skill_file(f)
    assert skill is not None
    assert skill.id == "bare"
    assert skill.content == "Just some instructions."
    assert skill.mcp_servers == []
