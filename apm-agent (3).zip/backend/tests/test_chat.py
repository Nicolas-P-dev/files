import pytest
from unittest.mock import AsyncMock, patch
from httpx import AsyncClient, ASGITransport
from agent.main import app


@pytest.mark.asyncio
async def test_chat_no_message():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        resp = await client.post("/api/chat", json={"message": ""})
        assert resp.status_code == 400


@pytest.mark.asyncio
async def test_chat_direct_response():
    mock_response = {"choices": [{"message": {"content": "Hi there!"}}]}
    with patch("agent.main.agent_loop.llm_call", new_callable=AsyncMock, return_value=mock_response):
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post("/api/chat", json={"message": "hello"})
            assert resp.status_code == 200
            data = resp.json()
            assert "response" in data
