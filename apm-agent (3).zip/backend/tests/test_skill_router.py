import pytest
from agent.skill_loader import Skill
from agent.skill_router import route


async def _mock_llm_skill(messages):
    return {"choices": [{"message": {"content": '{"skill": "project-status"}'}}]}


async def _mock_llm_greeting(messages):
    return {"choices": [{"message": {"content": "Hello! How can I help you today?"}}]}


async def _mock_llm_error(messages):
    raise Exception("LLM unreachable")


SKILLS = [
    Skill(id="project-status", name="Project Status", description="Query status", content="..."),
    Skill(id="task-management", name="Task Management", description="Manage tasks", content="..."),
]


@pytest.mark.asyncio
async def test_routes_to_skill():
    sid, direct = await route("What's the status of Project X?", SKILLS, "", _mock_llm_skill)
    assert sid == "project-status"
    assert direct is None


@pytest.mark.asyncio
async def test_direct_response():
    sid, direct = await route("Hello!", SKILLS, "", _mock_llm_greeting)
    assert sid is None
    assert direct and "Hello" in direct


@pytest.mark.asyncio
async def test_single_skill_skips_llm():
    sid, direct = await route("anything", [SKILLS[0]], "", _mock_llm_error)
    assert sid == "project-status"


@pytest.mark.asyncio
async def test_llm_failure_returns_none():
    sid, direct = await route("test", SKILLS, "", _mock_llm_error)
    assert sid is None
    assert direct is None
