from agent.mcp.registry import MCPRegistry


def test_empty_config(tmp_path):
    f = tmp_path / "empty.yaml"
    f.write_text("servers:\n")
    reg = MCPRegistry(str(f))
    assert reg.server_ids == []


def test_missing_config():
    reg = MCPRegistry("/nonexistent/path.yaml")
    assert reg.server_ids == []


def test_reset_cache(tmp_path):
    f = tmp_path / "test.yaml"
    f.write_text("servers:\n")
    reg = MCPRegistry(str(f))
    reg._openai_tools["test_tool"] = {"type": "function"}
    reg._tool_server["test_tool"] = "test-server"
    reg.reset_cache()
    assert len(reg._openai_tools) == 0
    assert len(reg._tool_server) == 0
