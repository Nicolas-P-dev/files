"""OpenTelemetry setup. Console exporter by default, swap for OTLP in production."""

import logging
import os

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource

logger = logging.getLogger(__name__)

_initialized = False


def init_telemetry(service_name: str = "apm-agent", service_version: str = "0.1.0"):
    global _initialized
    if _initialized:
        return

    resource = Resource.create({
        "service.name": service_name,
        "service.version": service_version,
    })

    provider = TracerProvider(resource=resource)

    otlp_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if otlp_endpoint:
        try:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
            exporter = OTLPSpanExporter(endpoint=otlp_endpoint)
            logger.info("OTel: OTLP exporter -> %s", otlp_endpoint)
        except ImportError:
            logger.warning("OTel: OTLP exporter not installed, falling back to console")
            exporter = ConsoleSpanExporter()
    else:
        exporter = ConsoleSpanExporter()
        logger.info("OTel: console exporter (set OTEL_EXPORTER_OTLP_ENDPOINT for OTLP)")

    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    _initialized = True


def get_tracer(name: str = __name__) -> trace.Tracer:
    return trace.get_tracer(name)
