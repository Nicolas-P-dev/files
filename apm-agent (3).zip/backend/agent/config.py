"""Application config. Only file that reads env vars. Everything else gets injected."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "APM Agent"
    app_version: str = "0.1.0"
    port: int = 8080
    log_level: str = "info"

    llm_base_url: str = ""
    llm_api_key: str = ""
    llm_deployment: str = "gpt-4o"
    llm_api_version: str = "2025-01-01-preview"
    llm_temperature: float = 1.0

    api_key: str = ""

    model_config = {
        "env_prefix": "APM_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }


settings = Settings()
