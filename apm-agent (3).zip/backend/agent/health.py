"""Health check endpoints."""

from fastapi import APIRouter

router = APIRouter(tags=["health"])

_registry = None
_version = "0.1.0"
_name = "APM Agent"


def init_health(registry, name: str = "APM Agent", version: str = "0.1.0"):
    global _registry, _name, _version
    _registry = registry
    _name = name
    _version = version


@router.get("/health")
async def health():
    result = {"status": "healthy", "agent": _name, "version": _version}
    if _registry:
        result["mcp_servers"] = _registry.server_ids
    return result


@router.get("/health/mcp")
async def mcp_health():
    if not _registry:
        return {"status": "no registry"}
    return await _registry.health_check()
