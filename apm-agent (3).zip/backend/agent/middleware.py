"""Request middleware: API key auth, request ID injection, request logging."""

import logging
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

PUBLIC_PATHS = {"/health", "/health/mcp", "/docs", "/openapi.json", "/dev-chat"}


class AuthMiddleware(BaseHTTPMiddleware):
    """Checks API key on protected routes. Disabled when api_key is empty."""

    def __init__(self, app, api_key: str = ""):
        super().__init__(app)
        self._api_key = api_key

    async def dispatch(self, request: Request, call_next):
        if self._api_key and not self._is_public(request.url.path):
            provided = request.headers.get("X-API-Key", "")
            if provided != self._api_key:
                return Response(
                    content='{"error": "Invalid or missing API key"}',
                    status_code=401,
                    media_type="application/json",
                )
        return await call_next(request)

    @staticmethod
    def _is_public(path: str) -> bool:
        return any(path == p or path.startswith(p + "/") for p in PUBLIC_PATHS)


class RequestContextMiddleware(BaseHTTPMiddleware):
    """Adds request ID and logs request duration."""

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])
        request.state.request_id = request_id

        t0 = time.monotonic()
        response = await call_next(request)
        duration = round((time.monotonic() - t0) * 1000)

        response.headers["X-Request-ID"] = request_id
        logger.info(
            "%s %s -> %d (%dms) [%s]",
            request.method, request.url.path,
            response.status_code, duration, request_id,
        )
        return response
