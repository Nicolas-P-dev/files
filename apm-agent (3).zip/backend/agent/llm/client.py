"""OpenAI-compatible LLM client.

Framework file: no config imports. All settings via constructor.
"""

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class LLMClient:

    def __init__(
        self,
        base_url: str,
        api_key: str,
        deployment: str,
        api_version: str = "2025-01-01-preview",
        temperature: float = 1.0,
        timeout: float = 30.0,
    ):
        self._base_url = base_url
        self._api_key = api_key
        self._deployment = deployment
        self._api_version = api_version
        self._temperature = temperature
        self._headers = {"api-key": api_key, "Content-Type": "application/json", "Cache-Control": "no-cache"}
        self._timeout = timeout

    async def chat(self, messages: list[dict], temperature: float | None = None) -> dict[str, Any]:
        if not self._api_key:
            return {"error": "LLM API key not configured"}

        url = f"{self._base_url}/deployments/{self._deployment}/chat/completions"
        params = {"api-version": self._api_version}
        payload: dict[str, Any] = {"messages": messages}

        temp = temperature or self._temperature
        if temp == 1.0:
            payload["temperature"] = temp

        try:
            async with httpx.AsyncClient(timeout=self._timeout, verify=False) as client:
                response = await client.post(url, json=payload, headers=self._headers, params=params)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error("LLM HTTP %s: %s", e.response.status_code, e.response.text[:200])
            return {"error": f"HTTP {e.response.status_code}: {e.response.text[:200]}"}
        except Exception as e:
            logger.error("LLM request failed: %s", e)
            return {"error": str(e)}

    async def simple(self, message: str) -> str:
        result = await self.chat([{"role": "user", "content": message}])
        if "error" in result:
            return f"Error: {result['error']}"
        try:
            return result["choices"][0]["message"]["content"]
        except (KeyError, IndexError):
            return f"Unexpected response: {result}"
