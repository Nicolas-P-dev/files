"""Routes user messages to skills via a fast LLM classification call.

Framework file: no config imports. Takes llm_call as a callable.
"""

import json
import logging
from typing import Callable, Optional

from agent.skill_loader import Skill

logger = logging.getLogger(__name__)

_ROUTER_PROMPT = """\
You are the {agent_name} router. Given a user message, decide how to handle it.

Available skills:
{skills}

Rules:
- If the message needs tools or project data, pick the best skill.
  Reply ONLY: {{"skill": "<skill_id>"}}
- If the message is conversational (greeting, thanks, help, small talk),
  reply directly as {agent_name} — a friendly project management assistant.
  Do NOT return JSON in this case, just answer naturally.

{user_context}"""


async def route(
    user_message: str,
    skills: list[Skill],
    user_prefs: str,
    llm_call: Callable,
    agent_name: str = "APM",
) -> tuple[Optional[str], Optional[str]]:
    """Returns (skill_id, None) or (None, direct_response) or (None, None)."""
    if not skills:
        return None, None

    if len(skills) == 1:
        return skills[0].id, None

    skill_lines = [f"- {s.id}: {s.name} — {s.description}" for s in skills]
    context = f"User preferences:\n{user_prefs}" if user_prefs else ""

    system = _ROUTER_PROMPT.format(
        agent_name=agent_name,
        skills="\n".join(skill_lines),
        user_context=context,
    )

    try:
        data = await llm_call([
            {"role": "system", "content": system},
            {"role": "user", "content": user_message},
        ])

        raw = data["choices"][0]["message"].get("content", "").strip()
        if not raw:
            return None, None

        cleaned = raw
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
            cleaned = cleaned.strip()

        try:
            result = json.loads(cleaned)
            skill_id = result.get("skill")
            if skill_id and skill_id in {s.id for s in skills}:
                logger.info("Router: skill=%s", skill_id)
                return skill_id, None
            if skill_id:
                logger.warning("Router returned unknown skill: %s", skill_id)
                return None, None
        except (json.JSONDecodeError, AttributeError):
            pass

        logger.info("Router: direct response (%d chars)", len(raw))
        return None, raw

    except Exception as e:
        logger.warning("Router failed: %s", e)
        return None, None
