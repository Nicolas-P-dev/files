"""Generic MCP client over HTTP. Handles JSON and SSE responses."""

import logging
import json
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class HybridMCPClient:

    def __init__(
        self,
        base_url: str,
        static_headers: dict = None,
        user_token_header: str = "",
        user_token_prefix: str = "",
        timeout: float = 30.0,
        client_name: str = "APM Agent",
        client_version: str = "0.1.0",
    ):
        self.base_url = base_url
        self._static_headers = static_headers or {}
        self._user_token_header = user_token_header
        self._user_token_prefix = user_token_prefix
        self._timeout = timeout
        self._client_name = client_name
        self._client_version = client_version
        self._session_id: str = ""
        self._http = httpx.AsyncClient(timeout=self._timeout, verify=False)

    def _build_headers(self, user_token: str = "") -> dict:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        headers.update(self._static_headers)
        if user_token and self._user_token_header:
            headers[self._user_token_header] = f"{self._user_token_prefix}{user_token}"
        if self._session_id:
            headers["mcp-session-id"] = self._session_id
        return headers

    async def _send(self, payload: dict, user_token: str = "") -> dict:
        try:
            response = await self._http.post(
                self.base_url,
                json=payload,
                headers=self._build_headers(user_token),
            )
            response.raise_for_status()

            sid = response.headers.get("mcp-session-id", "")
            if sid:
                self._session_id = sid

            ct = response.headers.get("content-type", "")
            if ct.startswith("application/json"):
                return response.json()
            elif ct.startswith("text/event-stream"):
                for line in response.text.strip().split("\n"):
                    if line.startswith("data: "):
                        try:
                            return json.loads(line[6:])
                        except json.JSONDecodeError:
                            continue
                return {"error": "No valid JSON in SSE response"}
            else:
                return {"error": f"Unexpected content type: {ct}"}

        except httpx.HTTPStatusError as e:
            logger.error("MCP HTTP %s: %s", e.response.status_code, e.response.text[:200])
            return {"error": f"HTTP {e.response.status_code}: {e.response.text[:200]}"}
        except Exception as e:
            logger.error("MCP request failed: %s", e)
            return {"error": str(e)}

    async def initialize(self, user_token: str = "") -> dict:
        return await self._send({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "clientInfo": {"name": self._client_name, "version": self._client_version},
            },
        }, user_token=user_token)

    async def list_tools(self, user_token: str = "") -> dict:
        return await self._send(
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            user_token=user_token,
        )

    async def call_tool(self, tool_name: str, arguments: dict, user_token: str = "") -> dict:
        return await self._send({
            "jsonrpc": "2.0", "id": 3, "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        }, user_token=user_token)

    async def health_check(self) -> dict:
        result = await self.initialize()
        if "error" in result:
            return {"status": "unhealthy", "error": result["error"]}
        return {"status": "healthy", "data": result.get("result", result)}

    async def close(self):
        await self._http.aclose()
