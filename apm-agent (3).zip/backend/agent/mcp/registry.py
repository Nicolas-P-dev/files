"""Multi-server MCP registry. Config-driven via YAML, discovers tools,
maps tool->server, converts to OpenAI format."""

import asyncio
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from agent.mcp.hybrid_client import HybridMCPClient

logger = logging.getLogger(__name__)


@dataclass
class MCPServerConfig:
    id: str
    url: str
    description: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    optional_headers: dict[str, str] = field(default_factory=dict)
    user_token_header: str = ""
    user_token_prefix: str = ""
    timeout: float = 30.0


def _resolve_env(value: str) -> str:
    return re.sub(r"\$\{(\w+)}", lambda m: os.environ.get(m.group(1), ""), value)


def _load_server_configs(config_path: str) -> dict[str, MCPServerConfig]:
    path = Path(config_path)
    if not path.exists():
        logger.warning("MCP config not found: %s", config_path)
        return {}

    with open(path) as f:
        raw = yaml.safe_load(f)

    servers = {}
    for sid, cfg in (raw.get("servers") or {}).items():
        url = _resolve_env(cfg.get("url", ""))
        if not url:
            logger.warning("Skipping MCP server '%s': no URL", sid)
            continue

        headers = {k: v for k, v in ((k, _resolve_env(v)) for k, v in cfg.get("headers", {}).items()) if v}
        optional = {k: v for k, v in ((k, _resolve_env(v)) for k, v in cfg.get("optional_headers", {}).items()) if v}

        servers[sid] = MCPServerConfig(
            id=sid, url=url, description=cfg.get("description", ""),
            headers=headers, optional_headers=optional,
            user_token_header=cfg.get("user_token_header", ""),
            user_token_prefix=cfg.get("user_token_prefix", ""),
            timeout=cfg.get("timeout", 30.0),
        )
        logger.info("MCP server registered: %s (%s)", sid, url[:60])

    return servers


class MCPRegistry:

    def __init__(self, config_path: str = "config/mcp_servers.yaml"):
        self._configs = _load_server_configs(config_path)
        self._clients: dict[str, HybridMCPClient] = {}
        self._tools_cache: dict[str, list[dict]] = {}
        self._openai_tools: dict[str, dict] = {}
        self._tool_server: dict[str, str] = {}

    @property
    def server_ids(self) -> list[str]:
        return list(self._configs.keys())

    def _client(self, sid: str) -> HybridMCPClient:
        if sid not in self._clients:
            cfg = self._configs.get(sid)
            if not cfg:
                raise ValueError(f"Unknown MCP server: {sid}")
            headers = {**cfg.headers, **cfg.optional_headers}
            self._clients[sid] = HybridMCPClient(
                base_url=cfg.url, static_headers=headers,
                user_token_header=cfg.user_token_header,
                user_token_prefix=cfg.user_token_prefix,
                timeout=cfg.timeout,
            )
        return self._clients[sid]

    async def discover_tools(self, server_ids: list[str] | None = None, user_token: str = "") -> list[dict]:
        targets = server_ids if server_ids is not None else list(self._configs.keys())
        uncached = [s for s in targets if s not in self._tools_cache]

        if uncached:
            async def _discover(sid: str):
                client = self._client(sid)
                cfg = self._configs[sid]
                token = user_token if cfg.user_token_header else ""
                result = await client.list_tools(user_token=token)
                tools = result.get("result", {}).get("tools", [])
                if not tools:
                    await client.initialize(user_token=token)
                    result = await client.list_tools(user_token=token)
                    tools = result.get("result", {}).get("tools", [])
                logger.info("Server '%s': %d tools", sid, len(tools))
                return sid, tools

            for result in await asyncio.gather(*[_discover(s) for s in uncached], return_exceptions=True):
                if isinstance(result, Exception):
                    logger.error("Tool discovery failed: %s", result)
                    continue
                sid, tools = result
                self._tools_cache[sid] = tools
                for t in tools:
                    name = t["name"]
                    self._tool_server[name] = sid
                    self._openai_tools[name] = {
                        "type": "function",
                        "function": {
                            "name": name,
                            "description": t.get("description", ""),
                            "parameters": t.get("inputSchema", {"type": "object", "properties": {}}),
                        },
                    }

        merged = []
        for sid in targets:
            merged.extend(self._tools_cache.get(sid, []))
        return merged

    def get_openai_tools(self, server_ids: list[str] | None = None) -> list[dict]:
        if server_ids is None:
            return list(self._openai_tools.values())
        result = []
        for sid in server_ids:
            for t in self._tools_cache.get(sid, []):
                tool = self._openai_tools.get(t["name"])
                if tool:
                    result.append(tool)
        return result

    async def call_tool(self, name: str, arguments: dict, user_token: str = "") -> dict:
        sid = self._tool_server.get(name)
        if not sid:
            return {"error": f"Unknown tool: {name}"}
        return await self._client(sid).call_tool(name, arguments, user_token=user_token)

    def server_for_tool(self, name: str) -> str | None:
        return self._tool_server.get(name)

    def reset_cache(self, server_id: str | None = None):
        if server_id:
            self._tools_cache.pop(server_id, None)
            for n in [n for n, s in self._tool_server.items() if s == server_id]:
                self._tool_server.pop(n, None)
                self._openai_tools.pop(n, None)
        else:
            self._tools_cache.clear()
            self._tool_server.clear()
            self._openai_tools.clear()

    async def health_check(self) -> dict:
        results = {}
        for sid in self._configs:
            try:
                results[sid] = await self._client(sid).health_check()
            except Exception as e:
                results[sid] = {"status": "unhealthy", "error": str(e)}
        return results
