"""FastAPI application. Wires config into framework components."""

import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from agent.config import settings
from agent.telemetry import init_telemetry
from agent.health import router as health_router, init_health
from agent.middleware import AuthMiddleware, RequestContextMiddleware
from agent.mcp.registry import MCPRegistry
from agent.agent_loop import AgentLoop, StatusEvent, TokenEvent
from agent.skill_loader import load_skills, load_user_prefs
from agent.skill_router import route

init_telemetry(service_name=settings.app_name, service_version=settings.app_version)

from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

logging.basicConfig(
    level=settings.log_level.upper(),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

BACKEND_DIR = Path(__file__).parent.parent.resolve()
SKILLS_DIR = BACKEND_DIR / "skills" / "default"
USERS_DIR = BACKEND_DIR / "skills" / "users"

registry = MCPRegistry(str(BACKEND_DIR / "config" / "mcp_servers.yaml"))
init_health(registry, name=settings.app_name, version=settings.app_version)

agent_loop = AgentLoop(
    registry=registry,
    llm_base_url=settings.llm_base_url,
    llm_api_key=settings.llm_api_key,
    llm_deployment=settings.llm_deployment,
    llm_api_version=settings.llm_api_version,
    llm_temperature=settings.llm_temperature,
)

BASE_PROMPT = """\
You are APM, a project management AI assistant.

## Tool Usage Rules
- Use the minimum number of tool calls needed.
- For write operations, present a clear summary and wait for user confirmation.
- If a tool returns an error, report it clearly. Do not retry without being asked.
- Report data accurately — never fabricate numbers or status.
"""


def _build_prompt(skill, user_prefs: str) -> str:
    parts = [BASE_PROMPT, f"## Active Skill: {skill.name}\n{skill.content}\n"]
    if user_prefs:
        parts.append(f"## User Preferences\n{user_prefs}\n")
    return "\n".join(parts)


def _resolve_prompt(message: str, skills, user_prefs: str, skill_id: str | None):
    """Build system prompt and server IDs from skill routing result."""
    if skill_id:
        skill = next((s for s in skills if s.id == skill_id), None)
    else:
        skill = None

    if skill:
        prompt = _build_prompt(skill, user_prefs)
        sids = skill.mcp_servers if skill.mcp_servers else None
        return prompt, sids, skill_id

    parts = [BASE_PROMPT]
    all_servers = set()
    for s in skills:
        parts.append(f"## {s.name}\n{s.content}\n")
        if s.mcp_servers:
            all_servers.update(s.mcp_servers)
    if user_prefs:
        parts.append(f"## User Preferences\n{user_prefs}\n")
    return "\n".join(parts), list(all_servers) or None, None


@asynccontextmanager
async def lifespan(app: FastAPI):
    skills = load_skills(SKILLS_DIR)
    logger.info("APM started — v%s, %d skills, servers: %s",
                settings.app_version, len(skills), registry.server_ids)
    yield
    await agent_loop.close()
    logger.info("APM shutdown.")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan,
)

FastAPIInstrumentor.instrument_app(app)

app.add_middleware(RequestContextMiddleware)
app.add_middleware(AuthMiddleware, api_key=settings.api_key)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

app.include_router(health_router)


@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    message = body.get("message", "").strip()
    token = body.get("token", "")
    user_id = body.get("user_id", "default")

    if not message:
        return JSONResponse({"error": "No message provided"}, status_code=400)

    skills = load_skills(SKILLS_DIR)
    prefs = load_user_prefs(USERS_DIR, user_id)

    skill_id, direct = await route(message, skills, prefs, agent_loop.llm_call)
    if direct:
        return {"response": direct, "skill": None}

    prompt, sids, resolved_skill = _resolve_prompt(message, skills, prefs, skill_id)

    try:
        response = await agent_loop.run(
            message=message, system_prompt=prompt,
            user_token=token, server_ids=sids,
        )
    except Exception as e:
        logger.error("Agent loop failed: %s", e, exc_info=True)
        return JSONResponse({"error": str(e)}, status_code=500)

    return {"response": response, "skill": resolved_skill}


@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    body = await request.json()
    message = body.get("message", "").strip()
    token = body.get("token", "")
    user_id = body.get("user_id", "default")

    if not message:
        return JSONResponse({"error": "No message provided"}, status_code=400)

    skills = load_skills(SKILLS_DIR)
    prefs = load_user_prefs(USERS_DIR, user_id)

    skill_id, direct = await route(message, skills, prefs, agent_loop.llm_call)
    if direct:
        async def _direct():
            yield f"data: {json.dumps({'type': 'token', 'content': direct})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'skill': None})}\n\n"
        return StreamingResponse(_direct(), media_type="text/event-stream")

    prompt, sids, resolved_skill = _resolve_prompt(message, skills, prefs, skill_id)

    async def _stream():
        try:
            async for event in agent_loop.run_stream(
                message=message, system_prompt=prompt,
                user_token=token, server_ids=sids,
            ):
                if isinstance(event, TokenEvent):
                    yield f"data: {json.dumps({'type': 'token', 'content': event.token})}\n\n"
                elif isinstance(event, StatusEvent):
                    yield f"data: {json.dumps({'type': 'status', 'message': event.message})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'skill': resolved_skill})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(_stream(), media_type="text/event-stream")


@app.get("/api/skills")
async def list_skills():
    skills = load_skills(SKILLS_DIR)
    return [{"id": s.id, "name": s.name, "description": s.description, "tags": s.tags} for s in skills]


dev_chat = BACKEND_DIR / "tools" / "dev-chat"
if dev_chat.exists():
    app.mount("/dev-chat", StaticFiles(directory=str(dev_chat), html=True), name="dev-chat")

frontend_dist = BACKEND_DIR.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="frontend")
