"""Agent loop — tool discovery, LLM reasoning, tool execution, streaming.

Framework file: no config imports. All settings injected via constructor.
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable

import httpx

from agent.mcp.registry import MCPRegistry
from agent.telemetry import get_tracer

logger = logging.getLogger(__name__)
tracer = get_tracer(__name__)


@dataclass
class StatusEvent:
    message: str

@dataclass
class TokenEvent:
    token: str


class AgentLoop:

    def __init__(
        self,
        registry: MCPRegistry,
        llm_base_url: str,
        llm_api_key: str,
        llm_deployment: str,
        llm_api_version: str = "2025-01-01-preview",
        llm_temperature: float = 1.0,
        max_rounds: int = 10,
        internal_tools: dict[str, Callable] | None = None,
    ):
        self._registry = registry
        self._llm_base_url = llm_base_url
        self._llm_api_key = llm_api_key
        self._llm_deployment = llm_deployment
        self._llm_api_version = llm_api_version
        self._llm_temperature = llm_temperature
        self._max_rounds = max_rounds
        self._internal_tools = internal_tools or {}
        self._http = httpx.AsyncClient(timeout=120, verify=False)

    def _llm_url(self) -> str:
        return f"{self._llm_base_url}/deployments/{self._llm_deployment}/chat/completions"

    def _llm_headers(self) -> dict:
        return {"api-key": self._llm_api_key, "Content-Type": "application/json"}

    def _llm_params(self) -> dict:
        return {"api-version": self._llm_api_version}

    async def llm_call(self, messages: list[dict], tools: list[dict] | None = None) -> dict:
        with tracer.start_as_current_span("llm_call") as span:
            payload: dict[str, Any] = {"messages": messages}
            if tools:
                payload["tools"] = tools
                payload["tool_choice"] = "auto"
            if self._llm_temperature == 1.0:
                payload["temperature"] = self._llm_temperature

            span.set_attribute("llm.deployment", self._llm_deployment)
            span.set_attribute("llm.message_count", len(messages))
            if tools:
                span.set_attribute("llm.tool_count", len(tools))

            resp = await self._http.post(
                self._llm_url(), json=payload,
                headers=self._llm_headers(), params=self._llm_params(),
            )
            resp.raise_for_status()
            return resp.json()

    async def _llm_stream(self, messages: list[dict], tools: list[dict] | None = None) -> AsyncIterator[dict]:
        payload: dict[str, Any] = {"messages": messages, "stream": True}
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
        if self._llm_temperature == 1.0:
            payload["temperature"] = self._llm_temperature

        async with self._http.stream(
            "POST", self._llm_url(), json=payload,
            headers=self._llm_headers(), params=self._llm_params(),
        ) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:].strip()
                if data == "[DONE]":
                    break
                try:
                    yield json.loads(data)
                except json.JSONDecodeError:
                    continue

    async def _get_tools(self, server_ids: list[str] | None, user_token: str) -> list[dict]:
        await self._registry.discover_tools(server_ids, user_token=user_token)
        tools = self._registry.get_openai_tools(server_ids)
        for name, fn in self._internal_tools.items():
            tools.append({
                "type": "function",
                "function": {
                    "name": name,
                    "description": fn.__doc__ or "",
                    "parameters": getattr(fn, "schema", {"type": "object", "properties": {}}),
                },
            })
        return tools

    async def _exec_tool(self, name: str, args: dict, user_token: str) -> str:
        with tracer.start_as_current_span("tool_call") as span:
            span.set_attribute("tool.name", name)

            if name in self._internal_tools:
                span.set_attribute("tool.type", "internal")
                try:
                    result = await self._internal_tools[name](**args)
                    return str(result) if not isinstance(result, str) else result
                except Exception as e:
                    logger.error("Internal tool %s failed: %s", name, e)
                    return f"Tool error: {e}"

            span.set_attribute("tool.type", "mcp")
            span.set_attribute("tool.server", self._registry.server_for_tool(name) or "unknown")
            try:
                result = await self._registry.call_tool(name, args, user_token=user_token)
                return self._extract_text(result)
            except Exception as e:
                logger.error("MCP tool %s failed: %s", name, e)
                return f"Tool error: {e}"

    async def run(
        self, message: str, system_prompt: str,
        user_token: str = "", server_ids: list[str] | None = None,
    ) -> str:
        result = []
        async for event in self.run_stream(message, system_prompt, user_token, server_ids):
            if isinstance(event, TokenEvent):
                result.append(event.token)
        return "".join(result)

    async def run_stream(
        self, message: str, system_prompt: str,
        user_token: str = "", server_ids: list[str] | None = None,
    ) -> AsyncIterator[StatusEvent | TokenEvent]:
        with tracer.start_as_current_span("agent_loop") as span:
            t0 = time.monotonic()

            openai_tools = await self._get_tools(server_ids, user_token)
            span.set_attribute("agent.tool_count", len(openai_tools))

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message},
            ]

            for round_num in range(self._max_rounds):
                span.set_attribute("agent.round", round_num + 1)
                logger.info("Round %d/%d", round_num + 1, self._max_rounds)

                tool_calls_acc: dict[int, dict] = {}
                content_parts = []
                finish = None

                try:
                    async for chunk in self._llm_stream(messages, openai_tools):
                        delta = chunk.get("choices", [{}])[0].get("delta", {})
                        finish = chunk.get("choices", [{}])[0].get("finish_reason") or finish

                        if "content" in delta and delta["content"]:
                            token = delta["content"]
                            content_parts.append(token)
                            yield TokenEvent(token=token)

                        for tc in delta.get("tool_calls", []):
                            idx = tc["index"]
                            if idx not in tool_calls_acc:
                                tool_calls_acc[idx] = {
                                    "id": tc.get("id", ""),
                                    "type": "function",
                                    "function": {"name": "", "arguments": ""},
                                }
                            acc = tool_calls_acc[idx]
                            if tc.get("id"):
                                acc["id"] = tc["id"]
                            fn = tc.get("function", {})
                            if fn.get("name"):
                                acc["function"]["name"] = fn["name"]
                            if fn.get("arguments"):
                                acc["function"]["arguments"] += fn["arguments"]

                except Exception as e:
                    logger.error("LLM stream failed: %s", e)
                    yield TokenEvent(token=f"\n\nLLM error: {e}")
                    return

                if not tool_calls_acc:
                    if not content_parts:
                        yield TokenEvent(token="(empty response)")
                    elapsed = round((time.monotonic() - t0) * 1000)
                    span.set_attribute("agent.duration_ms", elapsed)
                    logger.info("Done in %dms (%d rounds)", elapsed, round_num + 1)
                    return

                tool_calls = [tool_calls_acc[i] for i in sorted(tool_calls_acc)]
                assistant_msg = {"role": "assistant", "content": "".join(content_parts) or None, "tool_calls": tool_calls}
                messages.append(assistant_msg)

                names = [tc["function"]["name"] for tc in tool_calls]
                yield StatusEvent(message=f"Calling {', '.join(names)}...")

                async def _run_tool(tc):
                    name = tc["function"]["name"]
                    try:
                        args = json.loads(tc["function"]["arguments"])
                    except json.JSONDecodeError:
                        args = {}
                    text = await self._exec_tool(name, args, user_token)
                    return tc["id"], text[:4000]

                results = await asyncio.gather(*[_run_tool(tc) for tc in tool_calls])
                for call_id, text in results:
                    messages.append({"role": "tool", "tool_call_id": call_id, "content": text})

            yield TokenEvent(token="Reached maximum reasoning steps.")

    @staticmethod
    def _extract_text(result: dict) -> str:
        if "result" in result:
            content = result["result"]
            if isinstance(content, dict) and "content" in content:
                parts = content["content"]
                if isinstance(parts, list):
                    return "\n".join(p.get("text", str(p)) for p in parts if isinstance(p, dict))
                return str(parts)
            return str(content)
        if "error" in result:
            err = result["error"]
            return f"Error: {err.get('message', str(err)) if isinstance(err, dict) else err}"
        return str(result)

    def reset_cache(self):
        self._registry.reset_cache()

    async def close(self):
        await self._http.aclose()
