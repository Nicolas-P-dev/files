"""Loads skills from flat markdown files with YAML frontmatter.

Framework file: no config imports. Paths relative to package root.
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)


@dataclass
class Skill:
    id: str
    name: str
    description: str
    content: str
    mcp_servers: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    version: str = "1.0"


def _parse_skill_file(path: Path) -> Optional[Skill]:
    try:
        raw = path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error("Failed to read %s: %s", path, e)
        return None

    match = _FRONTMATTER_RE.match(raw)
    if match:
        try:
            meta = yaml.safe_load(match.group(1)) or {}
        except yaml.YAMLError as e:
            logger.warning("Bad YAML in %s: %s", path.name, e)
            meta = {}
        body = raw[match.end():].strip()
    else:
        meta = {}
        body = raw.strip()

    mcp = meta.get("mcp_servers", [])
    if isinstance(mcp, str):
        mcp = [s.strip() for s in mcp.split(",") if s.strip()]

    return Skill(
        id=path.stem,
        name=meta.get("name", path.stem.replace("-", " ").title()),
        description=meta.get("description", ""),
        content=body,
        mcp_servers=mcp,
        tags=meta.get("tags", []),
        version=str(meta.get("version", "1.0")),
    )


def load_skills(skills_dir: Path) -> list[Skill]:
    if not skills_dir.exists():
        logger.warning("Skills directory not found: %s", skills_dir)
        return []
    skills = []
    for path in sorted(skills_dir.glob("*.md")):
        skill = _parse_skill_file(path)
        if skill:
            skills.append(skill)
    logger.info("Loaded %d skills from %s", len(skills), skills_dir)
    return skills


def load_user_prefs(users_dir: Path, user_id: str) -> str:
    path = users_dir / f"{user_id}.md"
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception as e:
        logger.warning("Failed to read user prefs %s: %s", path, e)
        return ""


def save_user_prefs(users_dir: Path, user_id: str, content: str) -> None:
    users_dir.mkdir(parents=True, exist_ok=True)
    path = users_dir / f"{user_id}.md"
    path.write_text(content, encoding="utf-8")
    logger.info("Saved user prefs: %s", path)
