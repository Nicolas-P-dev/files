Respond concisely. Use bullet points for lists. Include issue keys in all references.
