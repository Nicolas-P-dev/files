"""Tests for the EventEmitter."""

import os
import sys
import time
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.events import EventEmitter, AgentEvent


def test_emit_and_log():
    emitter = EventEmitter()
    emitter.emit("test_event", trigger_id="T01", value=42)

    log = emitter.get_log()
    assert len(log) == 1
    assert log[0]["event_type"] == "test_event"
    assert log[0]["trigger_id"] == "T01"
    assert log[0]["data"]["value"] == 42


def test_subscriber_receives_events():
    emitter = EventEmitter()
    received = []
    emitter.subscribe(lambda e: received.append(e))

    emitter.emit("event_a", data_key="hello")
    emitter.emit("event_b", data_key="world")

    assert len(received) == 2
    assert received[0].event_type == "event_a"
    assert received[1].event_type == "event_b"


def test_multiple_subscribers():
    emitter = EventEmitter()
    received_a = []
    received_b = []
    emitter.subscribe(lambda e: received_a.append(e))
    emitter.subscribe(lambda e: received_b.append(e))

    emitter.emit("test")

    assert len(received_a) == 1
    assert len(received_b) == 1


def test_subscriber_error_doesnt_break_others():
    emitter = EventEmitter()
    received = []

    def bad_subscriber(e):
        raise ValueError("oops")

    emitter.subscribe(bad_subscriber)
    emitter.subscribe(lambda e: received.append(e))

    emitter.emit("test")
    assert len(received) == 1, "Good subscriber should still receive event"


def test_get_events_since():
    emitter = EventEmitter()
    emitter.emit("early")
    ts = time.time()
    time.sleep(0.01)
    emitter.emit("late")

    events = emitter.get_events_since(ts)
    assert len(events) == 1
    assert events[0]["event_type"] == "late"


def test_agent_event_serialization():
    event = AgentEvent(
        event_type="test",
        trigger_id="T01",
        data={"score": 0.95},
    )

    d = event.to_dict()
    assert d["event_type"] == "test"
    assert d["trigger_id"] == "T01"
    assert d["data"]["score"] == 0.95

    j = event.to_json()
    import json
    parsed = json.loads(j)
    assert parsed["event_type"] == "test"
