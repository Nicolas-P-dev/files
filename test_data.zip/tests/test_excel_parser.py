"""Tests for the Excel parser."""

import os
import sys
import pytest

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from test_data.generate import generate_sample_excel
from skill.triggers.excel_parser import parse_triggers_excel


@pytest.fixture(scope="module")
def sample_excel(tmp_path_factory):
    """Generate a sample Excel in a temp directory."""
    # Use the generate function, but we need to temporarily override OUTPUT_DIR
    import test_data.generate as gen
    original_dir = gen.OUTPUT_DIR
    tmp_dir = str(tmp_path_factory.mktemp("test_excel"))
    gen.OUTPUT_DIR = tmp_dir
    os.makedirs(os.path.join(tmp_dir, "sample_documents"), exist_ok=True)
    path = gen.generate_sample_excel()
    gen.OUTPUT_DIR = original_dir
    return path


def test_parse_corporate_triggers(sample_excel):
    result = parse_triggers_excel(sample_excel, "corporate")
    triggers = result["triggers"]

    assert len(triggers) > 0, "Should parse at least one trigger"
    assert len(triggers) >= 15, f"Expected at least 15 corporate triggers, got {len(triggers)}"

    # Check trigger structure
    for t in triggers:
        assert "id" in t
        assert "trigger_text" in t
        assert "category" in t or t["category"] == ""
        assert "topic" in t


def test_parse_retail_triggers(sample_excel):
    result = parse_triggers_excel(sample_excel, "retail")
    triggers = result["triggers"]

    assert len(triggers) > 0, "Should parse at least one retail trigger"
    assert len(triggers) >= 8, f"Expected at least 8 retail triggers, got {len(triggers)}"


def test_triggers_have_examples(sample_excel):
    result = parse_triggers_excel(sample_excel, "corporate")
    triggers_with_examples = [t for t in result["triggers"] if t.get("examples")]
    assert len(triggers_with_examples) > 0, "Some triggers should have examples"


def test_guidance_notes_extracted(sample_excel):
    result = parse_triggers_excel(sample_excel, "corporate")
    assert result["guidance_notes"], "Guidance notes should be extracted"
    assert len(result["guidance_notes"]) > 50, "Guidance notes should be substantial"


def test_cross_reference_with_reference_sheet(sample_excel):
    result = parse_triggers_excel(sample_excel, "corporate")
    triggers = result["triggers"]

    # At least some triggers should have stage_ref from reference sheet
    triggers_with_ref = [t for t in triggers if t.get("source_ref")]
    assert len(triggers_with_ref) > 0, "Some triggers should have cross-reference data"
