"""Tests for the upgraded content-aware MockLLM and agentic flow nodes."""

import os
import sys
import json
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.llm import MockLLM, _get_topic_keywords


@pytest.fixture
def llm():
    return MockLLM()


# ===== Plan Search =====

def test_mock_plan_search(llm):
    prompt = (
        "Plan search strategy for this forbearance trigger.\n\n"
        "Category: Concessions\n"
        "Topic: Maturity\n"
        "Trigger: Extension of maturity dates beyond original terms\n"
        "Stage Reference: S2\n"
        "Hard/Soft: Soft\n"
    )
    response = llm.call(prompt)
    result = json.loads(response)
    assert "queries" in result
    assert isinstance(result["queries"], list)
    assert len(result["queries"]) >= 3
    assert "target_doc_types" in result
    assert "search_rationale" in result


def test_plan_search_returns_relevant_queries(llm):
    prompt = (
        "Plan search strategy for this forbearance trigger.\n\n"
        "Category: Loss events\n"
        "Topic: Bankruptcy\n"
        "Trigger: Bankruptcy filing or insolvency proceedings initiated\n"
    )
    result = json.loads(llm.call(prompt))
    queries_lower = " ".join(result["queries"]).lower()
    # Should contain at least one bankruptcy-related term
    assert any(
        kw in queries_lower
        for kw in ["bankruptcy", "insolvency", "liquidation", "filing"]
    )


# ===== Refine Search =====

def test_mock_refine_search(llm):
    prompt = (
        "Refine search queries. The previous search did not find sufficient results.\n\n"
        "Topic: Covenant\n"
        "Trigger: Covenant breach waived by the bank\n"
        "Previous queries: [\"covenant breach waiver\"]\n"
    )
    result = json.loads(llm.call(prompt))
    assert "queries" in result
    assert "strategy" in result
    assert len(result["queries"]) >= 2


# ===== Content-Aware Evidence Evaluation =====

def test_mock_evidence_eval_found_when_evidence_matches(llm):
    """When chunks contain matching keywords, should return FOUND."""
    prompt = (
        "Evaluate evidence for the following trigger.\n\n"
        "Category: Concessions\n"
        "Topic: Maturity\n"
        "Trigger: Extension of maturity dates beyond original terms\n"
        "Stage Reference: S2\n\n"
        "## Retrieved Document Excerpts\n"
        "--- Excerpt 1 ---\n"
        "Source: npl_report.pdf (page 3)\n"
        "Relevance: 0.65\n"
        "Text: The facility maturity has been extended by 24 months beyond "
        "the original maturity date, from March 2023 to March 2025. This extension "
        "was granted as part of a broader restructuring of the loan terms.\n"
    )
    result = json.loads(llm.call(prompt))
    assert result["status"] == "FOUND"
    assert result["confidence"] >= 0.5
    assert result["source_document"] == "npl_report.pdf"
    assert result["key_evidence"]  # Should have extracted evidence


def test_mock_evidence_eval_not_found_when_no_match(llm):
    """When chunks don't contain relevant keywords, should return NOT_FOUND."""
    prompt = (
        "Evaluate evidence for the following trigger.\n\n"
        "Category: Concessions\n"
        "Topic: Debt conversion\n"
        "Trigger: Conversion of debt to equity instruments\n"
        "Stage Reference: S2\n\n"
        "## Retrieved Document Excerpts\n"
        "--- Excerpt 1 ---\n"
        "Source: financial_statement.pdf (page 1)\n"
        "Relevance: 0.20\n"
        "Text: The company reported total revenue of EUR 50 million for the fiscal year. "
        "Operating expenses were EUR 42 million, resulting in an operating margin of 16%.\n"
    )
    result = json.loads(llm.call(prompt))
    assert result["status"] == "NOT_FOUND"
    assert result["confidence"] >= 0.5


def test_mock_evidence_eval_inconclusive_on_partial_match(llm):
    """Partial keyword overlap should yield INCONCLUSIVE."""
    prompt = (
        "Evaluate evidence for the following trigger.\n\n"
        "Category: Financial difficulty indicators\n"
        "Topic: Cash flow\n"
        "Trigger: Insufficient operating cash flow to service debt obligations\n"
        "Stage Reference: S2\n\n"
        "## Retrieved Document Excerpts\n"
        "--- Excerpt 1 ---\n"
        "Source: financial_statement.pdf (page 2)\n"
        "Relevance: 0.30\n"
        "Text: The company's operating cash flow decreased compared to prior year. "
        "Revenue targets were partially met. The board is monitoring the situation.\n"
    )
    result = json.loads(llm.call(prompt))
    # Partial match: "cash flow" appears but not "insufficient" or "debt service"
    assert result["status"] in ("INCONCLUSIVE", "FOUND")


# ===== Stage Classification =====

def test_mock_stage_classification(llm):
    prompt = (
        "Classify stage for this trigger.\n\n"
        "Trigger: Bankruptcy filing\n"
        "Reference Stage: S3\n"
        "NPE Trigger: Yes\n"
        "Hard/Soft: Hard\n"
        "Forbearance Measure: No\n"
    )
    result = json.loads(llm.call(prompt))
    assert result["classification"] in ("S2 trigger", "S3 trigger", "Not a trigger", "N/a")
    assert "reasoning" in result


def test_npe_trigger_gives_s3(llm):
    """NPE triggers should classify as S3."""
    prompt = (
        "Classify stage for this trigger.\n\n"
        "Trigger: Bankruptcy filing\n"
        "Reference Stage: S3\n"
        "NPE Trigger: Yes\n"
        "Hard/Soft: Hard\n"
    )
    result = json.loads(llm.call(prompt))
    assert result["classification"] == "S3 trigger"


def test_soft_trigger_gives_s2(llm):
    """Soft triggers without NPE flag should classify as S2."""
    prompt = (
        "Classify stage for this trigger.\n\n"
        "Trigger: Interest rate reduction below market\n"
        "Reference Stage: S2\n"
        "NPE Trigger: No\n"
        "Hard/Soft: Soft\n"
    )
    result = json.loads(llm.call(prompt))
    assert result["classification"] == "S2 trigger"


# ===== Cross-trigger Synthesis =====

def test_mock_synthesize(llm):
    prompt = (
        "Synthesize cross-trigger findings.\n\n"
        "## All trigger results\n"
        "[!] Concessions/Maturity: FOUND (confidence: 0.85)\n"
        "[!] Financial difficulty indicators/Going concern: FOUND (confidence: 0.78)\n"
        "[?] Financial difficulty indicators/Cash flow: INCONCLUSIVE (confidence: 0.45)\n"
        "[ ] Loss events/Bankruptcy: NOT_FOUND (confidence: 0.90)\n"
    )
    result = json.loads(llm.call(prompt))
    assert "overall_risk" in result
    assert "forbearance_confirmed" in result
    assert "correlations" in result
    assert "upgrade_candidates" in result


# ===== Re-evaluation =====

def test_mock_reevaluate(llm):
    prompt = (
        "Re-evaluate this INCONCLUSIVE trigger with full context.\n\n"
        "Trigger: Cash flow deficit\n"
        "Initial assessment: INCONCLUSIVE (confidence: 0.45)\n"
        "Upgrade recommendation: Yes\n"
        "Confirmed findings: Multiple evidence found for related triggers.\n"
    )
    result = json.loads(llm.call(prompt))
    assert "decision" in result
    assert result["decision"] in ("upgrade", "keep")
    assert "new_status" in result
    assert "reasoning" in result


# ===== Keyword Mapping =====

def test_get_topic_keywords():
    kw = _get_topic_keywords("Maturity")
    assert "maturity" in kw
    assert "extension" in kw

    kw = _get_topic_keywords("Going concern")
    assert "going concern" in kw

    # Fallback for unknown topics
    kw = _get_topic_keywords("Unknown special topic")
    assert len(kw) > 0  # Should still return something


# ===== call_structured fallback =====

def test_call_structured_fallback(llm):
    """call_structured should return a fallback dict on parse error."""
    # Force an unparseable response via a prompt that hits the fallback
    # (In practice this is hard to trigger with the current routing, but
    #  we can test the error path directly)
    result = llm.call_structured("some unroutable prompt with no keywords")
    assert isinstance(result, dict)
