"""Generate realistic test data: sample triggers Excel and mock PDF documents."""

import os
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from fpdf import FPDF


OUTPUT_DIR = os.path.join(os.path.dirname(__file__))

# ============================================================
# Trigger definitions for test data
# ============================================================

CORPORATE_TRIGGERS = [
    # (Category, Topic, Trigger text, Examples)
    ("Concessions", "Interest rate",
     "Reduction of the interest rate below the market rate applicable to similar facilities at origination",
     ["Interest rate reduced from 4.5% to 1.2%, below market rate of 3.8%",
      "Rate modification within normal market range — not a concession",
      "Promotional rate applied temporarily — assess if linked to financial difficulty"]),

    ("Concessions", "Maturity",
     "Extension of maturity dates beyond original contractual terms",
     ["Maturity extended by 24 months per amendment No. 3",
      "Scheduled maturity unchanged despite borrower request",
      "Maturity extension as part of standard facility renewal — not a concession"]),

    ("Concessions", "Payment schedule",
     "Granting of a payment holiday or moratorium on principal and/or interest",
     ["6-month payment holiday granted commencing Q2 2023",
      "No payment holiday — all instalments paid on schedule",
      "COVID-related payment holiday under government scheme"]),

    ("Concessions", "Principal",
     "Partial or full write-off of principal amount",
     ["EUR 5m principal written off as part of restructuring",
      "No write-offs applied to the facility",
      "Provision made but no actual write-off executed"]),

    ("Concessions", "Debt conversion",
     "Conversion of debt to equity or other instruments",
     ["EUR 10m converted to subordinated loan as part of restructuring",
      "No debt conversion — facility remains as senior secured loan",
      ""]),

    ("Concessions", "Additional facility",
     "Granting of additional credit facilities to cover cash shortfalls",
     ["Bridge facility of EUR 15m granted to cover working capital deficit",
      "Revolving credit facility drawn within normal limits",
      ""]),

    ("Financial difficulty indicators", "Past due status",
     "Exposure past due for more than 30 days on any material obligation",
     ["Borrower 45 days past due on Q3 2023 instalment",
      "All payments current — no past due amounts",
      "Past due status cured within 30-day grace period"]),

    ("Financial difficulty indicators", "Covenant breach",
     "Breach or waiver of financial covenants in the facility agreement",
     ["DSCR covenant of 1.10x breached — actual ratio 0.95x in Q3 2023",
      "All covenants met as of latest reporting date",
      "Covenant waiver granted for one quarter pending restructuring"]),

    ("Financial difficulty indicators", "Credit rating downgrade",
     "Internal or external credit rating downgrade of two or more notches",
     ["Internal rating downgraded from BB+ to B- (3 notches)",
      "Rating unchanged at BBB- since facility origination",
      ""]),

    ("Financial difficulty indicators", "Cash flow deficit",
     "Projected or actual operating cash flow insufficient to service debt obligations",
     ["Cash flow projections show deficit of EUR 3m against debt service of EUR 8m",
      "Operating cash flow covers debt service by 1.5x",
      ""]),

    ("Financial difficulty indicators", "Going concern doubt",
     "Auditor has expressed going concern doubt in financial statements",
     ["Going concern qualification in 2023 audit report",
      "Clean audit opinion received — no going concern issues",
      ""]),

    ("Loss events", "Bankruptcy filing",
     "Borrower has filed for or is subject to bankruptcy/insolvency proceedings",
     ["Insolvency petition filed on 15.09.2023",
      "No insolvency proceedings — borrower operating normally",
      ""]),

    ("Loss events", "Cross-default",
     "Default on other material financial obligations (cross-default)",
     ["Default on syndicated facility triggered cross-default clause",
      "No cross-default events reported",
      ""]),

    ("Loss events", "Collateral impairment",
     "Significant decline in collateral value below the secured exposure amount",
     ["Property collateral revalued at EUR 12m vs. secured amount of EUR 18m",
      "Collateral value exceeds secured exposure — LTV at 65%",
      ""]),

    ("Forbearance measures", "Refinancing",
     "Refinancing of facilities under conditions the borrower could not obtain elsewhere",
     ["Facility refinanced at below-market terms due to financial difficulty",
      "Refinancing at market terms — competitive process conducted",
      ""]),

    ("Forbearance measures", "Forbearance flag",
     "Facility flagged as forborne in the bank's internal systems",
     ["Facility marked as 'forborne' in core banking system since Q2 2023",
      "No forbearance flag in bank systems",
      ""]),

    ("Forbearance measures", "Restructuring plan",
     "Borrower subject to an active restructuring or workout plan",
     ["Restructuring plan agreed in March 2023 with milestone review in Q4",
      "No restructuring — facility performing under original terms",
      ""]),
]

RETAIL_TRIGGERS = [
    ("Concessions", "Interest rate",
     "Reduction of the interest rate on consumer or mortgage facilities below market rate",
     ["Mortgage rate reduced from 3.2% to 1.5%", "Rate unchanged", ""]),

    ("Concessions", "Payment schedule",
     "Extension of payment terms or granting of payment holiday on retail exposures",
     ["Payment holiday of 3 months granted", "Regular payments maintained", ""]),

    ("Concessions", "Principal forgiveness",
     "Partial or total forgiveness of outstanding consumer debt principal",
     ["EUR 2,000 of credit card balance written off", "No forgiveness", ""]),

    ("Financial difficulty indicators", "Past due",
     "Consumer exposure past due for more than 30 days",
     ["Mortgage 60 days past due", "All payments current", ""]),

    ("Financial difficulty indicators", "Income deterioration",
     "Significant decline in borrower income or employment status change",
     ["Borrower declared unemployed in Q3 2023", "Stable employment", ""]),

    ("Financial difficulty indicators", "Debt-to-income",
     "Debt-to-income ratio exceeding prudential thresholds",
     ["DTI ratio at 55% vs threshold of 40%", "DTI ratio at 28%", ""]),

    ("Loss events", "Personal insolvency",
     "Borrower subject to personal insolvency or bankruptcy proceedings",
     ["Personal insolvency filed Sept 2023", "No insolvency", ""]),

    ("Loss events", "Collateral shortfall",
     "Property value decline resulting in negative equity position",
     ["Property value EUR 180k vs mortgage EUR 220k", "LTV at 70%", ""]),

    ("Forbearance measures", "Forbearance flag",
     "Retail exposure flagged as forborne in bank systems",
     ["Forborne flag applied since Jan 2023", "No flag", ""]),

    ("Forbearance measures", "Arrears capitalization",
     "Past due amounts capitalized into the outstanding balance",
     ["EUR 5,000 arrears capitalized into mortgage balance", "No capitalization", ""]),
]

REFERENCE_TRIGGERS = [
    # (ID, Name, NPE, S2, Source, Hard/Soft, Short/Long, Forbearance, Description)
    ("T01", "Interest rate reduction", "No", "Yes", "EBA GL 2018/06", "Soft", "Short-term", "Yes",
     "Reduction of interest rate below market rate as a concession to borrower in financial difficulty"),
    ("T02", "Maturity extension", "No", "Yes", "EBA GL 2018/06", "Soft", "Long-term", "Yes",
     "Extension of facility maturity beyond original contractual terms"),
    ("T03", "Payment holiday", "No", "Yes", "EBA GL 2018/06", "Soft", "Short-term", "Yes",
     "Granting of temporary suspension of principal and/or interest payments"),
    ("T04", "Principal write-off", "Yes", "Yes", "CRR Art. 178", "Hard", "Long-term", "Yes",
     "Partial or full write-off of principal amount"),
    ("T05", "Debt conversion", "No", "Yes", "EBA GL 2018/06", "Soft", "Long-term", "Yes",
     "Conversion of debt to equity or subordinated instruments"),
    ("T06", "Additional facility", "No", "Yes", "ECB NPL Guidance", "Soft", "Short-term", "Yes",
     "Granting of additional credit to cover cash shortfalls"),
    ("T07", "Past due >30 days", "No", "Yes", "IFRS 9 B5.5.28", "Soft", "Short-term", "No",
     "Material obligation past due for more than 30 days"),
    ("T08", "Covenant breach", "No", "Yes", "IFRS 9 B5.5.17", "Soft", "Short-term", "No",
     "Breach or waiver of financial covenants"),
    ("T09", "Credit rating downgrade", "No", "Yes", "IFRS 9 B5.5.17", "Soft", "Short-term", "No",
     "Internal or external credit rating downgrade of 2+ notches"),
    ("T10", "Cash flow deficit", "No", "Yes", "IFRS 9 B5.5.17", "Soft", "Short-term", "No",
     "Insufficient cash flow to service debt obligations"),
    ("T11", "Going concern doubt", "Yes", "Yes", "IAS 1.25", "Hard", "Long-term", "No",
     "Auditor going concern qualification"),
    ("T12", "Bankruptcy filing", "Yes", "No", "CRR Art. 178", "Hard", "Long-term", "No",
     "Borrower subject to bankruptcy or insolvency proceedings"),
    ("T13", "Cross-default", "Yes", "No", "CRR Art. 178", "Hard", "Short-term", "No",
     "Default on other material financial obligations"),
    ("T14", "Collateral impairment", "No", "Yes", "IFRS 9 B5.5.17", "Soft", "Short-term", "No",
     "Significant decline in collateral value below secured amount"),
    ("T15", "Refinancing concession", "No", "Yes", "EBA GL 2018/06", "Soft", "Long-term", "Yes",
     "Refinancing under non-market conditions"),
    ("T16", "Forbearance flag", "No", "Yes", "EBA ITS 2013/03", "Soft", "Long-term", "Yes",
     "Facility flagged as forborne in bank systems"),
    ("T17", "Restructuring plan", "No", "Yes", "ECB NPL Guidance", "Soft", "Long-term", "Yes",
     "Borrower subject to active restructuring or workout plan"),
]


def generate_sample_excel():
    """Generate the sample triggers Excel file."""
    wb = Workbook()

    # --- Sheet 1: Triggers Corporate ---
    ws_corp = wb.active
    ws_corp.title = "Triggers Corporate"
    _write_assessment_sheet(ws_corp, CORPORATE_TRIGGERS, "Corporate")

    # --- Sheet 2: Triggers Retail ---
    ws_retail = wb.create_sheet("Triggers Retail")
    _write_assessment_sheet(ws_retail, RETAIL_TRIGGERS, "Retail")

    # --- Sheet 3: triggers (reference) ---
    ws_ref = wb.create_sheet("triggers")
    _write_reference_sheet(ws_ref)

    output_path = os.path.join(OUTPUT_DIR, "sample_triggers.xlsx")
    wb.save(output_path)
    wb.close()
    print(f"Generated: {output_path}")
    return output_path


def _write_assessment_sheet(ws, triggers_data, sheet_label):
    """Write an assessment sheet (Corporate or Retail)."""
    header_fill = PatternFill(start_color="26890D", end_color="26890D", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)

    # Row 1: Title
    ws.cell(row=1, column=1, value=f"4. Classification Review outcomes")
    ws.cell(row=1, column=1).font = Font(bold=True, size=14)

    # Row 2: Subtitle
    ws.cell(row=2, column=1, value="Impairment trigger values and assessment")
    ws.cell(row=2, column=1).font = Font(bold=True, size=12)

    # Row 3: Guidance notes
    guidance = (
        "This checklist is used to assess whether forbearance measures have been granted "
        "to the borrower. For each trigger, the auditor should review the credit file "
        "documents and determine whether evidence exists. Column D contains the bank's "
        "reported values (do not delete or amend any of the formulas). Column E is for "
        "the validated/revised value. Column F is for the stage classification. Column G "
        "is for comments explaining the assessment. Examples in columns I-K provide "
        "reference for typical assessments."
    )
    ws.cell(row=3, column=1, value=guidance)
    ws.cell(row=3, column=1).alignment = Alignment(wrap_text=True)

    # Row 6: Headers
    headers = [
        "Category", "Topic", "Trigger",
        "Reported value by the Bank",
        "Validated / Revised value by the Bank team",
        "Validated value treated as S2, S3 trigger, Not a trigger or N/a",
        "Comment for Bank Team" if sheet_label == "Corporate" else "Potential treatments of the triggers",
        "",  # gap
        "Example 1", "Example 2", "Example 3",
    ]

    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=6, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(wrap_text=True, horizontal="center")

    # Data rows starting at row 7
    current_row = 7
    last_category = ""
    for category, topic, trigger_text, examples in triggers_data:
        # Only show category when it changes
        display_category = category if category != last_category else ""
        last_category = category

        ws.cell(row=current_row, column=1, value=display_category)
        ws.cell(row=current_row, column=2, value=topic)
        ws.cell(row=current_row, column=3, value=trigger_text)
        ws.cell(row=current_row, column=4, value="")  # Reported value (blank for test)
        ws.cell(row=current_row, column=5, value="")  # Validated value (output)
        ws.cell(row=current_row, column=6, value="")  # Stage classification (output)
        ws.cell(row=current_row, column=7, value="")  # Comment (output)
        ws.cell(row=current_row, column=8, value="")  # Gap

        for ex_idx, example in enumerate(examples):
            ws.cell(row=current_row, column=9 + ex_idx, value=example)

        current_row += 1

    # Column widths
    widths = [20, 18, 55, 20, 25, 25, 40, 3, 40, 40, 40]
    for i, w in enumerate(widths, 1):
        col_letter = chr(64 + i) if i <= 26 else "A"
        ws.column_dimensions[col_letter].width = w


def _write_reference_sheet(ws):
    """Write the triggers reference/master sheet."""
    header_fill = PatternFill(start_color="86BC25", end_color="86BC25", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=10)

    headers = [
        "Trigger ID", "Trigger name", "NPE trigger", "Stage 2 trigger",
        "Source", "Hard / Soft", "",
        "Short-term/Long-term", "Forbearance measure", "Description",
    ]

    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font

    for row_idx, ref in enumerate(REFERENCE_TRIGGERS, 2):
        tid, name, npe, s2, source, hard_soft, short_long, forb, desc = ref
        ws.cell(row=row_idx, column=1, value=tid)
        ws.cell(row=row_idx, column=2, value=name)
        ws.cell(row=row_idx, column=3, value=npe)
        ws.cell(row=row_idx, column=4, value=s2)
        ws.cell(row=row_idx, column=5, value=source)
        ws.cell(row=row_idx, column=6, value=hard_soft)
        ws.cell(row=row_idx, column=7, value="")  # gap
        ws.cell(row=row_idx, column=8, value=short_long)
        ws.cell(row=row_idx, column=9, value=forb)
        ws.cell(row=row_idx, column=10, value=desc)

    widths = [12, 30, 12, 14, 18, 12, 3, 18, 18, 60]
    for i, w in enumerate(widths, 1):
        col_letter = chr(64 + i) if i <= 26 else "A"
        ws.column_dimensions[col_letter].width = w


def generate_sample_pdfs():
    """Generate mock PDF documents for testing."""
    docs_dir = os.path.join(OUTPUT_DIR, "sample_documents")
    os.makedirs(docs_dir, exist_ok=True)

    _generate_npl_vermerk(docs_dir)
    _generate_facility_agreement(docs_dir)
    _generate_financial_statement(docs_dir)

    print(f"Generated PDFs in: {docs_dir}")


def _generate_npl_vermerk(docs_dir):
    """Generate a mock NPL Vermerk (non-performing loan report)."""
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "NPL Vermerk - Credit Assessment Report", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 8, "Debtor: ABC Manufacturing GmbH", ln=True)
    pdf.cell(0, 8, "Assessment Date: 30.09.2023", ln=True)
    pdf.cell(0, 8, "Prepared by: Credit Risk Department", ln=True)
    pdf.ln(10)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "1. Executive Summary", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "ABC Manufacturing GmbH is a medium-sized industrial company operating in the "
        "automotive supply chain. The company has experienced financial difficulties since "
        "Q2 2022 due to supply chain disruptions and rising energy costs. The total credit "
        "exposure amounts to EUR 25 million across two facilities."
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "2. Facility Overview", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "Facility A: Term Loan EUR 15m, original maturity 31.12.2024\n"
        "Facility B: Revolving Credit Facility EUR 10m, annual renewal\n\n"
        "Current utilization: Facility A fully drawn, Facility B drawn to EUR 8.5m."
    )
    pdf.ln(5)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "3. Forbearance Measures Granted", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "The following concessions have been granted to the borrower:\n\n"
        "3.1 Maturity Extension\n"
        "The facility maturity has been extended by 24 months beyond the original "
        "contractual terms as per amendment dated 15.03.2023. The original maturity of "
        "Facility A was 31.12.2024, now revised to 31.12.2026. This extension was "
        "granted at the borrower's request due to inability to refinance in current "
        "market conditions.\n\n"
        "3.2 Bridge Facility\n"
        "A bridge facility of EUR 5 million was granted in April 2023 to cover the "
        "shortfall in operating cash flows. This facility carries an interest rate of "
        "EURIBOR + 350bps, which is consistent with the risk profile but was granted "
        "outside normal credit approval processes due to urgency.\n\n"
        "3.3 Covenant Waiver\n"
        "The debt service coverage ratio covenant of 1.10x was breached in Q3 2023, "
        "with the actual ratio at 0.95x. A temporary waiver was granted for Q3 and Q4 "
        "2023 pending completion of the restructuring plan."
    )
    pdf.ln(5)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "4. Financial Performance", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "Revenue declined 18% year-over-year to EUR 42 million in H1 2023. "
        "EBITDA margin contracted from 12% to 6%. The company's internal credit "
        "rating was downgraded from BB+ to B- in June 2023, representing a three-notch "
        "downgrade reflecting the deterioration in financial performance and increased "
        "leverage.\n\n"
        "Operating cash flow for the trailing twelve months was EUR 2.1 million against "
        "debt service requirements of EUR 5.8 million, indicating a significant cash "
        "flow deficit."
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "5. Collateral Position", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "The term loan is secured by the company's manufacturing facility and equipment. "
        "A recent valuation (September 2023) assessed the collateral at EUR 12 million, "
        "down from EUR 18 million at origination. This represents a loan-to-value ratio "
        "of 125% on the term loan, indicating collateral shortfall.\n\n"
        "The revolving facility is unsecured."
    )

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "6. Restructuring Plan", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "A restructuring plan was agreed with the borrower in March 2023. Key elements:\n"
        "- Cost reduction program targeting EUR 3m annual savings\n"
        "- Divestiture of non-core business unit (expected proceeds EUR 5-7m)\n"
        "- Capital expenditure deferral\n"
        "- Milestone review scheduled for Q4 2023\n\n"
        "The borrower is subject to an active restructuring plan and is being monitored "
        "on a quarterly basis by the workout team."
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "7. Past Due Status", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "The borrower was 45 days past due on the Q3 2023 instalment of Facility A "
        "before the payment was received on 14.11.2023. This constitutes a breach of "
        "the past due threshold for stage assessment purposes."
    )

    output_path = os.path.join(docs_dir, "npl_vermerk_sample.pdf")
    pdf.output(output_path)
    print(f"  Generated: {output_path}")


def _generate_facility_agreement(docs_dir):
    """Generate a mock facility agreement PDF."""
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "Facility Agreement", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 8, "Between: Muster Bank AG (Lender)", ln=True)
    pdf.cell(0, 8, "And: ABC Manufacturing GmbH (Borrower)", ln=True)
    pdf.cell(0, 8, "Date: 15.06.2020", ln=True)
    pdf.cell(0, 8, "As amended by Amendment No. 3 dated 15.03.2023", ln=True)
    pdf.ln(10)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Section 1: Definitions and Interpretation", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "1.1 'Facility A' means the term loan facility in an aggregate amount of "
        "EUR 15,000,000.\n"
        "1.2 'Facility B' means the revolving credit facility in an aggregate amount of "
        "EUR 10,000,000.\n"
        "1.3 'Maturity Date' means, in respect of Facility A, 31 December 2026 "
        "(as amended per Amendment No. 3).\n"
        "1.4 'Original Maturity Date' means 31 December 2024."
    )
    pdf.ln(5)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Section 5: Interest", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "5.1 The rate of interest on each loan under Facility A shall be EURIBOR plus "
        "the applicable margin.\n"
        "5.2 The Margin shall be 2.50% per annum.\n"
        "5.3 The interest rate has not been modified from the original terms of the "
        "agreement. The current effective rate remains within market parameters for "
        "comparable credit risk profiles."
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Section 8: Financial Covenants", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "8.1 Debt Service Coverage Ratio: The Borrower shall maintain a Debt Service "
        "Coverage Ratio of not less than 1.10x, tested quarterly.\n\n"
        "8.2 Leverage Ratio: The ratio of Total Net Debt to EBITDA shall not exceed 4.0x.\n\n"
        "8.3 Covenant Waiver: Pursuant to the waiver letter dated 01.10.2023, the Lender "
        "has agreed to waive the DSCR covenant test for Q3 2023 and Q4 2023, subject to "
        "the Borrower's compliance with the restructuring milestones.\n\n"
        "8.4 The Leverage Ratio covenant was tested at 5.2x as of Q3 2023, which represents "
        "a breach of the 4.0x threshold."
    )
    pdf.ln(5)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Amendment No. 3", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "This Amendment No. 3 to the Facility Agreement provides for:\n\n"
        "(a) An extension of the Maturity Date of Facility A from 31 December 2024 to "
        "31 December 2026 (an extension of 24 months).\n\n"
        "(b) The establishment of a bridge facility of EUR 5,000,000 to provide additional "
        "working capital support during the restructuring period.\n\n"
        "(c) A temporary waiver of the Debt Service Coverage Ratio covenant for the "
        "financial quarters ending 30 September 2023 and 31 December 2023.\n\n"
        "All other terms and conditions of the Facility Agreement remain unchanged."
    )

    output_path = os.path.join(docs_dir, "facility_agreement_sample.pdf")
    pdf.output(output_path)
    print(f"  Generated: {output_path}")


def _generate_financial_statement(docs_dir):
    """Generate a mock financial statement PDF."""
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "Financial Statements", ln=True)
    pdf.set_font("Helvetica", "B", 14)
    pdf.cell(0, 8, "ABC Manufacturing GmbH", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 8, "For the year ended 31 December 2023", ln=True)
    pdf.ln(10)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Income Statement (Summary)", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "Revenue:                EUR 78.5 million (2022: EUR 95.2 million)\n"
        "Cost of goods sold:     EUR 62.8 million (2022: EUR 71.4 million)\n"
        "Gross profit:           EUR 15.7 million (2022: EUR 23.8 million)\n"
        "Operating expenses:     EUR 12.3 million (2022: EUR 11.9 million)\n"
        "EBITDA:                 EUR 6.2 million (2022: EUR 14.5 million)\n"
        "Depreciation:           EUR 3.8 million (2022: EUR 3.5 million)\n"
        "EBIT:                   EUR 2.4 million (2022: EUR 11.0 million)\n"
        "Interest expense:       EUR 1.8 million (2022: EUR 1.5 million)\n"
        "Net income:             EUR 0.4 million (2022: EUR 7.1 million)"
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Cash Flow Statement (Summary)", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "Operating cash flow:    EUR 2.1 million (2022: EUR 10.8 million)\n"
        "Investing activities:   EUR (1.5) million\n"
        "Financing activities:   EUR 4.2 million\n\n"
        "Note: The debt service requirements for 2023 amounted to EUR 5.8 million "
        "(principal repayments EUR 3.0 million, interest EUR 2.8 million). The operating "
        "cash flow of EUR 2.1 million was insufficient to cover these obligations, "
        "resulting in a cash flow deficit of EUR 3.7 million."
    )
    pdf.ln(5)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Auditor's Report (Extract)", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "We have audited the financial statements of ABC Manufacturing GmbH for the year "
        "ended 31 December 2023.\n\n"
        "In our opinion, the financial statements give a true and fair view of the "
        "financial position of the company.\n\n"
        "Without qualifying our opinion, we draw attention to the significant uncertainties "
        "regarding the company's ability to continue as a going concern. The company is "
        "dependent on the successful implementation of the restructuring plan and continued "
        "support from its lending banks. These conditions indicate the existence of a "
        "material uncertainty that may cast significant doubt on the company's ability to "
        "continue as a going concern."
    )
    pdf.ln(5)

    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 8, "Key Financial Ratios", ln=True)
    pdf.set_font("Helvetica", "", 10)
    pdf.multi_cell(0, 6,
        "Debt Service Coverage Ratio:  0.36x (2022: 1.86x)\n"
        "Net Debt / EBITDA:            5.2x (2022: 2.1x)\n"
        "Current Ratio:                0.85 (2022: 1.35)\n"
        "Interest Coverage Ratio:      1.33x (2022: 7.33x)\n\n"
        "The DSCR of 0.36x is significantly below the covenant threshold of 1.10x "
        "and indicates severe constraints on the borrower's ability to service its debt."
    )

    output_path = os.path.join(docs_dir, "financial_statement_sample.pdf")
    pdf.output(output_path)
    print(f"  Generated: {output_path}")


def main():
    print("Generating test data...")
    generate_sample_excel()
    generate_sample_pdfs()
    print("Done!")


if __name__ == "__main__":
    main()
