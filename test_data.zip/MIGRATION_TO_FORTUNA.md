# Forbearance Skill — Migration to Fortuna

Step-by-step guide for integrating the standalone forbearance-skill prototype into the Fortuna codebase.

**Estimated effort:** 2-3 days backend, 2-3 days frontend

---

## Architecture Overview

```
STANDALONE (current)                    FORTUNA (target)
========================               ========================
forbearance-skill/                     Fortuna_Azure/backend/
  nodes/              ──copy──>          src/forbearance/nodes/
  flow/               ──copy──>          src/forbearance/flow/
  skill/              ──copy──>          src/forbearance/skill/
  utils/llm.py        ──replace──>       (adapter wrapping llm_wrapper.py)
  utils/events.py     ──copy──>          src/forbearance/utils/events.py
  utils/config.py     ──merge──>         config/config.py (add forbearance section)
  main.py             ──drop──>          (replaced by router endpoint)
  api/server.py       ──replace──>       api/routers/forbearance_check.py
  embed_documents.py  ──adapt──>         (skip node; Fortuna ETL already embeds)

forbearance-skill/                     Fortuna_Azure/frontend/
  test_frontend/      ──replace──>       src/app/(main)/modules/forbearance-check/
```

---

## Step 1: Copy the Forbearance Module into Fortuna Backend

Create the directory structure inside Fortuna:

```
backend/src/forbearance/
  __init__.py
  nodes/
    __init__.py
    plan_search.py          # copy from nodes/
    execute_search.py       # copy, adapt ChromaDB access
    assess_results.py       # copy as-is
    refine_search.py        # copy as-is
    evaluate_evidence.py    # copy as-is
    classify_stage.py       # copy as-is
    finalize_trigger.py     # copy as-is
    synthesize_findings.py  # copy as-is
    reevaluate_inconclusive.py  # copy as-is
    parse_excel.py          # copy as-is
    embed_documents.py      # copy, add skip-if-fortuna mode
    generate_report.py      # copy as-is
  flow/
    __init__.py
    forbearance_flow.py     # copy as-is
  skill/
    triggers/
      excel_parser.py       # copy as-is
    scripts/
      chromadb_search.py    # copy, adapt to use Fortuna's connection_manager
      chunk_documents.py    # copy as-is (used only in standalone mode)
      generate_report.py    # copy as-is
    prompts/                # copy all .md files as-is
  utils/
    __init__.py
    events.py               # copy as-is
    console_logger.py       # copy as-is
```

Files you do NOT copy:
- `main.py` — replaced by the Fortuna router
- `api/server.py`, `api/websocket.py` — replaced by Fortuna's FastAPI app
- `utils/config.py` — merged into Fortuna's config
- `utils/llm.py` — replaced by adapter (Step 2)
- `test_frontend/` — replaced by Next.js module (Step 7)
- `test_data/` — not needed in production

### Import path updates

After copying, do a find-and-replace across all copied Python files:

| Old import prefix | New import prefix |
|---|---|
| `from nodes.` | `from src.forbearance.nodes.` |
| `from flow.` | `from src.forbearance.flow.` |
| `from utils.events` | `from src.forbearance.utils.events` |
| `from utils.console_logger` | `from src.forbearance.utils.console_logger` |
| `from utils.config` | `from config.config` (Fortuna's config) |
| `from utils.llm` | `from src.forbearance.utils.llm_adapter` |
| `from skill.` | `from src.forbearance.skill.` |
| `from pocketflow` | `from pocketflow` (no change, add to requirements) |

---

## Step 2: Create the LLM Adapter

The prototype uses `LLMInterface` (ABC) with `MockLLM`. In Fortuna, swap this for an adapter wrapping Fortuna's existing LLM infrastructure.

Create `backend/src/forbearance/utils/llm_adapter.py`:

```python
"""LLM adapter bridging forbearance skill to Fortuna's LLM infrastructure."""

import json
from src.utils.llm_connection_manager import LLMConnectionManager


class FortunaLLMAdapter:
    """
    Implements the same interface as the prototype's LLMInterface,
    but delegates to Fortuna's LLM connection manager.
    """

    def __init__(self, connection_manager: LLMConnectionManager = None):
        self._manager = connection_manager or LLMConnectionManager()

    def call(self, prompt: str, system_prompt: str = "",
             temperature: float = 0.1, json_mode: bool = False) -> str:
        """Send a prompt and get a response string."""
        # Use Fortuna's LLM wrapper
        connection = self._manager.get_connection()

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        # Adapt to whatever Fortuna's llm_wrapper exposes
        # This will depend on the exact API of llm_wrapper.py
        response = connection.invoke(
            messages=messages,
            temperature=temperature,
            response_format={"type": "json_object"} if json_mode else None,
        )

        # Extract text from response (adapt to Fortuna's return format)
        if hasattr(response, 'content'):
            return response.content
        return str(response)

    def call_structured(self, prompt: str, system_prompt: str = "",
                        temperature: float = 0.1) -> dict:
        """Send a prompt and get a parsed JSON dict back."""
        response = self.call(prompt, system_prompt, temperature, json_mode=True)
        try:
            return json.loads(response)
        except (json.JSONDecodeError, TypeError):
            return {"status": "NOT_FOUND", "confidence": 0.5,
                    "reasoning": "Failed to parse LLM response",
                    "validated_value": "Error"}
```

**Important**: The exact method names on Fortuna's `LLMConnectionManager` and its connection object may differ from what's shown above. You'll need to read `backend/src/utils/llm_wrapper.py` and `llm_connection_manager.py` to get the exact signatures. The key pattern is:
- Fortuna's LLM uses LangChain (`langchain-openai`), so the connection likely has `.invoke()` returning an `AIMessage` with `.content`
- If Fortuna uses `ChatOpenAI` from `langchain_openai`, the call pattern is `llm.invoke(messages)`

---

## Step 3: Adapt ChromaDB Access

The prototype creates its own ChromaDB client in `chromadb_search.py`. In Fortuna, use the existing `connection_manager.py`.

Edit the copied `backend/src/forbearance/skill/scripts/chromadb_search.py`:

```python
"""ChromaDB query utility — adapted for Fortuna's connection manager."""

# CHANGE: Instead of creating our own client, accept one from outside
# The get_chroma_client function now optionally accepts Fortuna's client

def get_chroma_client(persist_dir: str = None, fortuna_client=None):
    """Get ChromaDB client. Uses Fortuna's client if provided."""
    if fortuna_client is not None:
        return fortuna_client
    # Fallback to standalone mode
    import chromadb
    return chromadb.PersistentClient(path=persist_dir or "./chroma_db")
```

In the shared store setup (Step 5), pass Fortuna's ChromaDB client:

```python
from src.etl.db.chromaDB.connection_manager import ChromaDBConnectionManager

chroma_manager = ChromaDBConnectionManager()
shared["chroma_client"] = chroma_manager.get_client()
```

Then update `ExecuteSearchNode.prep()` and `EmbedDocumentsNode.prep()` to use `shared.get("chroma_client")` instead of creating a new client:

```python
# In execute_search.py prep():
client = shared.get("chroma_client") or get_chroma_client(config.chroma_persist_dir)
```

This change is backward-compatible — standalone mode still works.

---

## Step 4: Handle Document Embedding (Skip in Fortuna)

Fortuna's ETL pipeline already extracts, chunks, and embeds documents into ChromaDB. The `EmbedDocumentsNode` should detect this and skip.

The node already has skip logic (`collection_exists` check). For Fortuna, the collection name must match what Fortuna's ETL creates. Check Fortuna's collection naming convention in `backend/src/etl/db/chromaDB/create_chromadb.py` and set:

```python
# In shared store setup, use Fortuna's collection name
shared["chroma_collection"] = f"fortuna_{debtor_id}"  # Match Fortuna's naming
```

If Fortuna uses a different naming scheme (check `create_chromadb.py`), adjust accordingly. The `EmbedDocumentsNode` will find the collection already exists and skip embedding.

**Alternative (cleaner)**: Create a new flow variant that skips `EmbedDocumentsNode` entirely:

```python
def create_fortuna_forbearance_flow() -> Flow:
    """Flow variant for Fortuna — skips embedding (ETL already done)."""
    parse_excel = ParseExcelNode(max_retries=2, wait=1)
    # Skip EmbedDocumentsNode — go straight to trigger batch
    trigger_batch = TriggerBatchFlow()
    synthesize = SynthesizeFindingsNode(max_retries=2, wait=1)
    reevaluate = ReevaluateInconclusiveNode(max_retries=2, wait=1)
    generate_report = GenerateReportNode(max_retries=1)

    parse_excel >> trigger_batch >> synthesize
    synthesize - "reevaluate" >> reevaluate >> generate_report
    synthesize - "default" >> generate_report

    return Flow(start=parse_excel)
```

Pre-populate `shared["chroma_collection"]` and `shared["document_metadata"]` from Fortuna's RDBMS before running the flow.

---

## Step 5: Add Fortuna Configuration

Add forbearance settings to Fortuna's config. Edit `backend/config/config.py`:

```python
# Add to existing Config class or create a new section

class ForbearanceConfig:
    """Configuration for forbearance checking skill."""
    # Search settings
    max_chunks_per_query: int = 5
    max_chunks_per_trigger: int = 10
    num_search_queries: int = 5
    chunk_size: int = 1000
    chunk_overlap: int = 200

    # Assessment thresholds
    min_relevance_score: float = 0.35
    min_chunks_above_threshold: int = 2
    relevance_threshold: float = 0.25

    # Output
    output_dir: str = "./output/forbearance"
```

---

## Step 6: Create the Forbearance Router

Create `backend/api/routers/forbearance_check.py`:

```python
"""FastAPI router for forbearance checking."""

import uuid
import os
import threading
from fastapi import APIRouter, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse

from src.forbearance.flow.forbearance_flow import create_forbearance_flow
from src.forbearance.utils.events import EventEmitter
from src.forbearance.utils.console_logger import console_subscriber
from src.forbearance.utils.llm_adapter import FortunaLLMAdapter
from src.utils.llm_connection_manager import LLMConnectionManager
from src.etl.db.chromaDB.connection_manager import ChromaDBConnectionManager
from src.etl.db.rdbms.debtor_manager import DebtorManager
from src.etl.db.rdbms.input_doc_manager import InputDocManager
from config.config import ForbearanceConfig

router = APIRouter(prefix="/api/forbearance", tags=["forbearance"])

# In-memory store of active/completed runs
runs: dict = {}


@router.post("/run")
async def start_forbearance_check(
    excel_file: UploadFile = File(...),
    sheet_type: str = Form("corporate"),
    debtor_id: str = Form(...),
    reference_year: int = Form(2023),
):
    """Start a forbearance check run for a debtor."""
    run_id = str(uuid.uuid4())[:8]
    config = ForbearanceConfig()

    # Save uploaded Excel
    upload_dir = os.path.join(config.output_dir, "uploads", run_id)
    os.makedirs(upload_dir, exist_ok=True)
    excel_path = os.path.join(upload_dir, excel_file.filename)
    with open(excel_path, "wb") as f:
        f.write(await excel_file.read())

    # Get Fortuna infrastructure
    llm_adapter = FortunaLLMAdapter(LLMConnectionManager())
    chroma_client = ChromaDBConnectionManager().get_client()

    # Get document metadata from Fortuna's RDBMS
    doc_manager = InputDocManager()
    docs = doc_manager.get_documents(debtor_id, reference_year)
    doc_metadata = [{"filename": d.filename, "pages": d.pages, "doc_type": d.doc_type}
                    for d in docs]

    # Determine ChromaDB collection name (match Fortuna's naming)
    # CHECK: Verify this matches what Fortuna's ETL creates
    collection_name = f"fortuna_{debtor_id}"

    emitter = EventEmitter()
    emitter.subscribe(console_subscriber)

    shared = {
        "excel_path": excel_path,
        "sheet_type": sheet_type,
        "documents_dir": "",  # Not used — Fortuna ETL already embedded
        "debtor_id": debtor_id,
        "reference_year": reference_year,
        "emitter": emitter,
        "event_log": [],
        "config": config,
        "llm": llm_adapter,
        "chroma_client": chroma_client,
        "chroma_collection": collection_name,
        "document_metadata": doc_metadata,
    }

    runs[run_id] = {"status": "running", "shared": shared, "emitter": emitter}

    def execute():
        try:
            emitter.emit("flow_started")
            flow = create_forbearance_flow()
            flow.run(shared)
            runs[run_id]["status"] = "completed"
            emitter.emit("flow_completed")
        except Exception as e:
            runs[run_id]["status"] = "error"
            emitter.emit("flow_error", error=str(e))

    thread = threading.Thread(target=execute, daemon=True)
    thread.start()

    return {"run_id": run_id, "status": "started"}


@router.get("/runs/{run_id}/status")
async def get_run_status(run_id: str):
    """Get current status of a forbearance run."""
    run = runs.get(run_id)
    if not run:
        return JSONResponse(status_code=404, content={"error": "Run not found"})

    results = run["shared"].get("results", [])
    total = len(run["shared"].get("triggers", []))
    completed = len(results)

    return {
        "run_id": run_id,
        "status": run["status"],
        "progress": {"completed": completed, "total": total},
    }


@router.get("/runs/{run_id}/events")
async def get_run_events(run_id: str, since: float = 0):
    """Get events since a timestamp (for polling)."""
    run = runs.get(run_id)
    if not run:
        return JSONResponse(status_code=404, content={"error": "Run not found"})

    events = run["emitter"].get_events_since(since)
    return {"events": events}


@router.get("/runs/{run_id}/results")
async def get_run_results(run_id: str):
    """Get final results of a completed run."""
    run = runs.get(run_id)
    if not run:
        return JSONResponse(status_code=404, content={"error": "Run not found"})

    return {
        "status": run["status"],
        "results": run["shared"].get("results", []),
        "report": run["shared"].get("report", {}),
        "synthesis": run["shared"].get("synthesis", {}),
    }


@router.get("/runs/{run_id}/report")
async def download_report(run_id: str, format: str = "excel"):
    """Download the generated report."""
    run = runs.get(run_id)
    if not run:
        return JSONResponse(status_code=404, content={"error": "Run not found"})

    report = run["shared"].get("report", {})
    if format == "excel":
        path = report.get("excel_output_path")
    else:
        path = report.get("json_output_path")

    if not path or not os.path.exists(path):
        return JSONResponse(status_code=404, content={"error": "Report not ready"})

    return FileResponse(path)
```

### Register the router in Fortuna's main app

Edit `backend/api/main.py`:

```python
from api.routers.forbearance_check import router as forbearance_router

# After existing router includes:
app.include_router(forbearance_router)
```

---

## Step 7: Add Frontend Module

Create the forbearance check page in Fortuna's Next.js frontend.

### 7a. Add sidebar navigation entry

Edit `frontend/src/ui/navbar.tsx` (or `Sidebar.tsx`) to add:

```typescript
{
  label: "Forbearance Check",
  icon: <SecurityIcon />,  // or appropriate MUI icon
  href: "/modules/forbearance-check",
}
```

### 7b. Create the page

Create `frontend/src/app/(main)/modules/forbearance-check/page.tsx`:

```typescript
"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Box, Typography, Button, TextField, MenuItem,
  LinearProgress, Paper, Chip, Collapse, IconButton,
} from "@mui/material";
import {
  ExpandMore as ExpandMoreIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Help as HelpIcon,
  HourglassEmpty as PendingIcon,
  Search as SearchIcon,
  Download as DownloadIcon,
} from "@mui/icons-material";
import PageHeader from "@/components/PageHeader";
import CircularLoader from "@/ui/circularLoader";
import AlertBox from "@/ui/alert";
import { backend_url } from "@/config";

interface TriggerResult {
  trigger_id: string;
  status: "FOUND" | "NOT_FOUND" | "INCONCLUSIVE";
  confidence: number;
  stage_classification: string;
  comment: string;
  evidence: Array<{ text: string; document: string; page: number }>;
  reasoning: string;
  search_queries: string[];
  search_attempts: number;
}

interface RunProgress {
  completed: number;
  total: number;
}

export default function ForbearanceCheckPage() {
  const [loading, setLoading] = useState(false);
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [sheetType, setSheetType] = useState("corporate");
  const [runId, setRunId] = useState<string | null>(null);
  const [progress, setProgress] = useState<RunProgress>({ completed: 0, total: 0 });
  const [results, setResults] = useState<TriggerResult[]>([]);
  const [expandedTrigger, setExpandedTrigger] = useState<string | null>(null);
  const [synthesis, setSynthesis] = useState<any>(null);
  const [runStatus, setRunStatus] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch current debtor on mount
  useEffect(() => {
    const fetchDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
        }
      } catch (error) {
        console.error("Error fetching debtor:", error);
      }
    };
    fetchDebtor();
  }, []);

  // Poll for progress when a run is active
  useEffect(() => {
    if (!runId || runStatus === "completed" || runStatus === "error") return;

    const interval = setInterval(async () => {
      try {
        const statusRes = await fetch(
          `${backend_url}/api/forbearance/runs/${runId}/status`
        );
        const statusData = await statusRes.json();

        setProgress(statusData.progress || { completed: 0, total: 0 });
        setRunStatus(statusData.status);

        if (statusData.status === "completed") {
          // Fetch final results
          const resultsRes = await fetch(
            `${backend_url}/api/forbearance/runs/${runId}/results`
          );
          const resultsData = await resultsRes.json();
          setResults(resultsData.results || []);
          setSynthesis(resultsData.synthesis || null);
          setLoading(false);
          clearInterval(interval);
        } else if (statusData.status === "error") {
          setAlertMessage("Forbearance check failed. Check server logs.");
          setLoading(false);
          clearInterval(interval);
        }
      } catch (error) {
        console.error("Polling error:", error);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [runId, runStatus]);

  const handleStartCheck = async () => {
    if (!fileInputRef.current?.files?.length) {
      setAlertMessage("Please select a triggers Excel file");
      return;
    }

    const formData = new FormData();
    formData.append("excel_file", fileInputRef.current.files[0]);
    formData.append("sheet_type", sheetType);
    formData.append("debtor_id", currentDebtor || "unknown");
    formData.append("reference_year", "2023");

    setLoading(true);
    setResults([]);
    setSynthesis(null);

    try {
      const response = await fetch(`${backend_url}/api/forbearance/run`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) throw new Error("Failed to start forbearance check");

      const data = await response.json();
      setRunId(data.run_id);
      setRunStatus("running");
    } catch (error) {
      setAlertMessage((error as Error).message);
      setLoading(false);
    }
  };

  const handleDownload = async (format: string) => {
    if (!runId) return;
    window.open(
      `${backend_url}/api/forbearance/runs/${runId}/report?format=${format}`,
      "_blank"
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "FOUND": return <WarningIcon sx={{ color: "#ED8B00" }} />;
      case "NOT_FOUND": return <CheckCircleIcon sx={{ color: "#26890D" }} />;
      case "INCONCLUSIVE": return <HelpIcon sx={{ color: "#53565A" }} />;
      default: return <PendingIcon sx={{ color: "#D0D0CE" }} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "FOUND": return { bg: "rgba(237, 139, 0, 0.1)", text: "#ED8B00" };
      case "NOT_FOUND": return { bg: "rgba(38, 137, 13, 0.1)", text: "#26890D" };
      case "INCONCLUSIVE": return { bg: "rgba(83, 86, 90, 0.1)", text: "#53565A" };
      default: return { bg: "#F5F5F5", text: "#999" };
    }
  };

  return (
    <Box sx={{ padding: "24px 32px", minHeight: "calc(100vh - 48px)", bgcolor: "#F5F7F9" }}>
      <PageHeader
        title="Forbearance Check"
        subtitle="Analyze ECB forbearance triggers against credit file documents"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Controls */}
      <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }}>
        <Box sx={{ display: "flex", gap: 2, alignItems: "flex-end", flexWrap: "wrap" }}>
          <Box>
            <Typography variant="body2" sx={{ mb: 0.5, fontWeight: 600 }}>
              Triggers Excel
            </Typography>
            <input
              type="file"
              accept=".xlsx,.xls"
              ref={fileInputRef}
              style={{ fontSize: "0.875rem" }}
            />
          </Box>
          <TextField
            select
            size="small"
            label="Sheet Type"
            value={sheetType}
            onChange={(e) => setSheetType(e.target.value)}
            sx={{ minWidth: 160 }}
          >
            <MenuItem value="corporate">Corporate</MenuItem>
            <MenuItem value="retail">Retail</MenuItem>
          </TextField>
          <Button
            variant="contained"
            onClick={handleStartCheck}
            disabled={loading}
            startIcon={<SearchIcon />}
            sx={{
              bgcolor: "#26890D",
              "&:hover": { bgcolor: "#1a5f0a" },
              textTransform: "none",
            }}
          >
            Run Forbearance Check
          </Button>
        </Box>
      </Paper>

      {/* Progress */}
      {loading && (
        <Paper sx={{ p: 2, mb: 3, borderRadius: 2 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1 }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              Analyzing triggers...
            </Typography>
            <Typography variant="body2" color="textSecondary">
              {progress.completed} / {progress.total}
            </Typography>
          </Box>
          <LinearProgress
            variant="determinate"
            value={progress.total ? (progress.completed / progress.total) * 100 : 0}
            sx={{
              height: 8, borderRadius: 4,
              bgcolor: "rgba(38, 137, 13, 0.1)",
              "& .MuiLinearProgress-bar": { bgcolor: "#26890D", borderRadius: 4 },
            }}
          />
        </Paper>
      )}

      {/* Synthesis Summary */}
      {synthesis && (
        <Paper sx={{ p: 3, mb: 3, borderRadius: 2, border: "1px solid rgba(0,0,0,0.08)" }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
            Cross-Trigger Analysis
          </Typography>
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Chip
              label={`Risk: ${(synthesis.overall_risk || "").toUpperCase()}`}
              sx={{
                fontWeight: 600,
                bgcolor: synthesis.overall_risk === "high"
                  ? "rgba(237, 139, 0, 0.15)" : "rgba(38, 137, 13, 0.1)",
                color: synthesis.overall_risk === "high" ? "#ED8B00" : "#26890D",
              }}
            />
            <Chip
              label={`Forbearance: ${synthesis.forbearance_confirmed ? "CONFIRMED" : "Not confirmed"}`}
              sx={{
                fontWeight: 600,
                bgcolor: synthesis.forbearance_confirmed
                  ? "rgba(237, 139, 0, 0.15)" : "rgba(38, 137, 13, 0.1)",
                color: synthesis.forbearance_confirmed ? "#ED8B00" : "#26890D",
              }}
            />
          </Box>
          {synthesis.risk_narrative && (
            <Typography variant="body2" sx={{ mt: 1.5, color: "#53565A" }}>
              {synthesis.risk_narrative}
            </Typography>
          )}
        </Paper>
      )}

      {/* Results Summary Bar */}
      {results.length > 0 && (
        <Box sx={{ display: "flex", gap: 2, mb: 2, alignItems: "center" }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            {results.length} Triggers
          </Typography>
          <Chip
            size="small"
            label={`${results.filter(r => r.status === "FOUND").length} Found`}
            sx={{ bgcolor: "rgba(237, 139, 0, 0.15)", color: "#ED8B00" }}
          />
          <Chip
            size="small"
            label={`${results.filter(r => r.status === "NOT_FOUND").length} Not Found`}
            sx={{ bgcolor: "rgba(38, 137, 13, 0.1)", color: "#26890D" }}
          />
          <Chip
            size="small"
            label={`${results.filter(r => r.status === "INCONCLUSIVE").length} Inconclusive`}
            sx={{ bgcolor: "rgba(83, 86, 90, 0.1)", color: "#53565A" }}
          />
          <Box sx={{ flex: 1 }} />
          <Button
            size="small"
            startIcon={<DownloadIcon />}
            onClick={() => handleDownload("excel")}
            sx={{ textTransform: "none", color: "#26890D" }}
          >
            Excel Report
          </Button>
          <Button
            size="small"
            startIcon={<DownloadIcon />}
            onClick={() => handleDownload("json")}
            sx={{ textTransform: "none", color: "#53565A" }}
          >
            JSON
          </Button>
        </Box>
      )}

      {/* Trigger Results List */}
      {results.map((result, idx) => {
        const colors = getStatusColor(result.status);
        const isExpanded = expandedTrigger === result.trigger_id;

        return (
          <Paper
            key={result.trigger_id}
            sx={{
              mb: 1.5, borderRadius: 2, overflow: "hidden",
              border: `1px solid ${result.status === "FOUND" ? "rgba(237,139,0,0.3)" : "rgba(0,0,0,0.08)"}`,
            }}
          >
            {/* Trigger Header */}
            <Box
              sx={{
                display: "flex", alignItems: "center", gap: 1.5, p: 2,
                cursor: "pointer", "&:hover": { bgcolor: "rgba(0,0,0,0.02)" },
              }}
              onClick={() => setExpandedTrigger(isExpanded ? null : result.trigger_id)}
            >
              <Typography variant="body2" sx={{ color: "#999", minWidth: 32 }}>
                {idx + 1}.
              </Typography>
              {getStatusIcon(result.status)}
              <Box sx={{ flex: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {result.trigger_id}
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {result.comment?.substring(0, 100)}
                  {result.comment?.length > 100 ? "..." : ""}
                </Typography>
              </Box>
              <Chip
                size="small"
                label={result.status}
                sx={{ bgcolor: colors.bg, color: colors.text, fontWeight: 600 }}
              />
              {result.stage_classification && result.stage_classification !== "Not a trigger" && (
                <Chip
                  size="small"
                  label={result.stage_classification}
                  variant="outlined"
                  sx={{ fontWeight: 600 }}
                />
              )}
              <Typography variant="caption" color="textSecondary">
                {result.confidence ? `${Math.round(result.confidence * 100)}%` : ""}
              </Typography>
              <IconButton size="small">
                <ExpandMoreIcon
                  sx={{
                    transform: isExpanded ? "rotate(180deg)" : "rotate(0deg)",
                    transition: "transform 0.2s",
                  }}
                />
              </IconButton>
            </Box>

            {/* Expanded Detail */}
            <Collapse in={isExpanded}>
              <Box sx={{ px: 3, pb: 2, borderTop: "1px solid rgba(0,0,0,0.06)" }}>
                {/* Reasoning */}
                <Typography variant="subtitle2" sx={{ mt: 2, mb: 0.5, fontWeight: 700 }}>
                  Reasoning
                </Typography>
                <Typography variant="body2" sx={{ color: "#53565A", whiteSpace: "pre-line" }}>
                  {result.reasoning}
                </Typography>

                {/* Evidence */}
                {result.evidence?.length > 0 && (
                  <>
                    <Typography variant="subtitle2" sx={{ mt: 2, mb: 0.5, fontWeight: 700 }}>
                      Evidence ({result.evidence.length} sources)
                    </Typography>
                    {result.evidence.map((ev, i) => (
                      <Paper
                        key={i}
                        variant="outlined"
                        sx={{ p: 1.5, mb: 1, bgcolor: "#FAFAFA", borderRadius: 1 }}
                      >
                        <Typography variant="caption" sx={{ color: "#26890D", fontWeight: 600 }}>
                          {ev.document} p.{ev.page}
                        </Typography>
                        <Typography variant="body2" sx={{ mt: 0.5, fontSize: "0.8rem" }}>
                          {ev.text?.substring(0, 300)}
                          {ev.text?.length > 300 ? "..." : ""}
                        </Typography>
                      </Paper>
                    ))}
                  </>
                )}

                {/* Search Info */}
                <Typography variant="caption" color="textSecondary" sx={{ display: "block", mt: 1 }}>
                  Search: {result.search_queries?.length || 0} queries,{" "}
                  {result.search_attempts || 1} round(s)
                </Typography>
              </Box>
            </Collapse>
          </Paper>
        );
      })}

      {alertMessage && <AlertBox message={alertMessage} severity="error" />}
    </Box>
  );
}
```

---

## Step 8: Add PocketFlow Dependency

Add `pocketflow` to Fortuna's requirements:

```
# In backend/requirements_files/requirements.txt, add:
pocketflow>=0.0.2
```

PocketFlow is a minimal ~100-line framework with no transitive dependencies. It will not conflict with LangChain/LangGraph.

---

## Step 9: Verify the Integration

### 9a. Backend smoke test

```bash
cd backend
python -c "
from src.forbearance.flow.forbearance_flow import create_forbearance_flow
flow = create_forbearance_flow()
print('Flow created successfully')
print('Start node:', flow.start.__class__.__name__)
"
```

### 9b. API test

Start Fortuna's backend, then:

```bash
curl -X POST http://localhost:8080/api/forbearance/run \
  -F "excel_file=@path/to/triggers.xlsx" \
  -F "sheet_type=corporate" \
  -F "debtor_id=1234567" \
  -F "reference_year=2023"
```

### 9c. Frontend test

Start Fortuna's frontend, navigate to `/modules/forbearance-check`, upload the triggers Excel, and verify:
- Progress bar updates every 2 seconds
- Triggers appear in the list as they complete
- Expanding a trigger shows reasoning + evidence
- Download buttons produce Excel and JSON reports

---

## Integration Checklist

| # | Task | Status |
|---|---|---|
| 1 | Copy forbearance module to `backend/src/forbearance/` | |
| 2 | Update all import paths | |
| 3 | Create `FortunaLLMAdapter` wrapping `llm_wrapper.py` | |
| 4 | Adapt `chromadb_search.py` to accept Fortuna's client | |
| 5 | Verify ChromaDB collection naming matches Fortuna's ETL | |
| 6 | Add `ForbearanceConfig` to Fortuna's config | |
| 7 | Create `forbearance_check.py` router | |
| 8 | Register router in `api/main.py` | |
| 9 | Add `pocketflow` to requirements.txt | |
| 10 | Add sidebar nav entry for "Forbearance Check" | |
| 11 | Create `forbearance-check/page.tsx` frontend module | |
| 12 | Backend smoke test | |
| 13 | E2E test with real debtor data | |

---

## Key Risks and Mitigations

### Risk 1: ChromaDB collection naming mismatch
The prototype uses `forbearance_{debtor_id}` as the collection name. Fortuna's ETL may use a different convention. **Mitigation**: Check `backend/src/etl/db/chromaDB/create_chromadb.py` before integration and align the naming.

### Risk 2: LLM response format differences
The prototype expects plain string responses from `llm.call()`. Azure OpenAI via LangChain returns `AIMessage` objects. **Mitigation**: The `FortunaLLMAdapter` handles this conversion. Test with a few sample prompts before running the full flow.

### Risk 3: Fortuna's LLM may not support json_mode
The prototype uses `json_mode=True` for structured responses. If Fortuna's GPT-4o deployment doesn't support `response_format`, the adapter should strip this parameter. **Mitigation**: The `call_structured()` method has a JSON parse fallback.

### Risk 4: Document embedding quality differences
Fortuna's ETL uses different chunking (potentially table-aware chunking via `table_chunker_class.py`). This may affect retrieval quality. **Mitigation**: The iterative search refinement handles low-quality initial results. Test with real documents and tune `AssessResultsNode` thresholds if needed.

### Risk 5: PocketFlow vs LangGraph coexistence
Fortuna uses LangGraph for existing agents. The forbearance skill uses PocketFlow. These are independent — they don't share state or conflict. **Mitigation**: PocketFlow is a ~100-line module with no dependencies. It can coexist with LangGraph.

---

## What Stays Standalone

These components are NOT needed in Fortuna and should remain in the standalone prototype:

- `test_data/` — test fixtures (generate.py, sample documents)
- `test_frontend/index.html` — replaced by Next.js module
- `tests/` — prototype-specific tests
- `utils/llm.py` MockLLM — only for standalone testing
- `main.py` — CLI entry point for standalone mode

The standalone prototype remains fully functional for development and demos independent of Fortuna.
