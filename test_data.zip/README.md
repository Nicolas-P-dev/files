# Forbearance Check Skill

AI-powered forbearance checking for ECB credit file reviews. Analyzes debtor documents for signs of forbearance measures granted to borrowers in financial difficulty.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Generate test data (run once)
python -m test_data.generate

# Run CLI mode (console output)
python main.py --mode cli --excel test_data/sample_triggers.xlsx --docs test_data/sample_documents/

# Run server mode (FastAPI + WebSocket + test frontend)
python main.py --mode server
# Then open http://localhost:8000/test in browser
```

## Architecture

Uses PocketFlow for workflow orchestration:

```
ParseExcel -> EmbedDocuments -> EvaluateTriggerBatch -> GenerateReport
```

- **ParseExcelNode**: Reads ECB triggers checklist, cross-references with master trigger list
- **EmbedDocumentsNode**: Extracts PDF text, chunks, stores in ChromaDB
- **EvaluateTriggerBatch**: For each trigger: generate search queries -> search ChromaDB -> evaluate evidence -> classify stage
- **GenerateReportNode**: Produces Excel + JSON reports

## Key Design Decisions

- **Excel IS the configuration** — no hardcoded triggers. Update the Excel, agent behavior changes.
- **Mock LLM** for standalone development — swap to Azure OpenAI via `LLM_PROVIDER=azure` env var.
- **Full event observability** — every agent action emits events for real-time frontend visualization.
- **Abstract interfaces** — LLM and ChromaDB access are behind interfaces for easy Fortuna integration.

## Project Structure

```
nodes/              PocketFlow node implementations
flow/               Flow wiring
skill/              Skill package (prompts, parsers, scripts)
utils/              Config, events, LLM interface
api/                FastAPI server + WebSocket
test_frontend/      Single-file test UI
test_data/          Generated test fixtures
tests/              Unit tests
```

## Running Tests

```bash
pip install pytest
python -m pytest tests/ -v
```
