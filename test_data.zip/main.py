"""Entry point for the Forbearance Check Skill — CLI and server modes."""

import argparse
import os
import sys
import shutil

from utils.config import Config
from utils.events import EventEmitter
from utils.console_logger import console_subscriber
from utils.llm import MockLLM
from flow.forbearance_flow import create_forbearance_flow


def run_cli(excel_path: str, docs_dir: str, sheet_type: str = "corporate"):
    """Run forbearance check in CLI mode with console output."""
    config = Config.from_env()
    emitter = EventEmitter()
    emitter.subscribe(console_subscriber)

    llm = MockLLM()

    # Clean up any existing ChromaDB data for fresh run
    if os.path.exists(config.chroma_persist_dir):
        shutil.rmtree(config.chroma_persist_dir, ignore_errors=True)

    shared = {
        "excel_path": excel_path,
        "sheet_type": sheet_type,
        "documents_dir": docs_dir,
        "debtor_id": "cli_run",
        "reference_year": 2023,
        "emitter": emitter,
        "event_log": [],
        "config": config,
        "llm": llm,
    }

    print("=" * 60)
    print("  Forbearance Check Skill — CLI Mode")
    print("=" * 60)
    print(f"  Excel: {excel_path}")
    print(f"  Documents: {docs_dir}")
    print(f"  Sheet type: {sheet_type}")
    print("=" * 60)

    emitter.emit("flow_started")

    try:
        flow = create_forbearance_flow()
        flow.run(shared)
        emitter.emit("flow_completed")
    except Exception as e:
        emitter.emit("flow_error", error=str(e))
        print(f"\nFATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1

    # Print final summary
    report = shared.get("report", {})
    summary = report.get("summary", {})

    print("\n" + "=" * 60)
    print("  RESULTS SUMMARY")
    print("=" * 60)
    print(f"  Total triggers:  {summary.get('total_triggers', 0)}")
    print(f"  FOUND:           {summary.get('found', 0)}")
    print(f"  NOT FOUND:       {summary.get('not_found', 0)}")
    print(f"  INCONCLUSIVE:    {summary.get('inconclusive', 0)}")
    print(f"  S2 triggers:     {summary.get('s2_triggers', 0)}")
    print(f"  S3 triggers:     {summary.get('s3_triggers', 0)}")
    print("-" * 60)
    print(f"  Excel report:    {report.get('excel_output_path', 'N/A')}")
    print(f"  JSON report:     {report.get('json_output_path', 'N/A')}")
    print("=" * 60)

    return 0


def run_server(host: str = "0.0.0.0", port: int = 8000):
    """Run the FastAPI server."""
    import uvicorn
    from api.server import app

    print("=" * 60)
    print("  Forbearance Check Skill — Server Mode")
    print(f"  http://{host}:{port}")
    print(f"  Test frontend: http://localhost:{port}/test")
    print("=" * 60)

    uvicorn.run(app, host=host, port=port)


def main():
    parser = argparse.ArgumentParser(description="Forbearance Check Skill")
    parser.add_argument(
        "--mode",
        choices=["cli", "server"],
        default="cli",
        help="Run mode: 'cli' for console output, 'server' for FastAPI",
    )
    parser.add_argument(
        "--excel",
        default="test_data/sample_triggers.xlsx",
        help="Path to triggers Excel file (CLI mode)",
    )
    parser.add_argument(
        "--docs",
        default="test_data/sample_documents/",
        help="Path to documents directory (CLI mode)",
    )
    parser.add_argument(
        "--sheet-type",
        default="corporate",
        choices=["corporate", "retail"],
        help="Sheet type to evaluate",
    )
    parser.add_argument("--host", default="0.0.0.0", help="Server host")
    parser.add_argument("--port", type=int, default=8000, help="Server port")

    args = parser.parse_args()

    if args.mode == "cli":
        if not os.path.exists(args.excel):
            print(f"ERROR: Excel file not found: {args.excel}")
            print("Run 'python -m test_data.generate' first to create test data.")
            sys.exit(1)
        sys.exit(run_cli(args.excel, args.docs, args.sheet_type))
    else:
        run_server(args.host, args.port)


if __name__ == "__main__":
    main()
