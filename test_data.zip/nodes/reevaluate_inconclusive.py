"""ReevaluateInconclusiveNode — second pass on INCONCLUSIVE triggers with full context."""

import json
from pocketflow import Node


class ReevaluateInconclusiveNode(Node):
    """
    After synthesis, re-evaluates INCONCLUSIVE triggers using:
    - Full context of all findings (what was FOUND elsewhere)
    - Correlation insights from synthesis
    - Upgrade recommendations from cross-trigger analysis

    This is the agent's "second opinion" — reviewing borderline cases
    with the benefit of the complete picture.
    """

    def prep(self, shared):
        # Find INCONCLUSIVE triggers and upgrade candidates
        inconclusive_indices = []
        upgrade_ids = set(shared.get("upgrade_trigger_ids", []))

        for i, result in enumerate(shared["results"]):
            if result["status"] == "INCONCLUSIVE" or result["trigger_id"] in upgrade_ids:
                inconclusive_indices.append(i)

        return {
            "indices": inconclusive_indices,
            "results": shared["results"],
            "triggers": shared["triggers"],
            "synthesis": shared.get("synthesis", {}),
            "accumulated_findings": shared.get("accumulated_findings", []),
            "upgrade_ids": upgrade_ids,
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        indices = prep_res["indices"]
        results = prep_res["results"]
        triggers = prep_res["triggers"]
        synthesis = prep_res["synthesis"]
        accumulated = prep_res["accumulated_findings"]
        upgrade_ids = prep_res["upgrade_ids"]
        llm = prep_res["llm"]

        if not indices:
            return {"reevaluated": 0, "upgraded": 0, "updates": []}

        # Build full context summary
        found_summary = ""
        for finding in accumulated:
            if finding["status"] == "FOUND":
                found_summary += (
                    f"- {finding['category']}/{finding['topic']}: "
                    f"{finding.get('key_evidence', 'confirmed')[:100]}\n"
                )

        correlations = synthesis.get("correlations", [])
        corr_text = ""
        for c in correlations:
            corr_text += (
                f"- {c.get('triggers', [])}: {c.get('relationship', '')} "
                f"({c.get('impact', '')})\n"
            )

        updates = []

        for idx in indices:
            result = results[idx]
            trigger = triggers[idx]
            trigger_id = result["trigger_id"]

            is_upgrade_candidate = trigger_id in upgrade_ids
            upgrade_reason = ""
            for u in synthesis.get("upgrade_candidates", []):
                if u.get("trigger_id") == trigger_id:
                    upgrade_reason = u.get("reason", "")

            prompt = (
                f"Re-evaluate this trigger with full credit file context.\n\n"
                f"## Trigger\n"
                f"Category: {trigger.get('category', '')}\n"
                f"Topic: {trigger.get('topic', '')}\n"
                f"Trigger: {trigger.get('trigger_text', '')}\n"
                f"Initial assessment: {result['status']} "
                f"(confidence: {result['confidence']:.2f})\n"
                f"Initial reasoning: {result.get('reasoning', '')[:200]}\n\n"
                f"## Confirmed findings in this credit file\n"
                f"{found_summary or '(none)'}\n\n"
                f"## Cross-trigger correlations\n"
                f"{corr_text or '(none)'}\n\n"
            )

            if is_upgrade_candidate:
                prompt += (
                    f"## Upgrade recommendation\n"
                    f"Cross-trigger analysis suggests upgrading this trigger. "
                    f"Reason: {upgrade_reason}\n\n"
                )

            prompt += (
                f"Given the full context, should this trigger be:\n"
                f"1. UPGRADED to FOUND (if corroborating evidence justifies it)\n"
                f"2. KEPT as {result['status']}\n"
                f"3. DOWNGRADED to NOT_FOUND (if other findings contradict it)\n\n"
                f"Return JSON: {{\"decision\": \"upgrade/keep/downgrade\", "
                f"\"new_status\": \"FOUND/INCONCLUSIVE/NOT_FOUND\", "
                f"\"new_confidence\": 0.0-1.0, "
                f"\"reasoning\": \"...\", "
                f"\"stage_classification\": \"S2 trigger/S3 trigger/N/a\"}}"
            )

            reeval = llm.call_structured(prompt)

            decision = reeval.get("decision", "keep")
            if decision == "upgrade":
                updates.append({
                    "index": idx,
                    "trigger_id": trigger_id,
                    "old_status": result["status"],
                    "new_status": reeval.get("new_status", "FOUND"),
                    "new_confidence": reeval.get("new_confidence", 0.7),
                    "new_stage": reeval.get("stage_classification", "S2 trigger"),
                    "reasoning": reeval.get("reasoning", ""),
                })

        return {
            "reevaluated": len(indices),
            "upgraded": len(updates),
            "updates": updates,
        }

    def post(self, shared, prep_res, exec_res):
        updates = exec_res.get("updates", [])

        # Apply upgrades to results
        for update in updates:
            idx = update["index"]
            result = shared["results"][idx]
            result["status"] = update["new_status"]
            result["confidence"] = update["new_confidence"]
            result["stage_classification"] = update["new_stage"]
            result["reasoning"] += (
                f"\n\n[SECOND PASS] Upgraded from {update['old_status']} to "
                f"{update['new_status']}. Reason: {update['reasoning']}"
            )
            result["comment"] = (
                f"[Re-evaluated] {result['comment']} "
                f"Updated after cross-trigger analysis: {update['reasoning'][:150]}"
            )

            # Update accumulated findings
            for finding in shared.get("accumulated_findings", []):
                if finding["trigger_id"] == update["trigger_id"]:
                    finding["status"] = update["new_status"]
                    finding["stage"] = update["new_stage"]

        emitter = prep_res.get("emitter")
        if emitter:
            emitter.emit(
                "reevaluation_completed",
                total_reevaluated=exec_res["reevaluated"],
                upgraded=exec_res["upgraded"],
                updates=[
                    {
                        "trigger_id": u["trigger_id"],
                        "old": u["old_status"],
                        "new": u["new_status"],
                        "stage": u["new_stage"],
                    }
                    for u in updates
                ],
            )

        return "default"
