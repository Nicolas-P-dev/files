"""ParseExcelNode — reads the triggers checklist Excel and populates shared store."""

from pocketflow import Node
from skill.triggers.excel_parser import parse_triggers_excel


class ParseExcelNode(Node):
    """
    Reads the triggers checklist Excel. Parses both the assessment sheet
    (Corporate or Retail) and the reference Triggers sheet.
    """

    def prep(self, shared):
        return {
            "excel_path": shared["excel_path"],
            "sheet_type": shared["sheet_type"],
        }

    def exec(self, prep_res):
        excel_path = prep_res["excel_path"]
        sheet_type = prep_res["sheet_type"]
        return parse_triggers_excel(excel_path, sheet_type)

    def post(self, shared, prep_res, exec_res):
        shared["triggers"] = exec_res["triggers"]
        shared["guidance_notes"] = exec_res["guidance_notes"]

        emitter = shared.get("emitter")
        if emitter:
            emitter.emit(
                "excel_parse_started",
                path=prep_res["excel_path"],
                sheet_type=prep_res["sheet_type"],
            )
            categories = list(set(t["category"] for t in exec_res["triggers"] if t["category"]))
            emitter.emit(
                "excel_parse_completed",
                trigger_count=len(exec_res["triggers"]),
                categories=categories,
            )

        return "default"
