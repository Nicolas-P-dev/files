"""EvaluateEvidenceNode — LLM evaluates whether evidence supports the trigger."""

import time
import os
from pocketflow import Node


class EvaluateEvidenceNode(Node):
    """
    Given search results, has the LLM evaluate whether the evidence
    supports the trigger being present. Includes cross-trigger context
    for more informed assessment.
    """

    def prep(self, shared):
        current = shared["_current"]
        return {
            "trigger": current["trigger"],
            "search_results": current["search_results"],
            "all_queries_used": current["all_queries_used"],
            "search_attempts": current["search_attempt"],
            "accumulated_findings": shared.get("accumulated_findings", []),
            "guidance_notes": shared.get("guidance_notes", ""),
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        trigger = prep_res["trigger"]
        chunks = prep_res["search_results"]
        llm = prep_res["llm"]
        accumulated = prep_res["accumulated_findings"]

        start_time = time.time()

        # Format chunks for the prompt
        chunks_text = ""
        for i, chunk in enumerate(chunks, 1):
            chunks_text += (
                f"\n--- Excerpt {i} ---\n"
                f"Source: {chunk['document']} (page {chunk['page']})\n"
                f"Relevance: {chunk['relevance_score']:.3f}\n"
                f"Text: {chunk['text']}\n"
            )
        if not chunks_text:
            chunks_text = "(No relevant document excerpts were found)"

        # Format examples
        examples_text = ""
        for i, ex in enumerate(trigger.get("examples", []), 1):
            examples_text += f"Example {i}: {ex}\n"
        if not examples_text:
            examples_text = "(No examples provided)"

        # Format cross-trigger context
        context_text = ""
        related = [f for f in accumulated if f["status"] == "FOUND"]
        if related:
            context_text = "## Previously confirmed findings in this credit file\n"
            for f in related[-5:]:
                context_text += (
                    f"- {f['topic']}: {f.get('key_evidence', 'evidence found')[:100]}\n"
                )
            context_text += (
                "\nConsider these findings as additional context. "
                "Related findings may corroborate or inform your assessment.\n"
            )

        prompt = (
            f"Evaluate evidence for the following forbearance trigger.\n\n"
            f"Category: {trigger.get('category', '')}\n"
            f"Topic: {trigger.get('topic', '')}\n"
            f"Trigger: {trigger.get('trigger_text', '')}\n"
            f"Stage Reference: {trigger.get('stage_ref', '')}\n\n"
            f"## Reference Examples from ECB Checklist\n{examples_text}\n\n"
            f"{context_text}\n"
            f"## Retrieved Document Excerpts\n{chunks_text}\n\n"
            f"## Search effort\n"
            f"Searched with {len(prep_res['all_queries_used'])} queries "
            f"across {prep_res['search_attempts']} search rounds.\n\n"
            f"Evaluate the evidence. Return JSON with: status, confidence, reasoning, "
            f"key_evidence, source_document, source_page, validated_value"
        )

        eval_result = llm.call_structured(prompt)
        eval_result["processing_time_ms"] = int((time.time() - start_time) * 1000)

        return eval_result

    def post(self, shared, prep_res, exec_res):
        current = shared["_current"]
        current["eval_result"] = exec_res

        trigger = prep_res["trigger"]
        emitter = prep_res.get("emitter")

        if emitter:
            emitter.emit(
                "eval_reasoning",
                trigger_id=trigger["id"],
                reasoning=exec_res.get("reasoning", ""),
            )
            emitter.emit(
                "eval_completed",
                trigger_id=trigger["id"],
                status=exec_res.get("status", "NOT_FOUND"),
                confidence=exec_res.get("confidence", 0.0),
                evidence_count=len(current["search_results"]),
            )

        status = exec_res.get("status", "NOT_FOUND")
        if status == "FOUND":
            return "found"
        else:
            return "not_found"
