"""SynthesizeFindingsNode — correlates findings across triggers for deeper insight."""

import json
from pocketflow import Node


class SynthesizeFindingsNode(Node):
    """
    After all triggers are individually evaluated, this node performs
    cross-trigger analysis:
    - Identifies correlated findings (e.g., financial difficulty + concession = forbearance)
    - Detects patterns that strengthen or weaken individual assessments
    - Flags triggers that should be reconsidered based on the full picture
    - Generates an overall risk narrative
    """

    def prep(self, shared):
        return {
            "triggers": shared["triggers"],
            "results": shared["results"],
            "accumulated_findings": shared.get("accumulated_findings", []),
            "document_relevance": shared.get("document_relevance", {}),
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        results = prep_res["results"]
        triggers = prep_res["triggers"]
        llm = prep_res["llm"]
        doc_relevance = prep_res["document_relevance"]

        found = [r for r in results if r["status"] == "FOUND"]
        inconclusive = [r for r in results if r["status"] == "INCONCLUSIVE"]

        # Build findings summary for LLM
        findings_text = ""
        for r in results:
            marker = {"FOUND": "[!]", "INCONCLUSIVE": "[?]", "NOT_FOUND": "[ ]"}.get(
                r["status"], "[ ]"
            )
            findings_text += (
                f"{marker} {r.get('category', '')}/{r.get('topic', '')}: "
                f"{r['status']} (confidence: {r['confidence']:.2f})"
            )
            if r.get("key_evidence"):
                findings_text += f" — {r['key_evidence'][:80]}"
            findings_text += "\n"

        # Document relevance summary
        doc_text = ""
        for doc, stats in sorted(
            doc_relevance.items(),
            key=lambda x: x[1]["total_score"],
            reverse=True,
        ):
            avg = stats["total_score"] / max(stats["hit_count"], 1)
            doc_text += f"  {doc}: {stats['hit_count']} hits, avg relevance {avg:.3f}\n"

        prompt = (
            f"Synthesize cross-trigger findings for this credit file.\n\n"
            f"## All trigger results\n{findings_text}\n\n"
            f"## Document relevance\n{doc_text}\n\n"
            f"## Analysis tasks\n"
            f"1. Identify correlations between findings (e.g., financial difficulty "
            f"indicators that corroborate concession findings)\n"
            f"2. Flag any INCONCLUSIVE triggers that should be upgraded to FOUND "
            f"given corroborating evidence from other triggers\n"
            f"3. Flag any findings that seem inconsistent with each other\n"
            f"4. Provide an overall forbearance risk assessment\n\n"
            f"Return JSON:\n"
            f'{{"correlations": [{{"triggers": ["id1", "id2"], "relationship": "...", '
            f'"impact": "strengthens/weakens"}}], '
            f'"upgrade_candidates": [{{"trigger_id": "...", "reason": "..."}}], '
            f'"inconsistencies": [], '
            f'"overall_risk": "high/medium/low", '
            f'"risk_narrative": "...", '
            f'"forbearance_confirmed": true/false}}'
        )

        result = llm.call_structured(prompt)
        return result

    def post(self, shared, prep_res, exec_res):
        shared["synthesis"] = exec_res

        # Mark triggers that should be upgraded from INCONCLUSIVE
        upgrade_candidates = exec_res.get("upgrade_candidates", [])
        shared["upgrade_trigger_ids"] = [
            u["trigger_id"] for u in upgrade_candidates
        ]

        emitter = prep_res.get("emitter")
        if emitter:
            correlations = exec_res.get("correlations", [])
            emitter.emit(
                "synthesis_completed",
                correlations_found=len(correlations),
                upgrade_candidates=len(upgrade_candidates),
                overall_risk=exec_res.get("overall_risk", "unknown"),
                forbearance_confirmed=exec_res.get("forbearance_confirmed", False),
                risk_narrative=exec_res.get("risk_narrative", ""),
            )

        # Decide whether to re-evaluate inconclusives
        has_upgrades = len(upgrade_candidates) > 0
        has_inconclusives = any(
            r["status"] == "INCONCLUSIVE" for r in shared["results"]
        )

        if has_upgrades or has_inconclusives:
            return "reevaluate"
        else:
            return "default"
