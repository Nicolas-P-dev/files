"""FinalizeTriggerNode — assembles the final result for a trigger and updates shared state."""

import time
from pocketflow import Node


class FinalizeTriggerNode(Node):
    """
    Terminal node in the per-trigger sub-flow. Assembles the full result,
    appends to shared["results"], and updates accumulated_findings and
    document_relevance for cross-trigger learning.
    """

    def prep(self, shared):
        current = shared["_current"]
        return {
            "trigger": current["trigger"],
            "trigger_index": current["trigger_index"],
            "eval_result": current.get("eval_result", {}),
            "stage_result": current.get("stage_result"),
            "search_results": current["search_results"],
            "all_queries_used": current["all_queries_used"],
            "search_attempts": current["search_attempt"],
            "total_triggers": len(shared["triggers"]),
            "emitter": shared.get("emitter"),
            "start_time": current.get("start_time", time.time()),
        }

    def exec(self, prep_res):
        trigger = prep_res["trigger"]
        eval_result = prep_res["eval_result"]
        stage_result = prep_res["stage_result"]
        chunks = prep_res["search_results"]

        status = eval_result.get("status", "NOT_FOUND")

        # Determine stage classification
        if status == "FOUND" and stage_result:
            stage_classification = stage_result.get("classification", "S2 trigger")
        elif status == "INCONCLUSIVE":
            stage_classification = "N/a"
        else:
            stage_classification = "Not a trigger"

        # Build comment
        comment = _build_comment(trigger, eval_result, stage_classification)

        # Build evidence list
        evidence = [
            {
                "text": c["text"][:500],
                "document": c["document"],
                "page": c["page"],
                "relevance_score": c["relevance_score"],
            }
            for c in chunks[:5]
        ]

        elapsed_ms = int((time.time() - prep_res["start_time"]) * 1000)

        return {
            "trigger_id": trigger["id"],
            "status": status,
            "confidence": eval_result.get("confidence", 0.0),
            "validated_value": eval_result.get("validated_value", ""),
            "stage_classification": stage_classification,
            "comment": comment,
            "evidence": evidence,
            "search_queries": prep_res["all_queries_used"],
            "reasoning": eval_result.get("reasoning", ""),
            "processing_time_ms": elapsed_ms,
            "search_attempts": prep_res["search_attempts"],
            # Cross-trigger metadata
            "category": trigger.get("category", ""),
            "topic": trigger.get("topic", ""),
            "key_evidence": eval_result.get("key_evidence"),
        }

    def post(self, shared, prep_res, exec_res):
        # Append result
        shared["results"].append(exec_res)

        # Update accumulated findings for cross-trigger reasoning
        shared.setdefault("accumulated_findings", []).append({
            "trigger_id": exec_res["trigger_id"],
            "status": exec_res["status"],
            "confidence": exec_res["confidence"],
            "category": exec_res.get("category", ""),
            "topic": exec_res.get("topic", ""),
            "stage": exec_res["stage_classification"],
            "key_evidence": exec_res.get("key_evidence"),
        })

        # Update document relevance tracking
        for ev in exec_res.get("evidence", []):
            doc = ev["document"]
            score = ev["relevance_score"]
            doc_rel = shared.setdefault("document_relevance", {})
            if doc not in doc_rel:
                doc_rel[doc] = {"total_score": 0.0, "hit_count": 0}
            doc_rel[doc]["total_score"] += score
            doc_rel[doc]["hit_count"] += 1

        # Emit completion event
        trigger = prep_res["trigger"]
        emitter = prep_res.get("emitter")
        if emitter:
            emitter.emit(
                "trigger_completed",
                trigger_id=trigger["id"],
                status=exec_res["status"],
                stage=exec_res["stage_classification"],
                time_ms=exec_res["processing_time_ms"],
                index=prep_res["trigger_index"],
                total=prep_res["total_triggers"],
                search_attempts=exec_res["search_attempts"],
            )

        return "default"


def _build_comment(trigger: dict, eval_result: dict, stage: str) -> str:
    """Build the comment text for column G."""
    status = eval_result.get("status", "NOT_FOUND")
    reasoning = eval_result.get("reasoning", "")
    key_evidence = eval_result.get("key_evidence")

    if status == "FOUND":
        comment = f"Evidence found for '{trigger.get('topic', '')}' trigger. "
        comment += f"Classification: {stage}. "
        if key_evidence:
            comment += f'Key evidence: "{key_evidence[:150]}" '
        src = eval_result.get("source_document", "")
        if src:
            comment += f"({src}"
            if eval_result.get("source_page"):
                comment += f" p.{eval_result['source_page']}"
            comment += ")"
    elif status == "INCONCLUSIVE":
        comment = f"Inconclusive evidence for '{trigger.get('topic', '')}' trigger. "
        comment += "Manual review recommended. "
        if reasoning:
            comment += reasoning[:200]
    else:
        comment = (
            f"No evidence found for '{trigger.get('topic', '')}' trigger "
            f"in the reviewed documents."
        )

    return comment
