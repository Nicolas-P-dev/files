"""GenerateReportNode — aggregates results and generates Excel + JSON outputs."""

import os
from pocketflow import Node
from skill.scripts.generate_report import generate_excel_report, generate_json_report
from utils.config import Config


class GenerateReportNode(Node):
    """
    Aggregates all trigger results and generates output reports.
    """

    def prep(self, shared):
        return {
            "triggers": shared["triggers"],
            "results": shared["results"],
            "config": shared.get("config", Config()),
            "sheet_type": shared.get("sheet_type", "corporate"),
            "debtor_id": shared.get("debtor_id", "unknown"),
        }

    def exec(self, prep_res):
        config = prep_res["config"]
        triggers = prep_res["triggers"]
        results = prep_res["results"]
        sheet_type = prep_res["sheet_type"]
        debtor_id = prep_res["debtor_id"]

        os.makedirs(config.output_dir, exist_ok=True)

        # Generate Excel report
        excel_path = os.path.join(
            config.output_dir,
            f"forbearance_report_{debtor_id}.xlsx",
        )
        generate_excel_report(triggers, results, excel_path, sheet_type)

        # Generate JSON report
        json_path = os.path.join(
            config.output_dir,
            f"forbearance_report_{debtor_id}.json",
        )
        generate_json_report(triggers, results, json_path)

        # Build summary
        total = len(results)
        found = sum(1 for r in results if r.get("status") == "FOUND")
        not_found = sum(1 for r in results if r.get("status") == "NOT_FOUND")
        inconclusive = sum(1 for r in results if r.get("status") == "INCONCLUSIVE")
        s2 = sum(1 for r in results if r.get("stage_classification") == "S2 trigger")
        s3 = sum(1 for r in results if r.get("stage_classification") == "S3 trigger")

        return {
            "excel_output_path": excel_path,
            "json_output_path": json_path,
            "summary": {
                "total_triggers": total,
                "found": found,
                "not_found": not_found,
                "inconclusive": inconclusive,
                "s2_triggers": s2,
                "s3_triggers": s3,
            },
        }

    def post(self, shared, prep_res, exec_res):
        shared["report"] = {
            "summary": exec_res["summary"],
            "excel_output_path": exec_res["excel_output_path"],
            "json_output_path": exec_res["json_output_path"],
        }

        emitter = shared.get("emitter")
        if emitter:
            emitter.emit(
                "report_completed",
                excel_path=exec_res["excel_output_path"],
                summary=exec_res["summary"],
            )

        return "default"
