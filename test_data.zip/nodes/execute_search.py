"""ExecuteSearchNode — runs queries against ChromaDB and collects chunks."""

from pocketflow import Node
from skill.scripts.chromadb_search import (
    get_chroma_client,
    get_or_create_collection,
    multi_query_search,
)
from utils.config import Config


class ExecuteSearchNode(Node):
    """
    Executes the current search queries against ChromaDB.
    Merges new results with any existing results from previous attempts.
    """

    def prep(self, shared):
        config = shared.get("config", Config())
        client = get_chroma_client(config.chroma_persist_dir)
        collection = get_or_create_collection(client, shared["chroma_collection"])
        current = shared["_current"]

        return {
            "queries": current["queries"],
            "existing_results": current["search_results"],
            "collection": collection,
            "config": config,
            "trigger_id": current["trigger"]["id"],
            "attempt": current["search_attempt"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        queries = prep_res["queries"]
        collection = prep_res["collection"]
        config = prep_res["config"]
        existing = prep_res["existing_results"]

        # Execute search
        new_results = multi_query_search(
            collection,
            queries,
            n_results_per_query=config.max_chunks_per_query,
            max_total=config.max_chunks_per_trigger,
        )

        # Merge with existing results (deduplicate by chunk_id)
        seen_ids = {r["chunk_id"] for r in existing}
        merged = list(existing)
        for r in new_results:
            if r["chunk_id"] not in seen_ids:
                seen_ids.add(r["chunk_id"])
                merged.append(r)

        # Re-sort by relevance
        merged.sort(key=lambda x: x["relevance_score"], reverse=True)

        # Trim to max
        merged = merged[:config.max_chunks_per_trigger]

        return {
            "results": merged,
            "new_count": len(new_results),
            "total_count": len(merged),
            "top_score": merged[0]["relevance_score"] if merged else 0.0,
        }

    def post(self, shared, prep_res, exec_res):
        shared["_current"]["search_results"] = exec_res["results"]

        emitter = prep_res.get("emitter")
        if emitter:
            emitter.emit(
                "search_results",
                trigger_id=prep_res["trigger_id"],
                chunks_found=exec_res["total_count"],
                new_chunks=exec_res["new_count"],
                top_score=exec_res["top_score"],
                attempt=prep_res["attempt"],
            )

        return "default"
