"""EmbedDocumentsNode — extracts, chunks, and embeds credit file PDFs into ChromaDB."""

from pocketflow import Node
from skill.scripts.chunk_documents import extract_and_chunk_pdfs, get_document_metadata
from skill.scripts.chromadb_search import (
    get_chroma_client,
    get_or_create_collection,
    add_chunks_to_collection,
    collection_exists,
)
from utils.config import Config


class EmbedDocumentsNode(Node):
    """
    Takes credit file documents, chunks them, embeds them, stores in ChromaDB.
    Skips if the collection already exists.
    """

    def prep(self, shared):
        config = shared.get("config", Config())
        collection_name = f"{config.chroma_collection_prefix}_{shared.get('debtor_id', 'default')}"

        client = get_chroma_client(config.chroma_persist_dir)

        # Check if already embedded
        already_exists = collection_exists(client, collection_name)

        return {
            "documents_dir": shared["documents_dir"],
            "collection_name": collection_name,
            "client": client,
            "config": config,
            "already_exists": already_exists,
        }

    def exec(self, prep_res):
        if prep_res["already_exists"]:
            # Collection already exists, just get metadata
            return {
                "skipped": True,
                "collection_name": prep_res["collection_name"],
                "document_metadata": get_document_metadata(prep_res["documents_dir"]),
                "total_chunks": 0,
            }

        config = prep_res["config"]
        documents_dir = prep_res["documents_dir"]

        # Extract and chunk PDFs
        chunks = extract_and_chunk_pdfs(
            documents_dir,
            chunk_size=config.chunk_size,
            overlap=config.chunk_overlap,
        )

        # Store in ChromaDB
        collection = get_or_create_collection(
            prep_res["client"],
            prep_res["collection_name"],
        )
        num_added = add_chunks_to_collection(collection, chunks)

        # Build document metadata
        doc_meta = {}
        for chunk in chunks:
            fn = chunk["filename"]
            if fn not in doc_meta:
                doc_meta[fn] = {"filename": fn, "pages": 0, "chunks": 0, "doc_type": ""}
            doc_meta[fn]["pages"] = max(doc_meta[fn]["pages"], chunk["page"])
            doc_meta[fn]["chunks"] += 1

        return {
            "skipped": False,
            "collection_name": prep_res["collection_name"],
            "document_metadata": list(doc_meta.values()),
            "total_chunks": num_added,
            "chunk_details": chunks,
        }

    def post(self, shared, prep_res, exec_res):
        shared["chroma_collection"] = exec_res["collection_name"]
        shared["document_metadata"] = exec_res["document_metadata"]

        emitter = shared.get("emitter")
        if emitter:
            doc_count = len(exec_res["document_metadata"])
            emitter.emit("embed_started", doc_count=doc_count)

            for doc in exec_res["document_metadata"]:
                emitter.emit(
                    "embed_document",
                    filename=doc["filename"],
                    chunks=doc.get("chunks", 0),
                    pages=doc.get("pages", 0),
                )

            emitter.emit(
                "embed_completed",
                total_chunks=exec_res["total_chunks"],
                collection=exec_res["collection_name"],
            )

        return "default"
