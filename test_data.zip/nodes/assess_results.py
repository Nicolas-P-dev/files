"""AssessResultsNode — decides if search results are sufficient or need refinement."""

from pocketflow import Node


# Thresholds for result quality assessment
MIN_RELEVANCE_SCORE = 0.35   # Minimum top score to consider results useful
MIN_CHUNKS_ABOVE_THRESHOLD = 2  # Need at least 2 chunks above threshold
RELEVANCE_THRESHOLD = 0.25   # Individual chunk threshold


class AssessResultsNode(Node):
    """
    Evaluates the quality of search results and decides the next action:
    - "sufficient": Results are good enough to evaluate evidence
    - "insufficient": Results are poor, need to refine queries and retry
    - "max_attempts": Hit max retries, evaluate with what we have
    """

    def prep(self, shared):
        current = shared["_current"]
        return {
            "results": current["search_results"],
            "attempt": current["search_attempt"],
            "max_attempts": current["max_attempts"],
            "trigger": current["trigger"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        results = prep_res["results"]
        attempt = prep_res["attempt"]
        max_attempts = prep_res["max_attempts"]

        if not results:
            top_score = 0.0
            chunks_above = 0
            avg_score = 0.0
        else:
            top_score = results[0]["relevance_score"]
            chunks_above = sum(
                1 for r in results if r["relevance_score"] >= RELEVANCE_THRESHOLD
            )
            avg_score = sum(r["relevance_score"] for r in results) / len(results)

        sufficient = (
            top_score >= MIN_RELEVANCE_SCORE
            and chunks_above >= MIN_CHUNKS_ABOVE_THRESHOLD
        )

        return {
            "sufficient": sufficient,
            "top_score": top_score,
            "chunks_above_threshold": chunks_above,
            "avg_score": avg_score,
            "total_chunks": len(results),
            "at_max": attempt >= max_attempts,
        }

    def post(self, shared, prep_res, exec_res):
        trigger = prep_res["trigger"]
        emitter = prep_res.get("emitter")

        if emitter:
            emitter.emit(
                "search_assessed",
                trigger_id=trigger["id"],
                sufficient=exec_res["sufficient"],
                top_score=exec_res["top_score"],
                chunks_above_threshold=exec_res["chunks_above_threshold"],
                attempt=prep_res["attempt"],
                max_attempts=prep_res["max_attempts"],
            )

        if exec_res["sufficient"]:
            return "sufficient"
        elif exec_res["at_max"]:
            if emitter:
                emitter.emit(
                    "search_max_attempts",
                    trigger_id=trigger["id"],
                    message=f"Max search attempts ({prep_res['max_attempts']}) reached. Evaluating with best available results.",
                )
            return "max_attempts"
        else:
            return "insufficient"
