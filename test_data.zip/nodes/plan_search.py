"""PlanSearchNode — generates an initial search strategy for a trigger."""

import json
from pocketflow import Node


class PlanSearchNode(Node):
    """
    First node in the per-trigger sub-flow. Analyzes the trigger definition
    and plans a multi-angle search strategy, considering accumulated findings
    from previous triggers.
    """

    def prep(self, shared):
        idx = self.params["trigger_index"]
        trigger = shared["triggers"][idx]
        accumulated = shared.get("accumulated_findings", [])
        doc_relevance = shared.get("document_relevance", {})

        return {
            "trigger": trigger,
            "index": idx,
            "total": len(shared["triggers"]),
            "accumulated_findings": accumulated,
            "document_relevance": doc_relevance,
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        trigger = prep_res["trigger"]
        llm = prep_res["llm"]
        accumulated = prep_res["accumulated_findings"]

        # Build context from previous findings
        context_lines = []
        for finding in accumulated[-5:]:  # Last 5 findings for context
            if finding["status"] == "FOUND":
                context_lines.append(
                    f"- FOUND: {finding['topic']} — {finding.get('key_evidence', '')[:100]}"
                )

        context_str = "\n".join(context_lines) if context_lines else "(no prior findings)"

        # Ask LLM to plan the search strategy
        prompt = (
            f"Plan search strategy for this forbearance trigger.\n\n"
            f"Category: {trigger['category']}\n"
            f"Topic: {trigger['topic']}\n"
            f"Trigger: {trigger['trigger_text']}\n"
            f"Stage Reference: {trigger.get('stage_ref', '')}\n"
            f"Hard/Soft: {trigger.get('hard_soft', 'Soft')}\n\n"
            f"## Prior findings from this credit file\n{context_str}\n\n"
            f"## Instructions\n"
            f"Generate search queries to find evidence of this trigger in banking documents.\n"
            f"Consider what type of document would contain this information.\n"
            f"Generate 3-5 diverse search queries, each 3-8 words.\n\n"
            f"Return JSON:\n"
            f'{{"queries": ["q1", "q2", ...], '
            f'"target_doc_types": ["npl_report", "facility_agreement", "financial_statement"], '
            f'"search_rationale": "why these queries"}}'
        )

        result = llm.call(prompt, json_mode=True)
        try:
            plan = json.loads(result)
        except (json.JSONDecodeError, TypeError):
            # Fallback: generate basic queries from trigger text
            plan = {
                "queries": [trigger["trigger_text"][:60]],
                "target_doc_types": ["npl_report"],
                "search_rationale": "Fallback: direct trigger text search",
            }

        # Ensure queries is a list
        if isinstance(plan.get("queries"), str):
            plan["queries"] = [plan["queries"]]
        if not plan.get("queries"):
            plan["queries"] = [trigger["trigger_text"][:60]]

        return plan

    def post(self, shared, prep_res, exec_res):
        idx = prep_res["index"]
        trigger = prep_res["trigger"]

        # Initialize per-trigger working state
        import time as _time
        shared["_current"] = {
            "trigger": trigger,
            "trigger_index": idx,
            "search_plan": exec_res,
            "queries": exec_res.get("queries", []),
            "all_queries_used": list(exec_res.get("queries", [])),
            "search_results": [],
            "search_attempt": 1,
            "max_attempts": 3,
            "start_time": _time.time(),
        }

        emitter = prep_res.get("emitter")
        if emitter:
            emitter.emit(
                "trigger_started",
                trigger_id=trigger["id"],
                trigger_text=trigger["trigger_text"],
                index=idx,
                total=prep_res["total"],
            )
            emitter.emit(
                "search_planned",
                trigger_id=trigger["id"],
                queries=exec_res.get("queries", []),
                rationale=exec_res.get("search_rationale", ""),
                target_docs=exec_res.get("target_doc_types", []),
            )

        return "default"
