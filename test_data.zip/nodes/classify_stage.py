"""ClassifyStageNode — classifies FOUND triggers into S2/S3 stages."""

import time
from pocketflow import Node


class ClassifyStageNode(Node):
    """
    Given a FOUND trigger and its evidence, classify as S2 or S3.
    Uses cross-trigger context for more accurate classification.
    """

    def prep(self, shared):
        current = shared["_current"]
        return {
            "trigger": current["trigger"],
            "eval_result": current["eval_result"],
            "accumulated_findings": shared.get("accumulated_findings", []),
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        trigger = prep_res["trigger"]
        eval_result = prep_res["eval_result"]
        accumulated = prep_res["accumulated_findings"]
        llm = prep_res["llm"]

        # Count existing FOUND triggers for severity context
        found_count = sum(1 for f in accumulated if f["status"] == "FOUND")
        found_categories = list(set(
            f["category"] for f in accumulated if f["status"] == "FOUND"
        ))

        evidence_summary = eval_result.get("reasoning", "")
        key_evidence = eval_result.get("key_evidence", "")
        if key_evidence:
            evidence_summary += f"\nKey evidence: {key_evidence}"

        prompt = (
            f"Classify the stage for this confirmed forbearance trigger.\n\n"
            f"Trigger: {trigger.get('trigger_text', '')}\n"
            f"Reference Stage: {trigger.get('stage_ref', '')}\n"
            f"NPE Trigger: {'Yes' if trigger.get('npe_trigger') else 'No'}\n"
            f"Hard/Soft: {trigger.get('hard_soft', 'Soft')}\n"
            f"Forbearance Measure: {'Yes' if trigger.get('forbearance_measure') else 'No'}\n\n"
            f"## Evidence Summary\n{evidence_summary}\n\n"
            f"## Cross-trigger context\n"
            f"Total triggers found so far: {found_count}\n"
            f"Categories with findings: {', '.join(found_categories) if found_categories else 'none'}\n"
            f"{'Multiple forbearance measures detected - consider higher severity.' if found_count >= 2 else ''}\n\n"
            f"Classify the stage. Return JSON with: classification, reasoning, severity"
        )

        result = llm.call_structured(prompt)
        return result

    def post(self, shared, prep_res, exec_res):
        current = shared["_current"]
        current["stage_result"] = exec_res

        trigger = prep_res["trigger"]
        emitter = prep_res.get("emitter")

        classification = exec_res.get("classification", "S2 trigger")

        if emitter:
            emitter.emit(
                "stage_classification",
                trigger_id=trigger["id"],
                classification=classification,
                reasoning=exec_res.get("reasoning", ""),
                severity=exec_res.get("severity", "medium"),
            )

        return "default"
