"""RefineSearchNode — generates improved queries when initial search is insufficient."""

import json
from pocketflow import Node


class RefineSearchNode(Node):
    """
    When search results are insufficient, this node generates refined queries
    using different strategies based on the attempt number:
    - Attempt 2: Broaden terms, use financial synonyms, try document-specific queries
    - Attempt 3: Use evidence from best chunks to guide new queries, try related concepts
    """

    def prep(self, shared):
        current = shared["_current"]
        return {
            "trigger": current["trigger"],
            "attempt": current["search_attempt"],
            "previous_queries": current["all_queries_used"],
            "best_results": current["search_results"][:3],  # Top 3 so far
            "llm": shared["llm"],
            "emitter": shared.get("emitter"),
        }

    def exec(self, prep_res):
        trigger = prep_res["trigger"]
        attempt = prep_res["attempt"]
        previous_queries = prep_res["previous_queries"]
        best_results = prep_res["best_results"]
        llm = prep_res["llm"]

        # Build refinement context
        prev_queries_str = "\n".join(f"  - {q}" for q in previous_queries)

        best_chunks_str = ""
        if best_results:
            for i, r in enumerate(best_results[:3], 1):
                best_chunks_str += (
                    f"\n  Chunk {i} (score {r['relevance_score']:.3f}, "
                    f"{r['document']} p.{r['page']}): "
                    f"{r['text'][:150]}..."
                )

        if attempt == 1:
            strategy = (
                "The initial search found low-relevance results. "
                "Try broader financial terminology, synonyms, and alternative phrasings. "
                "Consider what specific document sections might contain this information."
            )
        else:
            strategy = (
                "Second refinement attempt. Try very different angles: "
                "look for indirect indicators, related financial metrics, "
                "or consequences of this trigger rather than direct mentions. "
                "Use the best chunks found so far as clues for better queries."
            )

        prompt = (
            f"Refine search queries for this forbearance trigger.\n\n"
            f"Trigger: {trigger['trigger_text']}\n"
            f"Category: {trigger['category']}\n"
            f"Topic: {trigger['topic']}\n\n"
            f"## Previous queries that yielded low-relevance results\n{prev_queries_str}\n\n"
            f"## Best chunks found so far\n{best_chunks_str or '(none)'}\n\n"
            f"## Refinement strategy\n{strategy}\n\n"
            f"Generate 3-5 NEW search queries that are DIFFERENT from the previous ones.\n"
            f"Return JSON: {{\"queries\": [\"q1\", \"q2\", ...], \"strategy\": \"what you changed\"}}"
        )

        result = llm.call(prompt, json_mode=True)
        try:
            refined = json.loads(result)
        except (json.JSONDecodeError, TypeError):
            # Fallback: generate alternative queries mechanically
            words = trigger["trigger_text"].split()
            refined = {
                "queries": [
                    " ".join(words[i:i+4]) for i in range(0, min(len(words), 12), 3)
                ],
                "strategy": "Fallback: sliding window over trigger text",
            }

        queries = refined.get("queries", [])
        if isinstance(queries, str):
            queries = [queries]

        return {
            "queries": queries,
            "strategy": refined.get("strategy", ""),
        }

    def post(self, shared, prep_res, exec_res):
        current = shared["_current"]

        # Update search state
        current["queries"] = exec_res["queries"]
        current["all_queries_used"].extend(exec_res["queries"])
        current["search_attempt"] += 1

        emitter = prep_res.get("emitter")
        if emitter:
            emitter.emit(
                "search_refined",
                trigger_id=prep_res["trigger"]["id"],
                new_queries=exec_res["queries"],
                strategy=exec_res["strategy"],
                attempt=current["search_attempt"],
            )

        return "default"
