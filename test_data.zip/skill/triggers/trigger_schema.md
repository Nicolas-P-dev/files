# Triggers Excel Schema

## Sheet: "Triggers Corporate" / "Triggers Retail"

Header row is auto-detected by scanning for "Category" + "Topic" + "Trigger" in row.

| Column | Field | Description |
|--------|-------|-------------|
| A | Category | Group (Concessions, Financial difficulty, Loss events, etc.) |
| B | Topic | Sub-category (Interest rate, Maturity, Payment schedule, etc.) |
| C | Trigger | The actual indicator text to search for |
| D | Reported value | Bank's reported value (may contain formulas — do not modify) |
| E | Validated value | **Output**: Our validated/revised value |
| F | Stage classification | **Output**: "S2 trigger", "S3 trigger", "Not a trigger", "N/a" |
| G | Comment | **Output**: Explanation text for bank team |
| H | (gap) | Separator column |
| I-K | Examples 1-3 | Reference examples for assessment |

## Sheet: "triggers" (Reference/Master)

| Column | Field | Description |
|--------|-------|-------------|
| A | Trigger ID | Identifier (T01, T02, etc.) |
| B | Trigger name | Name of the trigger |
| C | NPE trigger | Yes/No |
| D | Stage 2 trigger | Yes/No |
| E | Source | Regulation reference |
| F | Hard / Soft | Severity classification |
| G | (gap) | Separator |
| H | Short-term/Long-term | Duration classification |
| I | Forbearance measure | Yes/No |
| J | Description | Full description |
