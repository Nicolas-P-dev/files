"""Parse the ECB triggers checklist Excel into structured trigger definitions."""

import openpyxl
from typing import Optional


def parse_triggers_excel(excel_path: str, sheet_type: str = "corporate") -> dict:
    """
    Parse a triggers Excel file and return triggers list + guidance notes.

    Args:
        excel_path: Path to the Excel file
        sheet_type: "corporate" or "retail"

    Returns:
        dict with keys: "triggers" (list), "guidance_notes" (str)
    """
    wb = openpyxl.load_workbook(excel_path, data_only=True)

    # Determine which assessment sheet to use
    sheet_name = _find_assessment_sheet(wb, sheet_type)
    if not sheet_name:
        raise ValueError(
            f"Could not find {sheet_type} triggers sheet. "
            f"Available sheets: {wb.sheetnames}"
        )

    ws = wb[sheet_name]

    # Parse the reference sheet for cross-referencing
    ref_data = _parse_reference_sheet(wb)

    # Extract guidance notes (usually in row 3, merged cells)
    guidance_notes = _extract_guidance_notes(ws)

    # Find the header row
    header_row = _find_header_row(ws)
    if header_row is None:
        raise ValueError("Could not find header row containing 'Category', 'Topic', 'Trigger'")

    # Parse triggers from data rows
    triggers = []
    for row_idx in range(header_row + 1, ws.max_row + 1):
        category = _cell_value(ws, row_idx, 1)  # Column A
        topic = _cell_value(ws, row_idx, 2)      # Column B
        trigger_text = _cell_value(ws, row_idx, 3)  # Column C

        # Skip rows where all three key fields are empty
        if not category and not topic and not trigger_text:
            continue

        # Skip rows with no trigger text (category/topic header rows)
        if not trigger_text:
            continue

        reported_value = _cell_value(ws, row_idx, 4)  # Column D

        # Extract examples (columns I, J, K = 9, 10, 11)
        examples = []
        for col in [9, 10, 11]:
            val = _cell_value(ws, row_idx, col)
            if val:
                examples.append(str(val))

        # Cross-reference with reference sheet
        ref = _find_reference(ref_data, trigger_text)

        trigger_id = ref.get("trigger_id", f"T{len(triggers)+1:02d}") if ref else f"T{len(triggers)+1:02d}"

        triggers.append({
            "id": trigger_id,
            "category": category or "",
            "topic": topic or "",
            "trigger_text": trigger_text,
            "reported_value": reported_value,
            "stage_ref": ref.get("stage_ref", "S2") if ref else "S2",
            "npe_trigger": ref.get("npe_trigger", False) if ref else False,
            "hard_soft": ref.get("hard_soft", "Soft") if ref else "Soft",
            "forbearance_measure": ref.get("forbearance_measure", False) if ref else False,
            "examples": examples,
            "source_ref": ref.get("source", "") if ref else "",
            "original_row": row_idx,
        })

    wb.close()
    return {"triggers": triggers, "guidance_notes": guidance_notes}


def _find_assessment_sheet(wb, sheet_type: str) -> Optional[str]:
    """Find the correct assessment sheet by name."""
    target = sheet_type.lower()
    for name in wb.sheetnames:
        lower = name.lower()
        if target == "corporate" and "corporate" in lower and "trigger" in lower:
            return name
        if target == "retail" and "retail" in lower and "trigger" in lower:
            return name
    # Fallback: try partial match
    for name in wb.sheetnames:
        lower = name.lower()
        if target in lower:
            return name
    return None


def _find_header_row(ws) -> Optional[int]:
    """Scan for the header row containing 'Category', 'Topic', 'Trigger'."""
    for row_idx in range(1, min(ws.max_row + 1, 20)):
        values = []
        for col in range(1, min(ws.max_column + 1, 15)):
            val = _cell_value(ws, row_idx, col)
            if val:
                values.append(str(val).lower().strip())

        # Look for a row that has category/topic/trigger headers
        has_trigger = any("trigger" in v for v in values)
        has_category = any("category" in v for v in values)
        has_topic = any("topic" in v for v in values)

        if has_trigger and (has_category or has_topic):
            return row_idx

    return None


def _extract_guidance_notes(ws) -> str:
    """Extract guidance notes from the header area (usually rows 2-4)."""
    notes = []
    for row_idx in range(1, min(ws.max_row + 1, 6)):
        for col in range(1, min(ws.max_column + 1, 10)):
            val = _cell_value(ws, row_idx, col)
            if val and len(str(val)) > 100:  # Guidance notes are long text blocks
                notes.append(str(val))
    return "\n".join(notes) if notes else ""


def _parse_reference_sheet(wb) -> list[dict]:
    """Parse the 'triggers' reference/master sheet."""
    ref_sheet = None
    for name in wb.sheetnames:
        # Match "triggers" but not "Triggers Corporate" or "Triggers Retail"
        lower = name.lower().strip()
        if lower == "triggers" or (lower.startswith("trigger") and "corporate" not in lower and "retail" not in lower):
            ref_sheet = wb[name]
            break

    if ref_sheet is None:
        return []

    # Find header row in reference sheet
    header_row = None
    for row_idx in range(1, min(ref_sheet.max_row + 1, 10)):
        val_a = _cell_value(ref_sheet, row_idx, 1)
        val_b = _cell_value(ref_sheet, row_idx, 2)
        if val_a and val_b:
            a_lower = str(val_a).lower()
            b_lower = str(val_b).lower()
            if "trigger" in a_lower and ("name" in b_lower or "trigger" in b_lower):
                header_row = row_idx
                break

    if header_row is None:
        # Try row 1 as default
        header_row = 1

    refs = []
    for row_idx in range(header_row + 1, ref_sheet.max_row + 1):
        trigger_id = _cell_value(ref_sheet, row_idx, 1)
        trigger_name = _cell_value(ref_sheet, row_idx, 2)

        if not trigger_id and not trigger_name:
            continue

        npe_raw = _cell_value(ref_sheet, row_idx, 3)
        s2_raw = _cell_value(ref_sheet, row_idx, 4)
        source = _cell_value(ref_sheet, row_idx, 5)
        hard_soft = _cell_value(ref_sheet, row_idx, 6)
        # Column 7 is gap
        forbearance_raw = _cell_value(ref_sheet, row_idx, 9)

        npe_trigger = _is_yes(npe_raw)
        s2_trigger = _is_yes(s2_raw)
        forbearance_measure = _is_yes(forbearance_raw)

        # Determine stage reference
        if npe_trigger and s2_trigger:
            stage_ref = "S2+S3"
        elif npe_trigger:
            stage_ref = "S3"
        elif s2_trigger:
            stage_ref = "S2"
        else:
            stage_ref = "S2"

        refs.append({
            "trigger_id": str(trigger_id) if trigger_id else "",
            "trigger_name": str(trigger_name) if trigger_name else "",
            "npe_trigger": npe_trigger,
            "s2_trigger": s2_trigger,
            "stage_ref": stage_ref,
            "source": str(source) if source else "",
            "hard_soft": str(hard_soft) if hard_soft else "Soft",
            "forbearance_measure": forbearance_measure,
        })

    return refs


def _find_reference(ref_data: list[dict], trigger_text: str) -> Optional[dict]:
    """Find the best matching reference entry for a trigger text (fuzzy)."""
    if not ref_data or not trigger_text:
        return None

    trigger_lower = trigger_text.lower().strip()
    trigger_words = set(trigger_lower.split())

    best_match = None
    best_score = 0

    for ref in ref_data:
        ref_name = ref.get("trigger_name", "").lower().strip()
        if not ref_name:
            continue

        # Exact match
        if trigger_lower == ref_name:
            return ref

        # Word overlap score
        ref_words = set(ref_name.split())
        if not ref_words:
            continue
        overlap = len(trigger_words & ref_words)
        score = overlap / max(len(trigger_words), len(ref_words))

        # Substring match bonus
        if ref_name in trigger_lower or trigger_lower in ref_name:
            score += 0.3

        if score > best_score and score > 0.3:
            best_score = score
            best_match = ref

    return best_match


def _cell_value(ws, row: int, col: int):
    """Get cell value, handling None and empty strings."""
    cell = ws.cell(row=row, column=col)
    val = cell.value
    if val is None:
        return None
    if isinstance(val, str) and val.strip() == "":
        return None
    return val


def _is_yes(value) -> bool:
    """Check if a cell value represents 'Yes'."""
    if value is None:
        return False
    return str(value).strip().lower() in ("yes", "y", "true", "1", "x")
