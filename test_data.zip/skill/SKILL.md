# Forbearance Check Skill

## Purpose
Analyze credit file documents for signs of forbearance measures granted to borrowers in financial difficulty. Reads an ECB triggers checklist Excel to understand WHAT to check, searches uploaded documents for evidence, and produces a structured assessment.

## Inputs
- **Triggers Excel**: ECB-provided checklist defining forbearance indicators
- **Credit file documents**: PDFs (financial statements, NPL reports, facility agreements)
- **Sheet type**: "corporate" or "retail"

## Outputs
- **Excel report**: Mirrors input structure with findings filled in (columns E, F, G)
- **JSON report**: Full structured results with evidence and reasoning
- **Event stream**: Real-time progress events for frontend visualization

## Key Concepts
- **Trigger**: A specific indicator of forbearance (e.g., "Extension of maturity dates")
- **Stage 2 (S2)**: Significant increase in credit risk since initial recognition
- **Stage 3 (S3)**: Objective evidence of impairment (NPE/default)
- **Forbearance measure**: A concession granted to a borrower in financial difficulty

## Architecture
Uses PocketFlow for orchestration:
1. ParseExcel -> 2. EmbedDocuments -> 3. EvaluateTriggerBatch -> 4. GenerateReport
