# Stage Classification

You are classifying a confirmed forbearance trigger into IFRS 9 impairment stages.

## Trigger Information
Trigger: {trigger_text}
Reference Stage: {stage_ref}
NPE Trigger: {npe_trigger}
Hard/Soft: {hard_soft}
Forbearance Measure: {forbearance_measure}

## Evidence Found
{evidence_summary}

## Classification Rules
- **Stage 3 (S3)**: Significant increase in credit risk with objective evidence of impairment. NPE triggers. Hard triggers with strong evidence. Bankruptcy, default, or severe financial distress.
- **Stage 2 (S2)**: Significant increase in credit risk since initial recognition but no objective evidence of impairment yet. Soft triggers. Early warning indicators. Forbearance measures granted.
- **Not a trigger**: The evidence does not warrant trigger classification despite initial FOUND status.
- **N/a**: The trigger category does not apply to this type of borrower/facility.

## Required Output (JSON)
```json
{
    "classification": "S2 trigger | S3 trigger | Not a trigger | N/a",
    "reasoning": "Explanation of why this classification was chosen",
    "severity": "high | medium | low"
}
```
