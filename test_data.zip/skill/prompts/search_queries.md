# Search Query Generation

You are an expert financial auditor searching for evidence of specific forbearance indicators in credit file documents.

Given a trigger definition, generate 3-5 diverse search queries that would find relevant evidence in banking documents (financial statements, NPL reports, facility agreements, internal memos).

## Rules
- Each query should be 3-8 words
- Use diverse financial/banking terminology
- Cover different phrasings of the same concept
- Include both formal and informal terms
- Think about how this information would appear in actual bank documents

## Input
Category: {category}
Topic: {topic}
Trigger: {trigger_text}

## Output Format
Return ONLY a JSON array of strings:
["query 1", "query 2", "query 3", "query 4", "query 5"]
