"""PDF text extraction and chunking for ChromaDB ingestion."""

import os
import fitz  # PyMuPDF


def extract_and_chunk_pdfs(documents_dir: str, chunk_size: int = 1000,
                           overlap: int = 200) -> list[dict]:
    """
    Extract text from all PDFs in a directory and chunk them.

    Args:
        documents_dir: Directory containing PDF files
        chunk_size: Target characters per chunk
        overlap: Character overlap between chunks

    Returns:
        List of chunk dicts with keys: text, filename, page, chunk_index
    """
    all_chunks = []
    doc_metadata = []

    if not os.path.isdir(documents_dir):
        return all_chunks

    for filename in sorted(os.listdir(documents_dir)):
        if not filename.lower().endswith(".pdf"):
            continue

        filepath = os.path.join(documents_dir, filename)
        pages_text = extract_pdf_text(filepath)

        doc_chunks = chunk_pages(pages_text, filename, chunk_size, overlap)
        all_chunks.extend(doc_chunks)

        doc_metadata.append({
            "filename": filename,
            "pages": len(pages_text),
            "chunks": len(doc_chunks),
            "doc_type": _guess_doc_type(filename),
        })

    return all_chunks


def extract_pdf_text(filepath: str) -> list[dict]:
    """
    Extract text from a PDF file, page by page.

    Returns:
        List of dicts: [{"page": 1, "text": "..."}, ...]
    """
    pages = []
    doc = fitz.open(filepath)
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text")
        if text.strip():
            pages.append({"page": page_num + 1, "text": text})
    doc.close()
    return pages


def chunk_pages(pages_text: list[dict], filename: str,
                chunk_size: int = 1000, overlap: int = 200) -> list[dict]:
    """
    Chunk extracted page text into overlapping segments.
    Tries to break at sentence boundaries.
    """
    chunks = []
    chunk_index = 0

    for page_data in pages_text:
        page_num = page_data["page"]
        text = page_data["text"]

        if len(text) <= chunk_size:
            chunks.append({
                "text": text.strip(),
                "filename": filename,
                "page": page_num,
                "chunk_index": chunk_index,
            })
            chunk_index += 1
            continue

        # Split into overlapping chunks at sentence boundaries
        start = 0
        while start < len(text):
            end = start + chunk_size

            if end < len(text):
                # Try to find a sentence boundary near the end
                boundary = _find_sentence_boundary(text, end, chunk_size)
                if boundary > start:
                    end = boundary

            chunk_text = text[start:end].strip()
            if chunk_text:
                chunks.append({
                    "text": chunk_text,
                    "filename": filename,
                    "page": page_num,
                    "chunk_index": chunk_index,
                })
                chunk_index += 1

            start = end - overlap
            if start < 0:
                start = 0
            # Prevent infinite loop
            if end >= len(text):
                break

    return chunks


def _find_sentence_boundary(text: str, position: int, chunk_size: int) -> int:
    """Find the nearest sentence boundary (., !, ?) near the given position."""
    # Look backwards from position for a sentence-ending punctuation
    search_range = min(200, chunk_size // 4)
    for i in range(position, max(position - search_range, 0), -1):
        if i < len(text) and text[i] in ".!?\n" and (i + 1 >= len(text) or text[i + 1] in " \n\t"):
            return i + 1
    return position


def _guess_doc_type(filename: str) -> str:
    """Guess document type from filename."""
    lower = filename.lower()
    if "npl" in lower or "vermerk" in lower:
        return "npl_report"
    elif "facility" in lower or "agreement" in lower:
        return "facility_agreement"
    elif "financial" in lower or "statement" in lower:
        return "financial_statement"
    elif "covenant" in lower:
        return "covenant_report"
    else:
        return "other"


def get_document_metadata(documents_dir: str) -> list[dict]:
    """Get metadata about PDFs without chunking them."""
    metadata = []
    if not os.path.isdir(documents_dir):
        return metadata

    for filename in sorted(os.listdir(documents_dir)):
        if not filename.lower().endswith(".pdf"):
            continue
        filepath = os.path.join(documents_dir, filename)
        doc = fitz.open(filepath)
        metadata.append({
            "filename": filename,
            "pages": len(doc),
            "doc_type": _guess_doc_type(filename),
        })
        doc.close()
    return metadata
