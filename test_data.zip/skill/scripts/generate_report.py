"""Excel + JSON report generation from trigger evaluation results."""

import json
import os
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side


# Color definitions
FILL_FOUND = PatternFill(start_color="FFE0E0", end_color="FFE0E0", fill_type="solid")       # Light red
FILL_NOT_FOUND = PatternFill(start_color="E0FFE0", end_color="E0FFE0", fill_type="solid")   # Light green
FILL_INCONCLUSIVE = PatternFill(start_color="FFF3E0", end_color="FFF3E0", fill_type="solid") # Light amber
FILL_HEADER = PatternFill(start_color="26890D", end_color="26890D", fill_type="solid")       # Deloitte green
FILL_SUMMARY_HEADER = PatternFill(start_color="86BC25", end_color="86BC25", fill_type="solid")

FONT_HEADER = Font(bold=True, color="FFFFFF", size=11)
FONT_BOLD = Font(bold=True, size=10)
FONT_NORMAL = Font(size=10)

THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)


def generate_excel_report(triggers: list[dict], results: list[dict],
                          output_path: str, sheet_type: str = "corporate") -> str:
    """
    Generate an Excel report mirroring the input structure with findings.

    Args:
        triggers: List of trigger definitions
        results: List of trigger evaluation results (same order)
        output_path: Path to write the Excel file
        sheet_type: "corporate" or "retail"

    Returns:
        Path to the generated Excel file
    """
    wb = Workbook()

    # Create findings sheet
    ws = wb.active
    ws.title = f"Findings {sheet_type.title()}"
    _write_findings_sheet(ws, triggers, results)

    # Create summary sheet
    ws_summary = wb.create_sheet("Summary", 0)
    _write_summary_sheet(ws_summary, triggers, results)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    wb.save(output_path)
    wb.close()
    return output_path


def _write_findings_sheet(ws, triggers: list[dict], results: list[dict]):
    """Write the main findings sheet."""
    # Headers
    headers = [
        "Category", "Topic", "Trigger", "Reported Value",
        "Validated / Revised Value", "Stage Classification",
        "Comment", "", "Status", "Confidence", "Key Evidence"
    ]

    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = FILL_HEADER
        cell.font = FONT_HEADER
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal="center", wrap_text=True)

    # Set column widths
    col_widths = [18, 18, 45, 20, 25, 20, 45, 3, 14, 12, 50]
    for i, width in enumerate(col_widths, 1):
        ws.column_dimensions[chr(64 + i) if i <= 26 else chr(64 + (i - 1) // 26) + chr(64 + (i - 1) % 26 + 1)].width = width

    # Data rows
    for row_idx, (trigger, result) in enumerate(zip(triggers, results), 2):
        status = result.get("status", "NOT_FOUND")

        # Pick the row fill based on status
        if status == "FOUND":
            fill = FILL_FOUND
        elif status == "INCONCLUSIVE":
            fill = FILL_INCONCLUSIVE
        else:
            fill = FILL_NOT_FOUND

        row_data = [
            trigger.get("category", ""),
            trigger.get("topic", ""),
            trigger.get("trigger_text", ""),
            trigger.get("reported_value", ""),
            result.get("validated_value", ""),
            result.get("stage_classification", ""),
            result.get("comment", ""),
            "",  # gap column
            status,
            result.get("confidence", 0),
            _get_key_evidence_text(result),
        ]

        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.fill = fill
            cell.font = FONT_NORMAL
            cell.border = THIN_BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    # Freeze header row
    ws.freeze_panes = "A2"


def _write_summary_sheet(ws, triggers: list[dict], results: list[dict]):
    """Write the summary sheet with aggregated counts."""
    total = len(results)
    found = sum(1 for r in results if r.get("status") == "FOUND")
    not_found = sum(1 for r in results if r.get("status") == "NOT_FOUND")
    inconclusive = sum(1 for r in results if r.get("status") == "INCONCLUSIVE")
    s2 = sum(1 for r in results if r.get("stage_classification") == "S2 trigger")
    s3 = sum(1 for r in results if r.get("stage_classification") == "S3 trigger")

    # Title
    cell = ws.cell(row=1, column=1, value="Forbearance Check Summary")
    cell.font = Font(bold=True, size=14)
    ws.merge_cells("A1:C1")

    # Summary table
    summary_data = [
        ("Total triggers evaluated", total),
        ("FOUND", found),
        ("NOT FOUND", not_found),
        ("INCONCLUSIVE", inconclusive),
        ("", ""),
        ("Stage 2 triggers", s2),
        ("Stage 3 triggers", s3),
    ]

    for row_idx, (label, value) in enumerate(summary_data, 3):
        label_cell = ws.cell(row=row_idx, column=1, value=label)
        label_cell.font = FONT_BOLD
        label_cell.border = THIN_BORDER

        value_cell = ws.cell(row=row_idx, column=2, value=value)
        value_cell.font = FONT_NORMAL
        value_cell.border = THIN_BORDER
        value_cell.alignment = Alignment(horizontal="center")

        if label == "FOUND":
            value_cell.fill = FILL_FOUND
        elif label == "NOT FOUND":
            value_cell.fill = FILL_NOT_FOUND
        elif label == "INCONCLUSIVE":
            value_cell.fill = FILL_INCONCLUSIVE

    # Category breakdown
    row_start = len(summary_data) + 5
    ws.cell(row=row_start, column=1, value="Findings by Category").font = Font(bold=True, size=12)

    categories = {}
    for trigger, result in zip(triggers, results):
        cat = trigger.get("category", "Unknown")
        if cat not in categories:
            categories[cat] = {"total": 0, "found": 0}
        categories[cat]["total"] += 1
        if result.get("status") == "FOUND":
            categories[cat]["found"] += 1

    headers = ["Category", "Total Triggers", "Found"]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=row_start + 1, column=col_idx, value=header)
        cell.fill = FILL_SUMMARY_HEADER
        cell.font = FONT_HEADER
        cell.border = THIN_BORDER

    for i, (cat, counts) in enumerate(categories.items(), row_start + 2):
        ws.cell(row=i, column=1, value=cat).border = THIN_BORDER
        ws.cell(row=i, column=2, value=counts["total"]).border = THIN_BORDER
        found_cell = ws.cell(row=i, column=3, value=counts["found"])
        found_cell.border = THIN_BORDER
        if counts["found"] > 0:
            found_cell.fill = FILL_FOUND

    # Column widths
    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 18


def _get_key_evidence_text(result: dict) -> str:
    """Extract the key evidence text from a result."""
    evidence = result.get("evidence", [])
    if evidence:
        top = evidence[0]
        return f"[{top.get('document', '?')} p.{top.get('page', '?')}] {top.get('text', '')[:200]}"
    return ""


def generate_json_report(triggers: list[dict], results: list[dict],
                         output_path: str) -> str:
    """
    Generate a JSON report with full structured results.

    Args:
        triggers: List of trigger definitions
        results: List of trigger evaluation results
        output_path: Path to write the JSON file

    Returns:
        Path to the generated JSON file
    """
    total = len(results)
    found = sum(1 for r in results if r.get("status") == "FOUND")
    not_found = sum(1 for r in results if r.get("status") == "NOT_FOUND")
    inconclusive = sum(1 for r in results if r.get("status") == "INCONCLUSIVE")
    s2 = sum(1 for r in results if r.get("stage_classification") == "S2 trigger")
    s3 = sum(1 for r in results if r.get("stage_classification") == "S3 trigger")

    report = {
        "summary": {
            "total_triggers": total,
            "found": found,
            "not_found": not_found,
            "inconclusive": inconclusive,
            "s2_triggers": s2,
            "s3_triggers": s3,
        },
        "triggers": [
            {
                "trigger": trigger,
                "result": result,
            }
            for trigger, result in zip(triggers, results)
        ],
    }

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str, ensure_ascii=False)

    return output_path
