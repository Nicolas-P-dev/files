"""ChromaDB query utility for document retrieval."""

import chromadb
from chromadb.config import Settings


def get_chroma_client(persist_dir: str = "./chroma_db") -> chromadb.ClientAPI:
    """Get or create a ChromaDB persistent client."""
    return chromadb.PersistentClient(path=persist_dir)


def get_or_create_collection(client: chromadb.ClientAPI,
                             collection_name: str) -> chromadb.Collection:
    """Get or create a ChromaDB collection."""
    return client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )


def add_chunks_to_collection(collection: chromadb.Collection,
                             chunks: list[dict]) -> int:
    """
    Add document chunks to a ChromaDB collection.

    Args:
        collection: ChromaDB collection
        chunks: List of chunk dicts with keys: text, filename, page, chunk_index

    Returns:
        Number of chunks added
    """
    if not chunks:
        return 0

    ids = []
    documents = []
    metadatas = []

    for i, chunk in enumerate(chunks):
        chunk_id = f"{chunk['filename']}_{chunk['page']}_{chunk['chunk_index']}"
        ids.append(chunk_id)
        documents.append(chunk["text"])
        metadatas.append({
            "filename": chunk["filename"],
            "page": chunk["page"],
            "chunk_index": chunk["chunk_index"],
        })

    # Add in batches (ChromaDB limit)
    batch_size = 500
    for start in range(0, len(ids), batch_size):
        end = start + batch_size
        collection.add(
            ids=ids[start:end],
            documents=documents[start:end],
            metadatas=metadatas[start:end],
        )

    return len(ids)


def query_collection(collection: chromadb.Collection,
                     query_text: str,
                     n_results: int = 5) -> list[dict]:
    """
    Query a ChromaDB collection and return ranked results.

    Args:
        collection: ChromaDB collection
        query_text: Search query string
        n_results: Number of results to return

    Returns:
        List of result dicts with keys: text, document, page, relevance_score, chunk_id
    """
    try:
        results = collection.query(
            query_texts=[query_text],
            n_results=n_results,
        )
    except Exception:
        return []

    parsed = []
    if not results or not results.get("documents"):
        return parsed

    documents = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0] if results.get("distances") else [0.0] * len(documents)
    ids = results["ids"][0]

    for doc, meta, dist, chunk_id in zip(documents, metadatas, distances, ids):
        # ChromaDB returns distances; convert to similarity score
        # For cosine distance: similarity = 1 - distance
        similarity = max(0.0, 1.0 - dist)
        parsed.append({
            "text": doc,
            "document": meta.get("filename", ""),
            "page": meta.get("page", 0),
            "relevance_score": round(similarity, 4),
            "chunk_id": chunk_id,
        })

    return parsed


def multi_query_search(collection: chromadb.Collection,
                       queries: list[str],
                       n_results_per_query: int = 5,
                       max_total: int = 10) -> list[dict]:
    """
    Run multiple queries and return deduplicated, ranked results.

    Args:
        collection: ChromaDB collection
        queries: List of search query strings
        n_results_per_query: Results per individual query
        max_total: Maximum total unique results to return

    Returns:
        Deduplicated list of result dicts, sorted by relevance_score
    """
    seen_ids = set()
    all_results = []

    for query in queries:
        results = query_collection(collection, query, n_results_per_query)
        for r in results:
            cid = r["chunk_id"]
            if cid not in seen_ids:
                seen_ids.add(cid)
                all_results.append(r)

    # Sort by relevance score descending
    all_results.sort(key=lambda x: x["relevance_score"], reverse=True)

    return all_results[:max_total]


def collection_exists(client: chromadb.ClientAPI, name: str) -> bool:
    """Check if a collection already exists."""
    try:
        existing = client.list_collections()
        # In newer chromadb versions, list_collections returns names
        if isinstance(existing, list):
            if len(existing) > 0:
                if hasattr(existing[0], 'name'):
                    return any(c.name == name for c in existing)
                else:
                    return name in existing
        return False
    except Exception:
        return False
