"""WebSocket event bridge for real-time progress streaming."""

import asyncio
from fastapi import WebSocket
from utils.events import EventEmitter, AgentEvent


class WebSocketEventBridge:
    """
    Bridges EventEmitter to WebSocket connections.
    When an event fires, it's immediately pushed to all connected clients.
    """

    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, event: AgentEvent):
        """Send event to all connected WebSocket clients."""
        message = event.to_json()
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception:
                disconnected.append(connection)

        for conn in disconnected:
            self.disconnect(conn)

    def create_subscriber(self, loop: asyncio.AbstractEventLoop):
        """Create a sync callback that schedules async broadcast."""
        def sync_callback(event: AgentEvent):
            asyncio.run_coroutine_threadsafe(self.broadcast(event), loop)
        return sync_callback
