"""FastAPI server with REST endpoints and WebSocket for real-time events."""

import os
import uuid
import asyncio
import threading
import shutil
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from flow.forbearance_flow import create_forbearance_flow
from utils.events import EventEmitter
from utils.console_logger import console_subscriber
from utils.llm import MockLLM
from utils.config import Config
from api.websocket import WebSocketEventBridge

app = FastAPI(title="Forbearance Check Skill", version="0.1.0")

# In-memory store of active/completed runs
runs: dict[str, dict] = {}

# WebSocket bridge
ws_bridge = WebSocketEventBridge()

# Upload directory
UPLOAD_DIR = "./uploads"


def save_upload(upload_file: UploadFile, run_id: str) -> str:
    """Save an uploaded file and return the path."""
    run_dir = os.path.join(UPLOAD_DIR, run_id)
    os.makedirs(run_dir, exist_ok=True)
    file_path = os.path.join(run_dir, upload_file.filename)
    with open(file_path, "wb") as f:
        content = upload_file.file.read()
        f.write(content)
    upload_file.file.seek(0)
    return file_path


def get_docs_dir(run_id: str) -> str:
    """Get the documents directory for a run."""
    docs_dir = os.path.join(UPLOAD_DIR, run_id, "documents")
    os.makedirs(docs_dir, exist_ok=True)
    return docs_dir


@app.post("/api/run")
async def run_forbearance_check(
    excel_file: UploadFile = File(...),
    sheet_type: str = Form("corporate"),
    documents: list[UploadFile] = File(default=[]),
):
    """
    Start a forbearance check run.
    Returns a run_id for tracking progress via WebSocket.
    """
    run_id = str(uuid.uuid4())[:8]

    # Save uploaded files
    excel_path = save_upload(excel_file, run_id)
    docs_dir = get_docs_dir(run_id)
    for doc in documents:
        if doc.filename:
            doc_path = os.path.join(docs_dir, doc.filename)
            with open(doc_path, "wb") as f:
                f.write(doc.file.read())
            doc.file.seek(0)

    # Create event emitter and shared store
    config = Config.from_env()
    emitter = EventEmitter()
    emitter.subscribe(console_subscriber)

    # Add WebSocket subscriber
    try:
        loop = asyncio.get_running_loop()
        emitter.subscribe(ws_bridge.create_subscriber(loop))
    except RuntimeError:
        pass

    llm = MockLLM()

    shared = {
        "excel_path": excel_path,
        "sheet_type": sheet_type,
        "documents_dir": docs_dir,
        "debtor_id": f"run_{run_id}",
        "reference_year": 2023,
        "emitter": emitter,
        "event_log": [],
        "config": config,
        "llm": llm,
    }

    runs[run_id] = {
        "status": "running",
        "shared": shared,
        "emitter": emitter,
    }

    # Run flow in background thread
    def execute():
        try:
            emitter.emit("flow_started")
            flow = create_forbearance_flow()
            flow.run(shared)
            emitter.emit("flow_completed")
            runs[run_id]["status"] = "completed"
        except Exception as e:
            runs[run_id]["status"] = "error"
            runs[run_id]["error"] = str(e)
            emitter.emit("flow_error", error=str(e))

    thread = threading.Thread(target=execute, daemon=True)
    thread.start()

    return {"run_id": run_id, "status": "started"}


@app.get("/api/runs/{run_id}/status")
async def get_run_status(run_id: str):
    """Get current status of a run."""
    if run_id not in runs:
        return JSONResponse({"error": "Run not found"}, status_code=404)

    run = runs[run_id]
    response = {"run_id": run_id, "status": run["status"]}

    if run["status"] == "error":
        response["error"] = run.get("error", "Unknown error")

    if run["status"] == "completed":
        shared = run["shared"]
        if "report" in shared:
            response["summary"] = shared["report"].get("summary", {})

    return response


@app.get("/api/runs/{run_id}/events")
async def get_run_events(run_id: str, since: float = 0):
    """Get events since a timestamp (for polling fallback)."""
    if run_id not in runs:
        return JSONResponse({"error": "Run not found"}, status_code=404)

    emitter = runs[run_id]["emitter"]
    events = emitter.get_events_since(since)
    return {"run_id": run_id, "events": events}


@app.get("/api/runs/{run_id}/results")
async def get_run_results(run_id: str):
    """Get final results of a completed run."""
    if run_id not in runs:
        return JSONResponse({"error": "Run not found"}, status_code=404)

    run = runs[run_id]
    if run["status"] != "completed":
        return JSONResponse(
            {"error": f"Run not completed (status: {run['status']})"},
            status_code=400,
        )

    shared = run["shared"]
    return {
        "run_id": run_id,
        "report": shared.get("report", {}),
        "results": shared.get("results", []),
        "triggers": shared.get("triggers", []),
    }


@app.get("/api/runs/{run_id}/report")
async def download_report(run_id: str, format: str = "excel"):
    """Download the generated report (Excel or JSON)."""
    if run_id not in runs:
        return JSONResponse({"error": "Run not found"}, status_code=404)

    run = runs[run_id]
    if run["status"] != "completed":
        return JSONResponse(
            {"error": f"Run not completed (status: {run['status']})"},
            status_code=400,
        )

    shared = run["shared"]
    report = shared.get("report", {})

    if format == "json":
        path = report.get("json_output_path")
        media_type = "application/json"
    else:
        path = report.get("excel_output_path")
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    if not path or not os.path.exists(path):
        return JSONResponse({"error": "Report file not found"}, status_code=404)

    return FileResponse(path, media_type=media_type, filename=os.path.basename(path))


@app.websocket("/ws/{run_id}")
async def websocket_endpoint(websocket: WebSocket, run_id: str):
    """WebSocket for real-time event streaming."""
    await ws_bridge.connect(websocket)

    try:
        # Send any existing events for this run
        if run_id in runs:
            emitter = runs[run_id]["emitter"]
            for event_dict in emitter.get_log():
                await websocket.send_text(
                    __import__("json").dumps(event_dict, default=str)
                )

        # Keep connection alive
        while True:
            try:
                await websocket.receive_text()
            except WebSocketDisconnect:
                break
    finally:
        ws_bridge.disconnect(websocket)


# Mount test frontend
frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "test_frontend")
if os.path.isdir(frontend_dir):
    app.mount("/test", StaticFiles(directory=frontend_dir, html=True), name="test")
