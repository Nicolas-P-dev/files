from dataclasses import dataclass, field
from typing import Optional
import os


@dataclass
class Config:
    """Configuration for the forbearance skill. All values have sensible defaults."""

    # LLM settings
    llm_provider: str = "mock"          # "mock" or "azure"
    llm_temperature: float = 0.1
    llm_max_tokens: int = 2000

    # Azure OpenAI (only needed when llm_provider="azure")
    azure_endpoint: Optional[str] = None
    azure_api_key: Optional[str] = None
    azure_deployment: str = "gpt-4o"
    azure_api_version: str = "2024-02-15-preview"

    # Embedding settings
    embedding_provider: str = "mock"    # "mock" or "azure" or "sentence-transformers"
    embedding_model: str = "text-embedding-ada-002"

    # ChromaDB settings
    chroma_persist_dir: str = "./chroma_db"
    chroma_collection_prefix: str = "forbearance"

    # Document processing
    chunk_size: int = 1000
    chunk_overlap: int = 200
    max_chunks_per_query: int = 5
    max_chunks_per_trigger: int = 10

    # Search settings
    num_search_queries: int = 5

    # Output settings
    output_dir: str = "./output"

    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000

    @classmethod
    def from_env(cls) -> "Config":
        """Load config from environment variables where available."""
        return cls(
            llm_provider=os.getenv("LLM_PROVIDER", "mock"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            azure_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
            embedding_provider=os.getenv("EMBEDDING_PROVIDER", "mock"),
            chroma_persist_dir=os.getenv("CHROMA_PERSIST_DIR", "./chroma_db"),
            output_dir=os.getenv("OUTPUT_DIR", "./output"),
        )
