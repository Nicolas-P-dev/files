from abc import ABC, abstractmethod
import json
import random
import time
import hashlib
import re


class LLMInterface(ABC):
    """Abstract LLM interface. All LLM calls go through this."""

    @abstractmethod
    def call(self, prompt: str, system_prompt: str = "", temperature: float = 0.1,
             json_mode: bool = False) -> str:
        """Send a prompt and get a response string."""
        pass

    @abstractmethod
    def call_structured(self, prompt: str, system_prompt: str = "",
                        temperature: float = 0.1) -> dict:
        """Send a prompt and get a parsed JSON dict back."""
        pass


# ====================================================================
# Keyword mapping: trigger topics -> terms that would appear in docs
# ====================================================================
TRIGGER_KEYWORDS = {
    "interest rate": [
        "interest rate", "rate reduced", "rate reduction", "below market",
        "coupon", "margin", "euribor", "rate modification", "rate change",
    ],
    "maturity": [
        "maturity", "extended", "extension", "prolongation", "original maturity",
        "maturity date", "repayment schedule", "amended maturity", "term extension",
    ],
    "payment": [
        "payment holiday", "moratorium", "payment schedule", "payment suspension",
        "installment", "amortization", "payment deferral", "grace period",
    ],
    "principal": [
        "write-off", "principal reduction", "debt forgiveness", "write down",
        "haircut", "principal forgiveness",
    ],
    "debt conversion": [
        "debt to equity", "conversion", "subordinated", "debt swap",
        "converted to", "instrument conversion",
    ],
    "additional facility": [
        "bridge facility", "additional credit", "additional facility",
        "working capital", "shortfall", "cash shortfall", "new facility",
    ],
    "past due": [
        "past due", "days past due", "overdue", "arrears", "late payment",
        "instalment", "non-payment", "delinquent",
    ],
    "covenant": [
        "covenant", "breach", "waiver", "dscr", "debt service coverage",
        "leverage ratio", "financial ratio", "non-compliance", "threshold",
    ],
    "credit rating": [
        "credit rating", "downgrade", "downgraded", "rating", "notch",
        "internal rating", "rating migration", "risk classification",
    ],
    "cash flow": [
        "cash flow", "insufficient", "deficit", "operating cash",
        "debt service", "cash shortfall", "liquidity",
    ],
    "going concern": [
        "going concern", "audit", "auditor", "material uncertainty",
        "significant doubt", "ability to continue",
    ],
    "bankruptcy": [
        "bankruptcy", "insolvency", "liquidation", "winding", "petition",
        "insolvency proceedings",
    ],
    "cross-default": [
        "cross-default", "cross default", "default on other", "syndicated",
        "non-payment", "other obligations",
    ],
    "collateral": [
        "collateral", "security", "loan-to-value", "ltv", "property value",
        "valuation", "collateral shortfall", "impairment",
    ],
    "refinancing": [
        "refinancing", "refinanced", "rollover", "renewal", "below-market",
        "non-market conditions",
    ],
    "forbearance flag": [
        "forborne", "forbearance flag", "flagged", "forbearance status",
        "bank system", "core banking",
    ],
    "restructuring": [
        "restructuring", "workout", "restructuring plan", "reorganization",
        "milestone", "cost reduction", "divestiture",
    ],
}


def _get_topic_keywords(topic: str) -> list[str]:
    """Get keywords for a trigger topic."""
    topic_lower = topic.lower().strip()
    for key, keywords in TRIGGER_KEYWORDS.items():
        if key in topic_lower or topic_lower in key:
            return keywords
    # Fallback: split topic into individual words
    return [w.lower() for w in topic.split() if len(w) > 3]


class MockLLM(LLMInterface):
    """
    Content-aware Mock LLM. Parses evidence chunks from prompts and does
    keyword matching against trigger text to produce realistic results
    that correlate with actual document content.
    """

    def _seed_from(self, text: str) -> int:
        return int(hashlib.md5(text.encode()).hexdigest()[:8], 16)

    def call(self, prompt: str, system_prompt: str = "", temperature: float = 0.1,
             json_mode: bool = False) -> str:
        # Simulate latency (shorter now for iterative search)
        time.sleep(random.uniform(0.1, 0.5))

        lower = prompt.lower()

        # Route to appropriate handler based on prompt content
        # Note: reevaluate must be checked before evaluate (substring overlap)
        if "plan search" in lower or ("search quer" in lower and "generate" in lower):
            return self._mock_plan_search(prompt)
        elif "refine search" in lower or "refinement" in lower:
            return self._mock_refine_search(prompt)
        elif "re-evaluate" in lower or "reevaluat" in lower:
            return self._mock_reevaluate(prompt)
        elif "evaluate" in lower and ("evidence" in lower or "trigger" in lower):
            return self._mock_evidence_eval(prompt)
        elif "classify" in lower and "stage" in lower:
            return self._mock_stage_classification(prompt)
        elif "synthesize" in lower or "cross-trigger" in lower:
            return self._mock_synthesize(prompt)
        else:
            return self._mock_plan_search(prompt)

    def call_structured(self, prompt: str, system_prompt: str = "",
                        temperature: float = 0.1) -> dict:
        response = self.call(prompt, system_prompt, temperature, json_mode=True)
        try:
            return json.loads(response)
        except (json.JSONDecodeError, TypeError):
            return {"status": "NOT_FOUND", "confidence": 0.5,
                    "reasoning": "Mock LLM parse error", "validated_value": "Error"}

    def _extract_field(self, prompt: str, field: str) -> str:
        """Extract a field value from a prompt like 'Trigger: some text here'."""
        pattern = rf"{field}:\s*(.+?)(?:\n|$)"
        match = re.search(pattern, prompt, re.IGNORECASE)
        return match.group(1).strip() if match else ""

    def _extract_chunks_text(self, prompt: str) -> str:
        """Extract the document excerpts section from the prompt."""
        # Look for chunks between "Excerpt" markers or after "Document Excerpts"
        match = re.search(
            r"(?:Document Excerpts|Excerpt\s*1)(.+?)(?:##|Search effort|$)",
            prompt, re.DOTALL | re.IGNORECASE,
        )
        return match.group(1) if match else ""

    def _calculate_evidence_score(self, trigger_text: str, topic: str,
                                   chunks_text: str) -> tuple[float, str, str, int]:
        """
        Calculate how well the chunks match the trigger.
        Returns: (score, best_quote, best_doc, best_page)
        """
        if not chunks_text or "(No relevant" in chunks_text:
            return 0.0, "", "", 0

        chunks_lower = chunks_text.lower()
        keywords = _get_topic_keywords(topic)

        # Also extract keywords directly from trigger text
        trigger_words = [
            w.lower().rstrip(".,;:")
            for w in trigger_text.split()
            if len(w) > 3 and w.lower() not in (
                "the", "and", "for", "with", "from", "that", "this",
                "been", "have", "has", "not", "any", "are", "was",
                "which", "more", "than", "other", "below", "beyond",
            )
        ]
        all_keywords = list(set(keywords + trigger_words))

        # Count keyword hits
        hits = 0
        total = len(all_keywords)
        for kw in all_keywords:
            if kw in chunks_lower:
                hits += 1

        score = hits / max(total, 1)

        # Find the best matching chunk for evidence extraction
        best_quote = ""
        best_doc = ""
        best_page = 0

        # Parse individual chunks
        chunk_pattern = r"Source:\s*(\S+)\s*\(page\s*(\d+)\).*?Text:\s*(.+?)(?=---|\Z)"
        chunks = re.findall(chunk_pattern, chunks_text, re.DOTALL)

        best_chunk_score = 0
        for doc, page, text in chunks:
            text_lower = text.lower()
            chunk_hits = sum(1 for kw in all_keywords if kw in text_lower)
            chunk_score = chunk_hits / max(len(all_keywords), 1)

            if chunk_score > best_chunk_score:
                best_chunk_score = chunk_score
                best_doc = doc.strip()
                best_page = int(page)
                # Extract the most relevant sentence
                sentences = re.split(r'[.!?\n]', text)
                best_sentence = ""
                best_sent_hits = 0
                for sent in sentences:
                    sent = sent.strip()
                    if len(sent) < 20:
                        continue
                    sent_hits = sum(1 for kw in all_keywords if kw in sent.lower())
                    if sent_hits > best_sent_hits:
                        best_sent_hits = sent_hits
                        best_sentence = sent

                best_quote = best_sentence[:250] if best_sentence else text.strip()[:250]

        return score, best_quote, best_doc, best_page

    # =================================================================
    # Handler: Plan Search
    # =================================================================
    def _mock_plan_search(self, prompt: str) -> str:
        trigger_text = self._extract_field(prompt, "Trigger")
        topic = self._extract_field(prompt, "Topic")
        category = self._extract_field(prompt, "Category")

        words = trigger_text.split() if trigger_text else ["loan", "modification"]
        keywords = _get_topic_keywords(topic) if topic else ["loan"]

        synonyms = {
            "reduction": ["decrease", "lowering", "cut"],
            "extension": ["prolongation", "lengthening", "deferral"],
            "modification": ["amendment", "change", "alteration"],
            "maturity": ["term", "repayment date", "due date"],
            "interest": ["rate", "coupon", "margin"],
            "payment": ["installment", "repayment", "amortization"],
            "covenant": ["condition", "financial ratio", "compliance"],
            "breach": ["violation", "non-compliance", "default"],
            "waiver": ["concession", "forbearance", "exemption"],
            "restructuring": ["reorganization", "workout", "rescheduling"],
            "collateral": ["security", "pledge", "guarantee"],
            "refinancing": ["rollover", "renewal", "replacement"],
            "bankruptcy": ["insolvency", "liquidation", "winding-up"],
            "default": ["non-performance", "failure to pay", "arrears"],
        }

        queries = []
        # Query 1: core trigger terms
        queries.append(" ".join(words[:6]))

        # Query 2: domain keywords
        if keywords:
            queries.append(" ".join(keywords[:4]))

        # Query 3-5: synonym expansions
        for w in words[:5]:
            wl = w.lower().rstrip(".,;:")
            if wl in synonyms:
                alt = random.choice(synonyms[wl])
                new_words = [alt if x.lower().rstrip(".,;:") == wl else x for x in words[:5]]
                queries.append(" ".join(new_words).lower())
                if len(queries) >= 5:
                    break

        # Pad with topic-based queries
        while len(queries) < 4:
            queries.append(f"{topic.lower()} concession financial")

        # Determine target document types
        topic_lower = topic.lower() if topic else ""
        if any(x in topic_lower for x in ["covenant", "maturity", "interest", "payment"]):
            target_docs = ["facility_agreement", "npl_report"]
        elif any(x in topic_lower for x in ["cash flow", "going concern", "rating"]):
            target_docs = ["financial_statement", "npl_report"]
        else:
            target_docs = ["npl_report", "facility_agreement", "financial_statement"]

        result = {
            "queries": queries[:5],
            "target_doc_types": target_docs,
            "search_rationale": (
                f"Searching for evidence of {topic.lower()} using {len(queries[:5])} "
                f"queries combining trigger-specific terms and financial domain vocabulary. "
                f"Targeting {', '.join(target_docs)} as most likely sources."
            ),
        }
        return json.dumps(result)

    # =================================================================
    # Handler: Refine Search
    # =================================================================
    def _mock_refine_search(self, prompt: str) -> str:
        trigger_text = self._extract_field(prompt, "Trigger")
        topic = self._extract_field(prompt, "Topic")

        keywords = _get_topic_keywords(topic) if topic else []
        trigger_words = [w.lower() for w in trigger_text.split() if len(w) > 3]

        # Generate alternative queries using different strategies
        queries = []

        # Strategy 1: use the domain keywords we didn't try yet
        if keywords:
            queries.append(" ".join(keywords[2:5]) if len(keywords) > 2 else " ".join(keywords))

        # Strategy 2: indirect indicators
        indirect_map = {
            "maturity": ["amendment", "loan term change", "facility modification date"],
            "interest rate": ["margin adjustment", "rate modification", "coupon change"],
            "covenant": ["financial ratio test", "compliance certificate", "waiver letter"],
            "payment": ["deferral arrangement", "moratorium agreement", "holiday granted"],
            "cash flow": ["liquidity shortage", "debt service shortfall", "operating deficit"],
            "restructuring": ["workout plan", "turnaround strategy", "cost reduction program"],
            "going concern": ["audit qualification", "material uncertainty", "doubt ability continue"],
            "collateral": ["property revaluation", "security value decline", "LTV ratio"],
        }
        topic_lower = topic.lower() if topic else ""
        for key, indirect in indirect_map.items():
            if key in topic_lower:
                queries.extend(indirect[:2])
                break

        # Strategy 3: consequence-based search
        queries.append(f"borrower financial difficulty {topic_lower}")

        while len(queries) < 3:
            queries.append(f"credit file {topic_lower} assessment")

        result = {
            "queries": queries[:5],
            "strategy": (
                f"Refined approach: using indirect indicators and consequence-based queries "
                f"for {topic}. Broadened terminology to catch implicit references."
            ),
        }
        return json.dumps(result)

    # =================================================================
    # Handler: Evidence Evaluation (content-aware)
    # =================================================================
    def _mock_evidence_eval(self, prompt: str) -> str:
        trigger_text = self._extract_field(prompt, "Trigger")
        topic = self._extract_field(prompt, "Topic")
        chunks_text = self._extract_chunks_text(prompt)

        # Content-aware scoring: actually analyze the chunks
        score, best_quote, best_doc, best_page = self._calculate_evidence_score(
            trigger_text, topic, chunks_text,
        )

        if score >= 0.35:
            status = "FOUND"
            confidence = round(min(0.95, 0.55 + score), 2)
            key_evidence = best_quote if best_quote else f"Evidence of {topic.lower()} identified in documents"
            reasoning = (
                f"Analysis of {len(re.findall(r'Excerpt', prompt))} document excerpts reveals "
                f"clear evidence matching the trigger definition. "
                f"Key terms matched: {int(score * 100)}% keyword overlap. "
                f"The most relevant passage from {best_doc} (page {best_page}) directly "
                f"addresses the trigger: \"{key_evidence[:120]}...\""
            )
            validated = f"Yes - evidence found ({best_doc} p.{best_page})"
        elif score >= 0.15:
            status = "INCONCLUSIVE"
            confidence = round(0.3 + score, 2)
            key_evidence = best_quote[:150] if best_quote else None
            reasoning = (
                f"Partial keyword overlap ({int(score * 100)}%) detected. "
                f"The documents reference some related concepts but do not explicitly "
                f"confirm the trigger '{trigger_text[:60]}'. "
                f"{'Best matching text from ' + best_doc + ': \"' + best_quote[:80] + '...\"' if best_quote else 'No strong matching passages found.'} "
                f"Manual review recommended."
            )
            validated = "Unclear - partial evidence, requires manual review"
        else:
            status = "NOT_FOUND"
            confidence = round(max(0.6, 0.85 - score), 2)
            key_evidence = None
            reasoning = (
                f"After reviewing all document excerpts, minimal keyword overlap "
                f"({int(score * 100)}%) was found with the trigger definition. "
                f"The documents do not contain sufficient evidence to support "
                f"'{trigger_text[:60]}'. No relevant passages identified."
            )
            validated = "No - no evidence found in reviewed documents"

        result = {
            "status": status,
            "confidence": confidence,
            "reasoning": reasoning,
            "key_evidence": key_evidence,
            "source_document": best_doc if best_doc else None,
            "source_page": best_page if best_page else None,
            "validated_value": validated,
        }
        return json.dumps(result)

    # =================================================================
    # Handler: Stage Classification
    # =================================================================
    def _mock_stage_classification(self, prompt: str) -> str:
        trigger_text = self._extract_field(prompt, "Trigger")
        npe_trigger = "yes" in self._extract_field(prompt, "NPE Trigger").lower()
        hard_soft = self._extract_field(prompt, "Hard/Soft")
        stage_ref = self._extract_field(prompt, "Reference Stage")

        # Check for multiple findings context
        multiple = "multiple" in prompt.lower() or "total triggers found" in prompt.lower()
        found_count_match = re.search(r"Total triggers found.*?:\s*(\d+)", prompt)
        found_count = int(found_count_match.group(1)) if found_count_match else 0

        if npe_trigger:
            classification = "S3 trigger"
            reasoning = (
                "NPE trigger — directly maps to Stage 3 per CRR Art. 178. "
                "Objective evidence of credit impairment."
            )
            severity = "high"
        elif hard_soft.lower() == "hard":
            classification = "S3 trigger"
            reasoning = (
                "Hard trigger with confirmed evidence indicates objective impairment. "
                "Stage 3 classification per IFRS 9."
            )
            severity = "high"
        elif found_count >= 3:
            classification = "S3 trigger"
            reasoning = (
                f"Multiple forbearance indicators detected ({found_count} triggers found). "
                f"The cumulative evidence suggests severe credit deterioration — Stage 3."
            )
            severity = "high"
        elif "s3" in stage_ref.lower():
            classification = "S3 trigger"
            reasoning = f"Reference classification is {stage_ref}. Evidence supports Stage 3."
            severity = "high"
        else:
            classification = "S2 trigger"
            reasoning = (
                "Soft trigger indicating significant increase in credit risk since initial recognition. "
                "Stage 2 classification per IFRS 9 B5.5.17."
            )
            severity = "medium"

        return json.dumps({
            "classification": classification,
            "reasoning": reasoning,
            "severity": severity,
        })

    # =================================================================
    # Handler: Cross-trigger Synthesis
    # =================================================================
    def _mock_synthesize(self, prompt: str) -> str:
        # Parse results from the prompt
        found_triggers = re.findall(r"\[!\]\s*(\w[\w\s/]*?):\s*FOUND", prompt)
        inconclusive_triggers = re.findall(r"\[\?]\s*(\w[\w\s/]*?):\s*INCONCLUSIVE", prompt)

        correlations = []
        upgrade_candidates = []

        # Look for financial difficulty + concession correlation
        found_set = set(t.lower().strip() for t in found_triggers)
        inconclusive_set = set(t.lower().strip() for t in inconclusive_triggers)

        concession_cats = {"concessions", "forbearance measures"}
        difficulty_cats = {"financial difficulty indicators", "loss events"}

        has_concession = any(
            any(c in t for c in ["concession", "interest", "maturity", "payment", "principal", "forbearance"])
            for t in found_set
        )
        has_difficulty = any(
            any(c in t for c in ["difficulty", "past due", "covenant", "cash flow", "going concern", "loss"])
            for t in found_set
        )

        if has_concession and has_difficulty:
            correlations.append({
                "triggers": list(found_set)[:3],
                "relationship": "Concession granted + financial difficulty confirmed = forbearance classification",
                "impact": "strengthens",
            })

        # Identify upgrade candidates: inconclusives that are corroborated
        for inc in inconclusive_triggers:
            inc_lower = inc.lower().strip()
            # If we found related triggers, the inconclusive might be upgradable
            if has_concession or has_difficulty:
                if any(kw in inc_lower for kw in ["covenant", "maturity", "payment", "rating", "cash"]):
                    upgrade_candidates.append({
                        "trigger_id": inc.split("/")[-1].strip() if "/" in inc else inc.strip(),
                        "reason": f"Corroborated by other confirmed findings in this credit file",
                    })

        overall_risk = "high" if len(found_triggers) >= 3 else ("medium" if found_triggers else "low")
        forbearance_confirmed = has_concession and has_difficulty

        risk_narrative = ""
        if forbearance_confirmed:
            risk_narrative = (
                f"Forbearance confirmed: {len(found_triggers)} triggers found including "
                f"both concession measures and financial difficulty indicators. "
                f"The borrower exhibits clear signs of financial distress with "
                f"corresponding bank concessions."
            )
        elif found_triggers:
            risk_narrative = (
                f"{len(found_triggers)} trigger(s) found but incomplete forbearance pattern. "
                f"Evidence exists for some indicators but full forbearance classification "
                f"requires further review."
            )
        else:
            risk_narrative = (
                "No triggers found. Based on the reviewed documents, there is no "
                "evidence of forbearance measures."
            )

        return json.dumps({
            "correlations": correlations,
            "upgrade_candidates": upgrade_candidates,
            "inconsistencies": [],
            "overall_risk": overall_risk,
            "risk_narrative": risk_narrative,
            "forbearance_confirmed": forbearance_confirmed,
        })

    # =================================================================
    # Handler: Re-evaluation of inconclusives
    # =================================================================
    def _mock_reevaluate(self, prompt: str) -> str:
        initial_status = self._extract_field(prompt, "Initial assessment")
        trigger_text = self._extract_field(prompt, "Trigger")

        # Check if there's an upgrade recommendation
        has_upgrade_rec = "upgrade recommendation" in prompt.lower()
        has_confirmed_findings = "confirmed findings" in prompt.lower() and "[" not in self._extract_field(prompt, "Confirmed findings") if "none" not in prompt.lower() else False

        # Count confirmed findings in context
        found_count = prompt.lower().count("evidence found") + prompt.lower().count(": confirmed")

        if has_upgrade_rec or found_count >= 2:
            decision = "upgrade"
            new_status = "FOUND"
            new_confidence = 0.72
            stage = "S2 trigger"
            reasoning = (
                f"Upgraded based on cross-trigger analysis. "
                f"Corroborating evidence from {found_count} other confirmed findings "
                f"strengthens the case for this trigger."
            )
        else:
            decision = "keep"
            new_status = initial_status.split()[0] if initial_status else "INCONCLUSIVE"
            new_confidence = 0.45
            stage = "N/a"
            reasoning = "Insufficient corroborating evidence to change the assessment."

        return json.dumps({
            "decision": decision,
            "new_status": new_status,
            "new_confidence": new_confidence,
            "reasoning": reasoning,
            "stage_classification": stage,
        })


class AzureOpenAILLM(LLMInterface):
    """
    Azure OpenAI integration. Stub for now — will be implemented when
    connecting to Fortuna.
    """

    def __init__(self):
        raise NotImplementedError(
            "Azure OpenAI not available in standalone mode. Use MockLLM."
        )

    def call(self, prompt: str, system_prompt: str = "", temperature: float = 0.1,
             json_mode: bool = False) -> str:
        pass

    def call_structured(self, prompt: str, system_prompt: str = "",
                        temperature: float = 0.1) -> dict:
        pass
