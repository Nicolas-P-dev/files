import time
import json
from typing import Callable, Optional
from dataclasses import dataclass, field, asdict


@dataclass
class AgentEvent:
    timestamp: float = field(default_factory=time.time)
    event_type: str = ""
    trigger_id: Optional[str] = None
    data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)


class EventEmitter:
    """
    Central event bus. Nodes emit events here.
    Subscribers (WebSocket, log file, console) receive them.

    Usage in a node:
        emitter = shared["emitter"]
        emitter.emit("trigger_started", trigger_id="T01", data={"index": 0, "total": 22})
    """

    def __init__(self):
        self._subscribers: list[Callable] = []
        self._event_log: list[AgentEvent] = []

    def subscribe(self, callback: Callable[[AgentEvent], None]):
        """Add a subscriber. Callback receives AgentEvent objects."""
        self._subscribers.append(callback)

    def emit(self, event_type: str, trigger_id: str = None, **data):
        """Emit an event to all subscribers and append to log."""
        event = AgentEvent(
            event_type=event_type,
            trigger_id=trigger_id,
            data=data,
        )
        self._event_log.append(event)
        for sub in self._subscribers:
            try:
                sub(event)
            except Exception as e:
                print(f"Event subscriber error: {e}")

    def get_log(self) -> list[dict]:
        """Return the full event log as list of dicts."""
        return [e.to_dict() for e in self._event_log]

    def get_events_since(self, timestamp: float) -> list[dict]:
        """Return events after a given timestamp (for polling)."""
        return [e.to_dict() for e in self._event_log if e.timestamp > timestamp]
