from utils.events import AgentEvent

ICONS = {
    "flow_started": ">>",
    "flow_completed": "[OK]",
    "flow_error": "[ERR]",
    "excel_parse_started": "[XLS]",
    "excel_parse_completed": "[XLS]",
    "embed_started": "[DOC]",
    "embed_document": "  [+]",
    "embed_completed": "[DB]",
    "trigger_started": "[?]",
    "search_planned": "  [P]",
    "search_results": "  [R]",
    "search_assessed": "  [A]",
    "search_refined": "  [~]",
    "search_max_attempts": "  [!]",
    "eval_started": "[E]",
    "eval_reasoning": "  [T]",
    "eval_completed": "  [=]",
    "stage_classification": "  [C]",
    "trigger_completed": "[v]",
    "synthesis_completed": "[SYN]",
    "reevaluation_completed": "[RE]",
    "report_started": "[RPT]",
    "report_completed": "[RPT]",
}


def console_subscriber(event: AgentEvent):
    """Pretty-print events to console for development."""
    icon = ICONS.get(event.event_type, "  *")

    if event.event_type == "trigger_started":
        idx = event.data.get("index", 0) + 1
        total = event.data.get("total", "?")
        text = event.data.get("trigger_text", "")[:60]
        print(f"\n{icon} [{idx}/{total}] {text}")

    elif event.event_type == "search_planned":
        queries = event.data.get("queries", [])
        rationale = event.data.get("rationale", "")[:80]
        print(f"{icon} Planned {len(queries)} queries: {queries[:2]}...")
        if rationale:
            print(f"       {rationale}")

    elif event.event_type == "search_results":
        count = event.data.get("chunks_found", 0)
        score = event.data.get("top_score", 0)
        attempt = event.data.get("attempt", 1)
        new = event.data.get("new_chunks", count)
        attempt_str = f" (attempt {attempt})" if attempt > 1 else ""
        print(f"{icon} Found {count} chunks, {new} new (top: {score:.3f}){attempt_str}")

    elif event.event_type == "search_assessed":
        sufficient = event.data.get("sufficient", False)
        top = event.data.get("top_score", 0)
        above = event.data.get("chunks_above_threshold", 0)
        attempt = event.data.get("attempt", 1)
        verdict = "SUFFICIENT" if sufficient else "INSUFFICIENT"
        print(f"{icon} {verdict} — top={top:.3f}, {above} chunks above threshold (attempt {attempt}/{event.data.get('max_attempts', 3)})")

    elif event.event_type == "search_refined":
        queries = event.data.get("new_queries", [])
        strategy = event.data.get("strategy", "")[:80]
        attempt = event.data.get("attempt", 2)
        print(f"{icon} Refined (attempt {attempt}): {queries[:2]}...")
        if strategy:
            print(f"       Strategy: {strategy}")

    elif event.event_type == "search_max_attempts":
        msg = event.data.get("message", "")[:80]
        print(f"{icon} {msg}")

    elif event.event_type == "eval_completed":
        status = event.data.get("status", "?")
        conf = event.data.get("confidence", 0)
        status_icon = {"FOUND": "(!)", "NOT_FOUND": "(ok)", "INCONCLUSIVE": "(?)"}.get(status, "?")
        print(f"{icon} {status_icon} {status} (confidence: {conf:.2f})")

    elif event.event_type == "trigger_completed":
        idx = event.data.get("index", 0) + 1
        total = event.data.get("total", "?")
        status = event.data.get("status", "?")
        stage = event.data.get("stage", "")
        time_ms = event.data.get("time_ms", 0)
        attempts = event.data.get("search_attempts", 1)
        attempts_str = f" [{attempts} search rounds]" if attempts > 1 else ""
        print(f"{icon} Trigger {idx}/{total}: {status} {stage} ({time_ms}ms){attempts_str}")

    elif event.event_type == "synthesis_completed":
        risk = event.data.get("overall_risk", "?")
        corr = event.data.get("correlations_found", 0)
        upgrades = event.data.get("upgrade_candidates", 0)
        confirmed = event.data.get("forbearance_confirmed", False)
        narrative = event.data.get("risk_narrative", "")[:120]
        print(f"\n{icon} Cross-trigger synthesis:")
        print(f"       Risk: {risk.upper()} | Correlations: {corr} | Upgrade candidates: {upgrades}")
        print(f"       Forbearance confirmed: {'YES' if confirmed else 'NO'}")
        if narrative:
            print(f"       {narrative}")

    elif event.event_type == "reevaluation_completed":
        total = event.data.get("total_reevaluated", 0)
        upgraded = event.data.get("upgraded", 0)
        updates = event.data.get("updates", [])
        print(f"\n{icon} Re-evaluated {total} triggers, upgraded {upgraded}:")
        for u in updates:
            print(f"       {u['trigger_id']}: {u['old']} -> {u['new']} ({u.get('stage', '')})")

    elif event.event_type == "flow_completed":
        print(f"\n{icon} Flow completed!")

    elif event.event_type == "report_completed":
        summary = event.data.get("summary", {})
        print(f"{icon} Report: {summary.get('found', 0)} found / {summary.get('total_triggers', 0)} total")

    elif event.event_type == "flow_error":
        print(f"{icon} ERROR: {event.data.get('error', 'Unknown')}")

    else:
        data_str = str(event.data)[:100] if event.data else ""
        print(f"{icon} {event.event_type} {data_str}")
