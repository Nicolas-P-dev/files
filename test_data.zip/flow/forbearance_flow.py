"""
Forbearance flow with agentic sub-flows and conditional transitions.

Architecture:
    ParseExcel -> EmbedDocuments -> TriggerBatchFlow -> SynthesizeFindings
                                                          |
                                                    "reevaluate" -> ReevaluateInconclusive
                                                          |                |
                                                       "default"          |
                                                          v               v
                                                      GenerateReport <----'

TriggerBatchFlow (per trigger):
    PlanSearch -> ExecuteSearch -> AssessResults
                                     |
                              "sufficient" -> EvaluateEvidence -- "found" --> ClassifyStage -> Finalize
                                     |                           -- "not_found" -----------> Finalize
                             "insufficient" -> RefineSearch -> ExecuteSearch (loop back)
                                     |
                             "max_attempts" -> EvaluateEvidence (evaluate with what we have)
"""

import time
from pocketflow import Flow, BatchFlow

from nodes.parse_excel import ParseExcelNode
from nodes.embed_documents import EmbedDocumentsNode
from nodes.plan_search import PlanSearchNode
from nodes.execute_search import ExecuteSearchNode
from nodes.assess_results import AssessResultsNode
from nodes.refine_search import RefineSearchNode
from nodes.evaluate_evidence import EvaluateEvidenceNode
from nodes.classify_stage import ClassifyStageNode
from nodes.finalize_trigger import FinalizeTriggerNode
from nodes.synthesize_findings import SynthesizeFindingsNode
from nodes.reevaluate_inconclusive import ReevaluateInconclusiveNode
from nodes.generate_report import GenerateReportNode


class TriggerBatchFlow(BatchFlow):
    """
    Iterates over all triggers, running the per-trigger sub-flow for each.
    The sub-flow includes iterative search refinement with conditional transitions.
    """

    def __init__(self):
        # Create per-trigger sub-flow nodes
        plan = PlanSearchNode(max_retries=2, wait=1)
        search = ExecuteSearchNode(max_retries=2, wait=1)
        assess = AssessResultsNode()
        refine = RefineSearchNode(max_retries=2, wait=1)
        evaluate = EvaluateEvidenceNode(max_retries=2, wait=1)
        classify = ClassifyStageNode(max_retries=2, wait=1)
        finalize = FinalizeTriggerNode()

        # Second search node for the refinement loop
        # (PocketFlow copies nodes, so we can reuse the same class)
        search2 = ExecuteSearchNode(max_retries=2, wait=1)
        assess2 = AssessResultsNode()

        # Wire the sub-flow with conditional transitions
        #
        # Main path: plan -> search -> assess
        plan >> search >> assess

        # If results are sufficient: evaluate evidence
        assess - "sufficient" >> evaluate

        # If results are insufficient: refine queries and search again
        assess - "insufficient" >> refine >> search2 >> assess2

        # Second assessment: sufficient or max_attempts both go to evaluate
        assess2 - "sufficient" >> evaluate
        assess2 - "insufficient" >> evaluate  # 3rd attempt: just evaluate
        assess2 - "max_attempts" >> evaluate

        # If max attempts on first assess (shouldn't happen with max=3, but safety)
        assess - "max_attempts" >> evaluate

        # After evaluation: if FOUND, classify stage then finalize
        evaluate - "found" >> classify >> finalize

        # If NOT_FOUND or INCONCLUSIVE: skip classification, go to finalize
        evaluate - "not_found" >> finalize

        super().__init__(start=plan)

    def prep(self, shared):
        """Return one param dict per trigger for BatchFlow iteration."""
        shared["results"] = []
        shared["accumulated_findings"] = []
        shared["document_relevance"] = {}
        return [{"trigger_index": i} for i in range(len(shared["triggers"]))]

    def post(self, shared, prep_res, exec_res):
        return "default"


def create_forbearance_flow() -> Flow:
    """
    Create the full forbearance checking flow with conditional transitions:

    ParseExcel -> EmbedDocuments -> TriggerBatchFlow -> SynthesizeFindings
                                                           |
                                                     "reevaluate" -> ReevaluateInconclusive -> GenerateReport
                                                     "default"   -> GenerateReport
    """
    parse_excel = ParseExcelNode(max_retries=2, wait=1)
    embed_documents = EmbedDocumentsNode(max_retries=2, wait=1)
    trigger_batch = TriggerBatchFlow()
    synthesize = SynthesizeFindingsNode(max_retries=2, wait=1)
    reevaluate = ReevaluateInconclusiveNode(max_retries=2, wait=1)
    generate_report = GenerateReportNode(max_retries=1)

    # Wire the outer flow
    parse_excel >> embed_documents >> trigger_batch >> synthesize

    # Conditional: if synthesis recommends re-evaluation
    synthesize - "reevaluate" >> reevaluate >> generate_report

    # Default: skip re-evaluation
    synthesize - "default" >> generate_report

    flow = Flow(start=parse_excel)
    return flow
