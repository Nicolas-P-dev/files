import React, { useState, useCallback } from 'react';
import { Box } from '@mui/material';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import RightPanel from './components/RightPanel';
import useChat from './hooks/useChat';
import useSessions from './hooks/useSessions';
import useHealthCheck from './hooks/useHealthCheck';

export default function App() {
  const [activeView, setActiveView] = useState('chat');
  const [inputValue, setInputValue] = useState('');
  const [rightPanel, setRightPanel] = useState(null);

  const {
    messages, isStreaming, streamingStatus, currentSkill, error,
    panelContent, sendMessage, cancelStream, loadSessionMessages,
    clearMessages, setPanelContent,
  } = useChat();

  const {
    sessions, activeSessionId, createSession, switchSession,
    deleteSession, refreshSessions,
  } = useSessions();

  const { tools, agentHealthy, refresh: refreshHealth } = useHealthCheck();

  const ensureSession = useCallback(() => {
    if (!activeSessionId) {
      return createSession();
    }
    return activeSessionId;
  }, [activeSessionId, createSession]);

  const handleSend = useCallback(() => {
    const text = inputValue.trim();
    if (!text) return;

    const sessionId = ensureSession();
    const userId = localStorage.getItem('apm_user_id') || 'default';
    const token = localStorage.getItem('apm_jira_token') || '';

    sendMessage(text, sessionId, userId, token);
    setInputValue('');

    setTimeout(() => refreshSessions(), 1000);
  }, [inputValue, ensureSession, sendMessage, refreshSessions]);

  const handleNewChat = useCallback(() => {
    const id = createSession();
    clearMessages();
    setRightPanel(null);
    setInputValue('');
  }, [createSession, clearMessages]);

  const handleSwitchSession = useCallback((sessionId) => {
    switchSession(sessionId);
    loadSessionMessages([]);
    setRightPanel(null);
  }, [switchSession, loadSessionMessages]);

  const handleDeleteSession = useCallback((sessionId) => {
    deleteSession(sessionId);
    if (sessionId === activeSessionId) {
      clearMessages();
    }
  }, [deleteSession, activeSessionId, clearMessages]);

  const handleViewChange = useCallback((view) => {
    setActiveView(view);
    if (view === 'chat') {
      setRightPanel(null);
    } else {
      setRightPanel({ panelType: view, data: null });
    }
  }, []);

  const handleOpenTools = useCallback(() => {
    setRightPanel(prev =>
      prev?.panelType === 'tools' ? null : { panelType: 'tools', data: null }
    );
  }, []);

  const handleOpenSettings = useCallback(() => {
    setRightPanel(prev =>
      prev?.panelType === 'settings' ? null : { panelType: 'settings', data: null }
    );
  }, []);

  const handleClosePanel = useCallback(() => {
    setRightPanel(null);
    setActiveView('chat');
  }, []);

  // Agent-triggered panel content
  React.useEffect(() => {
    if (panelContent) {
      setRightPanel(panelContent);
    }
  }, [panelContent]);

  const showPanel = rightPanel !== null;

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <Header
        agentHealthy={agentHealthy}
        tools={tools}
        onSettingsClick={handleOpenSettings}
      />

      <Box sx={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <Sidebar
          activeView={activeView}
          onViewChange={handleViewChange}
          sessions={sessions}
          activeSessionId={activeSessionId}
          onNewChat={handleNewChat}
          onSwitchSession={handleSwitchSession}
          onDeleteSession={handleDeleteSession}
          onSettingsClick={handleOpenSettings}
          onToolsClick={handleOpenTools}
        />

        {/* Main content area */}
        <Box sx={{
          flex: 1,
          display: 'flex',
          overflow: 'hidden',
          minWidth: 0,
        }}>
          {/* Chat always present */}
          <Box sx={{
            flex: showPanel ? '1 1 50%' : '1 1 100%',
            minWidth: 380,
            transition: 'flex 0.2s ease',
            overflow: 'hidden',
          }}>
            <ChatView
              messages={messages}
              isStreaming={isStreaming}
              streamingStatus={streamingStatus}
              inputValue={inputValue}
              onInputChange={setInputValue}
              onSend={handleSend}
            />
          </Box>

          {/* Right panel */}
          {showPanel && (
            <Box sx={{
              flex: '1 1 50%',
              maxWidth: '55%',
              minWidth: 360,
              overflow: 'hidden',
            }}>
              <RightPanel
                panelType={rightPanel.panelType}
                data={rightPanel.data}
                onClose={handleClosePanel}
              />
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
}
