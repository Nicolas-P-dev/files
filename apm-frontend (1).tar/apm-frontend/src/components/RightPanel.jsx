import React from 'react';
import { Box, Typography, IconButton, Divider } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ConnectedToolsPanel from './panels/ConnectedToolsPanel';
import SettingsPanel from './panels/SettingsPanel';
import PlaceholderPanel from './panels/PlaceholderPanel';

const PANEL_REGISTRY = {
  tools: { component: ConnectedToolsPanel, title: 'Connected Tools' },
  settings: { component: SettingsPanel, title: 'Settings' },
  board: { component: PlaceholderPanel, title: 'Sprint Board' },
  projects: { component: PlaceholderPanel, title: 'Projects' },
  team: { component: PlaceholderPanel, title: 'Team' },
  kanban: { component: PlaceholderPanel, title: 'Kanban Board' },
  table: { component: PlaceholderPanel, title: 'Data Table' },
  chart: { component: PlaceholderPanel, title: 'Chart' },
  custom: { component: PlaceholderPanel, title: 'Agent View' },
};

export default function RightPanel({ panelType, data, onClose }) {
  if (!panelType) return null;

  const config = PANEL_REGISTRY[panelType] || {
    component: PlaceholderPanel,
    title: panelType,
  };
  const PanelComponent = config.component;

  return (
    <Box sx={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      borderLeft: '1px solid #E6E6E6',
      bgcolor: '#fff',
      overflow: 'hidden',
    }}>
      {/* Panel Header */}
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 2, py: 1.5, borderBottom: '1px solid #E6E6E6', flexShrink: 0,
      }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          {config.title}
        </Typography>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </Box>

      {/* Panel Content */}
      <Box sx={{ flex: 1, overflow: 'auto' }}>
        <PanelComponent data={data} panelType={panelType} />
      </Box>
    </Box>
  );
}
