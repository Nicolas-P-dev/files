import React from 'react';
import { Box, Typography } from '@mui/material';
import ConstructionIcon from '@mui/icons-material/Construction';

export default function PlaceholderPanel({ panelType }) {
  return (
    <Box sx={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100%', textAlign: 'center', p: 4,
    }}>
      <ConstructionIcon sx={{ fontSize: 48, color: '#E6E6E6', mb: 2 }} />
      <Typography variant="h6" sx={{ color: '#63666A', mb: 1 }}>
        Coming Soon
      </Typography>
      <Typography variant="body2" sx={{ color: '#A5ADBA', maxWidth: 300 }}>
        The {panelType} view is being built. For now, use the chat to interact with your project data.
      </Typography>
    </Box>
  );
}
