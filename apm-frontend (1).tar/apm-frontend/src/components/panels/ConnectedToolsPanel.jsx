import React, { useState, useEffect } from 'react';
import {
  Box, Typography, Paper, Chip, CircularProgress, IconButton, Divider,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';

const TOOL_DISPLAY = {
  'mcp-atlassian': { label: 'Jira & Confluence', description: 'Atlassian Cloud integration' },
  'mcp-graph': { label: 'Microsoft 365', description: 'Outlook, Calendar, OneDrive, Teams' },
  'mcp-devops': { label: 'Azure DevOps', description: 'Work items, repos, pipelines' },
};

export default function ConnectedToolsPanel() {
  const [tools, setTools] = useState({});
  const [loading, setLoading] = useState(true);

  const fetchTools = async () => {
    setLoading(true);
    try {
      const resp = await fetch('/health/mcp');
      if (resp.ok) setTools(await resp.json());
    } catch { /* silent */ }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchTools(); }, []);

  const entries = Object.entries(tools);

  return (
    <Box sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="body2" sx={{ color: '#63666A' }}>
          MCP server connectivity
        </Typography>
        <IconButton size="small" onClick={fetchTools} disabled={loading}>
          <RefreshIcon fontSize="small" />
        </IconButton>
      </Box>

      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress size={24} sx={{ color: '#26890D' }} />
        </Box>
      )}

      {!loading && entries.length === 0 && (
        <Paper sx={{ p: 3, textAlign: 'center', bgcolor: '#F5F5F5' }}>
          <Typography variant="body2" sx={{ color: '#63666A' }}>
            No MCP servers configured
          </Typography>
        </Paper>
      )}

      {!loading && entries.map(([serverId, status]) => {
        const display = TOOL_DISPLAY[serverId] || { label: serverId, description: '' };
        const healthy = status?.status === 'healthy';

        return (
          <Paper
            key={serverId}
            variant="outlined"
            sx={{
              p: 2, mb: 1.5,
              borderColor: healthy ? 'rgba(38,137,13,0.3)' : 'rgba(218,41,28,0.3)',
              borderLeft: `3px solid ${healthy ? '#26890D' : '#DA291C'}`,
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                  {display.label}
                </Typography>
                <Typography variant="caption" sx={{ color: '#63666A' }}>
                  {display.description || serverId}
                </Typography>
              </Box>
              <Chip
                icon={healthy ? <CheckCircleIcon sx={{ fontSize: 14 }} /> : <ErrorIcon sx={{ fontSize: 14 }} />}
                label={healthy ? 'Connected' : 'Unavailable'}
                size="small"
                sx={{
                  bgcolor: healthy ? 'rgba(38,137,13,0.1)' : 'rgba(218,41,28,0.1)',
                  color: healthy ? '#26890D' : '#DA291C',
                  fontWeight: 600, fontSize: '0.7rem', height: 24,
                }}
              />
            </Box>
            {status?.error && (
              <Typography variant="caption" sx={{ color: '#DA291C', mt: 1, display: 'block' }}>
                {status.error}
              </Typography>
            )}
          </Paper>
        );
      })}
    </Box>
  );
}
