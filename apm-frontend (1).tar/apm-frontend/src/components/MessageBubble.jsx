import React from 'react';
import { Box, Typography, Chip, CircularProgress, Link } from '@mui/material';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeSanitize from 'rehype-sanitize';

const markdownComponents = {
  p: ({ children }) => (
    <Typography variant="body2" sx={{ lineHeight: 1.7, mb: 0.5, '&:last-child': { mb: 0 } }}>
      {children}
    </Typography>
  ),
  strong: ({ children }) => <strong>{children}</strong>,
  em: ({ children }) => <em>{children}</em>,
  ul: ({ children }) => <ul style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ul>,
  ol: ({ children }) => <ol style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ol>,
  li: ({ children }) => (
    <li><Typography variant="body2" component="span" sx={{ lineHeight: 1.7 }}>{children}</Typography></li>
  ),
  a: ({ href, children }) => (
    <Link href={href} target="_blank" rel="noopener noreferrer" sx={{
      color: '#26890D', textDecoration: 'underline', fontWeight: 500,
      wordBreak: 'break-all', '&:hover': { color: '#046A38' },
    }}>{children}</Link>
  ),
  code: ({ inline, children }) => inline ? (
    <code style={{
      background: 'rgba(0,0,0,0.05)', borderRadius: 4, padding: '0.1rem 0.3rem',
      fontFamily: "'Roboto Mono', monospace", fontSize: '0.85em',
    }}>{children}</code>
  ) : (
    <pre style={{
      whiteSpace: 'pre-wrap', wordWrap: 'break-word', margin: '0.5rem 0',
      padding: '0.75rem', borderRadius: 6, background: 'rgba(0,0,0,0.04)', overflow: 'auto',
    }}>
      <code style={{ fontFamily: "'Roboto Mono', monospace", fontSize: '0.85em' }}>{children}</code>
    </pre>
  ),
  h1: ({ children }) => <Typography variant="h6" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
  h2: ({ children }) => <Typography variant="subtitle1" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
  h3: ({ children }) => <Typography variant="subtitle2" sx={{ fontWeight: 700, mt: 0.5, mb: 0.5 }}>{children}</Typography>,
  table: ({ children }) => (
    <div style={{ overflowX: 'auto', margin: '0.5rem 0' }}>
      <table style={{ borderCollapse: 'collapse', width: '100%', border: '1px solid #E6E6E6' }}>{children}</table>
    </div>
  ),
  thead: ({ children }) => <thead style={{ backgroundColor: '#F5F5F5' }}>{children}</thead>,
  th: ({ children }) => <th style={{ textAlign: 'left', borderBottom: '2px solid #E6E6E6', padding: '8px 12px', fontWeight: 600 }}>{children}</th>,
  td: ({ children }) => <td style={{ borderBottom: '1px solid #E6E6E6', padding: '8px 12px' }}>{children}</td>,
  blockquote: ({ children }) => (
    <blockquote style={{ borderLeft: '3px solid #26890D', margin: '0.5rem 0', padding: '0.25rem 0.75rem', color: '#63666A' }}>
      {children}
    </blockquote>
  ),
  hr: () => <hr style={{ border: 'none', borderTop: '1px solid #E6E6E6', margin: '8px 0' }} />,
};

export default function MessageBubble({ message }) {
  const { role, content, isStreaming, skill, isError } = message;
  const isUser = role === 'user';

  return (
    <Box sx={{
      display: 'flex',
      justifyContent: isUser ? 'flex-end' : 'flex-start',
      mb: 2,
      px: 2,
    }}>
      <Box sx={{
        maxWidth: '75%',
        minWidth: 60,
      }}>
        <Box sx={{
          p: 2,
          borderRadius: 2.5,
          ...(isUser ? {
            background: 'linear-gradient(135deg, #26890D 0%, #046A38 100%)',
            color: '#fff',
            borderBottomRightRadius: 4,
            boxShadow: '0 2px 8px rgba(38,137,13,0.25)',
          } : {
            bgcolor: '#fff',
            color: '#000',
            borderBottomLeftRadius: 4,
            boxShadow: '0 1px 4px rgba(0,0,0,0.08)',
            border: '1px solid #E6E6E6',
            ...(isError && { borderColor: '#DA291C', bgcolor: '#FFF5F5' }),
          }),
        }}>
          {isUser ? (
            <Typography variant="body2" sx={{ lineHeight: 1.7 }}>{content}</Typography>
          ) : content ? (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeSanitize]}
              components={markdownComponents}
            >
              {content}
            </ReactMarkdown>
          ) : isStreaming ? (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.5 }}>
              <CircularProgress size={14} sx={{ color: '#26890D' }} />
              <Typography variant="body2" sx={{ color: '#63666A' }}>
                Thinking...
              </Typography>
            </Box>
          ) : null}
        </Box>

        {/* Skill badge + streaming status */}
        {!isUser && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5, px: 0.5 }}>
            {skill && (
              <Chip
                label={skill}
                size="small"
                sx={{
                  height: 18, fontSize: '0.65rem', fontWeight: 600,
                  bgcolor: 'rgba(38,137,13,0.1)', color: '#26890D',
                  '& .MuiChip-label': { px: 1 },
                }}
              />
            )}
            {isStreaming && message.streamingStatus && (
              <Typography variant="caption" sx={{ color: '#63666A' }}>
                {message.streamingStatus}
              </Typography>
            )}
          </Box>
        )}
      </Box>
    </Box>
  );
}
