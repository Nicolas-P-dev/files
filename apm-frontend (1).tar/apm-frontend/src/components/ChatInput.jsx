import React, { useRef, useEffect } from 'react';
import { Box, TextField, IconButton, InputAdornment, CircularProgress, Typography } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';

export default function ChatInput({ value, onChange, onSend, disabled, isStreaming }) {
  const inputRef = useRef(null);

  useEffect(() => {
    if (!disabled && !isStreaming) {
      inputRef.current?.focus();
    }
  }, [disabled, isStreaming]);

  const handleKeyDown = (e) => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !disabled) onSend();
    }
  };

  return (
    <Box sx={{ px: 2, py: 1.5, bgcolor: '#fff', borderTop: '1px solid #E6E6E6' }}>
      <TextField
        inputRef={inputRef}
        fullWidth
        variant="outlined"
        placeholder="Ask APM anything..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        multiline
        maxRows={4}
        size="small"
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton
                onClick={onSend}
                disabled={!value.trim() || disabled}
                edge="end"
                sx={{
                  color: '#26890D',
                  '&:hover': { bgcolor: 'rgba(38,137,13,0.08)' },
                  '&.Mui-disabled': { color: '#D0D0CE' },
                }}
              >
                {isStreaming ? (
                  <CircularProgress size={20} sx={{ color: '#26890D' }} />
                ) : (
                  <SendIcon />
                )}
              </IconButton>
            </InputAdornment>
          ),
          sx: {
            borderRadius: 2,
            bgcolor: '#FAFAFA',
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
              borderColor: '#26890D', borderWidth: 2,
            },
            '&:hover .MuiOutlinedInput-notchedOutline': {
              borderColor: '#86BC25',
            },
          },
        }}
      />
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 0.5, px: 0.5 }}>
        <Typography variant="caption" sx={{ color: '#A5ADBA' }}>
          Enter to send · Shift+Enter for new line
        </Typography>
        {isStreaming && (
          <Typography variant="caption" sx={{ color: '#26890D', fontWeight: 600 }}>
            Streaming...
          </Typography>
        )}
      </Box>
    </Box>
  );
}
