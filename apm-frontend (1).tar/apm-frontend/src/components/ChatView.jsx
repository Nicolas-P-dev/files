import React, { useRef, useEffect } from 'react';
import { Box, Typography, LinearProgress } from '@mui/material';
import MessageBubble from './MessageBubble';
import ChatInput from './ChatInput';

function WelcomeScreen() {
  return (
    <Box sx={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100%', textAlign: 'center', px: 4,
    }}>
      <Typography variant="h5" sx={{ color: '#000', mb: 1, fontWeight: 600 }}>
        Assistant Project Manager
      </Typography>
      <Typography variant="body1" sx={{ color: '#63666A', mb: 4, maxWidth: 480, lineHeight: 1.6 }}>
        AI-powered project management. Ask me anything about your projects, tasks, and team.
      </Typography>

      <Box sx={{
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5,
        maxWidth: 480, width: '100%',
      }}>
        {[
          'Show me my Jira projects',
          'What tasks are in progress?',
          'Create a new task for API review',
          'Sprint status for this week',
        ].map((prompt) => (
          <Box key={prompt} sx={{
            p: 2, borderRadius: 2, border: '1px solid #E6E6E6',
            bgcolor: '#fff', cursor: 'pointer',
            transition: 'all 0.15s',
            '&:hover': { borderColor: '#26890D', bgcolor: 'rgba(38,137,13,0.03)' },
          }}>
            <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 500 }}>
              {prompt}
            </Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

export default function ChatView({
  messages,
  isStreaming,
  streamingStatus,
  inputValue,
  onInputChange,
  onSend,
}) {
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Status bar for tool calls */}
      {streamingStatus && (
        <Box sx={{ px: 2, py: 0.75, bgcolor: 'rgba(38,137,13,0.05)', borderBottom: '1px solid #E6E6E6' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="caption" sx={{ color: '#26890D', fontWeight: 600 }}>
              {streamingStatus}
            </Typography>
          </Box>
          <LinearProgress sx={{
            mt: 0.5, height: 2, bgcolor: 'rgba(38,137,13,0.1)',
            '& .MuiLinearProgress-bar': { bgcolor: '#26890D' },
          }} />
        </Box>
      )}

      {/* Messages */}
      <Box sx={{
        flex: 1, overflowY: 'auto', py: 2,
        bgcolor: '#F5F5F5',
      }}>
        {messages.length === 0 ? (
          <WelcomeScreen />
        ) : (
          <>
            {messages.map((msg, i) => (
              <MessageBubble key={i} message={msg} />
            ))}
            <div ref={endRef} />
          </>
        )}
      </Box>

      {/* Input */}
      <ChatInput
        value={inputValue}
        onChange={onInputChange}
        onSend={onSend}
        disabled={isStreaming}
        isStreaming={isStreaming}
      />
    </Box>
  );
}
