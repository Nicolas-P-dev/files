import React from 'react';
import { Box, Typography, Chip, Divider, IconButton, Tooltip } from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';

export default function Header({ agentHealthy, tools, onSettingsClick }) {
  const connectedCount = Object.values(tools).filter(
    t => t.status === 'healthy'
  ).length;
  const totalCount = Object.keys(tools).length;

  return (
    <Box sx={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      bgcolor: '#000',
      color: '#fff',
      px: 2,
      py: 1,
      minHeight: 48,
      flexShrink: 0,
    }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, letterSpacing: '-0.02em' }}>
          APM
        </Typography>
        <Divider orientation="vertical" flexItem sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />
        <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
          Assistant Project Manager
        </Typography>
      </Box>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        {totalCount > 0 && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="caption" sx={{ color: '#A5ADBA' }}>
              Tools:
            </Typography>
            <Chip
              label={`${connectedCount}/${totalCount}`}
              size="small"
              sx={{
                bgcolor: connectedCount === totalCount
                  ? 'rgba(38,137,13,0.15)'
                  : connectedCount > 0
                    ? 'rgba(237,139,0,0.15)'
                    : 'rgba(218,41,28,0.15)',
                color: connectedCount === totalCount
                  ? '#86BC25'
                  : connectedCount > 0
                    ? '#ED8B00'
                    : '#DA291C',
                fontWeight: 600,
                fontSize: '0.7rem',
                height: 22,
              }}
            />
          </Box>
        )}

        <Chip
          label={agentHealthy ? 'Connected' : 'Disconnected'}
          size="small"
          sx={{
            bgcolor: agentHealthy ? 'rgba(38,137,13,0.15)' : 'rgba(218,41,28,0.15)',
            color: agentHealthy ? '#86BC25' : '#DA291C',
            fontWeight: 600,
            fontSize: '0.7rem',
            height: 22,
          }}
        />

        <Tooltip title="Settings">
          <IconButton size="small" onClick={onSettingsClick} sx={{ color: '#fff' }}>
            <SettingsIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
    </Box>
  );
}
