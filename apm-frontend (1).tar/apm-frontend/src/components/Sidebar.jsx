import React from 'react';
import {
  Box, Typography, List, ListItem, ListItemButton, ListItemIcon,
  ListItemText, Divider, IconButton, Tooltip,
} from '@mui/material';
import ChatIcon from '@mui/icons-material/Chat';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import FolderIcon from '@mui/icons-material/Folder';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';
import SettingsIcon from '@mui/icons-material/Settings';

const NAV_ITEMS = [
  { id: 'chat', label: 'Chat', icon: ChatIcon },
  { id: 'board', label: 'Board', icon: DashboardIcon, disabled: true },
  { id: 'projects', label: 'Projects', icon: FolderIcon, disabled: true },
  { id: 'team', label: 'Team', icon: PeopleIcon, disabled: true },
];

function formatSessionLabel(session) {
  const count = session.message_count || 0;
  return `${count} messages`;
}

function formatTimeGroup(updatedAt) {
  if (!updatedAt) return 'Recent';
  const now = new Date();
  const date = new Date(updatedAt * 1000);
  const diffMs = now - date;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return 'This Week';
  return 'Older';
}

function groupSessions(sessions) {
  const groups = {};
  sessions.forEach(s => {
    const group = formatTimeGroup(s.updated_at);
    if (!groups[group]) groups[group] = [];
    groups[group].push(s);
  });
  return groups;
}

export default function Sidebar({
  activeView,
  onViewChange,
  sessions,
  activeSessionId,
  onNewChat,
  onSwitchSession,
  onDeleteSession,
  onSettingsClick,
  onToolsClick,
}) {
  const grouped = groupSessions(sessions);

  return (
    <Box sx={{
      width: 260,
      height: '100%',
      bgcolor: '#000',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
    }}>
      {/* Navigation */}
      <List sx={{ px: 1, pt: 1.5, pb: 0.5 }}>
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const selected = activeView === item.id;
          return (
            <ListItem key={item.id} disablePadding sx={{ mb: 0.25 }}>
              <ListItemButton
                selected={selected}
                disabled={item.disabled}
                onClick={() => onViewChange(item.id)}
                sx={{
                  borderRadius: 1,
                  py: 0.75,
                  '&.Mui-selected': {
                    bgcolor: 'rgba(38,137,13,0.15)',
                    '& .MuiListItemIcon-root': { color: '#26890D' },
                  },
                  '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
                  '&.Mui-disabled': { opacity: 0.35 },
                }}
              >
                <ListItemIcon sx={{ color: selected ? '#26890D' : '#fff', minWidth: 36 }}>
                  <Icon fontSize="small" />
                </ListItemIcon>
                <ListItemText
                  primary={item.label}
                  primaryTypographyProps={{ fontSize: '0.875rem' }}
                />
                {item.disabled && (
                  <Typography variant="caption" sx={{ color: '#63666A', fontSize: '0.65rem' }}>
                    Soon
                  </Typography>
                )}
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>

      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.1)', mx: 1.5 }} />

      {/* New Chat Button */}
      <Box sx={{ px: 1.5, py: 1.5 }}>
        <ListItemButton
          onClick={onNewChat}
          sx={{
            borderRadius: 1,
            border: '1px solid rgba(38,137,13,0.4)',
            justifyContent: 'center',
            py: 0.75,
            '&:hover': { bgcolor: 'rgba(38,137,13,0.1)' },
          }}
        >
          <AddIcon fontSize="small" sx={{ color: '#26890D', mr: 1 }} />
          <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 600 }}>
            New Chat
          </Typography>
        </ListItemButton>
      </Box>

      {/* Session List */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1, pb: 1 }}>
        {Object.entries(grouped).map(([group, groupSessions]) => (
          <Box key={group}>
            <Typography variant="caption" sx={{
              color: '#63666A', px: 1, pt: 1.5, pb: 0.5, display: 'block',
              fontSize: '0.65rem', fontWeight: 600, textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}>
              {group}
            </Typography>
            {groupSessions.map(session => (
              <ListItem
                key={session.session_id}
                disablePadding
                secondaryAction={
                  <IconButton
                    size="small"
                    onClick={(e) => { e.stopPropagation(); onDeleteSession(session.session_id); }}
                    sx={{ color: '#63666A', opacity: 0, '.MuiListItem-root:hover &': { opacity: 1 } }}
                  >
                    <DeleteOutlineIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                }
                sx={{ '&:hover .MuiIconButton-root': { opacity: 1 } }}
              >
                <ListItemButton
                  selected={activeSessionId === session.session_id}
                  onClick={() => onSwitchSession(session.session_id)}
                  sx={{
                    borderRadius: 1,
                    py: 0.5,
                    pr: 5,
                    '&.Mui-selected': { bgcolor: 'rgba(255,255,255,0.08)' },
                    '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
                  }}
                >
                  <ListItemText
                    primary={session.session_id.slice(0, 20)}
                    secondary={formatSessionLabel(session)}
                    primaryTypographyProps={{
                      fontSize: '0.8rem', noWrap: true, color: '#fff',
                    }}
                    secondaryTypographyProps={{
                      fontSize: '0.65rem', color: '#63666A',
                    }}
                  />
                </ListItemButton>
              </ListItem>
            ))}
          </Box>
        ))}

        {sessions.length === 0 && (
          <Typography variant="caption" sx={{
            color: '#63666A', display: 'block', textAlign: 'center', py: 3, px: 2,
          }}>
            No conversations yet. Start a new chat above.
          </Typography>
        )}
      </Box>

      {/* Bottom Actions */}
      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.1)' }} />
      <List sx={{ px: 1, py: 0.5 }}>
        <ListItem disablePadding>
          <ListItemButton onClick={onToolsClick} sx={{
            borderRadius: 1, py: 0.75,
            '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
          }}>
            <ListItemIcon sx={{ color: '#fff', minWidth: 36 }}>
              <ElectricBoltIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText primary="Connected Tools" primaryTypographyProps={{ fontSize: '0.875rem' }} />
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton onClick={onSettingsClick} sx={{
            borderRadius: 1, py: 0.75,
            '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
          }}>
            <ListItemIcon sx={{ color: '#fff', minWidth: 36 }}>
              <SettingsIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: '0.875rem' }} />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );
}
