import { useState, useCallback, useEffect } from 'react';

const API_BASE = '/api';

function generateSessionId() {
  return `s_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export default function useSessions() {
  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchSessions = useCallback(async () => {
    try {
      setLoading(true);
      const resp = await fetch(`${API_BASE}/sessions`);
      if (resp.ok) {
        const data = await resp.json();
        setSessions(data);
      }
    } catch {
      // sessions endpoint may not be available yet
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSessions();
  }, [fetchSessions]);

  const createSession = useCallback(() => {
    const id = generateSessionId();
    setActiveSessionId(id);
    return id;
  }, []);

  const switchSession = useCallback((sessionId) => {
    setActiveSessionId(sessionId);
  }, []);

  const deleteSession = useCallback(async (sessionId) => {
    try {
      await fetch(`${API_BASE}/sessions/${sessionId}`, { method: 'DELETE' });
      setSessions(prev => prev.filter(s => s.session_id !== sessionId));
      if (activeSessionId === sessionId) {
        setActiveSessionId(null);
      }
    } catch {
      // silent fail
    }
  }, [activeSessionId]);

  const refreshSessions = useCallback(() => {
    fetchSessions();
  }, [fetchSessions]);

  return {
    sessions,
    activeSessionId,
    loading,
    createSession,
    switchSession,
    deleteSession,
    refreshSessions,
  };
}
