import { useState, useRef, useCallback } from 'react';

const API_BASE = '/api';

export default function useChat() {
  const [messages, setMessages] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingStatus, setStreamingStatus] = useState('');
  const [currentSkill, setCurrentSkill] = useState(null);
  const [error, setError] = useState(null);
  const [panelContent, setPanelContent] = useState(null);
  const abortRef = useRef(null);

  const sendMessage = useCallback(async (text, sessionId, userId = 'default', token = '') => {
    if (!text.trim() || isStreaming) return;

    const userMsg = { role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setIsStreaming(true);
    setStreamingStatus('');
    setCurrentSkill(null);
    setError(null);

    const assistantMsg = { role: 'assistant', content: '', isStreaming: true };
    setMessages(prev => [...prev, assistantMsg]);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const response = await fetch(`${API_BASE}/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          session_id: sessionId,
          user_id: userId,
          token,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const raw = line.slice(6).trim();
          if (!raw) continue;

          let event;
          try { event = JSON.parse(raw); }
          catch { continue; }

          switch (event.type) {
            case 'token':
              accumulated += event.content;
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) {
                  updated[updated.length - 1] = { ...last, content: accumulated };
                }
                return updated;
              });
              break;

            case 'status':
              setStreamingStatus(event.message);
              break;

            case 'done':
              setCurrentSkill(event.skill);
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) {
                  updated[updated.length - 1] = {
                    ...last,
                    isStreaming: false,
                    skill: event.skill,
                  };
                }
                return updated;
              });
              break;

            case 'panel':
              setPanelContent({
                panelType: event.panel_type,
                data: event.data,
              });
              break;

            case 'error':
              setError(event.message);
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) {
                  updated[updated.length - 1] = {
                    ...last,
                    isStreaming: false,
                    content: `Error: ${event.message}`,
                    isError: true,
                  };
                }
                return updated;
              });
              break;
          }
        }
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message);
        setMessages(prev => {
          const updated = [...prev];
          const last = updated[updated.length - 1];
          if (last?.isStreaming) {
            updated[updated.length - 1] = {
              ...last,
              isStreaming: false,
              content: `Connection error: ${err.message}`,
              isError: true,
            };
          }
          return updated;
        });
      }
    } finally {
      setIsStreaming(false);
      setStreamingStatus('');
      abortRef.current = null;
    }
  }, [isStreaming]);

  const cancelStream = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
    setStreamingStatus('');
  }, []);

  const loadSessionMessages = useCallback((sessionMessages) => {
    setMessages(sessionMessages || []);
    setCurrentSkill(null);
    setError(null);
    setPanelContent(null);
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setCurrentSkill(null);
    setError(null);
    setPanelContent(null);
  }, []);

  return {
    messages,
    isStreaming,
    streamingStatus,
    currentSkill,
    error,
    panelContent,
    sendMessage,
    cancelStream,
    loadSessionMessages,
    clearMessages,
    setPanelContent,
  };
}
