"use client";

import { createTheme } from "@mui/material/styles";

declare module "@mui/material/styles" {
  interface Palette {
    deloitte: {
      green: string;
      greenLight: string;
      black: string;
    };
    gray: {
      50: string;
      100: string;
      200: string;
      300: string;
      400: string;
      500: string;
    };
  }
  interface PaletteOptions {
    deloitte?: {
      green?: string;
      greenLight?: string;
      black?: string;
    };
    gray?: {
      50?: string;
      100?: string;
      200?: string;
      300?: string;
      400?: string;
      500?: string;
    };
  }
}

const theme = createTheme({
  palette: {
    primary: {
      main: "#26890D",
      light: "#86BC25",
    },
    secondary: {
      main: "#007CB0",
    },
    error: {
      main: "#DA291C",
    },
    warning: {
      main: "#ED8B00",
    },
    background: {
      default: "#F5F7F9",
      paper: "#FFFFFF",
    },
    text: {
      primary: "#000000",
      secondary: "#53565A",
    },
    deloitte: {
      green: "#26890D",
      greenLight: "#86BC25",
      black: "#000000",
    },
    gray: {
      50: "#F5F7F9",
      100: "#E6E6E6",
      200: "#D0D0CE",
      300: "#A5ADBA",
      400: "#6B778C",
      500: "#53565A",
    },
  },
  typography: {
    fontFamily: "'Open Sans', sans-serif",
    h4: {
      fontWeight: 600,
      fontSize: "1.5rem",
    },
    h5: {
      fontWeight: 600,
      fontSize: "1.25rem",
    },
    h6: {
      fontWeight: 600,
      fontSize: "1rem",
    },
    subtitle1: {
      fontWeight: 600,
      fontSize: "0.875rem",
    },
    subtitle2: {
      fontWeight: 600,
      fontSize: "0.8125rem",
    },
    body1: {
      fontWeight: 400,
      fontSize: "0.875rem",
    },
    body2: {
      fontWeight: 400,
      fontSize: "0.8125rem",
    },
    caption: {
      fontSize: "0.75rem",
      color: "#53565A",
    },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          borderRadius: 8,
        },
        containedPrimary: {
          backgroundColor: "#26890D",
          "&:hover": {
            backgroundColor: "#1e6e0a",
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 6,
        },
      },
    },
    MuiToggleButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 500,
        },
      },
    },
  },
});

export default theme;
