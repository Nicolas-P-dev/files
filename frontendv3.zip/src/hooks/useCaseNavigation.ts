"use client";

import { useCallback, useState } from "react";

export type CaseTab = "documents" | "triggers" | "assessment";

export type NavView =
  | { view: "case_list" }
  | { view: "case_detail"; caseId: string; tab: CaseTab };

export default function useCaseNavigation() {
  const [nav, setNav] = useState<NavView>({ view: "case_list" });

  const goToCaseList = useCallback(() => {
    setNav({ view: "case_list" });
  }, []);

  const openCase = useCallback((caseId: string, tab: CaseTab = "assessment") => {
    setNav({ view: "case_detail", caseId, tab });
  }, []);

  const switchTab = useCallback((tab: CaseTab) => {
    setNav((prev) => {
      if (prev.view !== "case_detail") return prev;
      return { ...prev, tab };
    });
  }, []);

  return { nav, goToCaseList, openCase, switchTab };
}
