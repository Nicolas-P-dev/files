"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import { io, Socket } from "socket.io-client";
import { API_BASE } from "@/lib/constants";
import type {
  WorkspaceMessageEvent,
  AgentThinkingEvent,
  ToolCalledEvent,
  ToolResultEvent,
  RoundTableStartedEvent,
  FindingSubmittedEvent,
  RunCompletedEvent,
  ActivityItem,
  RunStatus,
} from "@/lib/types";

let idCounter = 0;
function nextId(): string {
  return `ev-${++idCounter}`;
}

export default function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const [runId, setRunId] = useState<string | null>(null);
  const [runStatus, setRunStatus] = useState<RunStatus>("idle");
  const [items, setItems] = useState<ActivityItem[]>([]);
  const [thinkingAgent, setThinkingAgent] = useState<string | null>(null);

  // Pending tool calls waiting for results — keyed by "agent:tool"
  const pendingToolsRef = useRef<Map<string, string>>(new Map());

  // Connect once on mount
  useEffect(() => {
    const socket = io(API_BASE, {
      transports: ["websocket", "polling"],
      autoConnect: true,
    });

    socket.on("connect", () => setConnected(true));
    socket.on("disconnect", () => setConnected(false));

    socket.on("joined", () => {
      setRunStatus("running");
    });

    socket.on("replay_started", () => {
      setRunStatus("running");
    });

    socket.on("workspace_message", (data: WorkspaceMessageEvent) => {
      setThinkingAgent(null);
      setItems((prev) => [...prev, { kind: "message", data, id: nextId() }]);
    });

    socket.on("agent_thinking", (data: AgentThinkingEvent) => {
      setThinkingAgent(data.agent);
    });

    socket.on("tool_called", (data: ToolCalledEvent) => {
      const itemId = nextId();
      const key = `${data.agent}:${data.tool}`;
      pendingToolsRef.current.set(key, itemId);
      setItems((prev) => [...prev, { kind: "tool_call", data, id: itemId }]);
    });

    socket.on("tool_result", (data: ToolResultEvent) => {
      const key = `${data.agent}:${data.tool}`;
      const itemId = pendingToolsRef.current.get(key);
      pendingToolsRef.current.delete(key);
      if (itemId) {
        setItems((prev) =>
          prev.map((item) =>
            item.id === itemId && item.kind === "tool_call"
              ? { ...item, result: data }
              : item
          )
        );
      }
    });

    socket.on("round_table_started", (data: RoundTableStartedEvent) => {
      setItems((prev) => [
        ...prev,
        { kind: "round_table_start", data, id: nextId() },
      ]);
    });

    socket.on("finding_submitted", (data: FindingSubmittedEvent) => {
      setItems((prev) => [
        ...prev,
        { kind: "finding", data, id: nextId() },
      ]);
    });

    socket.on("run_completed", (data: RunCompletedEvent) => {
      setThinkingAgent(null);
      setRunStatus("completed");
      setItems((prev) => [
        ...prev,
        { kind: "run_completed", data, id: nextId() },
      ]);
    });

    socket.on("replay_finished", () => {
      setThinkingAgent(null);
      setRunStatus("completed");
    });

    socket.on("run_error", () => {
      setThinkingAgent(null);
      setRunStatus("failed");
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
    };
  }, []);

  const joinRun = useCallback((id: string) => {
    setRunId(id);
    setRunStatus("connecting");
    setItems([]);
    setThinkingAgent(null);
    idCounter = 0;
    pendingToolsRef.current.clear();
    socketRef.current?.emit("join_run", { run_id: id });
  }, []);

  const startReplay = useCallback(async (speed: number = 1.0) => {
    setItems([]);
    setThinkingAgent(null);
    setRunStatus("connecting");
    idCounter = 0;
    pendingToolsRef.current.clear();

    const res = await fetch(`${API_BASE}/api/forbearance/v2/replay`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        log_file: "demo_data/replay_log.json",
        speed: String(speed),
      }),
    });
    const json = await res.json();
    const id = json.run_id as string;
    setRunId(id);
    socketRef.current?.emit("join_run", { run_id: id });
  }, []);

  const startRun = useCallback(
    async (debtorId: string, sheetType: string, triggers = "T-1,T-2,T-3", maxCalls = "60") => {
      setItems([]);
      setThinkingAgent(null);
      setRunStatus("connecting");
      idCounter = 0;
      pendingToolsRef.current.clear();

      const res = await fetch(`${API_BASE}/api/forbearance/v2/run`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          debtor_id: debtorId,
          sheet_type: sheetType,
          skill_id: "forbearance_check",
          triggers,
          max_calls: maxCalls,
        }),
      });
      const json = await res.json();
      const id = json.run_id as string;
      setRunId(id);
      socketRef.current?.emit("join_run", { run_id: id });
    },
    []
  );

  return {
    connected,
    runId,
    runStatus,
    items,
    thinkingAgent,
    joinRun,
    startReplay,
    startRun,
  };
}
