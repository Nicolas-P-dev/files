"use client";

import { useState, useCallback, useRef, useEffect } from "react";

interface PanelSizes {
  left: number;
  center: number;
  right: number;
}

const MIN_PANEL_WIDTH = 200;

export default function useResizablePanels(
  containerRef: React.RefObject<HTMLDivElement | null>,
  initialSizes: PanelSizes = { left: 25, center: 45, right: 30 }
) {
  const [sizes, setSizes] = useState<PanelSizes>(initialSizes);
  const dragging = useRef<"left" | "right" | null>(null);
  const startX = useRef(0);
  const startSizes = useRef<PanelSizes>(initialSizes);

  const onMouseDown = useCallback(
    (handle: "left" | "right", e: React.MouseEvent) => {
      e.preventDefault();
      dragging.current = handle;
      startX.current = e.clientX;
      startSizes.current = { ...sizes };
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    },
    [sizes]
  );

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!dragging.current || !containerRef.current) return;

      const containerWidth = containerRef.current.offsetWidth;
      const handleWidth = 8; // two handles, 4px each
      const availableWidth = containerWidth - handleWidth;
      const dx = e.clientX - startX.current;
      const deltaPercent = (dx / availableWidth) * 100;

      const prev = startSizes.current;
      const minPercent = (MIN_PANEL_WIDTH / availableWidth) * 100;

      if (dragging.current === "left") {
        let newLeft = prev.left + deltaPercent;
        let newCenter = prev.center - deltaPercent;

        if (newLeft < minPercent) {
          newCenter += newLeft - minPercent;
          newLeft = minPercent;
        }
        if (newCenter < minPercent) {
          newLeft += newCenter - minPercent;
          newCenter = minPercent;
        }

        setSizes({ left: newLeft, center: newCenter, right: prev.right });
      } else {
        let newCenter = prev.center + deltaPercent;
        let newRight = prev.right - deltaPercent;

        if (newRight < minPercent) {
          newCenter += newRight - minPercent;
          newRight = minPercent;
        }
        if (newCenter < minPercent) {
          newRight += newCenter - minPercent;
          newCenter = minPercent;
        }

        setSizes({ left: prev.left, center: newCenter, right: newRight });
      }
    };

    const onMouseUp = () => {
      if (dragging.current) {
        dragging.current = null;
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
      }
    };

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, [containerRef]);

  return { sizes, onMouseDown, isDragging: dragging.current !== null };
}
