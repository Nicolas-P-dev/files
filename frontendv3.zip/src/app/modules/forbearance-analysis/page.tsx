"use client";

import React, { useCallback, useState, useMemo } from "react";
import dynamic from "next/dynamic";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import CircularProgress from "@mui/material/CircularProgress";
import IconButton from "@mui/material/IconButton";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import ArrowBackRoundedIcon from "@mui/icons-material/ArrowBackRounded";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import SecurityOutlinedIcon from "@mui/icons-material/SecurityOutlined";
import FactCheckOutlinedIcon from "@mui/icons-material/FactCheckOutlined";
import BusinessIcon from "@mui/icons-material/Business";
import Sidebar from "@/components/layout/Sidebar";
import ChatBar from "@/components/layout/ChatBar";
import TeamActivity from "@/components/panels/TeamActivity";
import FindingsDashboard from "@/components/panels/FindingsDashboard";
import CaseListView from "@/components/cases/CaseListView";
import DocumentsTab from "@/components/cases/DocumentsTab";
import TriggerRulesTab from "@/components/cases/TriggerRulesTab";
import { CaseProvider, useCases } from "@/context/CaseContext";
import useCaseNavigation from "@/hooks/useCaseNavigation";
import type { CaseTab } from "@/hooks/useCaseNavigation";
import useSocket from "@/hooks/useSocket";
import { API_BASE, API_PREFIX } from "@/lib/constants";
import type { TriggerCategory } from "@/lib/types";

// react-pdf uses browser-only APIs — must skip SSR
const DocumentModal = dynamic(
  () => import("@/components/panels/DocumentModal"),
  { ssr: false }
);

/* ------------------------------------------------------------------ */
/*  Tab button                                                         */
/* ------------------------------------------------------------------ */

function TabButton({
  label,
  icon,
  active,
  onClick,
}: {
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <Button
      onClick={onClick}
      startIcon={icon}
      sx={{
        fontSize: 12,
        fontWeight: active ? 700 : 500,
        color: active ? "#26890D" : "#6B778C",
        bgcolor: active ? "rgba(38,137,13,0.08)" : "transparent",
        borderBottom: active ? "2px solid #26890D" : "2px solid transparent",
        borderRadius: 0,
        px: 2,
        py: 0.75,
        minHeight: 40,
        "&:hover": {
          bgcolor: active ? "rgba(38,137,13,0.1)" : "rgba(0,0,0,0.03)",
        },
      }}
    >
      {label}
    </Button>
  );
}

/* ------------------------------------------------------------------ */
/*  Status badge                                                       */
/* ------------------------------------------------------------------ */

const STATUS_BADGE: Record<string, { label: string; color: string; bg: string }> = {
  draft: { label: "Draft", color: "#6B778C", bg: "rgba(107,119,140,0.08)" },
  ready: { label: "Ready", color: "#007CB0", bg: "rgba(0,124,176,0.08)" },
  running: { label: "Running", color: "#ED8B00", bg: "rgba(237,139,0,0.08)" },
  completed: { label: "Completed", color: "#26890D", bg: "rgba(38,137,13,0.08)" },
};

/* ------------------------------------------------------------------ */
/*  Inner page (has access to CaseContext)                              */
/* ------------------------------------------------------------------ */

function ForbearanceInner() {
  const { cases, addCase, deleteCase, getCase, addDocument, removeDocument, addTrigger, updateTrigger, removeTrigger, setTriggers } = useCases();
  const { nav, goToCaseList, openCase, switchTab } = useCaseNavigation();

  // Socket is always connected but startRun/startReplay only used in assessment tab
  const {
    connected,
    runId,
    runStatus,
    items,
    thinkingAgent,
    startReplay,
    startRun,
  } = useSocket();

  // Document modal state
  const [docModalOpen, setDocModalOpen] = useState(false);
  const [docModalTarget, setDocModalTarget] = useState({ doc: "", page: 1 });

  const openDocModal = useCallback((doc: string, page: number) => {
    setDocModalTarget({ doc, page });
    setDocModalOpen(true);
  }, []);

  // Active case
  const activeCase =
    nav.view === "case_detail" ? getCase(nav.caseId) : undefined;
  const activeTab: CaseTab =
    nav.view === "case_detail" ? nav.tab : "assessment";

  // Build TriggerCategory[] from active case triggers for FindingsDashboard
  const externalTriggers = useMemo((): TriggerCategory[] | undefined => {
    if (!activeCase) return undefined;
    const map = new Map<string, TriggerCategory>();
    for (const t of activeCase.triggers) {
      const cat = t.category || "Uncategorized";
      if (!map.has(cat)) map.set(cat, { name: cat, triggers: [] });
      map.get(cat)!.triggers.push({
        id: t.id,
        topic: t.topic,
        hard_soft: t.hardSoft,
        stage: t.stageReference,
      });
    }
    return Array.from(map.values());
  }, [activeCase]);

  // Handlers
  const handleCreateCase = useCallback(
    (data: { borrowerName: string; facilityRef: string; sheetType: "corporate" | "retail" }) => {
      const c = addCase(data);
      openCase(c.id, "documents");
    },
    [addCase, openCase]
  );

  const handleStartRun = useCallback(() => {
    if (!activeCase) return;
    const triggerIds = activeCase.triggers.map((t) => t.id).join(",");
    startRun(
      activeCase.id,
      activeCase.sheetType,
      triggerIds || "T-1,T-2,T-3",
      "60"
    );
  }, [activeCase, startRun]);

  const handleReplay = useCallback(() => {
    if (!activeCase?.lastReplayLog) {
      startReplay(1.0);
      return;
    }
    startReplay(1.0);
  }, [activeCase, startReplay]);

  const isRunning = runStatus === "running" || runStatus === "connecting";

  /* ---------------------------------------------------------------- */
  /*  Case List view                                                   */
  /* ---------------------------------------------------------------- */
  if (nav.view === "case_list") {
    return (
      <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
        <Sidebar />
        <CaseListView
          cases={cases}
          onOpenCase={(id) => openCase(id)}
          onCreateCase={handleCreateCase}
          onDeleteCase={deleteCase}
        />
      </Box>
    );
  }

  /* ---------------------------------------------------------------- */
  /*  Case Detail view                                                 */
  /* ---------------------------------------------------------------- */
  if (!activeCase) {
    // Case was deleted or not found — go back
    goToCaseList();
    return null;
  }

  const badge = STATUS_BADGE[activeCase.status] ?? STATUS_BADGE.draft;

  return (
    <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      <Sidebar activeCaseName={activeCase.borrowerName} activeFacilityRef={activeCase.facilityRef} />

      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          bgcolor: "#F5F7F9",
        }}
      >
        {/* Top bar: breadcrumb + tabs + actions */}
        <Box
          sx={{
            bgcolor: "background.paper",
            borderBottom: "1px solid #E6E6E6",
            flexShrink: 0,
          }}
        >
          {/* Row 1: breadcrumb + status + case meta */}
          <Box
            sx={{
              height: 48,
              px: 2,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <IconButton
              size="small"
              onClick={goToCaseList}
              sx={{ color: "#6B778C", mr: 0.25 }}
            >
              <ArrowBackRoundedIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography
              onClick={goToCaseList}
              sx={{
                fontSize: 12,
                color: "#007CB0",
                cursor: "pointer",
                "&:hover": { textDecoration: "underline" },
              }}
            >
              Forbearance Analysis
            </Typography>
            <Typography sx={{ fontSize: 12, color: "#A5ADBA" }}>/</Typography>
            <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
              <BusinessIcon sx={{ fontSize: 16, color: "#6B778C" }} />
              <Typography sx={{ fontSize: 13, fontWeight: 600, color: "#172B4D" }}>
                {activeCase.borrowerName}
              </Typography>
            </Box>
            <Chip
              label={activeCase.sheetType === "corporate" ? "Corporate" : "Retail"}
              size="small"
              sx={{
                height: 20,
                fontSize: 10,
                fontWeight: 600,
                bgcolor: "rgba(0,124,176,0.08)",
                color: "#007CB0",
                "& .MuiChip-label": { px: 0.5 },
              }}
            />
            <Chip
              label={badge.label}
              size="small"
              sx={{
                height: 20,
                fontSize: 10,
                fontWeight: 600,
                bgcolor: badge.bg,
                color: badge.color,
                "& .MuiChip-label": { px: 0.5 },
              }}
            />
            <Box sx={{ flex: 1 }} />
            <Typography sx={{ fontSize: 10, color: "#A5ADBA" }}>
              {activeCase.facilityRef}
            </Typography>
          </Box>

          {/* Row 2: tabs + assessment actions */}
          <Box
            sx={{
              px: 2,
              display: "flex",
              alignItems: "flex-end",
              gap: 0,
            }}
          >
            <TabButton
              label="Documents"
              icon={<DescriptionOutlinedIcon sx={{ fontSize: 15 }} />}
              active={activeTab === "documents"}
              onClick={() => switchTab("documents")}
            />
            <TabButton
              label="Trigger Rules"
              icon={<SecurityOutlinedIcon sx={{ fontSize: 15 }} />}
              active={activeTab === "triggers"}
              onClick={() => switchTab("triggers")}
            />
            <TabButton
              label="Assessment"
              icon={<FactCheckOutlinedIcon sx={{ fontSize: 15 }} />}
              active={activeTab === "assessment"}
              onClick={() => switchTab("assessment")}
            />

            {/* Spacer */}
            <Box sx={{ flex: 1 }} />

            {/* Assessment tab actions */}
            {activeTab === "assessment" && (
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, pb: 0.5 }}>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<ReplayRoundedIcon sx={{ fontSize: 14 }} />}
                  disabled={isRunning}
                  onClick={handleReplay}
                  sx={{
                    height: 32,
                    px: 1.5,
                    fontSize: 11,
                    fontWeight: 600,
                    borderColor: "#D0D0CE",
                    color: "#6B778C",
                    "&:hover": {
                      borderColor: "#007CB0",
                      color: "#007CB0",
                      bgcolor: "rgba(0,124,176,0.04)",
                    },
                  }}
                >
                  Replay
                </Button>
                {runStatus === "completed" && runId && (
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<DownloadRoundedIcon sx={{ fontSize: 14 }} />}
                    onClick={() =>
                      window.open(
                        `${API_BASE}${API_PREFIX}/run/${runId}/report?format=excel`,
                        "_blank"
                      )
                    }
                    sx={{
                      height: 32,
                      px: 1.5,
                      fontSize: 11,
                      fontWeight: 600,
                      borderColor: "#26890D",
                      color: "#26890D",
                      "&:hover": {
                        borderColor: "#1e6e0a",
                        color: "#1e6e0a",
                        bgcolor: "rgba(38,137,13,0.04)",
                      },
                    }}
                  >
                    Report
                  </Button>
                )}
                <Button
                  variant="contained"
                  size="small"
                  startIcon={
                    isRunning ? (
                      <CircularProgress size={12} sx={{ color: "#fff" }} />
                    ) : (
                      <PlayArrowRoundedIcon sx={{ fontSize: 16 }} />
                    )
                  }
                  disabled={isRunning}
                  onClick={handleStartRun}
                  sx={{
                    height: 32,
                    px: 2,
                    fontSize: 12,
                    fontWeight: 600,
                    bgcolor: "#26890D",
                    boxShadow: "none",
                    "&:hover": {
                      bgcolor: "#1e6e0a",
                      boxShadow: "0 2px 8px rgba(38,137,13,0.25)",
                    },
                    "&.Mui-disabled": { bgcolor: "#A5ADBA", color: "#fff" },
                  }}
                >
                  {isRunning ? "Running..." : "Run Assessment"}
                </Button>
              </Box>
            )}
          </Box>
        </Box>

        {/* Tab content */}
        {activeTab === "documents" && (
          <DocumentsTab
            documents={activeCase.documents}
            onAdd={(doc) => addDocument(activeCase.id, doc)}
            onRemove={(docId) => removeDocument(activeCase.id, docId)}
          />
        )}

        {activeTab === "triggers" && (
          <TriggerRulesTab
            triggers={activeCase.triggers}
            onAdd={(t) => addTrigger(activeCase.id, t)}
            onUpdate={(tid, patch) => updateTrigger(activeCase.id, tid, patch)}
            onRemove={(tid) => removeTrigger(activeCase.id, tid)}
            onSetAll={(trigs) => setTriggers(activeCase.id, trigs)}
          />
        )}

        {activeTab === "assessment" && (
          <>
            {/* Two-panel workspace */}
            {runStatus === "idle" && items.length === 0 ? (
              /* Empty state for assessment */
              <Box
                sx={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 1.5,
                  p: 4,
                }}
              >
                <Box
                  sx={{
                    width: 64,
                    height: 64,
                    borderRadius: 2,
                    bgcolor: "rgba(38,137,13,0.06)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <FactCheckOutlinedIcon sx={{ fontSize: 32, color: "#26890D" }} />
                </Box>
                <Typography sx={{ fontSize: 15, fontWeight: 600, color: "#172B4D" }}>
                  Ready to Assess
                </Typography>
                <Typography
                  sx={{
                    fontSize: 12,
                    color: "#6B778C",
                    textAlign: "center",
                    maxWidth: 360,
                    lineHeight: 1.6,
                  }}
                >
                  {activeCase.documents.length} document{activeCase.documents.length !== 1 ? "s" : ""} and{" "}
                  {activeCase.triggers.length} trigger{activeCase.triggers.length !== 1 ? "s" : ""} configured.
                  Click <strong>Run Assessment</strong> or <strong>Replay</strong> to begin.
                </Typography>
              </Box>
            ) : (
              <Box
                sx={{
                  display: "flex",
                  overflow: "hidden",
                  px: 2,
                  pt: 2,
                  pb: 2,
                  gap: 2,
                  flex: 1,
                }}
              >
                {/* Left panel: Team Activity (55%) */}
                <Box
                  sx={{
                    width: "55%",
                    minWidth: 300,
                    height: "100%",
                    overflow: "hidden",
                  }}
                >
                  <TeamActivity
                    items={items}
                    thinkingAgent={thinkingAgent}
                    runStatus={runStatus}
                    connected={connected}
                    onViewDocument={openDocModal}
                  />
                </Box>

                {/* Right panel: Findings Dashboard (45%) */}
                <Box
                  sx={{
                    width: "45%",
                    minWidth: 280,
                    height: "100%",
                    overflow: "hidden",
                  }}
                >
                  <FindingsDashboard
                    items={items}
                    runStatus={runStatus}
                    onViewDocument={openDocModal}
                    externalTriggers={externalTriggers}
                  />
                </Box>
              </Box>
            )}

            {/* Chat bar */}
            <ChatBar runId={runId} runStatus={runStatus} />
          </>
        )}
      </Box>

      {/* Document Modal */}
      <DocumentModal
        open={docModalOpen}
        onClose={() => setDocModalOpen(false)}
        docName={docModalTarget.doc}
        initialPage={docModalTarget.page}
      />
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Page wrapper with CaseProvider                                      */
/* ------------------------------------------------------------------ */

export default function ForbearanceAnalysisPage() {
  return (
    <CaseProvider>
      <ForbearanceInner />
    </CaseProvider>
  );
}
