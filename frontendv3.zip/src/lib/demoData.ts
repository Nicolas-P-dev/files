import type { Case } from "./caseTypes";

export const DEMO_CASE: Case = {
  id: "demo-meridian-001",
  borrowerName: "Meridian Industries GmbH",
  facilityRef: "FA-2019-MI-001",
  sheetType: "corporate",
  status: "ready",
  documents: [
    {
      id: "doc-1",
      filename: "FacilityAgreement.pdf",
      pageCount: 12,
      size: "1.4 MB",
      uploadDate: "2024-11-15",

    },
    {
      id: "doc-2",
      filename: "FinancialStatements_2023.pdf",
      pageCount: 28,
      size: "2.1 MB",
      uploadDate: "2024-11-15",

    },
    {
      id: "doc-3",
      filename: "NPL_Report.pdf",
      pageCount: 8,
      size: "0.9 MB",
      uploadDate: "2024-11-15",

    },
    {
      id: "doc-4",
      filename: "BoardMinutes_Q1_2023.pdf",
      pageCount: 6,
      size: "0.7 MB",
      uploadDate: "2024-11-15",

    },
    {
      id: "doc-5",
      filename: "Correspondence.pdf",
      pageCount: 4,
      size: "0.3 MB",
      uploadDate: "2024-11-15",

    },
  ],
  triggers: [
    {
      id: "T-1",
      category: "Concessions",
      topic: "Interest rate reduction below market",
      hardSoft: "Hard",
      stageReference: "Stage 2",
      description: "Reduction of the interest rate or other fees to a level below the rate the borrower could obtain on the market",

    },
    {
      id: "T-2",
      category: "Concessions",
      topic: "Maturity extension beyond original terms",
      hardSoft: "Hard",
      stageReference: "Stage 2",
      description: "Extension of the maturity date beyond the originally agreed terms",

    },
    {
      id: "T-3",
      category: "Concessions",
      topic: "Capitalization of arrears",
      hardSoft: "Hard",
      stageReference: "Stage 3",
      description: "Capitalization or deferral of arrears into the loan principal",

    },
    {
      id: "T-4",
      category: "Concessions",
      topic: "Covenant waiver or relaxation",
      hardSoft: "Soft",
      stageReference: "Stage 2",
      description: "Waiver or relaxation of financial covenants that would otherwise trigger default",

    },
    {
      id: "T-5",
      category: "Financial Difficulty Indicators",
      topic: "Significant financial difficulty of borrower",
      hardSoft: "Hard",
      stageReference: "Stage 2",
      description: "Evidence that the borrower is experiencing significant financial difficulty",

    },
    {
      id: "T-6",
      category: "Financial Difficulty Indicators",
      topic: "Breach of financial covenants",
      hardSoft: "Soft",
      stageReference: "Stage 2",
      description: "Breach or expected breach of financial covenants",

    },
    {
      id: "T-7",
      category: "Financial Difficulty Indicators",
      topic: "Financial covenant breach",
      hardSoft: "Hard",
      stageReference: "Stage 2",
      description: "Breach or expected breach of financial covenants indicating deterioration beyond original credit approval terms",

    },
    {
      id: "T-8",
      category: "Early Warning Signals",
      topic: "Repeated restructuring requests",
      hardSoft: "Hard",
      stageReference: "Stage 3",
      description: "Multiple restructuring requests within a specified period",

    },
    {
      id: "T-9",
      category: "Early Warning Signals",
      topic: "Cross-default or cross-acceleration",
      hardSoft: "Hard",
      stageReference: "Stage 3",
      description: "Cross-default or cross-acceleration clauses triggered on other facilities",

    },
    {
      id: "T-10",
      category: "Backstop Indicators",
      topic: "Unlikely to pay (UTP) assessment",
      hardSoft: "Hard",
      stageReference: "Stage 3",
      description: "Assessment that the borrower is unlikely to pay its credit obligations in full without realisation of collateral or restructuring",

    },
  ],
  lastAssessmentDate: null,
  createdAt: "2024-11-15",
  lastRunId: null,
  lastReplayLog: "demo_data/replay_log.json",
};
