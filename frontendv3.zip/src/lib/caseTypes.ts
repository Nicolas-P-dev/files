/** Case management data model */

export interface CaseDocument {
  id: string;
  filename: string;
  pageCount: number;
  size: string;
  uploadDate: string;
}

export interface CaseTrigger {
  id: string;
  category: string;
  topic: string;
  hardSoft: string;
  stageReference: string;
  description: string;
}

export type CaseStatus = "draft" | "ready" | "running" | "completed";

export interface Case {
  id: string;
  borrowerName: string;
  facilityRef: string;
  sheetType: "corporate" | "retail";
  status: CaseStatus;
  documents: CaseDocument[];
  triggers: CaseTrigger[];
  lastAssessmentDate: string | null;
  createdAt: string;
  lastRunId: string | null;
  lastReplayLog: string | null;
}
