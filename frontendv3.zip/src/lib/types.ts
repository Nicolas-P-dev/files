/** WebSocket event types matching Section 4.7 schemas */

export interface WorkspaceMessageEvent {
  run_id: string;
  speaker: string;
  type: string;
  content: string;
  importance: string;
  tools_used: string[];
  trigger_refs: string[];
  flags: string[];
  timestamp: number;
}

export interface AgentThinkingEvent {
  run_id: string;
  agent: string;
  turn: number;
}

export interface ToolCalledEvent {
  run_id: string;
  agent: string;
  tool: string;
  input: Record<string, unknown>;
}

export interface ToolResultEvent {
  run_id: string;
  agent: string;
  tool: string;
  result_preview: string;
}

export interface FindingSubmittedEvent {
  run_id: string;
  trigger_id: string;
  status: string;
  confidence: number;
  stage: string;
  reasoning: string;
  category?: string;
  topic?: string;
  hard_soft?: string;
}

export interface RoundTableStartedEvent {
  run_id: string;
  topic: string;
  participants: string[];
}

export interface RunCompletedEvent {
  run_id: string;
  total: number;
  found: number;
  not_found: number;
  inconclusive: number;
}

/** A display item in the activity stream — either a message card or a tool call */
export type ActivityItem =
  | { kind: "message"; data: WorkspaceMessageEvent; id: string }
  | { kind: "tool_call"; data: ToolCalledEvent; result?: ToolResultEvent; id: string }
  | { kind: "thinking"; data: AgentThinkingEvent; id: string }
  | { kind: "round_table_start"; data: RoundTableStartedEvent; id: string }
  | { kind: "finding"; data: FindingSubmittedEvent; id: string }
  | { kind: "run_completed"; data: RunCompletedEvent; id: string };

/** Run status */
export type RunStatus = "idle" | "connecting" | "running" | "completed" | "failed";

/** Document navigation command — sent from activity stream to document viewer */
export interface DocNavCommand {
  document: string;
  page: number;
  highlightColor?: "green" | "amber";
  /** Text to search for and highlight on the page (from tool_result) */
  searchText?: string;
}

/** Evidence highlight persisted in the viewer */
export interface Highlight {
  id: string;
  document: string;
  page: number;
  color: "green" | "amber";
  triggerId?: string;
}

/** Sample document metadata from /documents/list endpoint */
export interface SampleDocument {
  name: string;
  size: number;
}

/** Trigger info from GET /triggers endpoint */
export interface TriggerInfo {
  id: string;
  topic: string;
  hard_soft: string;
  stage: string;
}

/** Category grouping from GET /triggers endpoint */
export interface TriggerCategory {
  name: string;
  triggers: TriggerInfo[];
}
