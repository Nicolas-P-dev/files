/** Agent display names and accent colors */
export const AGENT_CONFIG: Record<
  string,
  { label: string; color: string; bgLight: string }
> = {
  lead_auditor: {
    label: "Lead Auditor",
    color: "#1B365D",
    bgLight: "rgba(27,54,93,0.06)",
  },
  document_analyst: {
    label: "Document Analyst",
    color: "#00838F",
    bgLight: "rgba(0,131,143,0.06)",
  },
  policy_expert: {
    label: "Policy Expert",
    color: "#8B1A4A",
    bgLight: "rgba(139,26,74,0.06)",
  },
  assessment_writer: {
    label: "Assessment Writer",
    color: "#2E7D32",
    bgLight: "rgba(46,125,50,0.06)",
  },
};

/** Message type labels */
export const MESSAGE_TYPE_LABELS: Record<string, string> = {
  directive: "Directive",
  finding: "Finding",
  reaction: "Reaction",
  flag: "Flag",
  question: "Question",
  assessment_draft: "Draft",
  decision: "Decision",
  synthesis: "Synthesis",
  user_input: "User",
};

export const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
export const API_PREFIX = "/api/forbearance/v2";
