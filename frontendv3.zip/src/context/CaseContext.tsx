"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import type { Case, CaseDocument, CaseTrigger, CaseStatus } from "@/lib/caseTypes";
import { DEMO_CASE } from "@/lib/demoData";

const STORAGE_KEY = "fortuna-cases-v2";

interface CaseContextValue {
  cases: Case[];
  addCase: (c: Omit<Case, "id" | "createdAt" | "status" | "documents" | "triggers" | "lastAssessmentDate" | "lastRunId" | "lastReplayLog">) => Case;
  updateCase: (id: string, patch: Partial<Case>) => void;
  deleteCase: (id: string) => void;
  getCase: (id: string) => Case | undefined;
  addDocument: (caseId: string, doc: CaseDocument) => void;
  removeDocument: (caseId: string, docId: string) => void;
  addTrigger: (caseId: string, trigger: CaseTrigger) => void;
  updateTrigger: (caseId: string, triggerId: string, patch: Partial<CaseTrigger>) => void;
  removeTrigger: (caseId: string, triggerId: string) => void;
  setTriggers: (caseId: string, triggers: CaseTrigger[]) => void;
  setCaseStatus: (caseId: string, status: CaseStatus) => void;
}

const CaseContext = createContext<CaseContextValue | null>(null);

function loadCases(): Case[] {
  if (typeof window === "undefined") return [DEMO_CASE];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Case[];
      // Ensure demo case is always present
      if (!parsed.find((c) => c.id === DEMO_CASE.id)) {
        return [DEMO_CASE, ...parsed];
      }
      return parsed;
    }
  } catch {
    // corrupt storage
  }
  return [DEMO_CASE];
}

function saveCases(cases: Case[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cases));
  } catch {
    // quota exceeded or private mode
  }
}

let idSeq = Date.now();
function genId(prefix: string) {
  return `${prefix}-${(++idSeq).toString(36)}`;
}

export function CaseProvider({ children }: { children: React.ReactNode }) {
  const [cases, setCases] = useState<Case[]>(() => loadCases());

  // Persist whenever cases change
  useEffect(() => {
    saveCases(cases);
  }, [cases]);

  const addCase = useCallback(
    (partial: Omit<Case, "id" | "createdAt" | "status" | "documents" | "triggers" | "lastAssessmentDate" | "lastRunId" | "lastReplayLog">): Case => {
      const newCase: Case = {
        ...partial,
        id: genId("case"),
        createdAt: new Date().toISOString().slice(0, 10),
        status: "draft",
        documents: [],
        triggers: [],
        lastAssessmentDate: null,
        lastRunId: null,
        lastReplayLog: null,
      };
      setCases((prev) => [...prev, newCase]);
      return newCase;
    },
    []
  );

  const updateCase = useCallback((id: string, patch: Partial<Case>) => {
    setCases((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...patch } : c))
    );
  }, []);

  const deleteCase = useCallback((id: string) => {
    if (id === DEMO_CASE.id) return; // never delete demo
    setCases((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const getCase = useCallback(
    (id: string) => cases.find((c) => c.id === id),
    [cases]
  );

  const addDocument = useCallback((caseId: string, doc: CaseDocument) => {
    setCases((prev) =>
      prev.map((c) =>
        c.id === caseId ? { ...c, documents: [...c.documents, doc] } : c
      )
    );
  }, []);

  const removeDocument = useCallback((caseId: string, docId: string) => {
    setCases((prev) =>
      prev.map((c) =>
        c.id === caseId
          ? { ...c, documents: c.documents.filter((d) => d.id !== docId) }
          : c
      )
    );
  }, []);

  const addTrigger = useCallback((caseId: string, trigger: CaseTrigger) => {
    setCases((prev) =>
      prev.map((c) =>
        c.id === caseId ? { ...c, triggers: [...c.triggers, trigger] } : c
      )
    );
  }, []);

  const updateTrigger = useCallback(
    (caseId: string, triggerId: string, patch: Partial<CaseTrigger>) => {
      setCases((prev) =>
        prev.map((c) =>
          c.id === caseId
            ? {
                ...c,
                triggers: c.triggers.map((t) =>
                  t.id === triggerId ? { ...t, ...patch } : t
                ),
              }
            : c
        )
      );
    },
    []
  );

  const removeTrigger = useCallback((caseId: string, triggerId: string) => {
    setCases((prev) =>
      prev.map((c) =>
        c.id === caseId
          ? { ...c, triggers: c.triggers.filter((t) => t.id !== triggerId) }
          : c
      )
    );
  }, []);

  const setTriggers = useCallback((caseId: string, triggers: CaseTrigger[]) => {
    setCases((prev) =>
      prev.map((c) => (c.id === caseId ? { ...c, triggers } : c))
    );
  }, []);

  const setCaseStatus = useCallback((caseId: string, status: CaseStatus) => {
    setCases((prev) =>
      prev.map((c) => (c.id === caseId ? { ...c, status } : c))
    );
  }, []);

  return (
    <CaseContext.Provider
      value={{
        cases,
        addCase,
        updateCase,
        deleteCase,
        getCase,
        addDocument,
        removeDocument,
        addTrigger,
        updateTrigger,
        removeTrigger,
        setTriggers,
        setCaseStatus,
      }}
    >
      {children}
    </CaseContext.Provider>
  );
}

export function useCases() {
  const ctx = useContext(CaseContext);
  if (!ctx) throw new Error("useCases must be used within CaseProvider");
  return ctx;
}
