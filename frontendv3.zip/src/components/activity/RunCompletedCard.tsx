"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import CheckCircleOutlineRoundedIcon from "@mui/icons-material/CheckCircleOutlineRounded";
import type { RunCompletedEvent } from "@/lib/types";

interface RunCompletedCardProps {
  data: RunCompletedEvent;
}

export default function RunCompletedCard({ data }: RunCompletedCardProps) {
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1,
        px: 1.5,
        py: 1,
        borderRadius: 1.5,
        bgcolor: "rgba(38,137,13,0.06)",
        border: "1px solid rgba(38,137,13,0.2)",
      }}
    >
      <CheckCircleOutlineRoundedIcon
        sx={{ fontSize: 18, color: "#26890D" }}
      />
      <Box>
        <Typography sx={{ fontSize: 12, fontWeight: 700, color: "#26890D" }}>
          Assessment Complete
        </Typography>
        <Typography sx={{ fontSize: 11, color: "#53565A" }}>
          {data.total} trigger{data.total !== 1 ? "s" : ""} evaluated
          {data.found > 0 && ` \u00b7 ${data.found} found`}
          {data.inconclusive > 0 && ` \u00b7 ${data.inconclusive} inconclusive`}
          {data.not_found > 0 && ` \u00b7 ${data.not_found} not found`}
        </Typography>
      </Box>
    </Box>
  );
}
