"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import OpenInNewRoundedIcon from "@mui/icons-material/OpenInNewRounded";
import type { ToolCalledEvent, ToolResultEvent } from "@/lib/types";

interface ToolCallBlockProps {
  data: ToolCalledEvent;
  result?: ToolResultEvent;
  onViewDocument?: (document: string, page: number) => void;
}

const TOOL_ICONS: Record<string, React.ReactNode> = {
  search_documents: <SearchRoundedIcon sx={{ fontSize: 11 }} />,
  read_page: <DescriptionOutlinedIcon sx={{ fontSize: 11 }} />,
};

/** Professional label instead of raw function call syntax */
function formatLabel(tool: string, input: Record<string, unknown>): string {
  if (tool === "search_documents") {
    const query = String(input.query ?? "");
    return query.length > 60 ? query.slice(0, 57) + "..." : query;
  }
  if (tool === "read_page") {
    return `${input.document ?? "?"}, page ${input.page ?? "?"}`;
  }
  return tool.replace(/_/g, " ");
}

function toolLabel(tool: string): string {
  if (tool === "search_documents") return "Search";
  if (tool === "read_page") return "Reading";
  return tool.replace(/_/g, " ");
}

export default function ToolCallBlock({
  data,
  result,
  onViewDocument,
}: ToolCallBlockProps) {
  const icon = TOOL_ICONS[data.tool] ?? (
    <SearchRoundedIcon sx={{ fontSize: 11 }} />
  );

  const isReadPage = data.tool === "read_page" && Boolean(data.input.document);

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 0.75,
        px: 1.25,
        py: 0.375,
        borderRadius: 1,
        bgcolor: "rgba(0,131,143,0.04)",
        border: "1px solid rgba(0,131,143,0.1)",
        overflow: "hidden",
      }}
    >
      <Box sx={{ flexShrink: 0, display: "flex", alignItems: "center", color: "#00838F" }}>
        {icon}
      </Box>
      <Typography
        sx={{
          fontSize: 10.5,
          fontWeight: 600,
          color: "#00838F",
          flexShrink: 0,
        }}
      >
        {toolLabel(data.tool)}
      </Typography>
      <Typography
        sx={{
          fontSize: 10.5,
          color: "#53565A",
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
          flex: 1,
        }}
      >
        {formatLabel(data.tool, data.input)}
      </Typography>
      {isReadPage && onViewDocument && (
        <Box
          component="button"
          onClick={() =>
            onViewDocument(
              String(data.input.document),
              Number(data.input.page ?? 1)
            )
          }
          sx={{
            all: "unset",
            display: "flex",
            alignItems: "center",
            gap: 0.375,
            ml: "auto",
            flexShrink: 0,
            cursor: "pointer",
            fontSize: 10,
            fontWeight: 600,
            color: "#007CB0",
            "&:hover": { color: "#005A80", textDecoration: "underline" },
          }}
        >
          <OpenInNewRoundedIcon sx={{ fontSize: 10 }} />
          View
        </Box>
      )}
    </Box>
  );
}
