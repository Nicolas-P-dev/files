"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import RemoveCircleOutlineRoundedIcon from "@mui/icons-material/RemoveCircleOutlineRounded";
import HelpOutlineRoundedIcon from "@mui/icons-material/HelpOutlineRounded";
import type { FindingSubmittedEvent } from "@/lib/types";

interface FindingCardProps {
  data: FindingSubmittedEvent;
}

const STATUS_CONFIG: Record<
  string,
  { icon: React.ReactNode; color: string; bg: string; label: string }
> = {
  FOUND: {
    icon: <CheckCircleRoundedIcon sx={{ fontSize: 13 }} />,
    color: "#26890D",
    bg: "rgba(38,137,13,0.06)",
    label: "Found",
  },
  NOT_FOUND: {
    icon: <RemoveCircleOutlineRoundedIcon sx={{ fontSize: 13 }} />,
    color: "#6B778C",
    bg: "rgba(107,119,140,0.06)",
    label: "Not Found",
  },
  INCONCLUSIVE: {
    icon: <HelpOutlineRoundedIcon sx={{ fontSize: 13 }} />,
    color: "#ED8B00",
    bg: "rgba(237,139,0,0.06)",
    label: "Inconclusive",
  },
};

export default function FindingCard({ data }: FindingCardProps) {
  const status = STATUS_CONFIG[data.status] ?? STATUS_CONFIG.INCONCLUSIVE;

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 0.75,
        px: 1.25,
        py: 0.625,
        borderRadius: 1,
        bgcolor: status.bg,
        border: `1px solid ${status.color}20`,
      }}
    >
      <Box sx={{ color: status.color, display: "flex", flexShrink: 0 }}>{status.icon}</Box>
      <Typography sx={{ fontSize: 10.5, fontWeight: 700, color: status.color, flexShrink: 0 }}>
        {data.trigger_id}
      </Typography>
      {data.topic && (
        <Typography
          sx={{
            fontSize: 10.5,
            color: "#53565A",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            flex: 1,
          }}
        >
          {data.topic}
        </Typography>
      )}
      {/* Small status dot instead of large chip */}
      <Box
        sx={{
          width: 5,
          height: 5,
          borderRadius: "50%",
          bgcolor: status.color,
          flexShrink: 0,
          ml: "auto",
        }}
      />
      <Typography sx={{ fontSize: 9.5, color: "#6B778C", flexShrink: 0 }}>
        {status.label} · {Math.round(data.confidence * 100)}%
      </Typography>
      {data.stage && (
        <Typography sx={{ fontSize: 9.5, color: "#1B365D", fontWeight: 600, flexShrink: 0 }}>
          {data.stage}
        </Typography>
      )}
    </Box>
  );
}
