"use client";

import React, { useState, useMemo } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import Collapse from "@mui/material/Collapse";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import FlagRoundedIcon from "@mui/icons-material/FlagRounded";
import ReactMarkdown from "react-markdown";
import { AGENT_CONFIG, MESSAGE_TYPE_LABELS } from "@/lib/constants";
import type { WorkspaceMessageEvent } from "@/lib/types";

/** Messages longer than this get a collapse/expand toggle */
const EXPAND_THRESHOLD = 800;

interface MessageCardProps {
  data: WorkspaceMessageEvent;
  onViewDocument?: (document: string, page: number) => void;
}

/** Regex to match PDF page references like "FacilityAgreement.pdf, p.4" */
const DOC_LINK_RE = /([\w_]+\.pdf)[,\s]+p(?:age)?\.?\s*(\d+)/gi;

/**
 * Pre-process content to convert PDF page references into markdown links
 * with a custom scheme so the `a` component can intercept them.
 */
function preprocessDocLinks(content: string): string {
  return content.replace(DOC_LINK_RE, (match, doc, page) => {
    return `[${match}](#viewdoc:${doc}:${page})`;
  });
}

export default function MessageCard({ data, onViewDocument }: MessageCardProps) {
  const agent = AGENT_CONFIG[data.speaker] ?? {
    label: data.speaker,
    color: "#53565A",
    bgLight: "rgba(83,86,90,0.06)",
  };

  const isDecision = data.type === "decision";
  const isLong = data.content.length > EXPAND_THRESHOLD;

  const [expanded, setExpanded] = useState(true);

  const timeStr = data.timestamp
    ? new Date(data.timestamp * 1000).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    : "";

  const isAWFinding =
    data.speaker === "assessment_writer" && data.type === "finding";

  // Pre-process content: inject doc links as markdown links
  const processedContent = useMemo(
    () => (onViewDocument ? preprocessDocLinks(data.content) : data.content),
    [data.content, onViewDocument],
  );

  /** Custom markdown components — compact typography, no extra margins */
  const mdComponents = useMemo(
    () => ({
      h1: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 11, fontWeight: 700, mt: 0.5, mb: 0.25 }}
        >
          {children}
        </Typography>
      ),
      h2: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 11, fontWeight: 700, mt: 0.5, mb: 0.25 }}
        >
          {children}
        </Typography>
      ),
      h3: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 10.5, fontWeight: 700, mt: 0.5, mb: 0.25 }}
        >
          {children}
        </Typography>
      ),
      h4: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 10.5, fontWeight: 600, mt: 0.25 }}
        >
          {children}
        </Typography>
      ),
      h5: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 10.5, fontWeight: 600 }}
        >
          {children}
        </Typography>
      ),
      h6: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="span"
          sx={{ display: "block", fontSize: 10.5, fontWeight: 600 }}
        >
          {children}
        </Typography>
      ),
      p: ({ children }: { children?: React.ReactNode }) => (
        <Typography
          component="div"
          sx={{
            fontSize: 11,
            lineHeight: 1.5,
            color: "text.primary",
            mb: 0.5,
            "&:last-child": { mb: 0 },
            ...(isAWFinding && { fontStyle: "italic", color: "#2E7D32" }),
          }}
        >
          {children}
        </Typography>
      ),
      strong: ({ children }: { children?: React.ReactNode }) => (
        <strong style={{ fontWeight: 700 }}>{children}</strong>
      ),
      em: ({ children }: { children?: React.ReactNode }) => (
        <em>{children}</em>
      ),
      hr: () => (
        <Box
          component="hr"
          sx={{
            border: "none",
            borderTop: "1px solid rgba(0,0,0,0.08)",
            my: 0.5,
          }}
        />
      ),
      ul: ({ children }: { children?: React.ReactNode }) => (
        <Box component="ul" sx={{ m: 0, pl: 2, "& li": { fontSize: 11, lineHeight: 1.5, mb: 0.25 } }}>
          {children}
        </Box>
      ),
      ol: ({ children }: { children?: React.ReactNode }) => (
        <Box component="ol" sx={{ m: 0, pl: 2, "& li": { fontSize: 11, lineHeight: 1.5, mb: 0.25 } }}>
          {children}
        </Box>
      ),
      blockquote: ({ children }: { children?: React.ReactNode }) => (
        <Box
          sx={{
            borderLeft: "2px solid rgba(0,0,0,0.12)",
            pl: 1,
            my: 0.25,
            color: "#53565A",
            fontSize: 10.5,
            fontStyle: "italic",
          }}
        >
          {children}
        </Box>
      ),
      code: ({ children }: { children?: React.ReactNode }) => (
        <Box
          component="code"
          sx={{
            fontSize: 10,
            bgcolor: "rgba(0,0,0,0.04)",
            px: 0.5,
            py: 0.125,
            borderRadius: 0.5,
          }}
        >
          {children}
        </Box>
      ),
      // Intercept links: doc viewer links have #viewdoc: prefix
      a: ({
        href,
        children,
      }: {
        href?: string;
        children?: React.ReactNode;
      }) => {
        if (href?.startsWith("#viewdoc:") && onViewDocument) {
          const parts = href.slice(9).split(":");
          const doc = parts[0];
          const page = parseInt(parts[1] ?? "1", 10);
          return (
            <span
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                onViewDocument(doc, page);
              }}
              style={{
                color: "#007CB0",
                textDecoration: "underline",
                cursor: "pointer",
              }}
            >
              {children}
            </span>
          );
        }
        return <span>{children}</span>;
      },
    }),
    [onViewDocument, isAWFinding],
  );

  const contentBlock = (
    <Box sx={{ px: 1, pb: 0.75, pt: 0 }}>
      <ReactMarkdown components={mdComponents as never}>
        {processedContent}
      </ReactMarkdown>
    </Box>
  );

  return (
    <Box
      sx={{
        borderRadius: 1,
        border: "1px solid",
        borderColor: "rgba(0,0,0,0.05)",
        borderLeft: isDecision
          ? "3px solid #C5A200"
          : `3px solid ${agent.color}`,
        bgcolor: agent.bgLight,
        overflow: "hidden",
      }}
    >
      {/* Header row */}
      <Box
        sx={{
          px: 1,
          py: 0.5,
          display: "flex",
          alignItems: "center",
          gap: 0.5,
          cursor: isLong ? "pointer" : "default",
        }}
        onClick={isLong ? () => setExpanded(!expanded) : undefined}
      >
        <Box
          sx={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            bgcolor: agent.color,
            flexShrink: 0,
          }}
        />
        <Typography
          sx={{
            fontSize: 10.5,
            fontWeight: 700,
            color: agent.color,
            letterSpacing: 0.2,
            flexShrink: 0,
          }}
        >
          {agent.label}
        </Typography>
        <Chip
          label={MESSAGE_TYPE_LABELS[data.type] ?? data.type}
          size="small"
          sx={{
            height: 16,
            fontSize: 9,
            fontWeight: 600,
            bgcolor: isDecision
              ? "rgba(197,162,0,0.12)"
              : `${agent.color}18`,
            color: isDecision ? "#8B6914" : agent.color,
            "& .MuiChip-label": { px: 0.5 },
            flexShrink: 0,
          }}
        />

        {isLong && (
          <Box sx={{ display: "flex", alignItems: "center", ml: "auto", gap: 0.25 }}>
            <ExpandMoreRoundedIcon
              sx={{
                fontSize: 14,
                color: "#6B778C",
                transform: expanded ? "rotate(180deg)" : "none",
                transition: "transform 0.2s",
              }}
            />
          </Box>
        )}

        <Typography
          className="msg-timestamp"
          sx={{
            fontSize: 9,
            color: "#A5ADBA",
            flexShrink: 0,
            ml: isLong ? 0 : "auto",
            opacity: 0.6,
          }}
        >
          {timeStr}
        </Typography>
      </Box>

      {/* Content */}
      {isLong ? (
        <Collapse in={expanded}>{contentBlock}</Collapse>
      ) : (
        contentBlock
      )}

      {/* Flags */}
      {data.flags && data.flags.length > 0 && (
        <Box
          sx={{
            px: 1,
            pb: 0.5,
            display: "flex",
            flexDirection: "column",
            gap: 0.25,
          }}
        >
          {data.flags.map((flag, i) => (
            <Box
              key={i}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                px: 0.75,
                py: 0.25,
                borderRadius: 0.5,
                bgcolor: "rgba(237,139,0,0.08)",
                border: "1px solid rgba(237,139,0,0.2)",
              }}
            >
              <FlagRoundedIcon
                sx={{ fontSize: 11, color: "#ED8B00", flexShrink: 0 }}
              />
              <Typography
                sx={{
                  fontSize: 10,
                  lineHeight: 1.4,
                  color: "#8B6914",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {flag}
              </Typography>
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
}
