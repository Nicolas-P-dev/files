"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { AGENT_CONFIG } from "@/lib/constants";

interface ThinkingIndicatorProps {
  agent: string;
}

export default function ThinkingIndicator({ agent }: ThinkingIndicatorProps) {
  const config = AGENT_CONFIG[agent] ?? {
    label: agent,
    color: "#53565A",
  };

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1,
        px: 1.5,
        py: 0.75,
      }}
    >
      <Box
        sx={{
          width: 7,
          height: 7,
          borderRadius: "50%",
          bgcolor: config.color,
          animation: "pulse 1.4s ease-in-out infinite",
          "@keyframes pulse": {
            "0%, 100%": { opacity: 0.4, transform: "scale(0.85)" },
            "50%": { opacity: 1, transform: "scale(1)" },
          },
        }}
      />
      <Typography sx={{ fontSize: 11, color: "#A5ADBA", fontStyle: "italic" }}>
        {config.label} is thinking...
      </Typography>
    </Box>
  );
}
