"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import ForumRoundedIcon from "@mui/icons-material/ForumRounded";
import type { RoundTableStartedEvent } from "@/lib/types";

interface RoundTableBlockProps {
  data: RoundTableStartedEvent;
}

export default function RoundTableBlock({ data }: RoundTableBlockProps) {
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 0.75,
        px: 1.5,
        py: 0.75,
        borderRadius: 1.5,
        bgcolor: "rgba(27,54,93,0.06)",
        border: "1px dashed rgba(27,54,93,0.25)",
      }}
    >
      <ForumRoundedIcon sx={{ fontSize: 14, color: "#1B365D" }} />
      <Typography
        sx={{
          fontSize: 11,
          fontWeight: 700,
          color: "#1B365D",
          letterSpacing: 0.3,
          textTransform: "uppercase",
        }}
      >
        Round Table
      </Typography>
      <Typography
        sx={{
          fontSize: 11,
          color: "#53565A",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          flex: 1,
        }}
      >
        {data.topic}
      </Typography>
    </Box>
  );
}
