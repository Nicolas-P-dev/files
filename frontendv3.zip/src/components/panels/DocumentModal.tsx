"use client";

import React, { useState, useRef, useCallback } from "react";
import Box from "@mui/material/Box";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import NavigateBeforeRoundedIcon from "@mui/icons-material/NavigateBeforeRounded";
import NavigateNextRoundedIcon from "@mui/icons-material/NavigateNextRounded";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import { API_BASE, API_PREFIX } from "@/lib/constants";

// Configure PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

interface DocumentModalProps {
  open: boolean;
  onClose: () => void;
  docName: string;
  initialPage?: number;
}

export default function DocumentModal({
  open,
  onClose,
  docName,
  initialPage = 1,
}: DocumentModalProps) {
  const [numPages, setNumPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(initialPage);
  const scrollRef = useRef<HTMLDivElement>(null);
  const pageRefs = useRef<Map<number, HTMLDivElement>>(new Map());

  const pdfUrl = `${API_BASE}${API_PREFIX}/documents/pdf/${docName}`;

  function onDocumentLoadSuccess({ numPages: n }: { numPages: number }) {
    setNumPages(n);
    // Navigate to initial page after load
    if (initialPage > 1) {
      setTimeout(() => {
        const el = pageRefs.current.get(initialPage);
        el?.scrollIntoView({ behavior: "smooth", block: "start" });
        setCurrentPage(initialPage);
      }, 300);
    }
  }

  const goToPage = useCallback((page: number) => {
    if (page < 1 || page > numPages) return;
    const el = pageRefs.current.get(page);
    el?.scrollIntoView({ behavior: "smooth", block: "start" });
    setCurrentPage(page);
  }, [numPages]);

  // Track current page on scroll
  const handleScroll = useCallback(() => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    const scrollMid = container.scrollTop + container.clientHeight / 3;

    let closestPage = 1;
    let closestDist = Infinity;

    pageRefs.current.forEach((el, page) => {
      const pageMid = el.offsetTop - container.offsetTop + el.clientHeight / 2;
      const dist = Math.abs(pageMid - scrollMid);
      if (dist < closestDist) {
        closestDist = dist;
        closestPage = page;
      }
    });

    setCurrentPage(closestPage);
  }, []);

  // Reset state when modal opens with new doc/page
  React.useEffect(() => {
    if (open) {
      setCurrentPage(initialPage);
      // Scroll to initial page after a brief delay for render
      setTimeout(() => {
        if (initialPage > 1) {
          const el = pageRefs.current.get(initialPage);
          el?.scrollIntoView({ behavior: "auto", block: "start" });
        }
      }, 400);
    }
  }, [open, initialPage, docName]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth={false}
      PaperProps={{
        sx: {
          width: "85vw",
          height: "85vh",
          maxWidth: "85vw",
          maxHeight: "85vh",
          display: "flex",
          flexDirection: "column",
          borderRadius: 2,
          overflow: "hidden",
        },
      }}
    >
      {/* Header */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          px: 2,
          py: 1,
          borderBottom: "1px solid #E6E6E6",
          bgcolor: "#FAFBFC",
          flexShrink: 0,
        }}
      >
        <Typography sx={{ fontSize: 14, fontWeight: 600, color: "#1B365D" }}>
          {docName}
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {/* Page navigation */}
          <IconButton
            size="small"
            disabled={currentPage <= 1}
            onClick={() => goToPage(currentPage - 1)}
            sx={{ p: 0.5 }}
          >
            <NavigateBeforeRoundedIcon sx={{ fontSize: 18 }} />
          </IconButton>
          <Typography sx={{ fontSize: 11, color: "#6B778C", minWidth: 60, textAlign: "center" }}>
            Page {currentPage} of {numPages || "..."}
          </Typography>
          <IconButton
            size="small"
            disabled={currentPage >= numPages}
            onClick={() => goToPage(currentPage + 1)}
            sx={{ p: 0.5 }}
          >
            <NavigateNextRoundedIcon sx={{ fontSize: 18 }} />
          </IconButton>

          {/* Close */}
          <IconButton onClick={onClose} size="small" sx={{ p: 0.5, ml: 1 }}>
            <CloseRoundedIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Box>
      </Box>

      {/* PDF content */}
      <DialogContent
        ref={scrollRef}
        onScroll={handleScroll}
        sx={{
          flex: 1,
          overflow: "auto",
          bgcolor: "#E8EAED",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          py: 2,
          gap: 2,
          p: 2,
        }}
      >
        <Document
          file={pdfUrl}
          onLoadSuccess={onDocumentLoadSuccess}
          loading={
            <Box sx={{ py: 4, textAlign: "center" }}>
              <Typography sx={{ fontSize: 12, color: "#6B778C" }}>
                Loading {docName}...
              </Typography>
            </Box>
          }
          error={
            <Box sx={{ py: 4, textAlign: "center" }}>
              <Typography sx={{ fontSize: 12, color: "#DA291C" }}>
                Failed to load {docName}
              </Typography>
            </Box>
          }
        >
          {Array.from({ length: numPages }, (_, i) => {
            const pageNum = i + 1;
            return (
              <Box
                key={pageNum}
                ref={(el: HTMLDivElement | null) => {
                  if (el) pageRefs.current.set(pageNum, el);
                }}
                sx={{
                  position: "relative",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
                  borderRadius: 0.5,
                  overflow: "hidden",
                  mb: 1,
                }}
              >
                <Page
                  pageNumber={pageNum}
                  width={700}
                  renderTextLayer={true}
                  renderAnnotationLayer={true}
                />
                <Box
                  sx={{
                    position: "absolute",
                    bottom: 4,
                    right: 4,
                    bgcolor: "rgba(0,0,0,0.5)",
                    color: "#fff",
                    fontSize: 9,
                    px: 0.75,
                    py: 0.25,
                    borderRadius: 0.5,
                  }}
                >
                  p. {pageNum}
                </Box>
              </Box>
            );
          })}
        </Document>
      </DialogContent>
    </Dialog>
  );
}
