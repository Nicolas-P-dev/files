"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import LinearProgress from "@mui/material/LinearProgress";
import Chip from "@mui/material/Chip";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import FactCheckOutlinedIcon from "@mui/icons-material/FactCheckOutlined";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import RemoveCircleOutlineRoundedIcon from "@mui/icons-material/RemoveCircleOutlineRounded";
import HelpOutlineRoundedIcon from "@mui/icons-material/HelpOutlineRounded";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import ExpandMoreRoundedIcon from "@mui/icons-material/ExpandMoreRounded";
import ExpandLessRoundedIcon from "@mui/icons-material/ExpandLessRounded";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import AutoAwesomeRoundedIcon from "@mui/icons-material/AutoAwesomeRounded";
import LinkRoundedIcon from "@mui/icons-material/LinkRounded";
import ForumRoundedIcon from "@mui/icons-material/ForumRounded";
import { API_BASE, API_PREFIX, AGENT_CONFIG } from "@/lib/constants";
import type {
  ActivityItem,
  RunStatus,
  FindingSubmittedEvent,
  WorkspaceMessageEvent,
  TriggerCategory,
  TriggerInfo,
} from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */

interface FindingsDashboardProps {
  items: ActivityItem[];
  runStatus: RunStatus;
  onViewDocument?: (document: string, page: number) => void;
  /** When provided, use these triggers instead of fetching from API */
  externalTriggers?: TriggerCategory[];
}

/* ------------------------------------------------------------------ */
/*  Status config — 5 visual states                                    */
/* ------------------------------------------------------------------ */

type TriggerState = "FOUND" | "NOT_FOUND" | "INCONCLUSIVE" | "EVALUATING" | "PENDING" | "NOT_EVALUATED";

const STATUS_CONFIG: Record<
  TriggerState,
  { icon: React.ReactNode; color: string; bg: string; label: string }
> = {
  FOUND: {
    icon: <CheckCircleRoundedIcon sx={{ fontSize: 14 }} />,
    color: "#26890D",
    bg: "rgba(38,137,13,0.08)",
    label: "Found",
  },
  NOT_FOUND: {
    icon: <RemoveCircleOutlineRoundedIcon sx={{ fontSize: 14 }} />,
    color: "#6B778C",
    bg: "rgba(107,119,140,0.06)",
    label: "Not Found",
  },
  INCONCLUSIVE: {
    icon: <HelpOutlineRoundedIcon sx={{ fontSize: 14 }} />,
    color: "#ED8B00",
    bg: "rgba(237,139,0,0.08)",
    label: "Inconclusive",
  },
  EVALUATING: {
    icon: (
      <Box
        sx={{
          width: 12,
          height: 12,
          borderRadius: "50%",
          bgcolor: "#007CB0",
          animation: "eval-pulse 1.4s ease-in-out infinite",
          "@keyframes eval-pulse": {
            "0%, 100%": { opacity: 0.3, transform: "scale(0.8)" },
            "50%": { opacity: 1, transform: "scale(1)" },
          },
        }}
      />
    ),
    color: "#007CB0",
    bg: "rgba(0,124,176,0.06)",
    label: "Evaluating",
  },
  PENDING: {
    icon: <RadioButtonUncheckedIcon sx={{ fontSize: 14 }} />,
    color: "#A5ADBA",
    bg: "transparent",
    label: "Pending",
  },
  NOT_EVALUATED: {
    icon: <RadioButtonUncheckedIcon sx={{ fontSize: 14 }} />,
    color: "#A5ADBA",
    bg: "rgba(165,173,186,0.04)",
    label: "Not Evaluated",
  },
};

/* ------------------------------------------------------------------ */
/*  Derived data from activity items                                   */
/* ------------------------------------------------------------------ */

interface ConversationExcerpt {
  speaker: string;
  type: string;
  content: string;
}

interface DerivedFinding {
  triggerId: string;
  status: string;
  confidence: number;
  stage: string;
  reasoning: string;
  category: string;
  topic: string;
  hardSoft: string;
  assessmentText: string;
  relatedTriggers: string[];
  evidenceRefs: { doc: string; page: number }[];
  conversationExcerpts: ConversationExcerpt[];
}

function deriveFindings(items: ActivityItem[]): {
  findingsMap: Map<string, DerivedFinding>;
  evaluatingSet: Set<string>;
  total: number | null;
  synthesisText: string | null;
} {
  const findingsMap = new Map<string, DerivedFinding>();
  const mentionedTriggers = new Set<string>();
  let total: number | null = null;
  let synthesisText: string | null = null;

  // First pass: collect findings
  for (const item of items) {
    if (item.kind === "finding") {
      const d = item.data as FindingSubmittedEvent;
      findingsMap.set(d.trigger_id, {
        triggerId: d.trigger_id,
        status: d.status,
        confidence: d.confidence,
        stage: d.stage ?? "",
        reasoning: d.reasoning ?? "",
        category: d.category ?? "",
        topic: d.topic ?? "",
        hardSoft: d.hard_soft ?? "",
        assessmentText: "",
        relatedTriggers: [],
        evidenceRefs: [],
        conversationExcerpts: [],
      });
    }

    if (item.kind === "run_completed") {
      total = (item.data as { total?: number }).total ?? null;
    }
  }

  // Second pass: enrich findings with workspace context
  for (const item of items) {
    if (item.kind !== "message") continue;

    const msg = item.data as WorkspaceMessageEvent;
    const refs = msg.trigger_refs ?? [];

    for (const ref of refs) {
      mentionedTriggers.add(ref);
    }

    // Detect synthesis
    if (msg.type === "synthesis") {
      synthesisText = msg.content ?? null;
    }

    // Enrich each referenced finding
    for (const ref of refs) {
      const finding = findingsMap.get(ref);
      if (!finding) continue;

      // Assessment text from assessment_writer
      if (
        msg.speaker === "assessment_writer" &&
        (msg.type === "finding" || msg.type === "assessment_draft")
      ) {
        if (!finding.assessmentText || msg.content.length > finding.assessmentText.length) {
          finding.assessmentText = msg.content.slice(0, 500);
        }
      }

      // Conversation excerpts (cap at 6 per trigger)
      if (msg.content.length > 15 && finding.conversationExcerpts.length < 6) {
        finding.conversationExcerpts.push({
          speaker: msg.speaker,
          type: msg.type,
          content: msg.content.slice(0, 200),
        });
      }
    }
  }

  // Parse evidence refs and related triggers from reasoning text
  for (const finding of findingsMap.values()) {
    // Evidence citations: "FileName.pdf p.3" / "FileName.pdf page 3"
    const docPattern = /([\w_]+\.pdf)\s+p(?:age)?\.?\s*(\d+)/gi;
    let m: RegExpExecArray | null;
    while ((m = docPattern.exec(finding.reasoning)) !== null) {
      finding.evidenceRefs.push({ doc: m[1], page: parseInt(m[2]) });
    }
    // Also check assessment text
    while ((m = docPattern.exec(finding.assessmentText)) !== null) {
      finding.evidenceRefs.push({ doc: m[1], page: parseInt(m[2]) });
    }
    // Deduplicate
    const seen = new Set<string>();
    finding.evidenceRefs = finding.evidenceRefs.filter((r) => {
      const key = `${r.doc}:${r.page}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    // Related triggers: T-\d+ mentions in reasoning (excluding self)
    const trigRefs = finding.reasoning.match(/T-\d+/g) ?? [];
    finding.relatedTriggers = [
      ...new Set(trigRefs.filter((t) => t !== finding.triggerId)),
    ];
  }

  // Evaluating = mentioned but no finding yet
  const evaluatingSet = new Set<string>();
  for (const t of mentionedTriggers) {
    if (!findingsMap.has(t)) evaluatingSet.add(t);
  }

  return { findingsMap, evaluatingSet, total, synthesisText };
}

/* ------------------------------------------------------------------ */
/*  Sub-component: trigger row (all 5 states)                          */
/* ------------------------------------------------------------------ */

interface TriggerRowProps {
  triggerInfo: TriggerInfo;
  finding?: DerivedFinding;
  state: TriggerState;
  expanded: boolean;
  onToggle: () => void;
  onViewDocument?: (document: string, page: number) => void;
  onSelectTrigger?: (triggerId: string) => void;
}

function TriggerRow({
  triggerInfo,
  finding,
  state,
  expanded,
  onToggle,
  onViewDocument,
  onSelectTrigger,
}: TriggerRowProps) {
  const cfg = STATUS_CONFIG[state];
  const hasDetail = !!finding;

  return (
    <Box
      id={`trigger-row-${triggerInfo.id}`}
      sx={{
        borderRadius: 1.5,
        border: state === "PENDING"
          ? "1px dashed rgba(165,173,186,0.4)"
          : `1px solid ${cfg.color}25`,
        bgcolor: expanded ? cfg.bg : "transparent",
        transition: "all 0.2s ease",
        "&:hover": { bgcolor: cfg.bg },
        opacity: state === "PENDING" ? 0.6 : state === "NOT_EVALUATED" ? 0.75 : 1,
      }}
    >
      {/* Compact row */}
      <Box
        onClick={hasDetail ? onToggle : undefined}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.5,
          px: 1,
          py: 0.5,
          cursor: hasDetail ? "pointer" : "default",
          userSelect: "none",
          minHeight: 32,
        }}
      >
        {/* Status indicator */}
        <Box
          sx={{
            color: cfg.color,
            display: "flex",
            alignItems: "center",
            flexShrink: 0,
            width: 16,
            justifyContent: "center",
          }}
        >
          {cfg.icon}
        </Box>

        {/* Trigger ID */}
        <Typography
          sx={{
            fontSize: 11,
            fontWeight: 700,
            color: state === "PENDING" || state === "NOT_EVALUATED" ? "#A5ADBA" : "#172B4D",
            flexShrink: 0,
            minWidth: 30,
          }}
        >
          {triggerInfo.id}
        </Typography>

        {/* Topic */}
        <Typography
          sx={{
            fontSize: 10.5,
            color: state === "PENDING" || state === "NOT_EVALUATED" ? "#A5ADBA" : "#6B778C",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            flex: 1,
          }}
        >
          {triggerInfo.topic}
        </Typography>

        {/* Status chip for completed findings */}
        {finding && (
          <Chip
            label={cfg.label}
            size="small"
            sx={{
              height: 16,
              fontSize: 9,
              fontWeight: 700,
              bgcolor: `${cfg.color}18`,
              color: cfg.color,
              "& .MuiChip-label": { px: 0.5 },
              flexShrink: 0,
            }}
          />
        )}

        {/* Not Evaluated chip — shown after run completes for unevaluated triggers */}
        {state === "NOT_EVALUATED" && (
          <Chip
            label="Not Evaluated"
            size="small"
            sx={{
              height: 16,
              fontSize: 9,
              fontWeight: 600,
              bgcolor: "rgba(165,173,186,0.12)",
              color: "#A5ADBA",
              "& .MuiChip-label": { px: 0.5 },
              flexShrink: 0,
            }}
          />
        )}

        {/* Evaluating label */}
        {state === "EVALUATING" && (
          <Typography
            sx={{
              fontSize: 9.5,
              color: "#007CB0",
              fontStyle: "italic",
              flexShrink: 0,
            }}
          >
            Evaluating...
          </Typography>
        )}

        {/* Confidence */}
        {finding && (
          <Typography
            sx={{ fontSize: 9.5, color: "#6B778C", flexShrink: 0 }}
          >
            {Math.round(finding.confidence * 100)}%
          </Typography>
        )}

        {/* Stage chip */}
        {finding?.stage && (
          <Chip
            label={finding.stage}
            size="small"
            sx={{
              height: 16,
              fontSize: 8.5,
              fontWeight: 600,
              bgcolor: "rgba(27,54,93,0.08)",
              color: "#1B365D",
              "& .MuiChip-label": { px: 0.4 },
              flexShrink: 0,
            }}
          />
        )}

        {/* Expand arrow */}
        {hasDetail && (
          <IconButton size="small" sx={{ p: 0.125 }}>
            {expanded ? (
              <ExpandLessRoundedIcon sx={{ fontSize: 14, color: "#6B778C" }} />
            ) : (
              <ExpandMoreRoundedIcon sx={{ fontSize: 14, color: "#6B778C" }} />
            )}
          </IconButton>
        )}
      </Box>

      {/* Expanded detail panel */}
      {hasDetail && (
        <Collapse in={expanded}>
          <Box
            sx={{
              px: 1.25,
              pb: 1.25,
              pt: 0.5,
              borderTop: `1px solid ${cfg.color}15`,
              display: "flex",
              flexDirection: "column",
              gap: 1,
            }}
          >
            {/* Assessment text (from Assessment Writer) */}
            {finding.assessmentText && (
              <DetailSection label="Assessment">
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "#172B4D",
                    lineHeight: 1.5,
                    whiteSpace: "pre-wrap",
                    fontStyle: "italic",
                    borderLeft: "2px solid #2E7D32",
                    pl: 1,
                  }}
                >
                  {finding.assessmentText}
                </Typography>
              </DetailSection>
            )}

            {/* Reasoning chain */}
            <DetailSection label="Reasoning">
              <Typography
                sx={{
                  fontSize: 11,
                  color: "#172B4D",
                  lineHeight: 1.5,
                  whiteSpace: "pre-wrap",
                }}
              >
                {finding.reasoning || "No reasoning available."}
              </Typography>
            </DetailSection>

            {/* Evidence citations */}
            {finding.evidenceRefs.length > 0 && (
              <DetailSection label="Evidence Sources">
                <Box sx={{ display: "flex", flexDirection: "column", gap: 0.25 }}>
                  {finding.evidenceRefs.map((ref, i) => (
                    <Box
                      key={i}
                      component="button"
                      onClick={(e: React.MouseEvent) => {
                        e.stopPropagation();
                        onViewDocument?.(ref.doc, ref.page);
                      }}
                      sx={{
                        all: "unset",
                        display: "flex",
                        alignItems: "center",
                        gap: 0.5,
                        cursor: "pointer",
                        fontSize: 10.5,
                        fontFamily: "'Menlo', 'Consolas', monospace",
                        color: "#007CB0",
                        py: 0.125,
                        "&:hover": {
                          color: "#005A80",
                          textDecoration: "underline",
                        },
                      }}
                    >
                      <DescriptionOutlinedIcon sx={{ fontSize: 11 }} />
                      {ref.doc}, page {ref.page}
                    </Box>
                  ))}
                </Box>
              </DetailSection>
            )}

            {/* Related triggers */}
            {finding.relatedTriggers.length > 0 && (
              <DetailSection label="Related Triggers">
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                  {finding.relatedTriggers.map((t) => (
                    <Chip
                      key={t}
                      label={t}
                      size="small"
                      icon={<LinkRoundedIcon sx={{ fontSize: 10 }} />}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTrigger?.(t);
                      }}
                      sx={{
                        height: 20,
                        fontSize: 10,
                        fontWeight: 600,
                        cursor: "pointer",
                        bgcolor: "rgba(27,54,93,0.06)",
                        color: "#1B365D",
                        "& .MuiChip-label": { px: 0.5 },
                        "& .MuiChip-icon": { color: "#1B365D", ml: 0.25 },
                        "&:hover": { bgcolor: "rgba(27,54,93,0.12)" },
                      }}
                    />
                  ))}
                </Box>
              </DetailSection>
            )}

            {/* Conversation excerpt */}
            {finding.conversationExcerpts.length > 0 && (
              <DetailSection label="Team Discussion">
                <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
                  {finding.conversationExcerpts.map((ex, i) => {
                    const agentCfg = AGENT_CONFIG[ex.speaker];
                    const label = agentCfg?.label ?? ex.speaker;
                    const color = agentCfg?.color ?? "#6B778C";
                    return (
                      <Box key={i} sx={{ display: "flex", gap: 0.5, alignItems: "flex-start" }}>
                        <Typography
                          sx={{
                            fontSize: 9.5,
                            fontWeight: 700,
                            color,
                            flexShrink: 0,
                            minWidth: 70,
                            pt: 0.125,
                          }}
                        >
                          {label}
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: 10,
                            color: "#172B4D",
                            lineHeight: 1.4,
                          }}
                        >
                          {ex.content}
                        </Typography>
                      </Box>
                    );
                  })}
                </Box>
              </DetailSection>
            )}

            {/* Stage classification */}
            {finding.stage && (
              <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                <Typography
                  sx={{
                    fontSize: 9.5,
                    fontWeight: 600,
                    color: "#6B778C",
                    textTransform: "uppercase",
                    letterSpacing: 0.5,
                  }}
                >
                  Classification:
                </Typography>
                <Chip
                  label={finding.stage}
                  size="small"
                  sx={{
                    height: 18,
                    fontSize: 9.5,
                    fontWeight: 700,
                    bgcolor: "rgba(27,54,93,0.1)",
                    color: "#1B365D",
                    "& .MuiChip-label": { px: 0.6 },
                  }}
                />
                {finding.hardSoft && (
                  <Chip
                    label={finding.hardSoft}
                    size="small"
                    sx={{
                      height: 18,
                      fontSize: 9.5,
                      fontWeight: 700,
                      bgcolor:
                        finding.hardSoft === "Hard"
                          ? "rgba(218,41,28,0.08)"
                          : "rgba(107,119,140,0.08)",
                      color:
                        finding.hardSoft === "Hard" ? "#DA291C" : "#6B778C",
                      "& .MuiChip-label": { px: 0.6 },
                    }}
                  />
                )}
              </Box>
            )}
          </Box>
        </Collapse>
      )}
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Reusable detail section header                                     */
/* ------------------------------------------------------------------ */

function DetailSection({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <Box>
      <Typography
        sx={{
          fontSize: 9.5,
          fontWeight: 600,
          color: "#6B778C",
          textTransform: "uppercase",
          letterSpacing: 0.5,
          mb: 0.375,
        }}
      >
        {label}
      </Typography>
      {children}
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Sub-component: collapsible category section                        */
/* ------------------------------------------------------------------ */

interface CategorySectionProps {
  name: string;
  triggers: TriggerInfo[];
  findingsMap: Map<string, DerivedFinding>;
  evaluatingSet: Set<string>;
  runStatus: RunStatus;
  expandedId: string | null;
  onToggleFinding: (id: string) => void;
  onViewDocument?: (document: string, page: number) => void;
  onSelectTrigger?: (id: string) => void;
  defaultOpen: boolean;
}

function CategorySection({
  name,
  triggers,
  findingsMap,
  evaluatingSet,
  runStatus,
  expandedId,
  onToggleFinding,
  onViewDocument,
  onSelectTrigger,
  defaultOpen,
}: CategorySectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  const isComplete = runStatus === "completed";

  // Count statuses in this category
  const counts = useMemo(() => {
    let found = 0,
      notFound = 0,
      inconclusive = 0,
      evaluating = 0,
      notEvaluated = 0;
    for (const t of triggers) {
      const f = findingsMap.get(t.id);
      if (f) {
        if (f.status === "FOUND") found++;
        else if (f.status === "NOT_FOUND") notFound++;
        else inconclusive++;
      } else if (evaluatingSet.has(t.id)) {
        if (isComplete) notEvaluated++;
        else evaluating++;
      } else {
        if (isComplete) notEvaluated++;
      }
    }
    return { found, notFound, inconclusive, evaluating, notEvaluated, total: triggers.length };
  }, [triggers, findingsMap, evaluatingSet, isComplete]);

  const completedInCategory =
    counts.found + counts.notFound + counts.inconclusive;

  return (
    <Box>
      {/* Category header */}
      <Box
        onClick={() => setOpen(!open)}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.75,
          px: 0.5,
          py: 0.5,
          cursor: "pointer",
          userSelect: "none",
          borderRadius: 1,
          "&:hover": { bgcolor: "rgba(27,54,93,0.04)" },
        }}
      >
        <IconButton size="small" sx={{ p: 0.125 }}>
          {open ? (
            <ExpandLessRoundedIcon sx={{ fontSize: 14, color: "#6B778C" }} />
          ) : (
            <ExpandMoreRoundedIcon sx={{ fontSize: 14, color: "#6B778C" }} />
          )}
        </IconButton>
        <Typography
          sx={{
            fontSize: 10.5,
            fontWeight: 700,
            color: "#1B365D",
            textTransform: "uppercase",
            letterSpacing: 0.5,
            flex: 1,
          }}
        >
          {name}
        </Typography>
        {/* Mini progress indicator */}
        <Typography sx={{ fontSize: 9.5, color: "#A5ADBA" }}>
          {completedInCategory}/{counts.total}
        </Typography>
        {/* Micro dots for status overview */}
        <Box sx={{ display: "flex", gap: 0.25 }}>
          {counts.found > 0 && (
            <Box
              sx={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                bgcolor: "#26890D",
              }}
              title={`${counts.found} found`}
            />
          )}
          {counts.inconclusive > 0 && (
            <Box
              sx={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                bgcolor: "#ED8B00",
              }}
              title={`${counts.inconclusive} inconclusive`}
            />
          )}
          {counts.evaluating > 0 && (
            <Box
              sx={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                bgcolor: "#007CB0",
                animation: "eval-pulse 1.4s ease-in-out infinite",
                "@keyframes eval-pulse": {
                  "0%, 100%": { opacity: 0.3 },
                  "50%": { opacity: 1 },
                },
              }}
              title={`${counts.evaluating} evaluating`}
            />
          )}
        </Box>
      </Box>

      {/* Trigger rows */}
      <Collapse in={open}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            gap: 0.375,
            pl: 1,
            pb: 0.75,
          }}
        >
          {triggers.map((t) => {
            const finding = findingsMap.get(t.id);
            let triggerState: TriggerState;
            if (finding) {
              triggerState = finding.status as TriggerState;
            } else if (evaluatingSet.has(t.id)) {
              triggerState = isComplete ? "NOT_EVALUATED" : "EVALUATING";
            } else {
              triggerState = isComplete ? "NOT_EVALUATED" : "PENDING";
            }
            return (
              <TriggerRow
                key={t.id}
                triggerInfo={t}
                finding={finding}
                state={triggerState}
                expanded={expandedId === t.id}
                onToggle={() => onToggleFinding(t.id)}
                onViewDocument={onViewDocument}
                onSelectTrigger={onSelectTrigger}
              />
            );
          })}
        </Box>
      </Collapse>
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Main component                                                     */
/* ------------------------------------------------------------------ */

export default function FindingsDashboard({
  items,
  runStatus,
  onViewDocument,
  externalTriggers,
}: FindingsDashboardProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [categories, setCategories] = useState<TriggerCategory[]>([]);
  const [triggersFetched, setTriggersFetched] = useState(false);
  const [triggersLoading, setTriggersLoading] = useState(true);

  // Use external triggers if provided, skip API fetch
  useEffect(() => {
    if (externalTriggers && externalTriggers.length > 0) {
      setCategories(externalTriggers);
      setTriggersFetched(true);
      setTriggersLoading(false);
      return;
    }
  }, [externalTriggers]);

  // Fetch trigger list on mount (only if no external triggers)
  useEffect(() => {
    if (externalTriggers && externalTriggers.length > 0) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `${API_BASE}${API_PREFIX}/triggers?sheet_type=corporate`
        );
        if (!res.ok) return;
        const json = await res.json();
        if (!cancelled && json.categories) {
          setCategories(json.categories as TriggerCategory[]);
          setTriggersFetched(true);
        }
      } catch {
        // Backend not running — categories will stay empty, dashboard still works
      } finally {
        if (!cancelled) setTriggersLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [externalTriggers]);

  const { findingsMap, evaluatingSet, total, synthesisText } = useMemo(
    () => deriveFindings(items),
    [items]
  );

  // If no categories fetched, build from finding events
  const effectiveCategories = useMemo((): TriggerCategory[] => {
    if (categories.length > 0) return categories;
    if (findingsMap.size === 0) return [];

    // Group findings by category (from finding_submitted events)
    const catMap = new Map<string, TriggerInfo[]>();
    for (const f of findingsMap.values()) {
      const cat = f.category || "Uncategorized";
      if (!catMap.has(cat)) catMap.set(cat, []);
      catMap.get(cat)!.push({
        id: f.triggerId,
        topic: f.topic || f.triggerId,
        hard_soft: f.hardSoft || "",
        stage: f.stage || "",
      });
    }
    return Array.from(catMap.entries()).map(([name, triggers]) => ({
      name,
      triggers,
    }));
  }, [categories, findingsMap]);

  const foundCount = useMemo(
    () => Array.from(findingsMap.values()).filter((f) => f.status === "FOUND").length,
    [findingsMap]
  );
  const notFoundCount = useMemo(
    () => Array.from(findingsMap.values()).filter((f) => f.status === "NOT_FOUND").length,
    [findingsMap]
  );
  const inconclusiveCount = useMemo(
    () => Array.from(findingsMap.values()).filter((f) => f.status === "INCONCLUSIVE").length,
    [findingsMap]
  );
  const evaluated = findingsMap.size;
  const totalTriggers = useMemo(() => {
    if (total !== null) return total;
    // Count from fetched categories
    return categories.reduce((acc, c) => acc + c.triggers.length, 0) || evaluated;
  }, [total, categories, evaluated]);
  const progress = totalTriggers > 0 ? (evaluated / totalTriggers) * 100 : 0;

  const isEmpty = findingsMap.size === 0 && evaluatingSet.size === 0;

  const handleToggleFinding = useCallback((id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  }, []);

  const handleSelectTrigger = useCallback((triggerId: string) => {
    setExpandedId(triggerId);
    // Scroll the trigger into view
    const el = document.getElementById(`trigger-row-${triggerId}`);
    el?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, []);

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "background.paper",
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {/* Panel header */}
      <Box
        sx={{
          px: 1.5,
          py: 1,
          borderBottom: "1px solid",
          borderColor: "#E6E6E6",
          display: "flex",
          alignItems: "center",
          gap: 0.75,
          flexShrink: 0,
        }}
      >
        <FactCheckOutlinedIcon
          sx={{ fontSize: 16, color: "text.secondary" }}
        />
        <Typography variant="subtitle1" sx={{ fontSize: 12, fontWeight: 600 }}>
          Findings Dashboard
        </Typography>
        {evaluated > 0 && (
          <Chip
            label={`${evaluated} / ${totalTriggers}`}
            size="small"
            sx={{
              height: 20,
              fontSize: 10,
              fontWeight: 700,
              ml: "auto",
              bgcolor: "rgba(27,54,93,0.08)",
              color: "#1B365D",
              "& .MuiChip-label": { px: 0.75 },
            }}
          />
        )}
      </Box>

      {/* Progress summary */}
      {(evaluated > 0 || runStatus === "running") && (
        <Box sx={{ px: 2, pt: 1.25, pb: 0.75, flexShrink: 0 }}>
          <Box sx={{ display: "flex", gap: 1.5, mb: 0.75 }}>
            <StatusDot color="#26890D" count={foundCount} label="Found" />
            <StatusDot color="#ED8B00" count={inconclusiveCount} label="Inconclusive" />
            <StatusDot color="#6B778C" count={notFoundCount} label="Not Found" />
          </Box>
          <LinearProgress
            variant={
              runStatus === "running" && evaluated === 0
                ? "indeterminate"
                : "determinate"
            }
            value={progress}
            sx={{
              height: 4,
              borderRadius: 2,
              bgcolor: "rgba(107,119,140,0.12)",
              "& .MuiLinearProgress-bar": {
                borderRadius: 2,
                bgcolor: "#26890D",
                transition: "transform 0.6s ease",
              },
            }}
          />
          {totalTriggers > 0 && (
            <Typography
              sx={{
                fontSize: 9.5,
                color: "#A5ADBA",
                mt: 0.375,
                textAlign: "right",
              }}
            >
              {evaluated} of {totalTriggers} triggers evaluated
            </Typography>
          )}
        </Box>
      )}

      {/* Scrollable trigger grid */}
      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          overflowX: "hidden",
          px: 2,
          py: 1,
          display: "flex",
          flexDirection: "column",
          gap: 0.5,
        }}
      >
        {/* Loading state — fetching trigger list */}
        {triggersLoading && isEmpty && (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 1,
              py: 2,
              px: 1,
            }}
          >
            {[1, 2, 3, 4, 5].map((i) => (
              <Box
                key={i}
                sx={{
                  height: 28,
                  borderRadius: 1,
                  bgcolor: "#F5F7F9",
                  animation: "shimmer 1.5s ease-in-out infinite",
                  animationDelay: `${i * 0.1}s`,
                  "@keyframes shimmer": {
                    "0%, 100%": { opacity: 0.4 },
                    "50%": { opacity: 0.8 },
                  },
                }}
              />
            ))}
          </Box>
        )}

        {/* Empty state — no triggers fetched and no findings */}
        {isEmpty && !triggersFetched && !triggersLoading && runStatus === "idle" && (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 2,
                bgcolor: "#F5F7F9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <FactCheckOutlinedIcon
                sx={{ fontSize: 28, color: "#A5ADBA" }}
              />
            </Box>
            <Typography
              variant="subtitle2"
              sx={{ color: "text.secondary", mb: 0.5 }}
            >
              No findings
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: "#A5ADBA", textAlign: "center", maxWidth: 200 }}
            >
              Trigger assessments will appear here during the analysis run
            </Typography>
          </Box>
        )}

        {/* Waiting state during early run */}
        {isEmpty && !triggersFetched && runStatus === "running" && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
              py: 4,
            }}
          >
            <Box
              sx={{
                width: 10,
                height: 10,
                borderRadius: "50%",
                bgcolor: "#26890D",
                animation: "eval-pulse 1.4s ease-in-out infinite",
                "@keyframes eval-pulse": {
                  "0%, 100%": { opacity: 0.3, transform: "scale(0.85)" },
                  "50%": { opacity: 1, transform: "scale(1)" },
                },
              }}
            />
            <Typography sx={{ fontSize: 12, color: "#6B778C" }}>
              Awaiting first findings...
            </Typography>
          </Box>
        )}

        {/* Category sections */}
        {effectiveCategories.map((cat) => (
          <CategorySection
            key={cat.name}
            name={cat.name}
            triggers={cat.triggers}
            findingsMap={findingsMap}
            evaluatingSet={evaluatingSet}
            runStatus={runStatus}
            expandedId={expandedId}
            onToggleFinding={handleToggleFinding}
            onViewDocument={onViewDocument}
            onSelectTrigger={handleSelectTrigger}
            defaultOpen
          />
        ))}

        {/* Synthesis section — after run completes, collapsible */}
        {runStatus === "completed" && synthesisText && (
          <SynthesisSection text={synthesisText} />
        )}
      </Box>
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Collapsible synthesis section                                      */
/* ------------------------------------------------------------------ */

function SynthesisSection({ text }: { text: string }) {
  const [open, setOpen] = useState(false);

  return (
    <Box
      sx={{
        mt: 2,
        borderRadius: 2,
        bgcolor: "rgba(27,54,93,0.04)",
        border: "1px solid rgba(27,54,93,0.12)",
        overflow: "hidden",
      }}
    >
      <Box
        onClick={() => setOpen(!open)}
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.75,
          px: 1.25,
          py: 0.75,
          cursor: "pointer",
          "&:hover": { bgcolor: "rgba(27,54,93,0.06)" },
        }}
      >
        <AutoAwesomeRoundedIcon sx={{ fontSize: 13, color: "#1B365D" }} />
        <Typography
          sx={{
            fontSize: 10,
            fontWeight: 700,
            color: "#1B365D",
            textTransform: "uppercase",
            letterSpacing: 0.5,
            flex: 1,
          }}
        >
          Overall Assessment
        </Typography>
        <ExpandMoreRoundedIcon
          sx={{
            fontSize: 14,
            color: "#6B778C",
            transform: open ? "rotate(180deg)" : "none",
            transition: "transform 0.2s",
          }}
        />
      </Box>
      <Collapse in={open}>
        <Box sx={{ px: 1.25, pb: 1, pt: 0.25 }}>
          <Typography
            sx={{
              fontSize: 10.5,
              color: "#172B4D",
              lineHeight: 1.6,
              whiteSpace: "pre-wrap",
            }}
          >
            {text}
          </Typography>
        </Box>
      </Collapse>
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Tiny status dot + count component                                  */
/* ------------------------------------------------------------------ */

function StatusDot({
  color,
  count,
  label,
}: {
  color: string;
  count: number;
  label: string;
}) {
  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.375 }}>
      <Box
        sx={{ width: 7, height: 7, borderRadius: "50%", bgcolor: color }}
      />
      <Typography sx={{ fontSize: 10, color: "#172B4D" }}>
        <strong>{count}</strong> {label}
      </Typography>
    </Box>
  );
}
