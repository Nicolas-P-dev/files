"use client";

import React, { useEffect, useRef } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import GroupsOutlinedIcon from "@mui/icons-material/GroupsOutlined";
import CircularProgress from "@mui/material/CircularProgress";
import Chip from "@mui/material/Chip";
import MessageCard from "@/components/activity/MessageCard";
import ToolCallBlock from "@/components/activity/ToolCallBlock";
import RoundTableBlock from "@/components/activity/RoundTableBlock";
import FindingCard from "@/components/activity/FindingCard";
import RunCompletedCard from "@/components/activity/RunCompletedCard";
import ThinkingIndicator from "@/components/activity/ThinkingIndicator";
import type { ActivityItem, RunStatus } from "@/lib/types";

interface TeamActivityProps {
  items: ActivityItem[];
  thinkingAgent: string | null;
  runStatus: RunStatus;
  connected: boolean;
  onViewDocument?: (document: string, page: number) => void;
}

/**
 * Group consecutive tool_call items between the same agent's messages
 * so they render as a compact block rather than separate cards.
 */
function groupItems(items: ActivityItem[]): (ActivityItem | ActivityItem[])[] {
  const grouped: (ActivityItem | ActivityItem[])[] = [];
  let toolBatch: ActivityItem[] = [];

  for (const item of items) {
    if (item.kind === "tool_call") {
      toolBatch.push(item);
    } else {
      if (toolBatch.length > 0) {
        grouped.push(toolBatch);
        toolBatch = [];
      }
      grouped.push(item);
    }
  }
  if (toolBatch.length > 0) {
    grouped.push(toolBatch);
  }
  return grouped;
}

/**
 * Detect round-table sections: a round_table_start followed by messages
 * until the next non-round-table message type appears from lead_auditor.
 */
function detectRoundTableRanges(items: ActivityItem[]): Set<string> {
  const inRoundTable = new Set<string>();
  let roundTableActive = false;

  for (const item of items) {
    if (item.kind === "round_table_start") {
      roundTableActive = true;
      inRoundTable.add(item.id);
      continue;
    }
    if (roundTableActive) {
      if (
        item.kind === "message" &&
        item.data.speaker !== "lead_auditor" &&
        (item.data.type === "finding" || item.data.type === "reaction")
      ) {
        inRoundTable.add(item.id);
      } else if (item.kind === "tool_call" || item.kind === "thinking") {
        inRoundTable.add(item.id);
      } else {
        roundTableActive = false;
      }
    }
  }
  return inRoundTable;
}

export default function TeamActivity({
  items,
  thinkingAgent,
  runStatus,
  connected,
  onViewDocument,
}: TeamActivityProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new items
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: "smooth",
      });
    }
  }, [items.length, thinkingAgent]);

  const grouped = groupItems(items);
  const roundTableIds = detectRoundTableRanges(items);

  // Collect consecutive round-table items into sections for rendering
  const rendered: React.ReactNode[] = [];
  let rtBuffer: React.ReactNode[] = [];
  let rtKey = "";
  let rtGroupIndex = 0;

  function flushRt() {
    if (rtBuffer.length > 0) {
      rtGroupIndex++;
      rendered.push(
        <Box
          key={`rt-group-${rtKey || rtGroupIndex}-${rtGroupIndex}`}
          sx={{
            borderLeft: "2px solid rgba(27,54,93,0.2)",
            borderRadius: 0,
            pl: 1.5,
            py: 0.5,
            display: "flex",
            flexDirection: "column",
            gap: 1.5,
            bgcolor: "transparent",
          }}
        >
          {rtBuffer}
        </Box>
      );
      rtBuffer = [];
    }
  }

  for (const entry of grouped) {
    // Handle tool_call batches
    if (Array.isArray(entry)) {
      const node = (
        <Box
          key={entry[0].id}
          sx={{ display: "flex", flexDirection: "column", gap: 0.375 }}
        >
          {entry.map((tc) =>
            tc.kind === "tool_call" ? (
              <ToolCallBlock key={tc.id} data={tc.data} result={tc.result} onViewDocument={onViewDocument} />
            ) : null
          )}
        </Box>
      );
      if (roundTableIds.has(entry[0].id)) {
        if (rtBuffer.length === 0) rtKey = entry[0].id;
        rtBuffer.push(node);
      } else {
        flushRt();
        rendered.push(node);
      }
      continue;
    }

    const item = entry;
    let node: React.ReactNode;

    switch (item.kind) {
      case "message":
        node = <MessageCard key={item.id} data={item.data} onViewDocument={onViewDocument} />;
        break;
      case "round_table_start":
        node = <RoundTableBlock key={item.id} data={item.data} />;
        break;
      case "finding":
        node = <FindingCard key={item.id} data={item.data} />;
        break;
      case "run_completed":
        node = <RunCompletedCard key={item.id} data={item.data} />;
        break;
      case "thinking":
        node = <ThinkingIndicator key={item.id} agent={item.data.agent} />;
        break;
      default:
        node = null;
    }

    if (!node) continue;

    if (roundTableIds.has(item.id)) {
      if (rtBuffer.length === 0) rtKey = item.id;
      rtBuffer.push(node);
    } else {
      flushRt();
      rendered.push(node);
    }
  }
  flushRt();

  const isEmpty = items.length === 0 && runStatus === "idle";
  const isConnecting = runStatus === "connecting";

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "background.paper",
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {/* Panel header */}
      <Box
        sx={{
          px: 1.5,
          py: 1,
          borderBottom: "1px solid",
          borderColor: "#E6E6E6",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <GroupsOutlinedIcon sx={{ fontSize: 16, color: "text.secondary" }} />
          <Typography variant="subtitle1" sx={{ fontSize: 12, fontWeight: 600 }}>
            Team Activity
          </Typography>
        </Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          {runStatus === "running" && (
            <Chip
              label="Live"
              size="small"
              sx={{
                height: 20,
                fontSize: 10,
                fontWeight: 700,
                bgcolor: "rgba(38,137,13,0.1)",
                color: "#26890D",
                "& .MuiChip-label": { px: 0.75 },
              }}
              icon={
                <Box
                  sx={{
                    width: 6,
                    height: 6,
                    borderRadius: "50%",
                    bgcolor: "#26890D",
                    animation: "pulse 1.4s ease-in-out infinite",
                    "@keyframes pulse": {
                      "0%, 100%": { opacity: 0.4 },
                      "50%": { opacity: 1 },
                    },
                  }}
                />
              }
            />
          )}
          {runStatus === "completed" && (
            <Chip
              label="Done"
              size="small"
              sx={{
                height: 20,
                fontSize: 10,
                fontWeight: 700,
                bgcolor: "rgba(107,119,140,0.1)",
                color: "#6B778C",
                "& .MuiChip-label": { px: 0.75 },
              }}
            />
          )}
          <Box
            sx={{
              width: 6,
              height: 6,
              borderRadius: "50%",
              bgcolor: connected ? "#26890D" : "#DA291C",
            }}
            title={connected ? "Connected" : "Disconnected"}
          />
        </Box>
      </Box>

      {/* Activity stream — scrollable container with fixed height */}
      <Box
        ref={scrollRef}
        sx={{
          flex: 1,
          minHeight: 0,
          overflowY: "auto",
          overflowX: "hidden",
          px: 1.5,
          py: 1,
          display: "flex",
          flexDirection: "column",
          gap: 1.5,
          /* Prevent flex children from stretching the container */
          "& > *": { flexShrink: 0 },
        }}
      >
        {isEmpty && (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 2,
                bgcolor: "#F5F7F9",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <GroupsOutlinedIcon sx={{ fontSize: 28, color: "#A5ADBA" }} />
            </Box>
            <Typography
              variant="subtitle2"
              sx={{ color: "text.secondary", mb: 0.5 }}
            >
              No activity yet
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: "#A5ADBA", textAlign: "center", maxWidth: 200 }}
            >
              Start an assessment to see real-time agent collaboration
            </Typography>
          </Box>
        )}

        {isConnecting && (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
              py: 3,
            }}
          >
            <CircularProgress size={16} sx={{ color: "#26890D" }} />
            <Typography sx={{ fontSize: 12, color: "#6B778C" }}>
              Connecting...
            </Typography>
          </Box>
        )}

        {rendered}

        {thinkingAgent && runStatus === "running" && (
          <ThinkingIndicator agent={thinkingAgent} />
        )}
      </Box>
    </Box>
  );
}
