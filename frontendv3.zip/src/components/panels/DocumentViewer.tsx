"use client";

import React, {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";
import Chip from "@mui/material/Chip";
import Tooltip from "@mui/material/Tooltip";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import ZoomInRoundedIcon from "@mui/icons-material/ZoomInRounded";
import ZoomOutRoundedIcon from "@mui/icons-material/ZoomOutRounded";
import VerticalSplitRoundedIcon from "@mui/icons-material/VerticalSplitRounded";
import ViewStreamRoundedIcon from "@mui/icons-material/ViewStreamRounded";
import NavigateBeforeRoundedIcon from "@mui/icons-material/NavigateBeforeRounded";
import NavigateNextRoundedIcon from "@mui/icons-material/NavigateNextRounded";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import type { DocNavCommand, Highlight, SampleDocument } from "@/lib/types";
import { API_BASE, API_PREFIX } from "@/lib/constants";

// Configure PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

/** Available documents — fetched from backend or hardcoded fallback */
const FALLBACK_DOCS: SampleDocument[] = [
  { name: "FacilityAgreement.pdf", size: 0 },
  { name: "FinancialStatements_2023.pdf", size: 0 },
  { name: "NPL_Report.pdf", size: 0 },
  { name: "BoardMinutes_Q1_2023.pdf", size: 0 },
  { name: "Correspondence.pdf", size: 0 },
];

interface DocumentViewerProps {
  docNav: DocNavCommand | null;
  highlights: Highlight[];
}

/** Tracking which pages have been navigated to by the DA (for page highlights) */
interface VisitedPage {
  document: string;
  page: number;
  color: "green" | "amber";
}

/** Temporary text highlight overlay */
interface TextHighlight {
  id: string;
  top: number;
  left: number;
  width: number;
  height: number;
  opacity: number;
}

// --- Animation constants ---
const ANIM_DURATION = 700; // ms
const ZOOM_TARGET = 2.0;
const ZOOM_DEFAULT = 1.0;
const HIGHLIGHT_FADE_MS = 3000;

function easeInOut(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

/** Single-document pane */
function PdfPane({
  docName,
  targetPage,
  zoom,
  visitedPages,
  containerWidth,
  searchText,
  onZoomChange,
}: {
  docName: string;
  targetPage: number | null;
  zoom: number;
  visitedPages: VisitedPage[];
  containerWidth: number;
  searchText?: string;
  onZoomChange?: (zoom: number) => void;
}) {
  const [numPages, setNumPages] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState(1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const pageRefs = useRef<Map<number, HTMLDivElement>>(new Map());
  const animatingRef = useRef(false);
  const [textHighlights, setTextHighlights] = useState<TextHighlight[]>([]);
  const prevTargetRef = useRef<{ page: number | null; doc: string }>({ page: null, doc: docName });
  const searchTextRef = useRef(searchText);
  searchTextRef.current = searchText;

  const pdfUrl = `${API_BASE}${API_PREFIX}/documents/pdf/${docName}`;
  const pageWidth = Math.max(200, (containerWidth - 32) * zoom);

  // Smooth scroll to target page with easeInOut
  useEffect(() => {
    if (targetPage === null || targetPage < 1 || !scrollRef.current) return;
    if (targetPage > numPages && numPages > 0) return;

    const page = targetPage;
    const el = pageRefs.current.get(page);
    if (!el) return;

    const container = scrollRef.current;

    // If coming from a different page, animate zoom-out first then zoom-in
    const prevPage = prevTargetRef.current.page;
    const isNewTarget = prevPage !== null && prevPage !== page;
    prevTargetRef.current = { page, doc: docName };

    if (isNewTarget && onZoomChange && zoom > ZOOM_DEFAULT) {
      // Zoom out first
      animatingRef.current = true;
      animateZoom(zoom, ZOOM_DEFAULT, ANIM_DURATION / 2, onZoomChange, () => {
        // Then scroll to new page
        scrollToElement(container, el, ANIM_DURATION / 2, () => {
          // Then zoom in and search for text
          animateZoom(ZOOM_DEFAULT, ZOOM_TARGET, ANIM_DURATION, onZoomChange, () => {
            animatingRef.current = false;
            setCurrentPage(page);
            searchForTextOnPage(page);
          });
        });
      });
    } else {
      // Direct scroll + zoom
      animatingRef.current = true;
      scrollToElement(container, el, ANIM_DURATION, () => {
        if (onZoomChange && zoom < ZOOM_TARGET) {
          animateZoom(zoom, ZOOM_TARGET, ANIM_DURATION, onZoomChange, () => {
            animatingRef.current = false;
            setCurrentPage(page);
            searchForTextOnPage(page);
          });
        } else {
          animatingRef.current = false;
          setCurrentPage(page);
          searchForTextOnPage(page);
        }
      });
    }
  }, [targetPage, numPages]); // eslint-disable-line react-hooks/exhaustive-deps

  function scrollToElement(
    container: HTMLDivElement,
    el: HTMLDivElement,
    duration: number,
    onComplete: () => void
  ) {
    const targetTop = el.offsetTop - container.offsetTop - 12;
    const startTop = container.scrollTop;
    const distance = targetTop - startTop;
    let startTime: number | null = null;

    function step(timestamp: number) {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      container.scrollTop = startTop + distance * easeInOut(progress);
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        onComplete();
      }
    }
    requestAnimationFrame(step);
  }

  function animateZoom(
    from: number,
    to: number,
    duration: number,
    setter: (z: number) => void,
    onComplete: () => void
  ) {
    let startTime: number | null = null;
    function step(timestamp: number) {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const current = from + (to - from) * easeInOut(progress);
      setter(current);
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        onComplete();
      }
    }
    requestAnimationFrame(step);
  }

  /** Search for text on the current page using the PDF.js text layer */
  function searchForTextOnPage(pageNum: number) {
    const text = searchTextRef.current;
    if (!text || text.length < 10) return;

    // Wait a bit for the text layer to render
    setTimeout(() => {
      const pageEl = pageRefs.current.get(pageNum);
      if (!pageEl) return;

      const textLayer = pageEl.querySelector(".react-pdf__Page__textContent");
      if (!textLayer) return;

      // Get all text spans
      const spans = textLayer.querySelectorAll("span");
      if (spans.length === 0) return;

      // Build full text from spans to find the search phrase
      const spanData: { el: HTMLSpanElement; text: string; start: number }[] = [];
      let fullText = "";
      spans.forEach((span) => {
        const t = span.textContent || "";
        spanData.push({ el: span, text: t, start: fullText.length });
        fullText += t;
      });

      // Search for a match (case-insensitive, first 50 chars)
      const searchPhrase = text.slice(0, 50).toLowerCase();
      const matchIdx = fullText.toLowerCase().indexOf(searchPhrase);
      if (matchIdx === -1) return;

      // Find which spans contain the match
      const matchEnd = matchIdx + searchPhrase.length;
      const matchingSpans: HTMLSpanElement[] = [];
      for (const sd of spanData) {
        const spanEnd = sd.start + sd.text.length;
        if (sd.start < matchEnd && spanEnd > matchIdx) {
          matchingSpans.push(sd.el);
        }
      }

      if (matchingSpans.length === 0) return;

      // Calculate bounding box relative to the page container
      const pageRect = pageEl.getBoundingClientRect();
      let minTop = Infinity, minLeft = Infinity, maxBottom = 0, maxRight = 0;

      for (const span of matchingSpans) {
        const rect = span.getBoundingClientRect();
        minTop = Math.min(minTop, rect.top - pageRect.top);
        minLeft = Math.min(minLeft, rect.left - pageRect.left);
        maxBottom = Math.max(maxBottom, rect.bottom - pageRect.top);
        maxRight = Math.max(maxRight, rect.right - pageRect.left);
      }

      const hlId = `hl-${Date.now()}`;
      const highlight: TextHighlight = {
        id: hlId,
        top: minTop - 4,
        left: minLeft - 4,
        width: maxRight - minLeft + 8,
        height: maxBottom - minTop + 8,
        opacity: 1,
      };

      setTextHighlights((prev) => [...prev, highlight]);

      // Scroll the highlight into the center of the viewport
      const scrollContainer = scrollRef.current;
      if (scrollContainer) {
        const highlightCenterY = pageEl.offsetTop + minTop + (maxBottom - minTop) / 2;
        const viewportCenter = scrollContainer.clientHeight / 2;
        const scrollTarget = highlightCenterY - viewportCenter;
        scrollContainer.scrollTo({
          top: Math.max(0, scrollTarget),
          behavior: "smooth",
        });
      }

      // Fade out after 3 seconds
      setTimeout(() => {
        setTextHighlights((prev) =>
          prev.map((h) => (h.id === hlId ? { ...h, opacity: 0 } : h))
        );
        // Remove after fade animation
        setTimeout(() => {
          setTextHighlights((prev) => prev.filter((h) => h.id !== hlId));
        }, 600);
      }, HIGHLIGHT_FADE_MS);
    }, 500); // Wait for text layer render
  }

  // Track current page on scroll
  const handleScroll = useCallback(() => {
    if (animatingRef.current || !scrollRef.current) return;
    const container = scrollRef.current;
    const scrollMid = container.scrollTop + container.clientHeight / 3;

    let closestPage = 1;
    let closestDist = Infinity;

    pageRefs.current.forEach((el, page) => {
      const pageMid = el.offsetTop - container.offsetTop + el.clientHeight / 2;
      const dist = Math.abs(pageMid - scrollMid);
      if (dist < closestDist) {
        closestDist = dist;
        closestPage = page;
      }
    });

    setCurrentPage(closestPage);
  }, []);

  function onDocumentLoadSuccess({ numPages: n }: { numPages: number }) {
    setNumPages(n);
    setCurrentPage(1);
  }

  // Pages visited in this document
  const visitedSet = useMemo(() => {
    const s = new Map<number, "green" | "amber">();
    for (const v of visitedPages) {
      if (v.document === docName) {
        s.set(v.page, v.color);
      }
    }
    return s;
  }, [visitedPages, docName]);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        overflow: "hidden",
        flex: 1,
      }}
    >
      {/* Page indicator bar */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 0.5,
          py: 0.5,
          borderBottom: "1px solid #E6E6E6",
          bgcolor: "#FAFBFC",
          flexShrink: 0,
        }}
      >
        <IconButton
          size="small"
          disabled={currentPage <= 1}
          onClick={() => {
            const el = pageRefs.current.get(currentPage - 1);
            el?.scrollIntoView({ behavior: "smooth", block: "start" });
            setCurrentPage((p) => Math.max(1, p - 1));
          }}
          sx={{ p: 0.25 }}
        >
          <NavigateBeforeRoundedIcon sx={{ fontSize: 16 }} />
        </IconButton>
        <Typography sx={{ fontSize: 10, color: "#6B778C", minWidth: 50, textAlign: "center" }}>
          {currentPage} / {numPages || "..."}
        </Typography>
        <IconButton
          size="small"
          disabled={currentPage >= numPages}
          onClick={() => {
            const el = pageRefs.current.get(currentPage + 1);
            el?.scrollIntoView({ behavior: "smooth", block: "start" });
            setCurrentPage((p) => Math.min(numPages, p + 1));
          }}
          sx={{ p: 0.25 }}
        >
          <NavigateNextRoundedIcon sx={{ fontSize: 16 }} />
        </IconButton>
      </Box>

      {/* Scrollable page container */}
      <Box
        ref={scrollRef}
        onScroll={handleScroll}
        sx={{
          flex: 1,
          overflowY: "auto",
          overflowX: "auto",
          bgcolor: "#E8EAED",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          py: 1.5,
          gap: 1.5,
        }}
      >
        <Document
          file={pdfUrl}
          onLoadSuccess={onDocumentLoadSuccess}
          loading={
            <Box sx={{ py: 4, textAlign: "center" }}>
              <Typography sx={{ fontSize: 11, color: "#6B778C" }}>
                Loading {docName}...
              </Typography>
            </Box>
          }
          error={
            <Box sx={{ py: 4, textAlign: "center" }}>
              <Typography sx={{ fontSize: 11, color: "#DA291C" }}>
                Failed to load {docName}
              </Typography>
            </Box>
          }
        >
          {Array.from({ length: numPages }, (_, i) => {
            const pageNum = i + 1;
            const highlightColor = visitedSet.get(pageNum);

            // Text highlights for this page
            const pageTextHighlights = textHighlights;

            return (
              <Box
                key={pageNum}
                ref={(el: HTMLDivElement | null) => {
                  if (el) pageRefs.current.set(pageNum, el);
                }}
                sx={{
                  position: "relative",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.12)",
                  borderRadius: 0.5,
                  overflow: "hidden",
                  // Highlight border for visited pages
                  ...(highlightColor && {
                    outline: `2px solid ${
                      highlightColor === "green"
                        ? "rgba(38,137,13,0.5)"
                        : "rgba(237,139,0,0.5)"
                    }`,
                    outlineOffset: 1,
                  }),
                }}
              >
                <Page
                  pageNumber={pageNum}
                  width={pageWidth}
                  renderTextLayer={true}
                  renderAnnotationLayer={true}
                />
                {/* Highlight overlay animation for visited pages */}
                {highlightColor && (
                  <Box
                    sx={{
                      position: "absolute",
                      inset: 0,
                      pointerEvents: "none",
                      bgcolor:
                        highlightColor === "green"
                          ? "rgba(38,137,13,0.06)"
                          : "rgba(237,139,0,0.06)",
                      animation: "highlightFadeIn 0.6s ease-out",
                      "@keyframes highlightFadeIn": {
                        "0%": { opacity: 0 },
                        "100%": { opacity: 1 },
                      },
                    }}
                  />
                )}
                {/* Text search highlights (temporary, fade after 3s) */}
                {pageNum === currentPage && pageTextHighlights.map((hl) => (
                  <Box
                    key={hl.id}
                    sx={{
                      position: "absolute",
                      top: hl.top,
                      left: hl.left,
                      width: hl.width,
                      height: hl.height,
                      bgcolor: "rgba(38,137,13,0.25)",
                      border: "2px solid rgba(38,137,13,0.6)",
                      borderRadius: 0.5,
                      pointerEvents: "none",
                      opacity: hl.opacity,
                      transition: "opacity 0.6s ease-out",
                      boxShadow: "0 0 12px rgba(38,137,13,0.3)",
                    }}
                  />
                ))}
                {/* Page number badge */}
                <Box
                  sx={{
                    position: "absolute",
                    bottom: 4,
                    right: 4,
                    bgcolor: "rgba(0,0,0,0.5)",
                    color: "#fff",
                    fontSize: 8,
                    px: 0.5,
                    py: 0.125,
                    borderRadius: 0.5,
                  }}
                >
                  p. {pageNum}
                </Box>
              </Box>
            );
          })}
        </Document>
      </Box>
    </Box>
  );
}

export default function DocumentViewer({
  docNav,
  highlights,
}: DocumentViewerProps) {
  const [availableDocs, setAvailableDocs] = useState<SampleDocument[]>([]);
  const [activeDoc, setActiveDoc] = useState<string>("");
  const [splitDoc, setSplitDoc] = useState<string>("");
  const [splitMode, setSplitMode] = useState(false);
  const [zoom, setZoom] = useState(ZOOM_DEFAULT);
  const [targetPage, setTargetPage] = useState<number | null>(null);
  const [searchText, setSearchText] = useState<string | undefined>();
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(400);
  const [visitedPages, setVisitedPages] = useState<VisitedPage[]>([]);

  // Track documents navigated to for split-view detection
  const recentDocsRef = useRef<{ doc: string; time: number }[]>([]);

  // Fetch available documents
  useEffect(() => {
    fetch(`${API_BASE}${API_PREFIX}/documents/list`)
      .then((r) => r.json())
      .then((data) => {
        if (data.documents?.length > 0) {
          setAvailableDocs(data.documents);
        } else {
          setAvailableDocs(FALLBACK_DOCS);
        }
      })
      .catch(() => setAvailableDocs(FALLBACK_DOCS));
  }, []);

  // Measure container width for responsive PDF sizing
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        setContainerWidth(splitMode ? w / 2 : w);
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [splitMode]);

  // Handle docNav commands from the socket (auto or manual click)
  useEffect(() => {
    if (!docNav) return;

    const { document: docName, page, highlightColor, searchText: navSearchText } = docNav;

    // Set active document if different
    if (docName && docName !== activeDoc) {
      // Check for split-view trigger: two different docs within 3 seconds
      const now = Date.now();
      recentDocsRef.current.push({ doc: docName, time: now });
      // Keep only last 3 seconds
      recentDocsRef.current = recentDocsRef.current.filter(
        (r) => now - r.time < 3000
      );
      const uniqueRecent = new Set(recentDocsRef.current.map((r) => r.doc));

      if (uniqueRecent.size >= 2 && activeDoc) {
        // Activate split view
        setSplitMode(true);
        setSplitDoc(activeDoc);
        setActiveDoc(docName);
      } else {
        setActiveDoc(docName);
      }
    }

    // Set search text for highlighting
    setSearchText(navSearchText);

    // Navigate to page
    if (page >= 1) {
      setTargetPage(page);
      // Clear after animation completes
      setTimeout(() => setTargetPage(null), 2500);
    }

    // Track visited page for highlights
    const color = highlightColor ?? "green";
    setVisitedPages((prev) => {
      const exists = prev.some(
        (v) => v.document === docName && v.page === page
      );
      if (exists) return prev;
      return [...prev, { document: docName, page, color }];
    });
  }, [docNav]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.15, 2.5));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.15, 0.4));

  const toggleSplit = () => {
    if (splitMode) {
      setSplitMode(false);
      setSplitDoc("");
    } else if (availableDocs.length >= 2) {
      const other = availableDocs.find((d) => d.name !== activeDoc);
      if (other) {
        setSplitMode(true);
        setSplitDoc(other.name);
      }
    }
  };

  const hasDoc = activeDoc !== "";

  return (
    <Box
      ref={containerRef}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "background.paper",
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {/* Panel header with controls */}
      <Box
        sx={{
          px: 1.5,
          py: 0.75,
          borderBottom: "1px solid",
          borderColor: "#E6E6E6",
          display: "flex",
          alignItems: "center",
          gap: 0.75,
          flexShrink: 0,
        }}
      >
        <DescriptionOutlinedIcon
          sx={{ fontSize: 14, color: "text.secondary", flexShrink: 0 }}
        />
        <Typography
          variant="subtitle1"
          sx={{ fontSize: 12, fontWeight: 600, flexShrink: 0, mr: 0.5 }}
        >
          Document Viewer
        </Typography>

        {/* Document selector */}
        {availableDocs.length > 0 && (
          <Select
            size="small"
            value={activeDoc}
            displayEmpty
            onChange={(e) => {
              setActiveDoc(e.target.value);
              setTargetPage(1);
              setTimeout(() => setTargetPage(null), 1000);
            }}
            renderValue={(val) =>
              val ? (
                <Typography sx={{ fontSize: 10 }}>{val}</Typography>
              ) : (
                <Typography sx={{ fontSize: 10, color: "#A5ADBA" }}>
                  Select document...
                </Typography>
              )
            }
            sx={{
              height: 26,
              fontSize: 10,
              flex: 1,
              minWidth: 0,
              "& .MuiSelect-select": { py: 0.25, px: 1 },
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "#E6E6E6",
              },
            }}
          >
            {availableDocs.map((doc) => (
              <MenuItem key={doc.name} value={doc.name} sx={{ fontSize: 11 }}>
                {doc.name}
              </MenuItem>
            ))}
          </Select>
        )}

        {/* Zoom controls */}
        {hasDoc && (
          <>
            <Tooltip title="Zoom out" arrow>
              <IconButton
                size="small"
                onClick={handleZoomOut}
                disabled={zoom <= 0.4}
                sx={{ p: 0.25 }}
              >
                <ZoomOutRoundedIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
            <Typography sx={{ fontSize: 9, color: "#6B778C", minWidth: 26, textAlign: "center" }}>
              {Math.round(zoom * 100)}%
            </Typography>
            <Tooltip title="Zoom in" arrow>
              <IconButton
                size="small"
                onClick={handleZoomIn}
                disabled={zoom >= 2.5}
                sx={{ p: 0.25 }}
              >
                <ZoomInRoundedIcon sx={{ fontSize: 14 }} />
              </IconButton>
            </Tooltip>
            <Tooltip title={splitMode ? "Single view" : "Split view"} arrow>
              <IconButton size="small" onClick={toggleSplit} sx={{ p: 0.25 }}>
                {splitMode ? (
                  <ViewStreamRoundedIcon sx={{ fontSize: 14 }} />
                ) : (
                  <VerticalSplitRoundedIcon sx={{ fontSize: 14 }} />
                )}
              </IconButton>
            </Tooltip>
          </>
        )}

        {/* Visited page count */}
        {visitedPages.length > 0 && (
          <Chip
            label={`${visitedPages.length} viewed`}
            size="small"
            sx={{
              height: 18,
              fontSize: 9,
              fontWeight: 600,
              bgcolor: "rgba(0,131,143,0.08)",
              color: "#00838F",
              "& .MuiChip-label": { px: 0.5 },
              flexShrink: 0,
            }}
          />
        )}
      </Box>

      {/* PDF content area */}
      {!hasDoc ? (
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            px: 3,
          }}
        >
          <Box
            sx={{
              width: 48,
              height: 48,
              borderRadius: 2,
              bgcolor: "#F5F7F9",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              mb: 1.5,
            }}
          >
            <DescriptionOutlinedIcon sx={{ fontSize: 24, color: "#A5ADBA" }} />
          </Box>
          <Typography
            variant="subtitle2"
            sx={{ color: "text.secondary", mb: 0.5, fontSize: 12 }}
          >
            No document loaded
          </Typography>
          <Typography
            variant="caption"
            sx={{ color: "#A5ADBA", textAlign: "center", maxWidth: 200, fontSize: 10 }}
          >
            Documents will appear here when agents begin searching
          </Typography>
        </Box>
      ) : (
        <Box
          sx={{
            flex: 1,
            display: "flex",
            overflow: "hidden",
          }}
        >
          {/* Primary pane */}
          <PdfPane
            docName={activeDoc}
            targetPage={targetPage}
            zoom={zoom}
            visitedPages={visitedPages}
            containerWidth={splitMode ? containerWidth : containerWidth}
            searchText={searchText}
            onZoomChange={setZoom}
          />

          {/* Split divider + secondary pane */}
          {splitMode && splitDoc && (
            <>
              <Box
                sx={{
                  width: 3,
                  bgcolor: "#E6E6E6",
                  flexShrink: 0,
                  position: "relative",
                  "&::after": {
                    content: '""',
                    position: "absolute",
                    top: "50%",
                    left: -2,
                    width: 7,
                    height: 28,
                    borderRadius: 4,
                    bgcolor: "#D0D0CE",
                    transform: "translateY(-50%)",
                  },
                }}
              />
              <Box sx={{ flex: 1, overflow: "hidden" }}>
                {/* Secondary doc selector */}
                <Box
                  sx={{
                    px: 1,
                    py: 0.5,
                    borderBottom: "1px solid #E6E6E6",
                    bgcolor: "#FAFBFC",
                  }}
                >
                  <Select
                    size="small"
                    value={splitDoc}
                    onChange={(e) => setSplitDoc(e.target.value)}
                    sx={{
                      height: 22,
                      fontSize: 10,
                      width: "100%",
                      "& .MuiSelect-select": { py: 0.125, px: 0.75 },
                      "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: "#E6E6E6",
                      },
                    }}
                  >
                    {availableDocs
                      .filter((d) => d.name !== activeDoc)
                      .map((doc) => (
                        <MenuItem
                          key={doc.name}
                          value={doc.name}
                          sx={{ fontSize: 11 }}
                        >
                          {doc.name}
                        </MenuItem>
                      ))}
                  </Select>
                </Box>
                <PdfPane
                  docName={splitDoc}
                  targetPage={null}
                  zoom={zoom}
                  visitedPages={visitedPages}
                  containerWidth={containerWidth}
                />
              </Box>
            </>
          )}
        </Box>
      )}
    </Box>
  );
}
