"use client";

import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import IconButton from "@mui/material/IconButton";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import BusinessIcon from "@mui/icons-material/Business";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import SecurityOutlinedIcon from "@mui/icons-material/SecurityOutlined";
import type { Case, CaseStatus } from "@/lib/caseTypes";
import NewCaseDialog from "./NewCaseDialog";

interface CaseListViewProps {
  cases: Case[];
  onOpenCase: (caseId: string) => void;
  onCreateCase: (data: {
    borrowerName: string;
    facilityRef: string;
    sheetType: "corporate" | "retail";
  }) => void;
  onDeleteCase: (caseId: string) => void;
}

const STATUS_STYLES: Record<CaseStatus, { label: string; color: string; bg: string }> = {
  draft: { label: "Draft", color: "#6B778C", bg: "rgba(107,119,140,0.08)" },
  ready: { label: "Ready", color: "#007CB0", bg: "rgba(0,124,176,0.08)" },
  running: { label: "Running", color: "#ED8B00", bg: "rgba(237,139,0,0.08)" },
  completed: { label: "Completed", color: "#26890D", bg: "rgba(38,137,13,0.08)" },
};

export default function CaseListView({
  cases,
  onOpenCase,
  onCreateCase,
  onDeleteCase,
}: CaseListViewProps) {
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <Box
      sx={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          height: 64,
          px: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          bgcolor: "background.paper",
          borderBottom: "1px solid #E6E6E6",
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <SecurityOutlinedIcon sx={{ fontSize: 20, color: "#26890D" }} />
          <Typography sx={{ fontSize: 18, fontWeight: 700, color: "#172B4D" }}>
            Forbearance Analysis
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddRoundedIcon />}
          onClick={() => setDialogOpen(true)}
          sx={{
            height: 36,
            px: 2.5,
            fontSize: 13,
            fontWeight: 600,
            bgcolor: "#26890D",
            boxShadow: "none",
            "&:hover": {
              bgcolor: "#1e6e0a",
              boxShadow: "0 2px 8px rgba(38,137,13,0.25)",
            },
          }}
        >
          New Case
        </Button>
      </Box>

      {/* Case list */}
      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          px: 3,
          py: 2.5,
          display: "flex",
          flexDirection: "column",
          gap: 1,
        }}
      >
        {cases.length === 0 && (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
            }}
          >
            <SecurityOutlinedIcon sx={{ fontSize: 48, color: "#A5ADBA" }} />
            <Typography sx={{ fontSize: 14, color: "#6B778C" }}>
              No cases
            </Typography>
            <Typography sx={{ fontSize: 12, color: "#A5ADBA" }}>
              Create a case to begin a forbearance assessment
            </Typography>
          </Box>
        )}
        {cases.map((c) => {
          const st = STATUS_STYLES[c.status];
          return (
            <Box
              key={c.id}
              onClick={() => onOpenCase(c.id)}
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 2,
                px: 2,
                py: 1.5,
                bgcolor: "background.paper",
                borderRadius: 2,
                border: "1px solid #E6E6E6",
                cursor: "pointer",
                transition: "all 0.15s ease",
                "&:hover": {
                  borderColor: "#26890D",
                  bgcolor: "rgba(38,137,13,0.02)",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
                },
              }}
            >
              {/* Avatar */}
              <Box
                sx={{
                  width: 40,
                  height: 40,
                  borderRadius: 1.5,
                  bgcolor: "rgba(38,137,13,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <BusinessIcon sx={{ fontSize: 22, color: "#26890D" }} />
              </Box>

              {/* Info */}
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                  <Typography
                    sx={{
                      fontSize: 14,
                      fontWeight: 600,
                      color: "#172B4D",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {c.borrowerName}
                  </Typography>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mt: 0.25 }}>
                  <Typography sx={{ fontSize: 11, color: "#6B778C" }}>
                    {c.facilityRef}
                  </Typography>
                  <Chip
                    label={c.sheetType === "corporate" ? "Corporate" : "Retail"}
                    size="small"
                    sx={{
                      height: 16,
                      fontSize: 9,
                      fontWeight: 600,
                      bgcolor: "rgba(0,124,176,0.08)",
                      color: "#007CB0",
                      "& .MuiChip-label": { px: 0.4 },
                    }}
                  />
                </Box>
              </Box>

              {/* Metadata */}
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  gap: 2,
                  flexShrink: 0,
                }}
              >
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, color: "#A5ADBA" }}>
                  <DescriptionOutlinedIcon sx={{ fontSize: 13 }} />
                  <Typography sx={{ fontSize: 11 }}>{c.documents.length}</Typography>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, color: "#A5ADBA" }}>
                  <SecurityOutlinedIcon sx={{ fontSize: 13 }} />
                  <Typography sx={{ fontSize: 11 }}>{c.triggers.length}</Typography>
                </Box>
                <Chip
                  label={st.label}
                  size="small"
                  sx={{
                    height: 22,
                    fontSize: 10,
                    fontWeight: 600,
                    bgcolor: st.bg,
                    color: st.color,
                    "& .MuiChip-label": { px: 0.75 },
                  }}
                />
                <Typography sx={{ fontSize: 10, color: "#A5ADBA", minWidth: 70, textAlign: "right" }}>
                  {c.createdAt}
                </Typography>
                <IconButton
                  size="small"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteCase(c.id);
                  }}
                  sx={{
                    color: "#A5ADBA",
                    "&:hover": { color: "#DA291C" },
                  }}
                >
                  <DeleteOutlineRoundedIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </Box>
            </Box>
          );
        })}
      </Box>

      <NewCaseDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onCreate={onCreateCase}
      />
    </Box>
  );
}
