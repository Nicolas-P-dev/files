"use client";

import React, { useRef, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import type { CaseDocument } from "@/lib/caseTypes";

interface DocumentsTabProps {
  documents: CaseDocument[];
  onAdd: (doc: CaseDocument) => void;
  onRemove: (docId: string) => void;
  readOnly?: boolean;
}

let docSeq = Date.now();

export default function DocumentsTab({
  documents,
  onAdd,
  onRemove,
  readOnly,
}: DocumentsTabProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (!f.name.toLowerCase().endsWith(".pdf")) continue;
      const sizeStr =
        f.size >= 1_000_000
          ? `${(f.size / 1_000_000).toFixed(1)} MB`
          : `${(f.size / 1_000).toFixed(0)} KB`;
      onAdd({
        id: `doc-${(++docSeq).toString(36)}`,
        filename: f.name,
        pageCount: 0,
        size: sizeStr,
        uploadDate: new Date().toISOString().slice(0, 10),
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <Box sx={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Upload area */}
      {!readOnly && (
        <Box
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          sx={{
            mx: 2,
            mt: 2,
            mb: 1,
            px: 3,
            py: 2,
            border: dragOver
              ? "2px dashed #26890D"
              : "2px dashed #D0D0CE",
            borderRadius: 2,
            bgcolor: dragOver ? "rgba(38,137,13,0.04)" : "transparent",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 0.5,
            cursor: "pointer",
            transition: "all 0.15s ease",
            "&:hover": {
              borderColor: "#26890D",
              bgcolor: "rgba(38,137,13,0.02)",
            },
          }}
        >
          <UploadFileRoundedIcon sx={{ fontSize: 24, color: "#A5ADBA" }} />
          <Typography sx={{ fontSize: 12, color: "#6B778C", fontWeight: 500 }}>
            Drop PDF files here or click to browse
          </Typography>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf"
            multiple
            hidden
            onChange={(e) => handleFiles(e.target.files)}
          />
        </Box>
      )}

      {/* Document list */}
      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          px: 2,
          py: 1,
          display: "flex",
          flexDirection: "column",
          gap: 0.5,
        }}
      >
        {documents.length === 0 && (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
              py: 4,
            }}
          >
            <DescriptionOutlinedIcon sx={{ fontSize: 36, color: "#A5ADBA" }} />
            <Typography sx={{ fontSize: 13, color: "#6B778C" }}>
              No documents uploaded
            </Typography>
            <Typography sx={{ fontSize: 11, color: "#A5ADBA" }}>
              Add credit file documents to this case
            </Typography>
          </Box>
        )}
        {documents.map((doc) => (
          <Box
            key={doc.id}
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1.5,
              px: 1.5,
              py: 1,
              borderRadius: 1.5,
              bgcolor: "#F5F7F9",
              "&:hover": { bgcolor: "#ECEEF1" },
            }}
          >
            <DescriptionOutlinedIcon sx={{ fontSize: 18, color: "#6B778C" }} />
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 500,
                  color: "#172B4D",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {doc.filename}
              </Typography>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 0.125 }}>
                {doc.pageCount > 0 && (
                  <Typography sx={{ fontSize: 10, color: "#A5ADBA" }}>
                    {doc.pageCount} pages
                  </Typography>
                )}
                <Typography sx={{ fontSize: 10, color: "#A5ADBA" }}>
                  {doc.size}
                </Typography>
              </Box>
            </Box>
            <Typography sx={{ fontSize: 10, color: "#A5ADBA" }}>
              {doc.uploadDate}
            </Typography>
            {!readOnly && (
              <IconButton
                size="small"
                onClick={() => onRemove(doc.id)}
                sx={{ color: "#A5ADBA", "&:hover": { color: "#DA291C" } }}
              >
                <DeleteOutlineRoundedIcon sx={{ fontSize: 15 }} />
              </IconButton>
            )}
          </Box>
        ))}
      </Box>

      {/* Footer summary */}
      <Box
        sx={{
          px: 2,
          py: 1,
          borderTop: "1px solid #E6E6E6",
          display: "flex",
          alignItems: "center",
          gap: 1,
          flexShrink: 0,
        }}
      >
        <Typography sx={{ fontSize: 11, color: "#6B778C" }}>
          {documents.length} document{documents.length !== 1 ? "s" : ""}
        </Typography>
      </Box>
    </Box>
  );
}
