"use client";

import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import ToggleButton from "@mui/material/ToggleButton";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

interface NewCaseDialogProps {
  open: boolean;
  onClose: () => void;
  onCreate: (data: {
    borrowerName: string;
    facilityRef: string;
    sheetType: "corporate" | "retail";
  }) => void;
}

export default function NewCaseDialog({
  open,
  onClose,
  onCreate,
}: NewCaseDialogProps) {
  const [borrowerName, setBorrowerName] = useState("");
  const [facilityRef, setFacilityRef] = useState("");
  const [sheetType, setSheetType] = useState<"corporate" | "retail">("corporate");

  const canCreate = borrowerName.trim().length > 0;

  const handleCreate = () => {
    if (!canCreate) return;
    onCreate({
      borrowerName: borrowerName.trim(),
      facilityRef: facilityRef.trim() || `FA-${Date.now().toString(36).toUpperCase()}`,
      sheetType,
    });
    setBorrowerName("");
    setFacilityRef("");
    setSheetType("corporate");
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 2 },
      }}
    >
      <DialogTitle
        sx={{
          fontSize: 16,
          fontWeight: 700,
          color: "#172B4D",
          pb: 1,
        }}
      >
        New Case
      </DialogTitle>
      <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
        <Box>
          <Typography
            sx={{
              fontSize: 11,
              fontWeight: 600,
              color: "#6B778C",
              mb: 0.5,
            }}
          >
            Borrower Name *
          </Typography>
          <TextField
            autoFocus
            fullWidth
            size="small"
            placeholder="Borrower name"
            value={borrowerName}
            onChange={(e) => setBorrowerName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            sx={{
              "& .MuiOutlinedInput-root": {
                fontSize: 13,
              },
            }}
          />
        </Box>
        <Box>
          <Typography
            sx={{
              fontSize: 11,
              fontWeight: 600,
              color: "#6B778C",
              mb: 0.5,
            }}
          >
            Facility Reference
          </Typography>
          <TextField
            fullWidth
            size="small"
            placeholder="Auto-generated if blank"
            value={facilityRef}
            onChange={(e) => setFacilityRef(e.target.value)}
            sx={{
              "& .MuiOutlinedInput-root": {
                fontSize: 13,
              },
            }}
          />
        </Box>
        <Box>
          <Typography
            sx={{
              fontSize: 11,
              fontWeight: 600,
              color: "#6B778C",
              mb: 0.5,
            }}
          >
            Sheet Type
          </Typography>
          <ToggleButtonGroup
            value={sheetType}
            exclusive
            onChange={(_, val) => val && setSheetType(val)}
            size="small"
            sx={{
              "& .MuiToggleButton-root": {
                fontSize: 12,
                fontWeight: 500,
                px: 2.5,
                py: 0.5,
                border: "1px solid #D0D0CE",
                color: "#6B778C",
                "&.Mui-selected": {
                  bgcolor: "rgba(38,137,13,0.08)",
                  color: "#26890D",
                  borderColor: "#26890D",
                  fontWeight: 600,
                  "&:hover": { bgcolor: "rgba(38,137,13,0.12)" },
                },
              },
            }}
          >
            <ToggleButton value="corporate">Corporate</ToggleButton>
            <ToggleButton value="retail">Retail</ToggleButton>
          </ToggleButtonGroup>
        </Box>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button
          onClick={onClose}
          sx={{ fontSize: 12, color: "#6B778C" }}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          disabled={!canCreate}
          onClick={handleCreate}
          sx={{
            fontSize: 12,
            fontWeight: 600,
            bgcolor: "#26890D",
            boxShadow: "none",
            "&:hover": { bgcolor: "#1e6e0a", boxShadow: "none" },
            "&.Mui-disabled": { bgcolor: "#A5ADBA", color: "#fff" },
          }}
        >
          Create Case
        </Button>
      </DialogActions>
    </Dialog>
  );
}
