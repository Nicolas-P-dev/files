"use client";

import React, { useCallback, useRef, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Chip from "@mui/material/Chip";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import EditRoundedIcon from "@mui/icons-material/EditRounded";
import FileUploadRoundedIcon from "@mui/icons-material/FileUploadRounded";
import FileDownloadRoundedIcon from "@mui/icons-material/FileDownloadRounded";
import SecurityOutlinedIcon from "@mui/icons-material/SecurityOutlined";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import type { CaseTrigger } from "@/lib/caseTypes";

interface TriggerRulesTabProps {
  triggers: CaseTrigger[];
  onAdd: (trigger: CaseTrigger) => void;
  onUpdate: (triggerId: string, patch: Partial<CaseTrigger>) => void;
  onRemove: (triggerId: string) => void;
  onSetAll: (triggers: CaseTrigger[]) => void;
  readOnly?: boolean;
}

const CATEGORIES = [
  "Concessions",
  "Financial Difficulty Indicators",
  "Early Warning Signals",
  "Backstop Indicators",
];
const HARD_SOFT = ["Hard", "Soft"];
const STAGES = ["Stage 1", "Stage 2", "Stage 3"];

let trigSeq = Date.now();

export default function TriggerRulesTab({
  triggers,
  onAdd,
  onUpdate,
  onRemove,
  onSetAll,
  readOnly,
}: TriggerRulesTabProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Group by category
  const grouped = React.useMemo(() => {
    const map = new Map<string, CaseTrigger[]>();
    for (const t of triggers) {
      const cat = t.category || "Uncategorized";
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(t);
    }
    return map;
  }, [triggers]);

  const handleExportExcel = useCallback(async () => {
    try {
      const XLSX = await import("xlsx");
      const data = triggers.map((t) => ({
        ID: t.id,
        Category: t.category,
        Topic: t.topic,
        "Hard/Soft": t.hardSoft,
        "Stage Reference": t.stageReference,
        Description: t.description,
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Triggers");
      XLSX.writeFile(wb, "trigger_rules.xlsx");
    } catch {
      // export failed
    }
  }, [triggers]);

  const handleImportExcel = useCallback(
    async (file: File) => {
      try {
        const XLSX = await import("xlsx");
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf);
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<Record<string, string>>(ws);
        const imported: CaseTrigger[] = rows
          .filter((r) => r["ID"] && r["Topic"])
          .map((r) => ({
            id: r["ID"] || `T-${(++trigSeq).toString(36)}`,
            category: r["Category"] || "Uncategorized",
            topic: r["Topic"] || "",
            hardSoft: r["Hard/Soft"] || "Soft",
            stageReference: r["Stage Reference"] || "",
            description: r["Description"] || "",
          }));
        if (imported.length > 0) {
          onSetAll(imported);
        }
      } catch {
        // import failed — invalid format
      }
    },
    [onSetAll]
  );

  return (
    <Box sx={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* Toolbar */}
      {!readOnly && (
        <Box
          sx={{
            px: 2,
            py: 1,
            display: "flex",
            alignItems: "center",
            gap: 1,
            borderBottom: "1px solid #E6E6E6",
            flexShrink: 0,
          }}
        >
          <Button
            size="small"
            startIcon={<AddRoundedIcon sx={{ fontSize: 14 }} />}
            onClick={() => setAddDialogOpen(true)}
            sx={{
              fontSize: 11,
              fontWeight: 600,
              color: "#26890D",
              "&:hover": { bgcolor: "rgba(38,137,13,0.06)" },
            }}
          >
            Add Trigger
          </Button>
          <Box sx={{ flex: 1 }} />
          <Button
            size="small"
            startIcon={<FileUploadRoundedIcon sx={{ fontSize: 14 }} />}
            onClick={() => fileRef.current?.click()}
            sx={{ fontSize: 11, color: "#6B778C" }}
          >
            Import Excel
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls"
            hidden
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleImportExcel(f);
              e.target.value = "";
            }}
          />
          <Button
            size="small"
            startIcon={<FileDownloadRoundedIcon sx={{ fontSize: 14 }} />}
            onClick={handleExportExcel}
            disabled={triggers.length === 0}
            sx={{ fontSize: 11, color: "#6B778C" }}
          >
            Export Excel
          </Button>
        </Box>
      )}

      {/* Trigger list */}
      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          px: 2,
          py: 1,
          display: "flex",
          flexDirection: "column",
          gap: 1.5,
        }}
      >
        {triggers.length === 0 && (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 1,
              py: 4,
            }}
          >
            <SecurityOutlinedIcon sx={{ fontSize: 36, color: "#A5ADBA" }} />
            <Typography sx={{ fontSize: 13, color: "#6B778C" }}>
              No trigger rules configured
            </Typography>
            <Typography sx={{ fontSize: 11, color: "#A5ADBA", textAlign: "center", maxWidth: 260 }}>
              Add triggers individually or import from Excel
            </Typography>
          </Box>
        )}

        {Array.from(grouped.entries()).map(([cat, trigs]) => (
          <Box key={cat}>
            <Typography
              sx={{
                fontSize: 10,
                fontWeight: 700,
                color: "#1B365D",
                textTransform: "uppercase",
                letterSpacing: 0.5,
                mb: 0.5,
                px: 0.5,
              }}
            >
              {cat}
            </Typography>
            <Box sx={{ display: "flex", flexDirection: "column", gap: 0.375 }}>
              {trigs.map((t) => (
                <TriggerRow
                  key={t.id}
                  trigger={t}
                  isEditing={editId === t.id}
                  onStartEdit={() => setEditId(t.id)}
                  onCancelEdit={() => setEditId(null)}
                  onSave={(patch) => {
                    onUpdate(t.id, patch);
                    setEditId(null);
                  }}
                  onRemove={() => onRemove(t.id)}
                  readOnly={readOnly}
                />
              ))}
            </Box>
          </Box>
        ))}
      </Box>

      {/* Footer summary */}
      <Box
        sx={{
          px: 2,
          py: 1,
          borderTop: "1px solid #E6E6E6",
          display: "flex",
          alignItems: "center",
          gap: 1,
          flexShrink: 0,
        }}
      >
        <Typography sx={{ fontSize: 11, color: "#6B778C" }}>
          {triggers.length} trigger{triggers.length !== 1 ? "s" : ""} across{" "}
          {grouped.size} categor{grouped.size !== 1 ? "ies" : "y"}
        </Typography>
      </Box>

      {/* Add trigger dialog */}
      <AddTriggerDialog
        open={addDialogOpen}
        onClose={() => setAddDialogOpen(false)}
        onAdd={(t) => {
          onAdd(t);
          setAddDialogOpen(false);
        }}
        existingIds={triggers.map((t) => t.id)}
      />
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Inline-editable trigger row                                        */
/* ------------------------------------------------------------------ */

function TriggerRow({
  trigger,
  isEditing,
  onStartEdit,
  onCancelEdit,
  onSave,
  onRemove,
  readOnly,
}: {
  trigger: CaseTrigger;
  isEditing: boolean;
  onStartEdit: () => void;
  onCancelEdit: () => void;
  onSave: (patch: Partial<CaseTrigger>) => void;
  onRemove: () => void;
  readOnly?: boolean;
}) {
  const [topic, setTopic] = useState(trigger.topic);
  const [hardSoft, setHardSoft] = useState(trigger.hardSoft);
  const [stage, setStage] = useState(trigger.stageReference);

  // Reset local state when editing starts
  React.useEffect(() => {
    if (isEditing) {
      setTopic(trigger.topic);
      setHardSoft(trigger.hardSoft);
      setStage(trigger.stageReference);
    }
  }, [isEditing, trigger]);

  if (isEditing) {
    return (
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          gap: 0.75,
          px: 1,
          py: 0.5,
          borderRadius: 1,
          bgcolor: "rgba(0,124,176,0.04)",
          border: "1px solid rgba(0,124,176,0.2)",
        }}
      >
        <Typography sx={{ fontSize: 11, fontWeight: 700, color: "#172B4D", minWidth: 32 }}>
          {trigger.id}
        </Typography>
        <TextField
          size="small"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          sx={{ flex: 1, "& .MuiOutlinedInput-root": { fontSize: 11, py: 0 } }}
        />
        <Select
          size="small"
          value={hardSoft}
          onChange={(e) => setHardSoft(e.target.value)}
          sx={{ fontSize: 11, minWidth: 70, "& .MuiSelect-select": { py: 0.375 } }}
        >
          {HARD_SOFT.map((hs) => (
            <MenuItem key={hs} value={hs} sx={{ fontSize: 11 }}>
              {hs}
            </MenuItem>
          ))}
        </Select>
        <Select
          size="small"
          value={stage}
          onChange={(e) => setStage(e.target.value)}
          sx={{ fontSize: 11, minWidth: 80, "& .MuiSelect-select": { py: 0.375 } }}
        >
          {STAGES.map((s) => (
            <MenuItem key={s} value={s} sx={{ fontSize: 11 }}>
              {s}
            </MenuItem>
          ))}
        </Select>
        <IconButton
          size="small"
          onClick={() => onSave({ topic, hardSoft, stageReference: stage })}
          sx={{ color: "#26890D", p: 0.25 }}
        >
          <CheckRoundedIcon sx={{ fontSize: 16 }} />
        </IconButton>
        <IconButton size="small" onClick={onCancelEdit} sx={{ color: "#6B778C", p: 0.25 }}>
          <CloseRoundedIcon sx={{ fontSize: 16 }} />
        </IconButton>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 0.75,
        px: 1,
        py: 0.5,
        borderRadius: 1,
        bgcolor: "#F5F7F9",
        "&:hover": { bgcolor: "#ECEEF1" },
      }}
    >
      <Typography sx={{ fontSize: 11, fontWeight: 700, color: "#172B4D", minWidth: 32 }}>
        {trigger.id}
      </Typography>
      <Typography
        sx={{
          fontSize: 11,
          color: "#6B778C",
          flex: 1,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {trigger.topic}
      </Typography>
      <Chip
        label={trigger.hardSoft}
        size="small"
        sx={{
          height: 16,
          fontSize: 9,
          fontWeight: 700,
          bgcolor:
            trigger.hardSoft === "Hard"
              ? "rgba(218,41,28,0.08)"
              : "rgba(107,119,140,0.08)",
          color: trigger.hardSoft === "Hard" ? "#DA291C" : "#6B778C",
          "& .MuiChip-label": { px: 0.4 },
        }}
      />
      <Chip
        label={trigger.stageReference || "—"}
        size="small"
        sx={{
          height: 16,
          fontSize: 9,
          fontWeight: 600,
          bgcolor: "rgba(27,54,93,0.08)",
          color: "#1B365D",
          "& .MuiChip-label": { px: 0.4 },
        }}
      />
      {!readOnly && (
        <>
          <IconButton
            size="small"
            onClick={onStartEdit}
            sx={{ color: "#A5ADBA", p: 0.125, "&:hover": { color: "#007CB0" } }}
          >
            <EditRoundedIcon sx={{ fontSize: 13 }} />
          </IconButton>
          <IconButton
            size="small"
            onClick={onRemove}
            sx={{ color: "#A5ADBA", p: 0.125, "&:hover": { color: "#DA291C" } }}
          >
            <DeleteOutlineRoundedIcon sx={{ fontSize: 13 }} />
          </IconButton>
        </>
      )}
    </Box>
  );
}

/* ------------------------------------------------------------------ */
/*  Add trigger dialog                                                  */
/* ------------------------------------------------------------------ */

function AddTriggerDialog({
  open,
  onClose,
  onAdd,
  existingIds,
}: {
  open: boolean;
  onClose: () => void;
  onAdd: (trigger: CaseTrigger) => void;
  existingIds: string[];
}) {
  const [id, setId] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [topic, setTopic] = useState("");
  const [hardSoft, setHardSoft] = useState("Soft");
  const [stage, setStage] = useState("Stage 2");
  const [description, setDescription] = useState("");

  const nextId = React.useMemo(() => {
    const nums = existingIds
      .map((x) => parseInt(x.replace(/^T-/, ""), 10))
      .filter((n) => !isNaN(n));
    return `T-${(Math.max(0, ...nums) + 1)}`;
  }, [existingIds]);

  React.useEffect(() => {
    if (open) setId(nextId);
  }, [open, nextId]);

  const canCreate = id.trim().length > 0 && topic.trim().length > 0;

  const handleCreate = () => {
    if (!canCreate) return;
    onAdd({
      id: id.trim(),
      category,
      topic: topic.trim(),
      hardSoft,
      stageReference: stage,
      description: description.trim(),
    });
    setId("");
    setTopic("");
    setDescription("");
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 2 } }}>
      <DialogTitle sx={{ fontSize: 16, fontWeight: 700, color: "#172B4D", pb: 1 }}>
        Add Trigger Rule
      </DialogTitle>
      <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 1.5, pt: 1 }}>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          <Box sx={{ flex: "0 0 80px" }}>
            <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
              ID *
            </Typography>
            <TextField
              size="small"
              fullWidth
              value={id}
              onChange={(e) => setId(e.target.value)}
              sx={{ "& .MuiOutlinedInput-root": { fontSize: 12 } }}
            />
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
              Category
            </Typography>
            <Select
              size="small"
              fullWidth
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              sx={{ fontSize: 12 }}
            >
              {CATEGORIES.map((c) => (
                <MenuItem key={c} value={c} sx={{ fontSize: 12 }}>
                  {c}
                </MenuItem>
              ))}
            </Select>
          </Box>
        </Box>
        <Box>
          <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
            Topic *
          </Typography>
          <TextField
            size="small"
            fullWidth
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            sx={{ "& .MuiOutlinedInput-root": { fontSize: 12 } }}
          />
        </Box>
        <Box sx={{ display: "flex", gap: 1.5 }}>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
              Hard/Soft
            </Typography>
            <Select
              size="small"
              fullWidth
              value={hardSoft}
              onChange={(e) => setHardSoft(e.target.value)}
              sx={{ fontSize: 12 }}
            >
              {HARD_SOFT.map((hs) => (
                <MenuItem key={hs} value={hs} sx={{ fontSize: 12 }}>
                  {hs}
                </MenuItem>
              ))}
            </Select>
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
              Stage Reference
            </Typography>
            <Select
              size="small"
              fullWidth
              value={stage}
              onChange={(e) => setStage(e.target.value)}
              sx={{ fontSize: 12 }}
            >
              {STAGES.map((s) => (
                <MenuItem key={s} value={s} sx={{ fontSize: 12 }}>
                  {s}
                </MenuItem>
              ))}
            </Select>
          </Box>
        </Box>
        <Box>
          <Typography sx={{ fontSize: 11, fontWeight: 600, color: "#6B778C", mb: 0.5 }}>
            Description
          </Typography>
          <TextField
            size="small"
            fullWidth
            multiline
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            sx={{ "& .MuiOutlinedInput-root": { fontSize: 12 } }}
          />
        </Box>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} sx={{ fontSize: 12, color: "#6B778C" }}>
          Cancel
        </Button>
        <Button
          variant="contained"
          disabled={!canCreate}
          onClick={handleCreate}
          sx={{
            fontSize: 12,
            fontWeight: 600,
            bgcolor: "#26890D",
            boxShadow: "none",
            "&:hover": { bgcolor: "#1e6e0a", boxShadow: "none" },
            "&.Mui-disabled": { bgcolor: "#A5ADBA", color: "#fff" },
          }}
        >
          Add Trigger
        </Button>
      </DialogActions>
    </Dialog>
  );
}
