"use client";

import React from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Divider from "@mui/material/Divider";
import Avatar from "@mui/material/Avatar";
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import SecurityOutlinedIcon from "@mui/icons-material/SecurityOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import FolderOutlinedIcon from "@mui/icons-material/FolderOutlined";
import BusinessIcon from "@mui/icons-material/Business";

const SIDEBAR_FULL = 260;

interface NavItem {
  label: string;
  icon: React.ReactNode;
  path: string;
  active?: boolean;
}

const navItems: NavItem[] = [
  {
    label: "Dashboard",
    icon: <DashboardOutlinedIcon sx={{ fontSize: 20 }} />,
    path: "/",
  },
  {
    label: "Credit Files",
    icon: <FolderOutlinedIcon sx={{ fontSize: 20 }} />,
    path: "/modules/credit-files",
  },
  {
    label: "Risk Assessment",
    icon: <AssessmentOutlinedIcon sx={{ fontSize: 20 }} />,
    path: "/modules/risk-assessment",
  },
  {
    label: "Forbearance Analysis",
    icon: <SecurityOutlinedIcon sx={{ fontSize: 20 }} />,
    path: "/modules/forbearance-analysis",
    active: true,
  },
  {
    label: "Settings",
    icon: <SettingsOutlinedIcon sx={{ fontSize: 20 }} />,
    path: "/settings",
  },
];

interface SidebarProps {
  activeCaseName?: string;
  activeFacilityRef?: string;
}

export default function Sidebar({ activeCaseName, activeFacilityRef }: SidebarProps = {}) {
  const width = SIDEBAR_FULL;

  return (
    <Box
      sx={{
        width,
        minWidth: width,
        height: "100vh",
        bgcolor: "#000000",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* Logo area + collapse toggle */}
      <Box sx={{ px: 2, pt: 2, pb: 1, display: "flex", flexDirection: "column", alignItems: "flex-start" }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "flex-start", width: "100%" }}>
          <Box
            sx={{
              width: 32,
              height: 32,
              bgcolor: "#26890D",
              borderRadius: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography
              sx={{
                color: "#fff",
                fontWeight: 700,
                fontSize: 15,
                letterSpacing: -0.5,
              }}
            >
              D.
            </Typography>
          </Box>
        </Box>
            <Typography
              sx={{
                color: "#86BC25",
                fontSize: 10,
                fontWeight: 500,
                letterSpacing: 2,
                textTransform: "uppercase",
                mt: 1,
                mb: 0.25,
              }}
            >
              aiStudio
            </Typography>
            <Typography
              sx={{
                color: "#FFFFFF",
                fontSize: 20,
                fontWeight: 700,
                letterSpacing: 1,
              }}
            >
              FORTUNA
            </Typography>
      </Box>

      <Divider sx={{ borderColor: "rgba(255,255,255,0.08)", mx: 1.5, my: 1 }} />

      {/* Navigation */}
      <List sx={{ px: 1, flex: 1 }}>
        {navItems.map((item) => (
            <ListItemButton
              key={item.label}
              selected={item.active}
              sx={{
                borderRadius: 1.5,
                mb: 0.5,
                py: 0.75,
                px: 1.5,
                justifyContent: "flex-start",
                color: item.active ? "#FFFFFF" : "rgba(255,255,255,0.55)",
                bgcolor: item.active
                  ? "rgba(38,137,13,0.15)"
                  : "transparent",
                "&:hover": {
                  bgcolor: item.active
                    ? "rgba(38,137,13,0.2)"
                    : "rgba(255,255,255,0.06)",
                },
                "&.Mui-selected": {
                  bgcolor: "rgba(38,137,13,0.15)",
                  "&:hover": {
                    bgcolor: "rgba(38,137,13,0.2)",
                  },
                },
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 32,
                  color: item.active ? "#86BC25" : "rgba(255,255,255,0.4)",
                  justifyContent: "center",
                }}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.label}
                primaryTypographyProps={{
                  fontSize: 12,
                  fontWeight: item.active ? 600 : 400,
                }}
              />
              {item.active && (
                <Box
                  sx={{
                    width: 5,
                    height: 5,
                    borderRadius: "50%",
                    bgcolor: "#86BC25",
                  }}
                />
              )}
            </ListItemButton>
        ))}
      </List>

      <Divider sx={{ borderColor: "rgba(255,255,255,0.08)", mx: 1.5 }} />

      {/* Current debtor — only show when a case is active */}
      {activeCaseName && (
        <Box sx={{ px: 2, py: 1.5 }}>
          <Typography
            sx={{
              color: "rgba(255,255,255,0.4)",
              fontSize: 9,
              fontWeight: 600,
              letterSpacing: 1.5,
              textTransform: "uppercase",
              mb: 0.75,
            }}
          >
            Current Debtor
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Avatar
              sx={{
                width: 28,
                height: 28,
                bgcolor: "rgba(38,137,13,0.2)",
                color: "#86BC25",
                fontSize: 12,
                fontWeight: 600,
              }}
            >
              <BusinessIcon sx={{ fontSize: 16 }} />
            </Avatar>
            <Box>
              <Typography
                sx={{
                  color: "#FFFFFF",
                  fontSize: 11,
                  fontWeight: 600,
                  lineHeight: 1.3,
                }}
              >
                {activeCaseName}
              </Typography>
              {activeFacilityRef && (
                <Typography
                  sx={{
                    color: "rgba(255,255,255,0.4)",
                    fontSize: 10,
                  }}
                >
                  {activeFacilityRef}
                </Typography>
              )}
            </Box>
          </Box>
        </Box>
      )}
    </Box>
  );
}
