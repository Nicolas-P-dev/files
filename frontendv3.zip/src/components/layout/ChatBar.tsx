"use client";

import React, { useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import SendRoundedIcon from "@mui/icons-material/SendRounded";
import { API_BASE, API_PREFIX } from "@/lib/constants";
import type { RunStatus } from "@/lib/types";

interface ChatBarProps {
  runId: string | null;
  runStatus: RunStatus;
}

export default function ChatBar({ runId, runStatus }: ChatBarProps) {
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const canSend =
    message.trim().length > 0 &&
    !sending &&
    runId !== null &&
    (runStatus === "running" || runStatus === "completed");

  const handleSend = async () => {
    if (!canSend || !runId) return;
    const text = message.trim();
    setMessage("");
    setSending(true);

    try {
      await fetch(`${API_BASE}${API_PREFIX}/run/${runId}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ message: text }),
      });
    } catch {
      // Network error — message won't appear in activity stream.
      // Could add a local error indicator, but for now silent fail is fine
      // since the WebSocket will show responses if the backend is reachable.
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const placeholder =
    runStatus === "running"
      ? "Send an instruction to the audit team..."
      : runStatus === "completed"
        ? "Ask a follow-up question about the assessment..."
        : "Start an assessment to chat with the team...";

  const disabled = runId === null || runStatus === "idle" || runStatus === "connecting";

  return (
    <Box
      sx={{
        minHeight: 64,
        px: 2,
        py: 1,
        display: "flex",
        alignItems: "center",
        gap: 1.5,
        bgcolor: "background.paper",
        borderTop: "1px solid",
        borderColor: "#E6E6E6",
        flexShrink: 0,
      }}
    >
      <TextField
        fullWidth
        size="small"
        placeholder={placeholder}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        sx={{
          "& .MuiOutlinedInput-root": {
            minHeight: 48,
            borderRadius: 2,
            fontSize: 13,
            px: 2,
            py: 1.5,
            bgcolor: disabled ? "#F0F0F0" : "#F5F7F9",
            "& fieldset": {
              borderColor: "#E6E6E6",
            },
            "&:hover fieldset": {
              borderColor: "#D0D0CE",
            },
            "&.Mui-focused fieldset": {
              borderColor: "#26890D",
              borderWidth: 1,
            },
          },
        }}
      />
      {sending && (
        <Typography sx={{ fontSize: 10, color: "#A5ADBA", flexShrink: 0 }}>
          Sending...
        </Typography>
      )}
      <IconButton
        onClick={handleSend}
        disabled={!canSend}
        sx={{
          width: 44,
          height: 44,
          bgcolor: canSend ? "#26890D" : "#E6E6E6",
          color: "#FFFFFF",
          borderRadius: 1.5,
          "&:hover": {
            bgcolor: canSend ? "#1e6e0a" : "#E6E6E6",
          },
          "&.Mui-disabled": {
            color: "#A5ADBA",
            bgcolor: "#E6E6E6",
          },
        }}
      >
        <SendRoundedIcon sx={{ fontSize: 20 }} />
      </IconButton>
    </Box>
  );
}
