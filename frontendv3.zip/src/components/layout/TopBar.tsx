"use client";

import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import ToggleButton from "@mui/material/ToggleButton";
import Chip from "@mui/material/Chip";
import CircularProgress from "@mui/material/CircularProgress";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import BusinessIcon from "@mui/icons-material/Business";
import { API_BASE, API_PREFIX } from "@/lib/constants";
import type { RunStatus } from "@/lib/types";

interface TopBarProps {
  onRunAssessment: (debtorId: string, sheetType: string) => void;
  onReplay: (speed: number) => void;
  runStatus: RunStatus;
  runId: string | null;
}

export default function TopBar({
  onRunAssessment,
  onReplay,
  runStatus,
  runId,
}: TopBarProps) {
  const [sheetType, setSheetType] = useState<string>("corporate");
  const isRunning = runStatus === "running" || runStatus === "connecting";

  return (
    <Box
      sx={{
        height: 64,
        px: 3,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        bgcolor: "background.paper",
        borderBottom: "1px solid",
        borderColor: "#E6E6E6",
        flexShrink: 0,
      }}
    >
      {/* Left section: Title + Borrower */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 700,
            fontSize: 18,
            color: "text.primary",
          }}
        >
          Forbearance Analysis
        </Typography>
        <Box sx={{ width: 1, height: 24, bgcolor: "#E6E6E6" }} />
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <BusinessIcon sx={{ fontSize: 18, color: "#6B778C" }} />
          <Typography
            sx={{ fontSize: 13, color: "text.secondary", fontWeight: 500 }}
          >
            Meridian Industries GmbH
          </Typography>
          <Chip
            label="Corporate"
            size="small"
            sx={{
              height: 22,
              fontSize: 11,
              fontWeight: 600,
              bgcolor: "rgba(0,124,176,0.08)",
              color: "#007CB0",
            }}
          />
        </Box>
      </Box>

      {/* Right section: Toggle + Buttons */}
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
        <ToggleButtonGroup
          value={sheetType}
          exclusive
          onChange={(_, val) => val && setSheetType(val)}
          size="small"
          disabled={isRunning}
          sx={{
            height: 34,
            "& .MuiToggleButton-root": {
              fontSize: 12,
              fontWeight: 500,
              px: 2,
              border: "1px solid #D0D0CE",
              color: "#6B778C",
              "&.Mui-selected": {
                bgcolor: "rgba(38,137,13,0.08)",
                color: "#26890D",
                borderColor: "#26890D",
                fontWeight: 600,
                "&:hover": {
                  bgcolor: "rgba(38,137,13,0.12)",
                },
              },
            },
          }}
        >
          <ToggleButton value="corporate">Corporate</ToggleButton>
          <ToggleButton value="retail">Retail</ToggleButton>
        </ToggleButtonGroup>

        {/* Replay button (dev/testing) */}
        <Button
          variant="outlined"
          size="small"
          startIcon={<ReplayRoundedIcon sx={{ fontSize: 16 }} />}
          disabled={isRunning}
          onClick={() => onReplay(1.0)}
          sx={{
            height: 36,
            px: 2,
            fontSize: 12,
            fontWeight: 600,
            borderColor: "#D0D0CE",
            color: "#6B778C",
            "&:hover": {
              borderColor: "#007CB0",
              color: "#007CB0",
              bgcolor: "rgba(0,124,176,0.04)",
            },
          }}
        >
          Replay
        </Button>

        {/* Download Report button — visible after run completes */}
        {runStatus === "completed" && runId && (
          <Button
            variant="outlined"
            size="small"
            startIcon={<DownloadRoundedIcon sx={{ fontSize: 16 }} />}
            onClick={() => {
              window.open(
                `${API_BASE}${API_PREFIX}/run/${runId}/report?format=excel`,
                "_blank"
              );
            }}
            sx={{
              height: 36,
              px: 2,
              fontSize: 12,
              fontWeight: 600,
              borderColor: "#26890D",
              color: "#26890D",
              "&:hover": {
                borderColor: "#1e6e0a",
                color: "#1e6e0a",
                bgcolor: "rgba(38,137,13,0.04)",
              },
            }}
          >
            Report
          </Button>
        )}

        {/* Run Assessment button */}
        <Button
          variant="contained"
          startIcon={
            isRunning ? (
              <CircularProgress size={14} sx={{ color: "#fff" }} />
            ) : (
              <PlayArrowRoundedIcon />
            )
          }
          disabled={isRunning}
          onClick={() => onRunAssessment("MI-2023-001", sheetType)}
          sx={{
            height: 36,
            px: 2.5,
            fontSize: 13,
            fontWeight: 600,
            bgcolor: "#26890D",
            boxShadow: "none",
            "&:hover": {
              bgcolor: "#1e6e0a",
              boxShadow: "0 2px 8px rgba(38,137,13,0.25)",
            },
            "&.Mui-disabled": {
              bgcolor: "#A5ADBA",
              color: "#fff",
            },
          }}
        >
          {isRunning ? "Running..." : "Run Assessment"}
        </Button>
      </Box>
    </Box>
  );
}
