"use client";

import React, { useRef } from "react";
import Box from "@mui/material/Box";
import useResizablePanels from "@/hooks/useResizablePanels";

interface ResizablePanelsProps {
  left: React.ReactNode;
  center: React.ReactNode;
  right: React.ReactNode;
}

export default function ResizablePanels({
  left,
  center,
  right,
}: ResizablePanelsProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { sizes, onMouseDown } = useResizablePanels(containerRef, {
    left: 25,
    center: 45,
    right: 30,
  });

  return (
    <Box
      ref={containerRef}
      sx={{
        display: "flex",
        flex: 1,
        overflow: "hidden",
        p: 2,
        gap: 0,
      }}
    >
      {/* Left panel */}
      <Box
        sx={{
          width: `${sizes.left}%`,
          minWidth: 200,
          overflow: "hidden",
          pr: 0.5,
        }}
      >
        {left}
      </Box>

      {/* Left resize handle */}
      <div
        className="resize-handle"
        onMouseDown={(e) => onMouseDown("left", e)}
      />

      {/* Center panel */}
      <Box
        sx={{
          width: `${sizes.center}%`,
          minWidth: 200,
          overflow: "hidden",
          px: 0.5,
        }}
      >
        {center}
      </Box>

      {/* Right resize handle */}
      <div
        className="resize-handle"
        onMouseDown={(e) => onMouseDown("right", e)}
      />

      {/* Right panel */}
      <Box
        sx={{
          width: `${sizes.right}%`,
          minWidth: 200,
          overflow: "hidden",
          pl: 0.5,
        }}
      >
        {right}
      </Box>
    </Box>
  );
}
