"""A2A routes — per-agent-slot FastAPI routers.

Each agent slot gets its own router mounted at /{agent_id}/.
Serves the AgentCard and handles JSON-RPC 2.0 A2A messages.
"""

import json
import logging
import os

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from host.agent_slot import AgentSlot, AgentSlotConfig
from host.a2a_handler import handle_stream, handle_send

logger = logging.getLogger(__name__)


def create_agent_router(agent_id: str, agent: AgentSlot) -> APIRouter:
    """Create a FastAPI router for a single agent slot.

    Endpoints:
        GET  /.well-known/agent-card.json  — A2A agent card discovery
        GET  /.well-known/agent.json       — legacy redirect
        POST /a2a/jsonrpc                  — JSON-RPC 2.0 handler
    """
    router = APIRouter()
    config = agent.config

    # --- Agent Card ---
    # Orchestrator fetches /.well-known/agent.json directly.
    # Serve the same card at both paths for compatibility.

    def _build_agent_card() -> dict:
        base_url = os.getenv("A2A_BASE_URL", "http://localhost:8080")
        return {
            "name": config.agent_card_name,
            "description": config.agent_card_description,
            "version": config.agent_card_version,
            "url": f"{base_url}/{agent_id}/a2a/jsonrpc",
            "defaultInputModes": ["text"],
            "defaultOutputModes": ["text"],
            "capabilities": {
                "pushNotifications": False,
                "streaming": True,
                "stateTransitionHistory": False,
            },
            "skills": [
                {
                    "id": agent_id,
                    "name": config.agent_card_name,
                    "description": config.agent_card_description,
                    "tags": [agent_id],
                }
            ],
        }

    @router.get("/.well-known/agent.json")
    async def agent_card():
        return JSONResponse(_build_agent_card())

    @router.get("/.well-known/agent-card.json")
    async def agent_card_alt():
        return JSONResponse(_build_agent_card())

    # --- JSON-RPC 2.0 ---

    @router.post("/a2a/jsonrpc")
    async def jsonrpc_handler(request: Request):
        body = await request.json()
        method = body.get("method", "")

        if method == "message/stream":
            return StreamingResponse(
                handle_stream(agent, body),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        elif method == "message/send":
            result = await handle_send(agent, body)
            return JSONResponse(result)

        else:
            return JSONResponse(
                {
                    "jsonrpc": "2.0",
                    "id": body.get("id"),
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {method}",
                    },
                },
                status_code=400,
            )

    return router
