"""Agent slot — the core of the MCP Agent.

Each slot wraps exactly one MCP server. It receives natural language,
uses an LLM to translate it into MCP tool calls, and returns the result.
The loop is driven entirely by OpenAI's finish_reason signal.
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable, Optional

from openai import AsyncAzureOpenAI

from host.mcp_client import MCPClient
from host.auth import exchange_token_obo

logger = logging.getLogger(__name__)


@dataclass
class AgentSlotConfig:
    """Configuration for a single agent slot."""

    agent_id: str
    mcp_url: str
    mcp_oauth_scope: str
    agent_card_name: str
    agent_card_description: str
    agent_card_version: str = "1.0.0"
    system_prompt_extra: str = ""
    tool_preselection: bool = False
    tool_preselection_threshold: int = 40
    tool_result_max_chars: int = 8000
    max_turns: int = 5
    timeout_per_tool: float = 30.0
    timeout_per_request: float = 120.0


class AgentSlot:
    """A single MCP Agent instance wrapping one MCP server."""

    def __init__(self, config: AgentSlotConfig):
        self.config = config
        self._llm = AsyncAzureOpenAI(
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-06-01"),
        )
        self._deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")

    def _build_system_prompt(self, server_name: str, server_description: str) -> str:
        """Build the system prompt dynamically from MCP server metadata."""
        extra = self.config.system_prompt_extra
        extra_section = f"\n{extra}" if extra else ""

        return f"""You are a helpful assistant with access to tools provided by {server_name}.
{server_description}{extra_section}

# Instructions
- Keep going until the user's query is completely resolved.
- If you are not sure about information, use your tools. Do NOT guess.
- Plan before each tool call and reflect on the outcomes.

# Error handling
- If a tool call fails, analyze the error and retry with corrected
  parameters, try an alternative approach, or explain what went wrong.

# Response format
- Be concise and actionable.
- When presenting data from tools, format it clearly."""

    def _truncate_result(self, result: str) -> str:
        """Truncate tool results exceeding the configured max length."""
        max_chars = self.config.tool_result_max_chars
        if len(result) <= max_chars:
            return result
        return result[:max_chars] + f"\n... [truncated, {len(result)} chars total]"

    async def run(
        self,
        user_message: str,
        auth_token: str,
        on_status: Optional[Callable[[str], Any]] = None,
    ) -> str:
        """Run the agent loop for a single A2A request.

        Args:
            user_message: Natural language from the orchestrator.
            auth_token: OBO JWT from the orchestrator.
            on_status: Callback for streaming status events during tool execution.

        Returns:
            The final text response.
        """
        start_time = time.monotonic()

        # 1. Exchange token for MCP server scope (None if no auth needed)
        mcp_token = await exchange_token_obo(auth_token, self.config.mcp_oauth_scope)

        # 2. Connect to MCP server
        mcp = MCPClient(self.config.mcp_url, timeout=self.config.timeout_per_tool)
        headers = {"Content-Type": "application/json"}
        if mcp_token:
            headers["Authorization"] = f"Bearer {mcp_token}"

        try:
            await mcp.connect(headers=headers)

            # 3. Get tools
            tools = mcp.openai_tools
            if not tools:
                return "No tools available from the connected MCP server."

            # 4. Build system prompt from MCP server metadata
            system_prompt = self._build_system_prompt(
                server_name=mcp.server_name,
                server_description=f"Server version: {mcp.server_version}",
            )

            # 5. Run the agent loop
            return await self._agent_loop(
                mcp=mcp,
                tools=tools,
                system_prompt=system_prompt,
                user_message=user_message,
                start_time=start_time,
                on_status=on_status,
            )

        finally:
            await mcp.disconnect()

    async def _agent_loop(
        self,
        mcp: MCPClient,
        tools: list[dict[str, Any]],
        system_prompt: str,
        user_message: str,
        start_time: float,
        on_status: Optional[Callable[[str], Any]] = None,
    ) -> str:
        """The finish_reason-driven tool-calling loop.

        Loops until the LLM returns finish_reason="stop" or limits are hit.
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

        for turn in range(self.config.max_turns):
            # Check total request timeout
            elapsed = time.monotonic() - start_time
            if elapsed >= self.config.timeout_per_request:
                logger.warning("Request timeout after %.1fs", elapsed)
                return "Request timed out. Here is what I have so far based on the tools I called."

            # Call LLM
            response = await self._llm.chat.completions.create(
                model=self._deployment,
                messages=messages,
                tools=tools,
                tool_choice="auto",
            )

            choice = response.choices[0]

            # --- finish_reason: "stop" → done ---
            if choice.finish_reason == "stop":
                return choice.message.content or ""

            # --- finish_reason: "tool_calls" → execute and loop ---
            if choice.finish_reason == "tool_calls":
                messages.append(choice.message)

                # Execute all tool calls (parallel if multiple)
                tool_tasks = []
                for tc in choice.message.tool_calls:
                    tool_tasks.append(
                        self._execute_tool_call(mcp, tc, on_status)
                    )

                results = await asyncio.gather(*tool_tasks)

                # Append all results to message history
                for tc, result_text in zip(choice.message.tool_calls, results):
                    truncated = self._truncate_result(result_text)
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": truncated,
                        }
                    )

                continue

            # --- finish_reason: "length" or "content_filter" → return partial ---
            return choice.message.content or "Response was cut short."

        # Max turns exhausted — ask LLM for a summary of what it has
        messages.append(
            {
                "role": "user",
                "content": "You have reached the maximum number of tool calls. "
                "Please summarize what you found so far and respond to the user.",
            }
        )
        response = await self._llm.chat.completions.create(
            model=self._deployment,
            messages=messages,
        )
        return response.choices[0].message.content or "Could not complete within allowed steps."

    async def _execute_tool_call(
        self,
        mcp: MCPClient,
        tool_call: Any,
        on_status: Optional[Callable[[str], Any]] = None,
    ) -> str:
        """Execute a single MCP tool call."""
        name = tool_call.function.name
        arguments = json.loads(tool_call.function.arguments)

        # Emit status event
        if on_status:
            await on_status(f"Executing: {name}")

        logger.info("Tool call: %s(%s)", name, json.dumps(arguments)[:200])

        result = await mcp.call_tool(
            name, arguments, timeout=self.config.timeout_per_tool
        )

        logger.info("Tool result: %s → %d chars", name, len(result))
        return result
