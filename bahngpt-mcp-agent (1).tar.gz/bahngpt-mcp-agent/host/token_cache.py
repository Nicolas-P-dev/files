"""Token cache for OBO token exchanges.

Caches tokens per (user_token_hash, scope) with a 5-minute refresh buffer
before expiry. Prevents hitting Entra ID rate limits on repeated requests.
"""

import hashlib
import logging
import time
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# Refresh tokens 5 minutes before they expire
_REFRESH_BUFFER_SECONDS = 300


@dataclass
class _CachedToken:
    access_token: str
    expires_at: float  # monotonic timestamp


class TokenCache:
    """In-memory token cache keyed by (token_hash, scope)."""

    MAX_ENTRIES = 10_000

    def __init__(self):
        self._cache: dict[str, _CachedToken] = {}

    def _key(self, user_token: str, scope: str) -> str:
        token_hash = hashlib.sha256(user_token.encode()).hexdigest()[:16]
        return f"{token_hash}:{scope}"

    def _evict_expired(self) -> None:
        """Remove expired entries."""
        now = time.monotonic()
        expired = [k for k, v in self._cache.items() if now >= v.expires_at]
        for k in expired:
            del self._cache[k]

    def get(self, user_token: str, scope: str) -> Optional[str]:
        """Get a cached token if still valid."""
        key = self._key(user_token, scope)
        cached = self._cache.get(key)
        if cached is None:
            return None
        if time.monotonic() >= cached.expires_at - _REFRESH_BUFFER_SECONDS:
            del self._cache[key]
            return None
        return cached.access_token

    def put(self, user_token: str, scope: str, access_token: str, expires_in: int) -> None:
        """Cache a token with its TTL. Evicts expired entries if cache is full."""
        if len(self._cache) >= self.MAX_ENTRIES:
            self._evict_expired()
        if len(self._cache) >= self.MAX_ENTRIES:
            # Still full after eviction — drop oldest half
            sorted_keys = sorted(self._cache, key=lambda k: self._cache[k].expires_at)
            for k in sorted_keys[: len(sorted_keys) // 2]:
                del self._cache[k]

        key = self._key(user_token, scope)
        self._cache[key] = _CachedToken(
            access_token=access_token,
            expires_at=time.monotonic() + expires_in,
        )
        logger.debug("Cached token for scope %s (expires in %ds)", scope, expires_in)

    def clear(self) -> None:
        """Clear all cached tokens."""
        self._cache.clear()


# Global singleton
token_cache = TokenCache()
