"""Agent registry — loads YAML config and creates agent slots on startup."""

import logging
import os
from pathlib import Path
from typing import Optional

import yaml

from host.agent_slot import AgentSlot, AgentSlotConfig

logger = logging.getLogger(__name__)


def _resolve_env(value: str) -> str:
    """Resolve ${ENV_VAR} or ${ENV_VAR:default} in config values."""
    if not isinstance(value, str) or not value.startswith("${"):
        return value
    inner = value[2:-1]  # strip ${ and }
    if ":" in inner:
        var, default = inner.split(":", 1)
        return os.getenv(var, default)
    return os.getenv(inner, "")


def load_agents(config_path: Optional[str] = None) -> dict[str, AgentSlot]:
    """Load agent slot definitions from YAML config.

    Args:
        config_path: Path to agents.yaml. Defaults to config/agents.yaml.

    Returns:
        Dict of agent_id → AgentSlot instances.
    """
    if config_path is None:
        config_path = str(Path(__file__).parent.parent / "config" / "agents.yaml")

    with open(config_path) as f:
        raw = yaml.safe_load(f)

    agents: dict[str, AgentSlot] = {}

    for agent_id, cfg in raw.get("agents", {}).items():
        try:
            card = cfg.get("agent_card", {})

            config = AgentSlotConfig(
                agent_id=agent_id,
                mcp_url=_resolve_env(cfg.get("mcp_url", "")),
                mcp_oauth_scope=_resolve_env(cfg.get("mcp_oauth_scope", "")),
                agent_card_name=card.get("name", f"MCP Agent ({agent_id})"),
                agent_card_description=card.get("description", ""),
                agent_card_version=card.get("version", "1.0.0"),
                system_prompt_extra=cfg.get("system_prompt_extra", ""),
                tool_preselection=cfg.get("tool_preselection", False),
                tool_preselection_threshold=cfg.get("tool_preselection_threshold", 40),
                tool_result_max_chars=cfg.get("tool_result_max_chars", 8000),
                max_turns=cfg.get("max_turns", 5),
                timeout_per_tool=cfg.get("timeout_per_tool", 30.0),
                timeout_per_request=cfg.get("timeout_per_request", 120.0),
            )

            if not config.mcp_url:
                logger.warning("Agent %s has no mcp_url configured, skipping", agent_id)
                continue

            agents[agent_id] = AgentSlot(config)
            logger.info(
                "Registered agent slot: %s → %s (%s)",
                agent_id,
                config.agent_card_name,
                config.mcp_url,
            )

        except Exception as e:
            logger.error("Failed to load agent slot %s: %s", agent_id, e)

    logger.info("Loaded %d agent slot(s)", len(agents))
    return agents
