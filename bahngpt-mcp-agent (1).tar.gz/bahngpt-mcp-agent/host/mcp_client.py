"""MCP client lifecycle manager.

Handles connection to a single MCP server via Streamable HTTP transport,
tool discovery, and tool execution.
"""

import asyncio
import logging
from contextlib import AsyncExitStack
from typing import Any, Optional

import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

from host.ssl_utils import create_ssl_context
from host.tool_converter import mcp_tools_to_openai

logger = logging.getLogger(__name__)


class MCPClient:
    """Manages lifecycle of a single MCP server connection."""

    def __init__(self, mcp_url: str, timeout: float = 30.0):
        self.mcp_url = mcp_url
        self.timeout = timeout
        self._exit_stack: Optional[AsyncExitStack] = None
        self._http_client: Optional[httpx.AsyncClient] = None
        self._session: Optional[ClientSession] = None
        self._mcp_tools: list = []
        self._openai_tools: list[dict[str, Any]] = []
        self._server_info: Optional[dict] = None
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def openai_tools(self) -> list[dict[str, Any]]:
        return self._openai_tools

    @property
    def server_name(self) -> str:
        if self._server_info:
            return getattr(self._server_info, "name", "MCP Server")
        return "MCP Server"

    @property
    def server_version(self) -> str:
        if self._server_info:
            return getattr(self._server_info, "version", "unknown")
        return "unknown"

    async def connect(self, headers: Optional[dict[str, str]] = None) -> None:
        """Connect to the MCP server and discover tools.

        Args:
            headers: HTTP headers (Content-Type, Authorization, etc.).
        """
        self._exit_stack = AsyncExitStack()

        try:
            # Build httpx client with DB CA certs + auth headers
            ssl_ctx = create_ssl_context()
            self._http_client = httpx.AsyncClient(
                verify=ssl_ctx,
                timeout=httpx.Timeout(self.timeout, read=300.0),
                headers=headers or {},
            )

            # streamable_http_client takes a pre-configured httpx client
            transport = await self._exit_stack.enter_async_context(
                streamable_http_client(
                    url=self.mcp_url,
                    http_client=self._http_client,
                )
            )
            # Returns (read_stream, write_stream, get_session_id)
            read_stream, write_stream, _ = transport

            self._session = await self._exit_stack.enter_async_context(
                ClientSession(read_stream, write_stream)
            )

            init_result = await self._session.initialize()
            self._server_info = init_result.serverInfo
            logger.info(
                "Connected to MCP server: %s v%s",
                self.server_name,
                self.server_version,
            )

            await self._discover_tools()
            self._connected = True

        except Exception:
            await self.disconnect()
            raise

    async def _discover_tools(self) -> None:
        """Fetch tools from MCP server and convert to OpenAI format."""
        if not self._session:
            raise RuntimeError("Not connected to MCP server")

        result = await self._session.list_tools()
        self._mcp_tools = result.tools
        self._openai_tools = mcp_tools_to_openai(self._mcp_tools)
        logger.info(
            "Discovered %d tools from %s", len(self._mcp_tools), self.server_name
        )

    async def refresh_tools(self) -> None:
        """Re-discover tools (called on tools/list_changed notification)."""
        await self._discover_tools()

    async def call_tool(
        self, name: str, arguments: dict[str, Any], timeout: float = 30.0
    ) -> str:
        """Execute a tool call on the MCP server.

        Args:
            name: Tool name.
            arguments: Tool arguments dict.
            timeout: Per-call timeout in seconds.

        Returns:
            Tool result as a string (serialized content array).
        """
        if not self._session:
            raise RuntimeError("Not connected to MCP server")

        try:
            result = await asyncio.wait_for(
                self._session.call_tool(name, arguments),
                timeout=timeout,
            )

            # Serialize MCP content array to string for LLM consumption
            parts = []
            for content in result.content:
                if hasattr(content, "text"):
                    parts.append(content.text)
                elif hasattr(content, "data"):
                    parts.append(f"[binary data: {content.mimeType}]")
                else:
                    parts.append(str(content))

            result_text = "\n".join(parts)

            if result.isError:
                return f"Tool error: {result_text}"

            return result_text

        except asyncio.TimeoutError:
            return f"Tool timeout: {name} did not respond within {timeout}s"
        except Exception as e:
            return f"Tool execution failed: {name}: {e}"

    async def disconnect(self) -> None:
        """Close the MCP connection and clean up resources."""
        if self._exit_stack:
            try:
                await self._exit_stack.aclose()
            except Exception as e:
                logger.warning("Error during MCP disconnect: %s", e)
        if self._http_client:
            try:
                await self._http_client.aclose()
            except Exception:
                pass
        self._session = None
        self._exit_stack = None
        self._http_client = None
        self._mcp_tools = []
        self._openai_tools = []
        self._connected = False
        logger.info("Disconnected from MCP server")

    async def health_check(self) -> bool:
        """Check if the MCP connection is alive."""
        if not self._connected or not self._session:
            return False
        try:
            await asyncio.wait_for(self._session.list_tools(), timeout=5.0)
            return True
        except Exception:
            return False
