"""BahnGPT MCP Agent — FastAPI server.

Hosts N independent MCP Agent slots, each wrapping one MCP server.
Each slot gets its own A2A endpoints mounted at /{agent_id}/.
"""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from host.agent_registry import load_agents
from host.a2a_routes import create_agent_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

# Global reference to loaded agents for health checks
_agents: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: load agent slots. Shutdown: cleanup."""
    global _agents

    logger.info("Starting BahnGPT MCP Agent host")

    # Load agent slots from config
    _agents = load_agents()

    if not _agents:
        logger.warning("No agent slots configured — running in empty mode")

    # Mount per-agent routers
    for agent_id, agent in _agents.items():
        router = create_agent_router(agent_id, agent)
        app.include_router(router, prefix=f"/{agent_id}")
        logger.info("Mounted agent: /%s", agent_id)

    yield

    # Cleanup
    logger.info("Shutting down MCP Agent host")
    _agents = {}


app = FastAPI(
    title="BahnGPT MCP Agent",
    description="Generic A2A agent wrapping MCP servers",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/health")
async def health():
    """Health check — reports status of all agent slots."""
    agent_status = {}
    for agent_id, agent in _agents.items():
        agent_status[agent_id] = {
            "name": agent.config.agent_card_name,
            "mcp_url": agent.config.mcp_url,
        }

    return JSONResponse(
        {
            "status": "healthy",
            "agent_count": len(_agents),
            "agents": agent_status,
        }
    )


@app.get("/agents")
async def list_agents():
    """List all registered agent slots with their agent card info."""
    agents_list = []
    for agent_id, agent in _agents.items():
        agents_list.append(
            {
                "id": agent_id,
                "name": agent.config.agent_card_name,
                "description": agent.config.agent_card_description,
                "mcp_url": agent.config.mcp_url,
            }
        )
    return JSONResponse({"agents": agents_list})


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8080"))
    uvicorn.run(app, host="0.0.0.0", port=port)
