"""SSL and HTTP client utilities.

Cached SSL context with DB internal CA cert support.
"""

import os
import ssl
import logging
from pathlib import Path
from typing import Optional

import httpx

logger = logging.getLogger(__name__)

_ssl_context_cache: Optional[ssl.SSLContext] = None


def create_ssl_context() -> ssl.SSLContext:
    """Return a cached ssl.SSLContext with custom CA certs loaded.

    Resolution order:
      1. SSL_CA_CERT_PATH env var
      2. /app/public/certs/RootCA.pem
      3. public/certs/RootCA.pem
      4. Default context (no custom certs)
    """
    global _ssl_context_cache

    if _ssl_context_cache is not None:
        return _ssl_context_cache

    ctx = ssl.create_default_context()

    cert_path_env = os.getenv("SSL_CA_CERT_PATH")
    cert_paths = (
        [Path(cert_path_env)]
        if cert_path_env
        else [
            Path("/app/public/certs/RootCA.pem"),
            Path("public/certs/RootCA.pem"),
        ]
    )

    for path in cert_paths:
        if path.exists():
            ctx.load_verify_locations(path)
            logger.info("SSL: loaded CA cert from %s", path)
            break
    else:
        logger.info("SSL: no custom CA cert found, using system defaults")

    _ssl_context_cache = ctx
    return ctx


def create_http_client(
    *,
    timeout: float = 120.0,
    **kwargs,
) -> httpx.AsyncClient:
    """Create an httpx.AsyncClient with the shared SSL context."""
    return httpx.AsyncClient(
        verify=create_ssl_context(),
        timeout=httpx.Timeout(timeout),
        **kwargs,
    )
