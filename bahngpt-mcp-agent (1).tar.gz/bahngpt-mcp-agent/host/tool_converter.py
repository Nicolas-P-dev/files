"""Convert MCP tool schemas to OpenAI function calling format.

MCP's inputSchema and OpenAI's parameters are both JSON Schema —
the mapping is nearly 1:1. This module handles the edge cases.
"""

import copy
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Fields that OpenAI strict mode rejects
_STRIP_FIELDS = {"$schema", "title", "additionalProperties"}


def _clean_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Remove meta-fields that OpenAI rejects and ensure required keys exist."""
    cleaned = copy.deepcopy(schema)

    for field in _STRIP_FIELDS:
        cleaned.pop(field, None)

    # OpenAI rejects schemas without 'properties'
    if "properties" not in cleaned:
        cleaned["properties"] = {}

    # Ensure type is set
    if "type" not in cleaned:
        cleaned["type"] = "object"

    # Recursively clean nested object schemas
    for prop_schema in cleaned.get("properties", {}).values():
        if isinstance(prop_schema, dict):
            for field in _STRIP_FIELDS:
                prop_schema.pop(field, None)
            # Recurse into nested objects
            if prop_schema.get("type") == "object" and "properties" in prop_schema:
                prop_schema.update(_clean_schema(prop_schema))

    # Inline $ref/$defs if present (some MCP servers emit Pydantic-style refs)
    if "$defs" in cleaned:
        cleaned = _inline_refs(cleaned)

    return cleaned


def _inline_refs(schema: dict[str, Any]) -> dict[str, Any]:
    """Inline $ref references from $defs. OpenAI doesn't support $ref."""
    defs = schema.pop("$defs", {})
    if not defs:
        return schema

    def _resolve(obj: Any) -> Any:
        if isinstance(obj, dict):
            if "$ref" in obj:
                ref_path = obj["$ref"]  # e.g. "#/$defs/MyModel"
                ref_name = ref_path.split("/")[-1]
                if ref_name in defs:
                    return _resolve(copy.deepcopy(defs[ref_name]))
                return obj
            return {k: _resolve(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_resolve(item) for item in obj]
        return obj

    return _resolve(schema)


def mcp_tools_to_openai(mcp_tools: list) -> list[dict[str, Any]]:
    """Convert a list of MCP tools to OpenAI function calling format.

    Args:
        mcp_tools: List of MCP Tool objects from session.list_tools().

    Returns:
        List of dicts in OpenAI's tools format:
        [{"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}]
    """
    openai_tools = []

    for tool in mcp_tools:
        try:
            schema = tool.inputSchema or {"type": "object", "properties": {}}
            cleaned = _clean_schema(schema)

            openai_tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description or f"Tool: {tool.name}",
                        "parameters": cleaned,
                    },
                }
            )
        except Exception as e:
            logger.warning("Failed to convert tool %s: %s", tool.name, e)

    logger.info("Converted %d MCP tools to OpenAI format", len(openai_tools))
    return openai_tools
