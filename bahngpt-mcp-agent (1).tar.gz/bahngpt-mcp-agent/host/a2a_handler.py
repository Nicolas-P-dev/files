"""A2A message handler — processes inbound JSON-RPC, emits SSE responses.

SSE envelope: each line includes jsonrpc, id, result fields.
Status events use result.status (not result.message) to avoid text accumulation.
Final response uses result.message.parts with "final": true.
"""

import json
import logging
from typing import AsyncIterator

from host.agent_slot import AgentSlot

logger = logging.getLogger(__name__)


def _sse_status_event(request_id: str, status_text: str) -> str:
    """Format a progress status event.

    Uses result.status path instead of result.message to keep
    status text separate from the final response text.
    """
    payload = {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "status": {
                "state": "working",
                "message": {
                    "role": "agent",
                    "parts": [{"kind": "text", "text": status_text}],
                },
            }
        },
    }
    return f"data: {json.dumps(payload)}\n\n"


def _sse_final_event(request_id: str, text: str) -> str:
    """Format the final response event with completion signal."""
    payload = {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "message": {
                "role": "agent",
                "parts": [{"kind": "text", "text": text}],
            }
        },
        "final": True,
    }
    return f"data: {json.dumps(payload)}\n\n"


def _sse_error_event(request_id: str, error: str) -> str:
    """Format an error event with completion signal."""
    payload = {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "message": {
                "role": "agent",
                "parts": [{"kind": "text", "text": f"Error: {error}"}],
            }
        },
        "final": True,
    }
    return f"data: {json.dumps(payload)}\n\n"


def extract_message_from_jsonrpc(body: dict) -> tuple[str, dict, str]:
    """Extract user message, metadata, and request ID from a JSON-RPC 2.0 request.

    The orchestrator sends:
    {
        "jsonrpc": "2.0",
        "method": "message/stream",
        "params": {
            "message": {
                "parts": [{"kind": "text", "text": "..."}],
                "metadata": {"orchestrator_jwt": "..."}
            },
            "metadata": {"orchestrator_jwt": "...", "user_id": "...", ...}
        },
        "id": "<message_id>"
    }

    Returns:
        Tuple of (user_message_text, metadata_dict, request_id).
    """
    request_id = body.get("id", "unknown")
    params = body.get("params", {})
    message = params.get("message", {})

    # Metadata can be in params.metadata or params.message.metadata
    metadata = params.get("metadata", {})
    msg_metadata = message.get("metadata", {})
    # Merge, params.metadata takes priority
    merged_metadata = {**msg_metadata, **metadata}

    # Extract text from parts — parts use "kind" not "type"
    parts = message.get("parts", [])
    text_parts = []
    for part in parts:
        if isinstance(part, dict):
            # Handle both "kind": "text" and "type": "TextPart" for robustness
            text = part.get("text", "")
            kind = part.get("kind", part.get("type", ""))
            if text and kind in ("text", "TextPart"):
                text_parts.append(text)

    user_message = "\n".join(text_parts) if text_parts else ""
    return user_message, merged_metadata, request_id


async def handle_stream(
    agent: AgentSlot,
    body: dict,
) -> AsyncIterator[str]:
    """Handle a streaming A2A request. Yields SSE data lines.

    Args:
        agent: The agent slot to process the request.
        body: The JSON-RPC 2.0 request body.

    Yields:
        SSE-formatted data lines.
    """
    user_message, metadata, request_id = extract_message_from_jsonrpc(body)
    auth_token = metadata.get("orchestrator_jwt", "")

    if not user_message:
        yield _sse_error_event(request_id, "No message text found in request")
        return

    if not auth_token:
        yield _sse_error_event(request_id, "No authentication token provided")
        return

    # Collect status events during tool execution
    status_events: list[str] = []

    async def on_status(msg: str) -> None:
        status_events.append(msg)

    try:
        # Emit initial status
        yield _sse_status_event(request_id, "Processing request...")

        # Run the agent loop
        result = await agent.run(
            user_message=user_message,
            auth_token=auth_token,
            on_status=on_status,
        )

        # Emit tool execution statuses
        for status in status_events:
            yield _sse_status_event(request_id, status)

        # Emit final result
        yield _sse_final_event(request_id, result)

    except Exception as e:
        logger.exception("Error processing A2A request")
        yield _sse_error_event(request_id, str(e))


async def handle_send(
    agent: AgentSlot,
    body: dict,
) -> dict:
    """Handle a non-streaming A2A request. Returns a JSON-RPC response.

    Args:
        agent: The agent slot to process the request.
        body: The JSON-RPC 2.0 request body.

    Returns:
        JSON-RPC 2.0 response dict.
    """
    user_message, metadata, request_id = extract_message_from_jsonrpc(body)
    auth_token = metadata.get("orchestrator_jwt", "")

    if not user_message:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32600, "message": "No message text found"},
        }

    if not auth_token:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32600, "message": "No authentication token"},
        }

    try:
        result = await agent.run(
            user_message=user_message,
            auth_token=auth_token,
        )

        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "message": {
                    "role": "agent",
                    "parts": [{"kind": "text", "text": result}],
                }
            },
        }

    except Exception as e:
        logger.exception("Error processing A2A request")
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32603, "message": str(e)},
        }
