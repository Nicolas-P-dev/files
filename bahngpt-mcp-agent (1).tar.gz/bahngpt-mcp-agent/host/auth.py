"""Authentication — JWT validation and OBO token exchange.

Entra ID JWKS validation with token caching.
"""

import os
import logging
from typing import Optional

import httpx
import jwt
from jwt import PyJWKClient

from host.ssl_utils import create_ssl_context
from host.token_cache import token_cache

logger = logging.getLogger(__name__)

_jwk_client: Optional[PyJWKClient] = None


def _get_jwk_client() -> PyJWKClient:
    """Get or create the JWKS client for token validation."""
    global _jwk_client
    if _jwk_client is None:
        tenant_id = os.environ["AZURE_AD_TENANT_ID"]
        jwks_url = (
            f"https://login.microsoftonline.com/{tenant_id}"
            f"/discovery/v2.0/keys"
        )
        _jwk_client = PyJWKClient(jwks_url)
    return _jwk_client


def validate_token(token: str) -> dict:
    """Validate a JWT token against Entra ID JWKS.

    Args:
        token: Bearer token (with or without 'Bearer ' prefix).

    Returns:
        Decoded token claims.

    Raises:
        jwt.InvalidTokenError: If token is invalid.
    """
    if token.startswith("Bearer "):
        token = token[7:]

    client = _get_jwk_client()
    signing_key = client.get_signing_key_from_jwt(token)

    claims = jwt.decode(
        token,
        signing_key.key,
        algorithms=["RS256"],
        options={"verify_aud": False},
    )
    return claims


def extract_user_email(claims: dict) -> str:
    """Extract user email from token claims."""
    for field in ("email", "upn", "preferred_username", "unique_name"):
        if field in claims:
            return claims[field]
    return claims.get("sub", "unknown")


async def exchange_token_obo(
    token: str,
    scope: str,
) -> Optional[str]:
    """Exchange a JWT for a scoped OBO token, with caching.

    Args:
        token: The inbound JWT from the orchestrator.
        scope: Target scope for the MCP server. Empty string or None means no auth needed.

    Returns:
        The exchanged access token string, or None if no auth is required.

    Raises:
        httpx.HTTPStatusError: If the token exchange fails.
    """
    # No auth needed for this MCP server (e.g. digitaler-fahrplan)
    if not scope:
        return None

    if token.startswith("Bearer "):
        token = token[7:]

    # Check cache first
    cached = token_cache.get(token, scope)
    if cached:
        logger.debug("Using cached OBO token for scope %s", scope)
        return cached

    # Exchange
    tenant_id = os.environ["AZURE_AD_TENANT_ID"]
    client_id = os.environ["MCP_AGENT_APP_REGISTRATION_ID"]
    client_secret = os.environ["AZURE_AD_CLIENT_SECRET"]

    token_url = (
        f"https://login.microsoftonline.com/{tenant_id}"
        f"/oauth2/v2.0/token"
    )

    ssl_ctx = create_ssl_context()

    async with httpx.AsyncClient(verify=ssl_ctx, timeout=10.0) as client:
        response = await client.post(
            token_url,
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                "client_id": client_id,
                "client_secret": client_secret,
                "assertion": token,
                "scope": scope,
                "requested_token_use": "on_behalf_of",
            },
        )
        response.raise_for_status()
        data = response.json()

        access_token = data["access_token"]
        expires_in = data.get("expires_in", 3600)

        # Cache for future requests
        token_cache.put(token, scope, access_token, expires_in)

        return access_token
