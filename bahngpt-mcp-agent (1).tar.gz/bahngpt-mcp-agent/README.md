# BahnGPT MCP Agent

Generic A2A agent that wraps MCP servers as protocol bridges for the BahnGPT orchestrator.

## Architecture

Each MCP Agent instance wraps exactly one MCP server (1:1 relationship). It receives natural language requests from the orchestrator via A2A (JSON-RPC 2.0), uses an LLM to translate them into MCP tool calls, and streams the response back via SSE.

Multiple agent instances run in a single container as a deployment optimization. Each has its own AgentCard, MCP connection, and tool catalog. The orchestrator discovers and routes to each independently.

Implements: ADR "MCP Agent as Protocol Bridge" (Option A), Deployment Topology Phase 1 (Option B — unified).

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your Azure OpenAI and MCP server details

# Run
uvicorn host.server:app --host 0.0.0.0 --port 8080
```

## Endpoints

Per agent slot (e.g. `/jira`):

| Endpoint | Method | Description |
|---|---|---|
| `/{agent_id}/.well-known/agent-card.json` | GET | A2A agent card discovery (protocol v0.3.0) |
| `/{agent_id}/.well-known/agent.json` | GET | Legacy redirect to agent-card.json |
| `/{agent_id}/a2a/jsonrpc` | POST | JSON-RPC 2.0 handler (message/stream, message/send) |

Shared:

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Health check for all agent slots |
| `/agents` | GET | List all registered agent slots |

## Adding a New MCP Agent

1. Add an entry to `config/agents.yaml`
2. Set the MCP server URL via environment variable
3. Restart the container

No code changes required.

## Project Structure

```
bahngpt-mcp-agent/
├── config/
│   ├── agents.yaml         # Agent slot definitions
│   └── dev.yaml            # Environment config overlay
├── host/
│   ├── server.py           # FastAPI app, lifespan, health
│   ├── agent_registry.py   # Loads YAML, creates agent slots
│   ├── agent_slot.py       # Core: LLM loop + MCP tool execution
│   ├── mcp_client.py       # MCP connection lifecycle (raw SDK)
│   ├── tool_converter.py   # MCP schema → OpenAI function format
│   ├── a2a_handler.py      # A2A message processing, SSE formatting
│   ├── a2a_routes.py       # FastAPI routes per agent slot
│   ├── auth.py             # JWT validation + OBO token exchange
│   └── ssl_utils.py        # SSL context for DB internal certs
├── public/certs/           # DB root CA certificate
├── Dockerfile
├── requirements.txt
└── .env.example
```
