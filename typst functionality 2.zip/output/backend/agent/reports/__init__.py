# Report/chart generation tools — grouped under agent.reports
