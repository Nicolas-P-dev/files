"""Dashboard widget rendering tools.

Renders multiple dashboard widgets (KPI cards, mini charts) as individual
PNGs in a single tool call.  Follows the same patterns as report_tools.py:
async function with ``.schema``, ``.max_result_chars``, and ``_context``.
"""

import json
import logging
import shutil
import tempfile
import uuid
from pathlib import Path

import agent.deps as deps
from agent.reports.report_tools import (
    _compile_typst,
    _escape_typst_string,
    _resolve_session_id,
)

logger = logging.getLogger(__name__)

# ── Widget type definitions ──────────────────────────────────────────────

_WIDGET_TYPES: dict[str, dict] = {
    "kpi": {"width": "8cm", "height": "4cm"},
    "bar": {"width": "10cm", "height": "7cm"},
    "line": {"width": "10cm", "height": "7cm"},
    "pie": {"width": "10cm", "height": "8cm"},
    "gauge": {"width": "8cm", "height": "6cm"},
    "burndown": {"width": "10cm", "height": "7cm"},
    "radar": {"width": "10cm", "height": "9cm"},
    "velocity": {"width": "10cm", "height": "7cm"},
}


def _build_widget_typ(widget: dict) -> str:
    """Generate a minimal .typ file for a single dashboard widget."""
    wtype = widget.get("type", "")
    spec = _WIDGET_TYPES.get(wtype)
    if spec is None:
        raise ValueError(
            f"Unknown widget type '{wtype}'. "
            f"Available: {list(_WIDGET_TYPES.keys())}"
        )

    title = widget.get("title", "")
    data = widget.get("data", {})
    wid = widget.get("id", "w")
    data_file = f"widget-{wid}-data.json"

    imports = (
        '#import "lib/brand.typ": *\n'
        '#import "lib/charts.typ": *\n'
        '#import "lib/kpis.typ": *\n'
    )

    page_setup = (
        f'#set page(width: {spec["width"]}, height: {spec["height"]}, margin: 0.5cm)\n'
        '#set text(font: "Open Sans", size: 10pt)\n\n'
    )

    data_load = f'#let d = json("{data_file}")\n\n'

    title_arg = f'  title: "{_escape_typst_string(title)}",\n' if title else ""

    if wtype == "kpi":
        body = (
            "#kpi-card(\n"
            '  d.at("label", default: ""),\n'
            '  d.at("value", default: "0"),\n'
            '  trend: d.at("trend", default: none),\n'
            '  color: d.at("color", default: auto),\n'
            '  sub-label: d.at("sub_label", default: none),\n'
            ")\n"
        )
    elif wtype == "bar":
        body = (
            "#bar-chart(\n"
            f"{title_arg}"
            '  data: d.at("items").map(i => (i.at(0), i.at(1))),\n'
            "  width: 9cm,\n"
            "  height: 5.5cm,\n"
            ")\n"
        )
    elif wtype == "line":
        body = (
            "#line-chart(\n"
            f"{title_arg}"
            '  data: d.at("series"),\n'
            "  width: 9cm,\n"
            "  height: 5.5cm,\n"
            ")\n"
        )
    elif wtype == "pie":
        body = (
            "#pie-chart(\n"
            f"{title_arg}"
            '  data: d.at("items").map(i => (i.at(0), i.at(1))),\n'
            "  width: 9cm,\n"
            "  height: 7cm,\n"
            ")\n"
        )
    elif wtype == "gauge":
        body = (
            "#gauge-chart(\n"
            f"{title_arg}"
            '  value: d.at("value", default: 0),\n'
            '  max: d.at("max", default: 100),\n'
            '  label: d.at("label", default: ""),\n'
            "  width: 7cm,\n"
            ")\n"
        )
    elif wtype == "burndown":
        body = (
            "#burndown-chart(\n"
            f"{title_arg}"
            '  data: d.at("points").map(p => (p.at(0), p.at(1))),\n'
            "  width: 9cm,\n"
            "  height: 5.5cm,\n"
            ")\n"
        )
    elif wtype == "radar":
        body = (
            "#radar-chart(\n"
            f"{title_arg}"
            '  data: d.at("dimensions").map(item => (item.at(0), item.at(1))),\n'
            "  width: 9cm,\n"
            ")\n"
        )
    elif wtype == "velocity":
        body = (
            "#velocity-chart(\n"
            f"{title_arg}"
            '  data: d.at("sprints").map(s => (s.at(0), s.at(1))),\n'
            "  width: 9cm,\n"
            "  height: 5.5cm,\n"
            ")\n"
        )
    else:
        raise ValueError(f"Unhandled widget type '{wtype}'")

    return imports + page_setup + data_load + body


# ── Main tool function ───────────────────────────────────────────────────

async def render_dashboard(
    widgets: str,
    session_id: str = "",
    _context: dict | None = None,
) -> str:
    """Render multiple dashboard widgets as individual PNG images.

    Each widget is a small Typst-rendered image (KPI card or mini chart).
    widgets: JSON string — array of widget definitions.
    Returns a JSON array of file references for inline display.
    """
    sid = _resolve_session_id(session_id, _context)
    if not sid:
        return json.dumps({"error": "No session_id provided"})

    templates_dir = deps.templates_dir
    if templates_dir is None:
        return json.dumps({"error": "templates_dir not initialised"})

    # Parse widget definitions
    try:
        widget_list = json.loads(widgets)
    except json.JSONDecodeError as exc:
        return json.dumps({"error": f"Invalid JSON widgets: {exc}"})

    if not isinstance(widget_list, list) or len(widget_list) == 0:
        return json.dumps({"error": "widgets must be a non-empty JSON array"})

    workdir: Path | None = None
    try:
        # Create ONE shared workdir with lib/, assets/, fonts/ copied once
        workdir = Path(tempfile.mkdtemp(prefix="typst_dash_"))
        for subdir in ("lib", "assets", "fonts"):
            src = templates_dir / subdir
            if src.exists():
                shutil.copytree(src, workdir / subdir, dirs_exist_ok=True)

        font_path = workdir / "fonts"
        results: list[dict] = []

        for widget in widget_list:
            wid = widget.get("id", str(uuid.uuid4())[:8])
            title = widget.get("title", "")

            try:
                # Generate .typ content
                typ_content = _build_widget_typ(widget)

                # Write .typ file at ROOT of workdir
                typ_file = workdir / f"widget-{wid}.typ"
                typ_file.write_text(typ_content, encoding="utf-8")

                # Write data.json alongside
                data_json = json.dumps(widget.get("data", {}), ensure_ascii=False)
                (workdir / f"widget-{wid}-data.json").write_text(
                    data_json, encoding="utf-8"
                )

                # Compile to PNG
                file_id = str(uuid.uuid4())
                output_path = workdir / f"{file_id}.png"

                _compile_typst(
                    typ_file,
                    output_path,
                    font_path if font_path.exists() else None,
                    root_path=workdir,
                )

                # Save via ExportStore
                png_bytes = output_path.read_bytes()
                await deps.export_store.save(sid, file_id, png_bytes, "png")

                results.append({
                    "widget_id": wid,
                    "file_id": file_id,
                    "file_type": "image",
                    "url": f"/api/sessions/{sid}/exports/{file_id}",
                    "title": title,
                })

            except (ValueError, RuntimeError) as exc:
                logger.error("Widget '%s' failed: %s", wid, exc)
                stderr = str(exc)
                if len(stderr) > 2000:
                    stderr = "..." + stderr[-2000:]
                results.append({
                    "widget_id": wid,
                    "title": title,
                    "error": stderr,
                })

        return json.dumps(results)

    except Exception as exc:
        logger.error("render_dashboard failed: %s", exc)
        return json.dumps({"error": str(exc)})
    finally:
        if workdir and workdir.exists():
            shutil.rmtree(workdir, ignore_errors=True)


render_dashboard.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "widgets": {
            "type": "string",
            "description": (
                "JSON string — array of widget definitions. "
                "Each widget: {id, type, title, data}. "
                "Types: kpi, bar, line, pie, gauge, burndown, radar, velocity."
            ),
        },
        "session_id": {
            "type": "string",
            "description": "Session ID for storage. Usually from context.",
        },
    },
    "required": ["widgets"],
}
render_dashboard.max_result_chars = 20000  # type: ignore[attr-defined]
