"""Internal tool functions exposed to the agent.

These are application-level tools: they know about documents, sessions, and
the structure store.  They are registered with AgentLoop via INTERNAL_TOOLS.
"""

import asyncio
import json
import logging
import re as _re
from contextvars import ContextVar
from typing import Callable

from agent.models import Estimate, HierarchyNode, ProjectBreakdown, SourceRef
from agent.reports.report_tools import render_report, render_chart, list_report_templates, get_report_source
from agent.reports.composer_tools import compose_report
from agent.reports.dashboard_tools import render_dashboard

logger = logging.getLogger(__name__)


def _coerce_update_fields(fields: dict) -> dict:
    """Validate known nested model fields so setattr receives proper instances.

    Without this, raw dicts from LLM JSON land on the node and Pydantic emits
    PydanticSerializationUnexpectedValue warnings on every model_dump call.
    Also normalises bare int/float estimates (e.g. {"estimate": 5}) to Estimate
    instances so Pydantic never sees a bare number where it expects a model.
    """
    if "estimate" in fields:
        est = fields["estimate"]
        if isinstance(est, (int, float)):
            fields["estimate"] = Estimate(value=est, unit="sp")
        elif isinstance(est, dict):
            try:
                fields["estimate"] = Estimate.model_validate(est)
            except Exception as exc:
                logger.warning("Invalid estimate data, skipping coercion: %s", exc)

    if "source_refs" in fields and isinstance(fields["source_refs"], list):
        try:
            fields["source_refs"] = [
                SourceRef.model_validate(r) if isinstance(r, dict) else r
                for r in fields["source_refs"]
            ]
        except Exception as exc:
            logger.warning("Invalid source_refs data, skipping coercion: %s", exc)

    if "children" in fields and isinstance(fields["children"], list):
        try:
            fields["children"] = [
                HierarchyNode.model_validate(c) if isinstance(c, dict) else c
                for c in fields["children"]
            ]
        except Exception as exc:
            logger.warning("Invalid children data, skipping coercion: %s", exc)

    if "due_date" in fields:
        if fields["due_date"] == "":
            fields["due_date"] = None

    if "jira_key" in fields and fields["jira_key"] is not None:
        fields["jira_key"] = str(fields["jira_key"])

    return fields


_TRAILING_COMMA_RE = _re.compile(r",\s*([}\]])")


def _strip_trailing_commas(s: str) -> str:
    """Remove trailing commas before closing braces/brackets, outside string literals.

    Handles the common LLM pattern of generating {"key": "val",} or ["item",].
    Only operates outside string literals to avoid corrupting string content.
    """
    result = []
    in_string = False
    escape_next = False

    i = 0
    while i < len(s):
        ch = s[i]
        if escape_next:
            escape_next = False
            result.append(ch)
            i += 1
            continue
        if ch == "\\" and in_string:
            escape_next = True
            result.append(ch)
            i += 1
            continue
        if ch == '"':
            in_string = not in_string
            result.append(ch)
            i += 1
            continue
        if in_string:
            result.append(ch)
            i += 1
            continue
        # Outside a string: check for comma followed by optional whitespace then } or ]
        if ch == ",":
            j = i + 1
            while j < len(s) and s[j] in " \t\r\n":
                j += 1
            if j < len(s) and s[j] in "}]":
                # Skip this trailing comma
                i += 1
                continue
        result.append(ch)
        i += 1

    return "".join(result)


def _repair_json(s: str) -> str:
    """Repair malformed LLM-generated JSON.

    Applies two passes:
    1. Strip trailing commas before closing braces/brackets (most common LLM error).
    2. Close any unclosed strings and unmatched brackets/braces (truncation).

    Does not attempt to recover semantically incomplete values — it only fixes
    the structural envelope so json.loads can succeed.
    """
    # Pass 1 — trailing comma removal
    s = _strip_trailing_commas(s)

    # Pass 2 — close unclosed structures (truncation)
    in_string = False
    escape_next = False
    stack: list[str] = []

    for ch in s:
        if escape_next:
            escape_next = False
            continue
        if ch == "\\" and in_string:
            escape_next = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            stack.append("}")
        elif ch == "[":
            stack.append("]")
        elif ch in "}]":
            if stack and stack[-1] == ch:
                stack.pop()

    suffix = ""
    if in_string:
        suffix += '"'
    suffix += "".join(reversed(stack))
    return s + suffix


def _parse_json_arg(value: object, expected_type: type) -> object:
    """Decode a tool argument that may arrive as a pre-parsed object or a JSON string.

    The LLM schema declares some arguments as "string" (so the LLM should send
    encoded JSON), but the LLM occasionally passes a native object.  agent_loop
    JSON-decodes all arguments in one pass, so a string argument stays a string
    while a native object stays a dict/list.  This helper handles both cases.

    If the string contains JSON syntax errors (trailing commas, truncation),
    _repair_json corrects them before re-attempting the parse.
    """
    if isinstance(value, expected_type):
        return value
    if not isinstance(value, str):
        raise TypeError(f"Expected {expected_type.__name__} or JSON string, got {type(value).__name__}")

    try:
        return json.loads(value, strict=False)
    except json.JSONDecodeError as original_exc:
        logger.debug(
            "JSON parse failed at char %d — attempting repair. "
            "Value head: %.200s … tail: %.200s",
            original_exc.pos, value[:200], value[-200:],
        )
        repaired = _repair_json(value)
        try:
            result = json.loads(repaired, strict=False)
            logger.warning(
                "Repaired malformed JSON (original %d chars, parse failed at char %d, "
                "repaired to %d chars)",
                len(value), original_exc.pos, len(repaired),
            )
            return result
        except json.JSONDecodeError:
            raise original_exc


def _sanitize_node(node: dict) -> dict:
    """Normalise a single HierarchyNode dict before Pydantic validation."""
    if not isinstance(node, dict):
        return node

    # String fields
    for field in ("title", "description"):
        if node.get(field) is None:
            node[field] = ""

    # Status
    if node.get("status") is None:
        node["status"] = "pending"

    # estimate: bare int/float → Estimate dict
    est = node.get("estimate")
    if isinstance(est, (int, float)):
        node["estimate"] = {"value": est, "unit": "sp"}

    # List fields that must not be None
    for field in ("source_refs", "children", "acceptance_criteria", "tags", "dependencies"):
        if node.get(field) is None:
            node[field] = []

    # due_date: empty string → None
    if node.get("due_date") == "":
        node["due_date"] = None

    # Recurse into children
    node["children"] = [_sanitize_node(c) for c in node["children"] if isinstance(c, dict)]

    return node


def _sanitize_structure(data: dict) -> dict:
    """Normalise a raw ProjectBreakdown dict before Pydantic validation.

    Handles every known mismatch between LLM output and the model schema so
    that the first save attempt succeeds and the full rich structure is kept.
    """
    if not isinstance(data, dict):
        return data

    # Top-level string fields
    for field in ("title", "description"):
        if data.get(field) is None:
            data[field] = ""

    # metadata: list or None → {}
    meta = data.get("metadata")
    if meta is None or isinstance(meta, list):
        data["metadata"] = {}

    # Top-level list fields
    for field in ("source_documents", "epics", "conflicts"):
        val = data.get(field)
        if val is None:
            data[field] = []
        elif not isinstance(val, list):
            data[field] = []

    # Sanitize every node in the epics tree recursively
    data["epics"] = [_sanitize_node(e) for e in data["epics"] if isinstance(e, dict)]

    return data


# In-memory project structure store: session_id → ProjectBreakdown
_structure_store: dict[str, ProjectBreakdown] = {}


async def extract_document_text(session_id: str, document_id: str) -> str:
    """Read extracted text from a single uploaded document."""
    import agent.deps as deps

    uploads_dir = deps.uploads_dir
    if uploads_dir is None:
        return f"[uploads_dir not initialised — cannot read document {document_id}]"
    extracted_path = uploads_dir / session_id / document_id / "extracted.txt"
    if not extracted_path.exists():
        return f"[No extracted text found for document {document_id} in session {session_id}]"
    return extracted_path.read_text(encoding="utf-8")

extract_document_text.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string"},
        "document_id": {"type": "string"},
    },
    "required": ["session_id", "document_id"],
}
extract_document_text.max_result_chars = 30000  # type: ignore[attr-defined]


async def extract_all_documents(session_id: str, _context: dict | None = None) -> str:
    """Extract text from ALL uploaded documents in a session in a single call.

    Returns a JSON object mapping document_id to its full extracted text.
    Also includes a 'meta' key with each document's name from meta.json if available.
    Use this instead of calling extract_document_text multiple times — it costs
    one round regardless of how many documents were uploaded.
    """
    import agent.deps as deps

    uploads_dir = deps.uploads_dir
    if uploads_dir is None:
        return json.dumps({"error": "uploads_dir not initialised"})

    session_dir = uploads_dir / session_id
    if not session_dir.exists():
        return json.dumps({"error": f"No uploads found for session {session_id}"})

    texts: dict[str, str] = {}
    meta: dict[str, dict] = {}

    for doc_dir in sorted(session_dir.iterdir()):
        if not doc_dir.is_dir():
            continue
        doc_id = doc_dir.name
        extracted_path = doc_dir / "extracted.txt"
        if extracted_path.exists():
            texts[doc_id] = extracted_path.read_text(encoding="utf-8")
        meta_path = doc_dir / "meta.json"
        if meta_path.exists():
            try:
                meta[doc_id] = json.loads(meta_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                pass

    if not texts:
        return json.dumps({"error": f"No extracted documents found for session {session_id}"})

    return json.dumps({"documents": texts, "meta": meta})

extract_all_documents.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string"},
    },
    "required": ["session_id"],
}
extract_all_documents.max_result_chars = 100000  # type: ignore[attr-defined]


async def save_project_structure(session_id: str, structure: str) -> str:
    """Save the generated project breakdown for the review console."""
    logger.info(
        "save_project_structure CALLED with args: session_id=%r, structure=%r (len=%d), kwargs={}",
        session_id,
        (structure[:100] if structure else "EMPTY"),
        (len(structure) if structure else 0),
    )
    try:
        input_size = len(structure) if isinstance(structure, str) else len(json.dumps(structure))
        logger.info("save_project_structure: input size %d chars", input_size)
        data = _parse_json_arg(structure, dict)
        data = _sanitize_structure(data)
        breakdown = ProjectBreakdown.model_validate(data)
        counts = breakdown.node_counts()
        logger.info(
            "save_project_structure: saved %d epics, %d stories, %d tasks",
            counts.get("epic", 0), counts.get("story", 0), counts.get("task", 0),
        )
        _structure_store[session_id] = breakdown
        return json.dumps({"status": "saved", "session_id": session_id, "id": breakdown.id})
    except Exception as exc:
        logger.error("save_project_structure failed for session %s: %s", session_id, exc)
        raise

save_project_structure.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string"},
        "structure": {"type": "string", "description": "JSON string of ProjectBreakdown"},
    },
    "required": ["session_id", "structure"],
}


async def load_project_structure(session_id: str) -> str:
    """Load the full project breakdown JSON into context for editing or processing.

    Returns the complete structure (potentially large). Use this when you need
    to read and modify the full hierarchy. For a quick status check (e.g. whether
    approved items exist), use get_project_status instead.
    """
    breakdown = _structure_store.get(session_id)
    if breakdown is None:
        return json.dumps({"error": f"No structure found for session {session_id}"})
    return breakdown.model_dump_json(exclude_none=True)

load_project_structure.max_result_chars = 80000  # type: ignore[attr-defined]
load_project_structure.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string"},
    },
    "required": ["session_id"],
}


async def get_project_status(session_id: str) -> str:
    """Return a lightweight status summary for a session (counts, approval state).

    Fast — returns only counts and status flags, not the full structure.
    Use this to check whether approved items exist before deploying, or to
    confirm a save completed, without loading the entire hierarchy into context.
    """
    breakdown = _structure_store.get(session_id)
    if breakdown is None:
        return json.dumps({"error": f"No structure found for session {session_id}"})

    status_counts: dict[str, dict[str, int]] = {}
    for epic in breakdown.epics:
        for node in [epic, *epic.children, *(t for s in epic.children for t in s.children)]:
            level = node.type
            status_counts.setdefault(level, {})
            status_counts[level][node.status] = status_counts[level].get(node.status, 0) + 1

    approved_counts = {k: v.get("approved", 0) for k, v in status_counts.items()}
    deployed_counts = {k: v.get("deployed", 0) for k, v in status_counts.items()}

    return json.dumps({
        "session_id": session_id,
        "title": breakdown.title,
        "status_counts": status_counts,
        "approved": approved_counts,
        "deployed": deployed_counts,
        "has_approved": any(n > 0 for n in approved_counts.values()),
        "has_deployed": any(n > 0 for n in deployed_counts.values()),
    })

get_project_status.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string"},
    },
    "required": ["session_id"],
}


# Per-request panel event list (legacy drain-based delivery).
_panel_events_var: ContextVar[list[dict] | None] = ContextVar("panel_events", default=None)

# Per-request asyncio Queue for truly async panel event delivery.
# When set, open_panel puts events here instead of the list so they can be
# consumed by the SSE generator concurrently with long-running tools.
_panel_queue_var: ContextVar[asyncio.Queue | None] = ContextVar("panel_queue", default=None)


async def open_panel(panel_type: str, data: str = "{}", _context: dict | None = None) -> str:
    """Open a panel in the user's interface. Any skill can call this.

    Available types: doc-review, kanban, table, chart, team, projects, effort.
    data is a JSON string of props for the panel component.
    """
    if isinstance(data, dict):
        parsed = data
    elif isinstance(data, str) and data:
        try:
            parsed = json.loads(data)
        except json.JSONDecodeError:
            parsed = {}
    else:
        parsed = {}

    # Always use the context's doc_session_id as the authoritative session.
    # The LLM may confuse document UUIDs from document_ids with the session ID.
    # Context is set by the frontend and is always the correct chat session.
    if _context and _context.get("doc_session_id"):
        parsed["session_id"] = _context["doc_session_id"]
    elif "session_id" not in parsed:
        logger.warning("open_panel called with no session_id in context or data")

    pe = {"panel_type": panel_type, "data": parsed}

    # Prefer queue-based delivery: panel events reach the frontend immediately,
    # even while a long-running tool (like deploy_to_jira) is still executing.
    queue = _panel_queue_var.get(None)
    if queue is not None:
        await queue.put(pe)
    else:
        # Fallback: accumulate in the list and drain after each agent event.
        events = _panel_events_var.get()
        if events is None:
            events = []
            _panel_events_var.set(events)
        events.append(pe)

    return f"Panel '{panel_type}' opened."

open_panel.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "panel_type": {
            "type": "string",
            "description": "Panel type identifier (e.g. doc-review, kanban, chart)",
        },
        "data": {
            "type": "string",
            "description": "JSON string of panel-specific props (e.g. {\"session_id\": \"...\"})",
        },
    },
    "required": ["panel_type"],
}


def drain_panel_events() -> list[dict]:
    """Return and clear all pending panel events accumulated during a run."""
    events = _panel_events_var.get()
    if events is None:
        return []
    result = events.copy()
    events.clear()
    return result


async def mark_items_deploying(session_id: str, _context: dict | None = None) -> str:
    """Mark all approved items as 'deploying' and refresh the panel immediately.

    Call this BEFORE deploy_to_jira so the user sees the deploying state
    while the Jira API calls are running. Because this runs in a separate
    tool-call round, the panel update reaches the frontend before the long
    deploy_to_jira call begins.
    """
    breakdown = _structure_store.get(session_id)
    if breakdown is None:
        return json.dumps({"error": f"No structure found for session {session_id}"})

    count = 0

    def _mark(node) -> None:
        nonlocal count
        if node.status == "approved":
            node.status = "deploying"
            count += 1
        for child in node.children:
            _mark(child)

    for epic in breakdown.epics:
        _mark(epic)
    _structure_store[session_id] = breakdown

    await open_panel(
        panel_type="doc-review",
        data=json.dumps({
            "session_id": (_context or {}).get("doc_session_id", session_id),
            "structure": json.loads(breakdown.model_dump_json(exclude_none=True)),
        }),
        _context=_context,
    )
    return json.dumps({"status": "deploying", "marked": count})

mark_items_deploying.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string", "description": "The doc session ID"},
    },
    "required": ["session_id"],
}


async def deploy_to_jira(
    session_id: str,
    project_key: str,
    platform: str = "jira",
    _context: dict | None = None,
) -> str:
    """Deploy all approved items in a session's project structure to Jira.

    Discovers issue types and the story-points field automatically at runtime.
    Config hints (jira_epic_type, jira_story_type, jira_task_type,
    jira_story_points_field) are used as first-try defaults; the tool falls
    back to auto-discovery if they are empty or fail.
    """
    from agent.deployers.jira import deploy_to_jira as _deploy
    return await _deploy(session_id=session_id, project_key=project_key, platform=platform, _context=_context)

deploy_to_jira.schema = {  # type: ignore[attr-defined]
    "type": "object",
    "properties": {
        "session_id": {"type": "string", "description": "The doc session ID"},
        "project_key": {"type": "string", "description": "Jira project key, e.g. 'AT8'"},
        "platform": {"type": "string", "description": "Deployment platform (default: 'jira')", "default": "jira"},
    },
    "required": ["session_id", "project_key"],
}
deploy_to_jira.max_result_chars = 10000  # type: ignore[attr-defined]



async def list_available_tools(server_id: str = "", _context: dict | None = None) -> str:
    """List all available MCP tools with their names and descriptions.

    Call this first to see what tools are available, then use call_mcp_tool
    to execute the one you need. Optionally filter by server_id.
    """
    import agent.deps as deps

    sids = [server_id] if server_id else None
    user_token = (_context or {}).get("user_token", "")
    extra_headers = (_context or {}).get("mcp_extra_headers", {})

    await deps.registry.discover_tools(sids, user_token=user_token,
                                       user_extra_headers=extra_headers)
    tools = deps.registry.get_openai_tools(sids)

    catalog = []
    for t in tools:
        fn = t.get("function", {})
        name = fn.get("name", "")
        desc = fn.get("description", "")
        params = fn.get("parameters", {}).get("properties", {})
        param_names = list(params.keys()) if params else []
        catalog.append({
            "name": name,
            "description": desc[:200],
            "parameters": param_names,
        })

    return json.dumps({"tool_count": len(catalog), "tools": catalog})

list_available_tools.schema = {
    "type": "object",
    "properties": {
        "server_id": {
            "type": "string",
            "description": "Optional MCP server ID to filter tools (e.g. 'mcp-atlassian'). Empty = all servers.",
        },
    },
    "required": [],
}
list_available_tools.max_result_chars = 50000


async def call_mcp_tool(tool_name: str, arguments: str = "{}", _context: dict | None = None) -> str:
    """Call any MCP tool by name with a JSON string of arguments.

    Use list_available_tools first to discover available tools and their
    parameter names. Then call this with the exact tool name and arguments.
    If the call fails with a schema error, the error message will tell you
    the correct parameters -- adjust and retry.
    """
    import agent.deps as deps

    args = _parse_json_arg(arguments, dict)

    user_token = (_context or {}).get("user_token", "")
    extra_headers = (_context or {}).get("mcp_extra_headers", {})

    try:
        result = await deps.registry.call_tool(
            tool_name, args,
            user_token=user_token,
            user_extra_headers=extra_headers,
        )
    except Exception as e:
        return json.dumps({"_display_name": tool_name, "_result": f"Tool error: {e}"})

    # Extract text using same logic as agent_loop
    if "result" in result:
        content = result["result"]
        if isinstance(content, dict) and "content" in content:
            parts = content["content"]
            if isinstance(parts, list):
                text = "\n".join(p.get("text", str(p)) for p in parts if isinstance(p, dict))
            else:
                text = str(parts)
        else:
            text = str(content)
    elif "error" in result:
        err = result["error"]
        text = f"Error: {err.get('message', str(err)) if isinstance(err, dict) else err}"
    else:
        text = str(result)

    return json.dumps({"_display_name": tool_name, "_result": text})

call_mcp_tool.schema = {
    "type": "object",
    "properties": {
        "tool_name": {
            "type": "string",
            "description": "Exact MCP tool name (e.g. 'jira_get_all_projects', 'jira_search')",
        },
        "arguments": {
            "type": "string",
            "description": "JSON string of tool arguments (e.g. '{\"jql\": \"assignee = currentUser()\"}')",
        },
    },
    "required": ["tool_name"],
}
call_mcp_tool.max_result_chars = 32000

INTERNAL_TOOLS: dict[str, Callable] = {
    "extract_document_text": extract_document_text,
    "extract_all_documents": extract_all_documents,
    "save_project_structure": save_project_structure,
    "load_project_structure": load_project_structure,
    "get_project_status": get_project_status,
    "open_panel": open_panel,
    "mark_items_deploying": mark_items_deploying,
    "deploy_to_jira": deploy_to_jira,
    "list_available_tools": list_available_tools,
    "call_mcp_tool": call_mcp_tool,
    "render_report": render_report,
    "render_chart": render_chart,
    "list_report_templates": list_report_templates,
    "get_report_source": get_report_source,
    "compose_report": compose_report,
    "render_dashboard": render_dashboard,
}
