"""Shared application singletons.

main.py's lifespan calls ``bootstrap()`` once at startup to create all
instances and assign them here.  Routers and tools import from this module
rather than from main.py to avoid circular dependencies.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from agent.agent_loop import AgentLoop
    from agent.mcp.registry import MCPRegistry
    from agent.orchestrator import Orchestrator
    from agent.session_store import SessionStore

from agent.reports.export_store import ExportStore

logger = logging.getLogger(__name__)

agent_loop: AgentLoop | None = None
orchestrator: Orchestrator | None = None
registry: MCPRegistry | None = None
store: SessionStore | None = None
skills_dir: Path | None = None
users_dir: Path | None = None
uploads_dir: Path | None = None
templates_dir: Path | None = None
exports_dir: Path | None = None
export_store: ExportStore | None = None

_data_dir: Path | None = None
_users_file: Path | None = None
_integrations_file: Path | None = None


def bootstrap(backend_dir: Path) -> int:
    """Create all singletons, populate this module, return skill count."""
    from agent.agent_loop import AgentLoop
    from agent.config import settings
    from agent.health import init_health
    from agent.internal_tools import INTERNAL_TOOLS
    from agent.mcp.registry import MCPRegistry
    from agent.orchestrator import Orchestrator
    from agent.session_store import SessionStore
    from agent.skill_loader import load_skills
    from agent.telemetry import init_telemetry

    init_telemetry(service_name=settings.app_name, service_version=settings.app_version)
    logging.basicConfig(
        level=settings.log_level.upper(),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    )
    for _noisy in ("httpx", "httpcore", "opentelemetry", "urllib3"):
        logging.getLogger(_noisy).setLevel(logging.WARNING)

    global agent_loop, orchestrator, registry, store
    global skills_dir, users_dir, uploads_dir
    global templates_dir, exports_dir, export_store
    global _data_dir, _users_file, _integrations_file

    skills_dir = backend_dir / "skills" / "default"
    users_dir  = backend_dir / "skills" / "users"
    sessions_dir = (
        Path(settings.sessions_dir) if settings.sessions_dir
        else backend_dir / "sessions"
    )
    uploads_dir = (
        Path(settings.uploads_dir) if settings.uploads_dir
        else backend_dir / "uploads"
    )
    uploads_dir.mkdir(parents=True, exist_ok=True)

    templates_dir = backend_dir / "templates"
    exports_dir = backend_dir / "exports"
    exports_dir.mkdir(parents=True, exist_ok=True)
    export_store = ExportStore(exports_dir)

    _data_dir = backend_dir / "data"
    _users_file = _data_dir / "users.json"
    _integrations_file = _data_dir / "user_integrations.json"

    registry = MCPRegistry(str(backend_dir / "config" / "mcp_servers.yaml"))
    init_health(registry, name=settings.app_name, version=settings.app_version)

    agent_loop = AgentLoop(
        registry=registry,
        llm_base_url=settings.llm_base_url,
        llm_api_key=settings.llm_api_key,
        llm_deployment=settings.llm_deployment,
        llm_api_version=settings.llm_api_version,
        llm_temperature=settings.llm_temperature,
        llm_max_tokens=settings.llm_max_tokens,
        internal_tools=INTERNAL_TOOLS,
    )

    orchestrator = Orchestrator(
        agent_loop=agent_loop,
        skills_dir=skills_dir,
        users_dir=users_dir,
        fast_llm_call=agent_loop.llm_call,
        planner_llm_call=agent_loop.llm_call,
    )

    store = SessionStore(sessions_dir)

    return len(load_skills(skills_dir))


ATLASSIAN_CLOUD_ID_HEADER = "X-Atlassian-Cloud-Id"


def mcp_http_extra_headers(user_jira_data: dict | None) -> dict[str, str]:
    """Headers to add on each HTTP MCP request when targeting a specific cloud (e.g. Jira)."""
    if not user_jira_data:
        return {}
    cid = str(user_jira_data.get("cloud_id", "")).strip()
    if not cid:
        return {}
    return {ATLASSIAN_CLOUD_ID_HEADER: cid}


# ------------------------------------------------------------------
# Jira token helpers (read from the same JSON files auth router writes)
# ------------------------------------------------------------------

def _load_json_file(path: Path) -> dict:
    if not path or not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def resolve_email_from_user_id(user_id: str) -> str | None:
    """Look up the email address for an internal user ID."""
    if not user_id or not _users_file:
        return None
    users = _load_json_file(_users_file)
    for email, record in users.items():
        profile = (record or {}).get("user", {})
        if profile.get("id") == user_id:
            return str(email).strip().lower()
    return None


def ensure_jira_access_token(user_id: str) -> str:
    """Return a valid Jira access token for the user, refreshing if expired.

    Reads from user_integrations.json (written by auth router).
    If the token is within 2 minutes of expiry, attempts a refresh using
    the stored refresh_token and Atlassian OAuth client credentials.
    """
    email = resolve_email_from_user_id(user_id)
    if not email or not _integrations_file:
        return ""

    integrations = _load_json_file(_integrations_file)
    jira = (integrations.get(email, {}) or {}).get("jira", {})
    if not jira or not jira.get("connected"):
        return ""

    access_token = str(jira.get("access_token", "")).strip()
    refresh_token = str(jira.get("refresh_token", "")).strip()
    expires_at_raw = str(jira.get("expires_at", "")).strip()

    needs_refresh = False
    if not access_token:
        needs_refresh = True
    elif expires_at_raw:
        try:
            expires_at = datetime.fromisoformat(expires_at_raw)
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) >= (expires_at - timedelta(minutes=2)):
                needs_refresh = True
        except Exception:
            needs_refresh = True

    if not needs_refresh:
        return access_token

    if not refresh_token:
        logger.warning("Jira token expired for %s but no refresh_token available", email)
        return access_token

    client_id = os.getenv("ATLASSIAN_OAUTH_CLIENT_ID", "").strip()
    client_secret = os.getenv("ATLASSIAN_OAUTH_CLIENT_SECRET", "").strip()
    if not client_id or not client_secret:
        logger.warning("Missing Atlassian OAuth client credentials; cannot refresh for %s", email)
        return access_token

    try:
        resp = httpx.post(
            "https://auth.atlassian.com/oauth/token",
            json={
                "grant_type": "refresh_token",
                "client_id": client_id,
                "client_secret": client_secret,
                "refresh_token": refresh_token,
            },
            headers={"Content-Type": "application/json"},
            timeout=30,
            verify=False,
        )
        if resp.status_code != 200:
            logger.warning("Atlassian token refresh failed for %s: %s", email, resp.status_code)
            return access_token

        data = resp.json()
        new_access = str(data.get("access_token", "")).strip()
        new_refresh = str(data.get("refresh_token", "")).strip()
        expires_in = int(data.get("expires_in") or 3600)
        if not new_access:
            logger.warning("Refresh response missing access_token for %s", email)
            return access_token

        jira["access_token"] = new_access
        if new_refresh:
            jira["refresh_token"] = new_refresh
        jira["expires_at"] = (datetime.now(timezone.utc) + timedelta(seconds=expires_in)).isoformat()

        integrations.setdefault(email, {})["jira"] = jira
        _integrations_file.write_text(
            json.dumps(integrations, ensure_ascii=False, indent=2), encoding="utf-8",
        )
        logger.info("Refreshed Jira token for %s", email)
        return new_access
    except Exception as e:
        logger.warning("Jira token refresh exception for %s: %s", email, e)
        return access_token


def resolve_user_jira_data(user_id: str) -> dict | None:
    """Build the jira data dict needed by stdio MCP clients.

    Merges per-user data from user_integrations.json with app-level
    OAuth settings from environment variables.
    """
    email = resolve_email_from_user_id(user_id)
    if not email or not _integrations_file:
        return None

    integrations = _load_json_file(_integrations_file)
    jira = (integrations.get(email, {}) or {}).get("jira", {})
    if not jira or not jira.get("connected"):
        return None

    base_url = os.getenv("JIRA_SERVER_URL", os.getenv("JIRA_URL", ""))
    inst_url = str(jira.get("instance_url", "")).strip()
    return {
        "access_token": str(jira.get("access_token", "")),
        "refresh_token": str(jira.get("refresh_token", "")),
        "cloud_id": str(jira.get("cloud_id", "")),
        "instance_name": str(jira.get("instance_name", "")),
        "instance_url": inst_url,
        "scope": str(jira.get("scope", "")),
        "client_id": os.getenv("ATLASSIAN_OAUTH_CLIENT_ID", ""),
        "client_secret": os.getenv("ATLASSIAN_OAUTH_CLIENT_SECRET", ""),
        "redirect_uri": os.getenv("ATLASSIAN_OAUTH_REDIRECT_URI", ""),
        "jira_server_url": inst_url or base_url,
    }
