import KanbanPanel from './panels/KanbanPanel';
import ProjectsPanel from './panels/ProjectsPanel';
import TeamPanel from './panels/TeamPanel';
import EffortPanel from './panels/EffortPanel';
import PdfPanel from './panels/PdfPanel';
import SettingsPanel from './panels/SettingsPanel';
import ConnectedToolsPanel from './panels/ConnectedToolsPanel';
import PlaceholderPanel from './panels/PlaceholderPanel';

const PANEL_REGISTRY = {
  dashboard:  { component: KanbanPanel,        title: 'Sprint Board' },
  projects:   { component: ProjectsPanel,      title: 'Projects Overview' },
  team:       { component: TeamPanel,          title: 'Team Management' },
  effort:     { component: EffortPanel,        title: 'Resource Planning' },
  'pdf-upload': { component: PdfPanel,         title: 'Requirements Extraction' },
  settings:   { component: SettingsPanel,      title: 'Settings' },
  tools:      { component: ConnectedToolsPanel, title: 'Connected Tools' },
  messages:   { component: PlaceholderPanel,   title: 'Messages' },

  kanban:     { component: KanbanPanel,        title: 'Sprint Board' },
  table:      { component: PlaceholderPanel,   title: 'Data Table' },
  chart:      { component: PlaceholderPanel,   title: 'Chart' },
  custom:     { component: PlaceholderPanel,   title: 'Agent View' },
};

export default PANEL_REGISTRY;
