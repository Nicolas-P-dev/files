import React from 'react';
import { Box, Typography, IconButton, Divider } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import PANEL_REGISTRY from './panelRegistry';
import PlaceholderPanel from './panels/PlaceholderPanel';

export default function RightPanel({ panelType, data, onClose }) {
  if (!panelType) return null;

  const config = PANEL_REGISTRY[panelType] || { component: PlaceholderPanel, title: panelType };
  const PanelComponent = config.component;

  return (
    <Box sx={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      borderLeft: '1px solid #E6E6E6',
      bgcolor: '#fff',
      overflow: 'hidden',
    }}>
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        px: 3, py: 1.5, borderBottom: '1px solid #E6E6E6', flexShrink: 0,
        bgcolor: '#FAFAFA',
      }}>
        <Typography variant="h5" sx={{ fontWeight: 650 }}>{config.title}</Typography>
        <IconButton size="small" onClick={onClose}><CloseIcon /></IconButton>
      </Box>
      <Box sx={{ flex: 1, overflow: 'auto' }}>
        <PanelComponent data={data} panelType={panelType} />
      </Box>
    </Box>
  );
}
