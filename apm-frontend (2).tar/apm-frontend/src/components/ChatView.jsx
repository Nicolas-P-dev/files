import React, { useState, useRef, useEffect } from 'react';
import {
  Box, Typography, TextField, IconButton, InputAdornment,
  CircularProgress, LinearProgress, Link, Chip,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeSanitize from 'rehype-sanitize';

const markdownComponents = {
  p: ({ children }) => <Typography variant="body2" sx={{ lineHeight: 1.6, mb: 0.5, '&:last-child': { mb: 0 } }}>{children}</Typography>,
  strong: ({ children }) => <strong>{children}</strong>,
  em: ({ children }) => <em>{children}</em>,
  ul: ({ children }) => <ul style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ul>,
  ol: ({ children }) => <ol style={{ margin: '0.25rem 0 0.25rem 1.25rem' }}>{children}</ol>,
  li: ({ children }) => <li><Typography variant="body2" component="span" sx={{ lineHeight: 1.6 }}>{children}</Typography></li>,
  a: ({ href, children }) => (
    <Link href={href} target="_blank" rel="noopener noreferrer" sx={{
      wordBreak: 'break-all', color: '#26890D', textDecoration: 'underline',
      fontWeight: 500, '&:hover': { color: '#046A38' },
    }}>{children}</Link>
  ),
  code: ({ inline, children }) => inline ? (
    <code style={{
      background: 'rgba(0,0,0,0.05)', borderRadius: 4, padding: '0.1rem 0.25rem',
      fontFamily: "'Roboto Mono', monospace",
    }}>{children}</code>
  ) : (
    <pre style={{
      whiteSpace: 'pre-wrap', wordWrap: 'break-word', margin: '0.5rem 0',
      padding: '0.5rem', borderRadius: 6, background: 'rgba(0,0,0,0.04)', overflow: 'auto',
    }}><code style={{ fontFamily: "'Roboto Mono', monospace" }}>{children}</code></pre>
  ),
  h1: ({ children }) => <Typography variant="h6" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
  h2: ({ children }) => <Typography variant="subtitle1" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
  h3: ({ children }) => <Typography variant="subtitle2" sx={{ fontWeight: 700, mt: 1, mb: 0.5 }}>{children}</Typography>,
  table: ({ children }) => <div style={{ overflowX: 'auto', margin: '0.5rem 0' }}><table style={{ borderCollapse: 'collapse', width: '100%', border: '1px solid #E6E6E6' }}>{children}</table></div>,
  thead: ({ children }) => <thead style={{ backgroundColor: '#F5F5F5' }}>{children}</thead>,
  th: ({ children }) => <th style={{ textAlign: 'left', borderBottom: '2px solid #E6E6E6', padding: '8px 12px', fontWeight: 600 }}>{children}</th>,
  td: ({ children }) => <td style={{ borderBottom: '1px solid #E6E6E6', padding: '8px 12px', verticalAlign: 'top' }}>{children}</td>,
  blockquote: ({ children }) => <blockquote style={{ borderLeft: '3px solid #E6E6E6', margin: '0.5rem 0', padding: '0.25rem 0.75rem', color: '#63666A' }}>{children}</blockquote>,
  hr: () => <hr style={{ border: 'none', borderTop: '1px solid #E6E6E6', margin: '8px 0' }} />,
};

const SUGGESTIONS = [
  'Show me my Jira projects',
  'What tasks are in progress?',
  'Create a new task for API review',
  'Give me a sprint status update',
];

function WelcomeScreen({ onSuggestionClick }) {
  return (
    <Box sx={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: '100%', textAlign: 'center', px: 3,
    }}>
      <Typography variant="h6" sx={{ color: '#000', mb: 1, fontWeight: 500 }}>
        Welcome to the Assistant Project Manager
      </Typography>
      <Typography variant="body2" sx={{ color: '#53565A', lineHeight: 1.6, mb: 3 }}>
        I can help you manage projects, update tasks, and streamline your workflow.
      </Typography>
      <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, maxWidth: 480, width: '100%' }}>
        {SUGGESTIONS.map(text => (
          <Box key={text} onClick={() => onSuggestionClick(text)} sx={{
            p: 2, borderRadius: 2, border: '1px solid #E6E6E6', bgcolor: 'white', cursor: 'pointer',
            transition: 'all 0.15s',
            '&:hover': { borderColor: '#26890D', bgcolor: 'rgba(38,137,13,0.03)' },
          }}>
            <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 500 }}>{text}</Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

export default function ChatView({ messages, isStreaming, streamingStatus, inputValue, onInputChange, onSend, onSuggestionClick }) {
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  const handleKeyDown = (e) => {
    if (e.isComposing || e.keyCode === 229) return;
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (inputValue.trim() && !isStreaming) onSend();
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Status bar */}
      {streamingStatus && (
        <Box sx={{ px: 2, py: 0.75, bgcolor: 'rgba(38,137,13,0.05)', borderBottom: '1px solid #E6E6E6' }}>
          <Typography variant="caption" sx={{ color: '#26890D', fontWeight: 600 }}>{streamingStatus}</Typography>
          <LinearProgress sx={{ mt: 0.5, height: 2, bgcolor: 'rgba(38,137,13,0.1)', '& .MuiLinearProgress-bar': { bgcolor: '#26890D' } }} />
        </Box>
      )}

      {/* Messages */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 2, py: 2, bgcolor: '#F5F5F5', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        {messages.length === 0 ? <WelcomeScreen onSuggestionClick={onSuggestionClick} /> : (
          <>
            {messages.map((msg, i) => {
              const isUser = msg.role === 'user';
              const isSystem = msg.role === 'system';

              return (
                <Box key={i} className={`message ${msg.role}`} sx={{
                  alignSelf: isUser ? 'flex-end' : isSystem ? 'center' : 'flex-start',
                  maxWidth: isSystem ? '70%' : '85%',
                  p: isSystem ? 1.5 : 2,
                  borderRadius: isSystem ? 2 : 3,
                  mb: 1.5,
                  wordBreak: 'break-word',
                  overflowWrap: 'break-word',
                }}>
                  {isUser ? (
                    <Typography variant="body2" component="div" sx={{ lineHeight: 1.6 }}>{msg.content}</Typography>
                  ) : msg.content ? (
                    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeSanitize]} components={markdownComponents}>
                      {msg.content}
                    </ReactMarkdown>
                  ) : msg.isStreaming ? (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <CircularProgress size={14} sx={{ color: '#26890D' }} />
                      <Typography variant="body2" sx={{ color: '#63666A' }}>Processing...</Typography>
                    </Box>
                  ) : null}
                </Box>
              );
            })}

            {/* Skill badge on last message */}
            {messages.length > 0 && (() => {
              const last = messages[messages.length - 1];
              return last?.skill && !last.isStreaming ? (
                <Box sx={{ alignSelf: 'flex-start', px: 0.5, mb: 1 }}>
                  <Chip label={last.skill} size="small" sx={{
                    height: 18, fontSize: '0.65rem', fontWeight: 600,
                    bgcolor: 'rgba(38,137,13,0.1)', color: '#26890D',
                  }} />
                </Box>
              ) : null;
            })()}

            <div ref={endRef} />
          </>
        )}
      </Box>

      {/* Input - exact v1 styling */}
      <Box sx={{ px: 2, py: 2, bgcolor: 'white', borderTop: '1px solid #E6E6E6' }}>
        <TextField
          fullWidth variant="outlined" placeholder="Type your message..."
          value={inputValue} onChange={(e) => onInputChange(e.target.value)}
          onKeyDown={handleKeyDown} disabled={isStreaming}
          multiline maxRows={4} size="small"
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={onSend} disabled={!inputValue.trim() || isStreaming} edge="end"
                  sx={{ color: '#26890D', '&:hover': { bgcolor: 'rgba(38,137,13,0.08)' }, '&.Mui-disabled': { color: '#D0D0CE' } }}>
                  {isStreaming ? <CircularProgress size={20} sx={{ color: '#26890D' }} /> : <SendIcon />}
                </IconButton>
              </InputAdornment>
            ),
            sx: {
              borderRadius: 2,
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#26890D', borderWidth: 2 },
              '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#26890D' },
            },
          }}
        />
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
          <Typography variant="caption" sx={{ color: '#A5ADBA' }}>Press Enter to send · Shift+Enter for new line</Typography>
          {isStreaming && <Typography variant="caption" sx={{ color: '#26890D' }}>Processing...</Typography>}
        </Box>
      </Box>
    </Box>
  );
}
