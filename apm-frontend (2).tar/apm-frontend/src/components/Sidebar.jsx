import React from 'react';
import {
  Box, Typography, List, ListItem, ListItemButton, ListItemIcon,
  ListItemText, Divider, IconButton,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import FolderIcon from '@mui/icons-material/Folder';
import PeopleIcon from '@mui/icons-material/People';
import CalculateIcon from '@mui/icons-material/Calculate';
import EmailIcon from '@mui/icons-material/Email';
import SettingsIcon from '@mui/icons-material/Settings';
import HelpIcon from '@mui/icons-material/Help';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ChatIcon from '@mui/icons-material/Chat';
import ElectricBoltIcon from '@mui/icons-material/ElectricBolt';

const NAV_ITEMS = [
  { id: 'pdf-upload', label: 'Upload Requirements', icon: PictureAsPdfIcon },
  { id: 'dashboard', label: 'Dashboard', icon: DashboardIcon },
  { id: 'projects', label: 'Projects', icon: FolderIcon },
  { id: 'team', label: 'Team', icon: PeopleIcon },
  { id: 'effort', label: 'Resource Planning', icon: CalculateIcon },
  { id: 'messages', label: 'Messages', icon: EmailIcon, disabled: true },
];

function formatSessionTitle(session) {
  if (session.first_message) return session.first_message.slice(0, 30);
  return session.session_id?.slice(0, 20) || 'Chat';
}

export default function Sidebar({
  activePanel,
  onPanelOpen,
  onPanelClose,
  sessions,
  activeSessionId,
  onNewChat,
  onSwitchSession,
  onDeleteSession,
  currentProject,
}) {
  const handleNavClick = (id) => {
    if (activePanel === id) {
      onPanelClose();
    } else {
      onPanelOpen(id);
    }
  };

  return (
    <Box sx={{
      width: 240,
      minWidth: 200,
      height: '100%',
      bgcolor: '#000',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      overflow: 'hidden',
    }}>
      {/* Logo + Title */}
      <Box sx={{ pt: 4, mb: 2 }}>
        <Box sx={{
          width: 120, height: 'auto', ml: 4, mb: 2,
          bgcolor: 'rgba(255,255,255,0.05)', borderRadius: 0.5, p: 0.5,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Typography variant="caption" sx={{ color: '#86BC25', fontWeight: 700, letterSpacing: 1.5 }}>
            DELOITTE
          </Typography>
        </Box>
        <Typography variant="h6" sx={{ fontWeight: 600, color: 'white', ml: 4 }}>
          Assistant Project Manager
        </Typography>
        <Typography variant="body2" sx={{ mt: 1, ml: 4, mr: 2, color: '#A5ADBA' }}>
          Automate & Manage Project Workflows
        </Typography>
      </Box>

      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />

      {/* Current Project */}
      {currentProject && (
        <Box sx={{ px: 2, py: 1.5 }}>
          <Typography variant="caption" sx={{ color: '#A5ADBA', display: 'block', mb: 0.5 }}>
            CURRENT PROJECT
          </Typography>
          <Box sx={{
            bgcolor: 'rgba(38, 137, 13, 0.1)',
            p: 1.5, borderRadius: 1,
            border: '1px solid rgba(38, 137, 13, 0.3)',
          }}>
            <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 600 }}>
              {currentProject}
            </Typography>
          </Box>
        </Box>
      )}

      {/* Navigation */}
      <List sx={{ px: 1, pt: 1 }}>
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const selected = activePanel === item.id;
          return (
            <ListItem key={item.id} disablePadding sx={{ mb: 0.25 }}>
              <ListItemButton
                selected={selected}
                disabled={item.disabled}
                onClick={() => handleNavClick(item.id)}
                sx={{
                  borderRadius: 1, py: 0.75,
                  '&.Mui-selected': {
                    bgcolor: 'rgba(38,137,13,0.15)',
                    '& .MuiListItemIcon-root': { color: '#26890D' },
                  },
                  '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
                  '&.Mui-disabled': { opacity: 0.35 },
                }}
              >
                <ListItemIcon sx={{ color: selected ? '#26890D' : '#fff', minWidth: 40 }}>
                  <Icon />
                </ListItemIcon>
                <ListItemText primary={item.label} />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>

      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)', mx: 1.5, my: 1 }} />

      {/* New Chat */}
      <Box sx={{ px: 1.5, pb: 1 }}>
        <ListItemButton
          onClick={onNewChat}
          sx={{
            borderRadius: 1,
            border: '1px solid rgba(38,137,13,0.4)',
            justifyContent: 'center', py: 0.75,
            '&:hover': { bgcolor: 'rgba(38,137,13,0.1)' },
          }}
        >
          <AddIcon fontSize="small" sx={{ color: '#26890D', mr: 1 }} />
          <Typography variant="body2" sx={{ color: '#26890D', fontWeight: 600 }}>
            New Chat
          </Typography>
        </ListItemButton>
      </Box>

      {/* Sessions */}
      <Box sx={{ flex: 1, overflowY: 'auto', px: 1 }}>
        {sessions.map(session => (
          <ListItem
            key={session.session_id}
            disablePadding
            secondaryAction={
              <IconButton
                size="small"
                onClick={(e) => { e.stopPropagation(); onDeleteSession(session.session_id); }}
                sx={{ color: '#63666A', opacity: 0, '.MuiListItem-root:hover &': { opacity: 1 } }}
              >
                <DeleteOutlineIcon sx={{ fontSize: 16 }} />
              </IconButton>
            }
            sx={{ '&:hover .MuiIconButton-root': { opacity: 1 } }}
          >
            <ListItemButton
              selected={activeSessionId === session.session_id}
              onClick={() => onSwitchSession(session.session_id)}
              sx={{
                borderRadius: 1, py: 0.5, pr: 5,
                '&.Mui-selected': { bgcolor: 'rgba(255,255,255,0.08)' },
                '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' },
              }}
            >
              <ListItemIcon sx={{ color: '#fff', minWidth: 32 }}>
                <ChatIcon sx={{ fontSize: 16 }} />
              </ListItemIcon>
              <ListItemText
                primary={formatSessionTitle(session)}
                primaryTypographyProps={{ fontSize: '0.8rem', noWrap: true, color: '#fff' }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </Box>

      {/* Bottom Actions */}
      <Divider sx={{ bgcolor: 'rgba(255,255,255,0.2)' }} />
      <List sx={{ px: 1, py: 0.5 }}>
        <ListItem disablePadding>
          <ListItemButton onClick={() => handleNavClick('tools')} sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
            <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><ElectricBoltIcon /></ListItemIcon>
            <ListItemText primary="Connected Tools" primaryTypographyProps={{ fontSize: '0.875rem' }} />
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton onClick={() => handleNavClick('settings')} sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
            <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><SettingsIcon /></ListItemIcon>
            <ListItemText primary="Settings" primaryTypographyProps={{ fontSize: '0.875rem' }} />
          </ListItemButton>
        </ListItem>
        <ListItem disablePadding>
          <ListItemButton sx={{ borderRadius: 1, py: 0.75, '&:hover': { bgcolor: 'rgba(255,255,255,0.05)' } }}>
            <ListItemIcon sx={{ color: '#fff', minWidth: 40 }}><HelpIcon /></ListItemIcon>
            <ListItemText primary="Help & Support" primaryTypographyProps={{ fontSize: '0.875rem' }} />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );
}
