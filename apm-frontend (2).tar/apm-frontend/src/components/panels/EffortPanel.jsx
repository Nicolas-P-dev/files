import React from 'react';
import { Box, Typography } from '@mui/material';
import CalculateIcon from '@mui/icons-material/Calculate';

/* TODO: Port v1 EffortEstimate into this panel. */
export default function EffortPanel({ data }) {
  return (
    <Box sx={{ p: 3, textAlign: 'center' }}>
      <CalculateIcon sx={{ fontSize: 48, color: '#E6E6E6', mb: 2 }} />
      <Typography variant="h6" sx={{ color: '#63666A', mb: 1 }}>Resource Planning</Typography>
      <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
        Port in progress — v1 EffortEstimate component goes here.
      </Typography>
    </Box>
  );
}
