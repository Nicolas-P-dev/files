import React from 'react';
import { Box, Typography, Paper, Chip, Tooltip, Avatar, Card, CardContent, Divider, Stack } from '@mui/material';
import AssignmentIcon from '@mui/icons-material/Assignment';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import SpeedIcon from '@mui/icons-material/Speed';

/* TODO: Wire to V2 data source (agent-triggered panel event or /api/board endpoint).
   For now renders static placeholder — replace with v1 KanbanBoard logic. */

export default function KanbanPanel({ data }) {
  const boardData = data?.board_data || data || {};
  const columns = Object.entries(boardData);

  if (columns.length === 0) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="body1" sx={{ color: '#63666A' }}>
          No board data available. Ask APM to show your sprint board.
        </Typography>
      </Box>
    );
  }

  const getStoryPointColor = (sp) => {
    if (!sp) return '#E5E8EC';
    if (sp <= 3) return '#26890D';
    if (sp <= 5) return '#26890D';
    return '#DA291C';
  };

  const getInitials = (name) => name ? name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) : '?';

  return (
    <Box sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box sx={{ display: 'flex', gap: 2, flex: 1, overflowX: 'auto', pb: 2 }}>
        {columns.map(([status, tasks]) => (
          <Paper key={status} elevation={0} sx={{
            flex: '1 1 0', minWidth: 280, display: 'flex', flexDirection: 'column',
            bgcolor: 'grey.50', borderRadius: 2, border: '1px solid', borderColor: 'grey.200',
          }}>
            <Box sx={{ p: 2, pb: 1.5, borderBottom: '2px solid #26890D' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography variant="subtitle1" fontWeight={600}>{status}</Typography>
                <Chip label={tasks.length} size="small" sx={{ height: 20, bgcolor: '#26890D', color: 'white' }} />
              </Box>
            </Box>
            <Box sx={{ flex: 1, overflowY: 'auto', p: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              {tasks.length === 0 ? (
                <Box sx={{ p: 2, textAlign: 'center', border: '1px dashed', borderColor: 'grey.300', borderRadius: 1, color: 'text.secondary' }}>
                  <Typography variant="body2">No tasks</Typography>
                </Box>
              ) : tasks.map(task => (
                <Card key={task.key} elevation={0} sx={{
                  border: '1px solid', borderColor: 'grey.200',
                  '&:hover': { transform: 'translateY(-2px)', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', cursor: 'pointer' },
                  transition: 'transform 0.2s, box-shadow 0.2s',
                }}>
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography variant="caption" sx={{ color: 'primary.main', fontFamily: 'monospace', fontWeight: 600, display: 'block', mb: 0.5 }}>
                      {task.key}
                    </Typography>
                    <Typography variant="body2" fontWeight={500} sx={{ mb: 1.5 }}>{task.summary}</Typography>
                    {task.assignee && (
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <Avatar sx={{ width: 24, height: 24, fontSize: '0.75rem', bgcolor: 'primary.main', mr: 1 }}>
                          {getInitials(task.assignee)}
                        </Avatar>
                        <Typography variant="body2" color="text.secondary" noWrap>{task.assignee}</Typography>
                      </Box>
                    )}
                    <Divider sx={{ my: 1 }} />
                    <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                      <Chip icon={<AssignmentIcon fontSize="small" />} label="Task" size="small" variant="outlined" sx={{ height: 24, fontSize: '0.75rem' }} />
                      {task.story_points && (
                        <Chip icon={<SpeedIcon fontSize="small" />} label={`${task.story_points} SP`} size="small" variant="outlined"
                          sx={{ height: 24, fontSize: '0.75rem', borderColor: getStoryPointColor(task.story_points), color: getStoryPointColor(task.story_points) }} />
                      )}
                    </Box>
                  </CardContent>
                </Card>
              ))}
            </Box>
          </Paper>
        ))}
      </Box>
    </Box>
  );
}
