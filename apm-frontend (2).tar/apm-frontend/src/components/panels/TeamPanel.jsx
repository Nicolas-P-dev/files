import React from 'react';
import { Box, Typography } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';

/* TODO: Port v1 TeamManagement into this panel. */
export default function TeamPanel({ data }) {
  return (
    <Box sx={{ p: 3, textAlign: 'center' }}>
      <PeopleIcon sx={{ fontSize: 48, color: '#E6E6E6', mb: 2 }} />
      <Typography variant="h6" sx={{ color: '#63666A', mb: 1 }}>Team Management</Typography>
      <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
        Port in progress — v1 TeamManagement component goes here.
      </Typography>
    </Box>
  );
}
