import React from 'react';
import { Box, Typography } from '@mui/material';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

/* TODO: Port v1 PDFReportDashboard into this panel. */
export default function PdfPanel({ data }) {
  return (
    <Box sx={{ p: 3, textAlign: 'center' }}>
      <PictureAsPdfIcon sx={{ fontSize: 48, color: '#E6E6E6', mb: 2 }} />
      <Typography variant="h6" sx={{ color: '#63666A', mb: 1 }}>Requirements Extraction</Typography>
      <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
        Port in progress — v1 PDFReportDashboard component goes here.
      </Typography>
    </Box>
  );
}
