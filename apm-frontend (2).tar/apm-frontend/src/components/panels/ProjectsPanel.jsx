import React from 'react';
import { Box, Typography } from '@mui/material';
import FolderIcon from '@mui/icons-material/Folder';

/* TODO: Port v1 ProjectsOverview into this panel. 
   Data will come from V2 API or agent-triggered panel events. */
export default function ProjectsPanel({ data }) {
  return (
    <Box sx={{ p: 3, textAlign: 'center' }}>
      <FolderIcon sx={{ fontSize: 48, color: '#E6E6E6', mb: 2 }} />
      <Typography variant="h6" sx={{ color: '#63666A', mb: 1 }}>Projects Overview</Typography>
      <Typography variant="body2" sx={{ color: '#A5ADBA' }}>
        Port in progress — v1 ProjectsOverview component goes here.
      </Typography>
    </Box>
  );
}
