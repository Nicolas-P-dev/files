import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, Chip, CircularProgress, IconButton } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';

const TOOL_LABELS = {
  'mcp-atlassian': { label: 'Jira & Confluence', desc: 'Atlassian Cloud' },
  'mcp-graph': { label: 'Microsoft 365', desc: 'Outlook, Calendar, Teams' },
  'mcp-devops': { label: 'Azure DevOps', desc: 'Work items, repos, pipelines' },
};

export default function ConnectedToolsPanel() {
  const [tools, setTools] = useState({});
  const [loading, setLoading] = useState(true);

  const fetch_ = async () => {
    setLoading(true);
    try {
      const resp = await fetch('/health/mcp');
      if (resp.ok) setTools(await resp.json());
    } catch { /* silent */ }
    finally { setLoading(false); }
  };

  useEffect(() => { fetch_(); }, []);

  return (
    <Box sx={{ p: 2.5 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
        <Typography variant="body2" sx={{ color: '#63666A' }}>MCP server connectivity</Typography>
        <IconButton size="small" onClick={fetch_} disabled={loading}><RefreshIcon fontSize="small" /></IconButton>
      </Box>

      {loading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress size={24} sx={{ color: '#26890D' }} /></Box>}

      {!loading && Object.entries(tools).map(([id, status]) => {
        const info = TOOL_LABELS[id] || { label: id, desc: '' };
        const ok = status?.status === 'healthy';
        return (
          <Paper key={id} variant="outlined" sx={{
            p: 2, mb: 1.5,
            borderColor: ok ? 'rgba(38,137,13,0.3)' : 'rgba(218,41,28,0.3)',
            borderLeft: `3px solid ${ok ? '#26890D' : '#DA291C'}`,
          }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>{info.label}</Typography>
                <Typography variant="caption" sx={{ color: '#63666A' }}>{info.desc}</Typography>
              </Box>
              <Chip
                icon={ok ? <CheckCircleIcon sx={{ fontSize: 14 }} /> : <ErrorIcon sx={{ fontSize: 14 }} />}
                label={ok ? 'Connected' : 'Unavailable'}
                size="small"
                sx={{
                  bgcolor: ok ? 'rgba(38,137,13,0.1)' : 'rgba(218,41,28,0.1)',
                  color: ok ? '#26890D' : '#DA291C',
                  fontWeight: 600, fontSize: '0.7rem', height: 24,
                }}
              />
            </Box>
          </Paper>
        );
      })}

      {!loading && Object.keys(tools).length === 0 && (
        <Paper sx={{ p: 3, textAlign: 'center', bgcolor: '#F5F5F5' }}>
          <Typography variant="body2" sx={{ color: '#63666A' }}>No MCP servers configured</Typography>
        </Paper>
      )}
    </Box>
  );
}
