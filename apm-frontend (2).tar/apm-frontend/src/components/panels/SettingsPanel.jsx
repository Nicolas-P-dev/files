import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Divider, Paper, Alert } from '@mui/material';
import SaveIcon from '@mui/icons-material/Save';

export default function SettingsPanel() {
  const [jiraToken, setJiraToken] = useState('');
  const [graphToken, setGraphToken] = useState('');
  const [userId, setUserId] = useState(() => localStorage.getItem('apm_user_id') || 'default');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    localStorage.setItem('apm_user_id', userId);
    if (jiraToken) localStorage.setItem('apm_jira_token', jiraToken);
    if (graphToken) localStorage.setItem('apm_graph_token', graphToken);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <Box sx={{ p: 2.5 }}>
      {saved && <Alert severity="success" sx={{ mb: 2 }}>Settings saved</Alert>}

      <Typography variant="subtitle2" sx={{ color: '#63666A', mb: 2 }}>User Profile</Typography>
      <TextField fullWidth size="small" label="User ID" value={userId} onChange={(e) => setUserId(e.target.value)} sx={{ mb: 3 }} />

      <Divider sx={{ mb: 2.5 }} />
      <Typography variant="subtitle2" sx={{ color: '#63666A', mb: 1 }}>Tool Authentication</Typography>
      <Typography variant="caption" sx={{ color: '#A5ADBA', display: 'block', mb: 2 }}>
        Tokens are stored locally and sent with each request.
      </Typography>

      <TextField fullWidth size="small" label="Jira API Token" type="password" value={jiraToken}
        onChange={(e) => setJiraToken(e.target.value)} placeholder="Atlassian API token"
        helperText="id.atlassian.com/manage-profile/security/api-tokens" sx={{ mb: 2 }} />
      <TextField fullWidth size="small" label="Graph API Token" type="password" value={graphToken}
        onChange={(e) => setGraphToken(e.target.value)} placeholder="Microsoft Graph token" sx={{ mb: 3 }} />

      <Button variant="contained" startIcon={<SaveIcon />} onClick={handleSave}
        sx={{ bgcolor: '#26890D', '&:hover': { bgcolor: '#046A38' } }}>
        Save Settings
      </Button>

      <Divider sx={{ my: 3 }} />
      <Paper variant="outlined" sx={{ p: 2, bgcolor: '#F5F5F5' }}>
        <Typography variant="body2"><strong>APM</strong> — Assistant Project Manager</Typography>
        <Typography variant="caption" sx={{ color: '#63666A' }}>v0.1.0 · Skill-based AI agent with MCP tool integration</Typography>
      </Paper>
    </Box>
  );
}
