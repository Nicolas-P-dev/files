import React from 'react';
import { Box, Typography, Chip, Divider } from '@mui/material';

export default function Header({ agentHealthy, currentProject }) {
  return (
    <Box sx={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      bgcolor: '#000',
      color: '#fff',
      px: 1.5,
      py: 1,
      minHeight: 48,
      flexShrink: 0,
    }}>
      <Box className="header-left" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        {/* Logo placeholder — replace src with your logo.png import */}
        <Box sx={{
          height: 28, width: 80,
          bgcolor: 'rgba(255,255,255,0.1)', borderRadius: 0.5,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Typography variant="caption" sx={{ color: '#86BC25', fontWeight: 700, letterSpacing: 1 }}>
            DELOITTE
          </Typography>
        </Box>
        <Divider orientation="vertical" flexItem sx={{ mx: 2, bgcolor: 'rgba(255,255,255,0.2)' }} />
      </Box>

      <Box className="header-center" sx={{ display: 'flex', alignItems: 'center' }}>
        <Typography variant="body2" sx={{ color: '#A5ADBA', mr: 0.5 }}>
          Project: {currentProject || 'APM'}
        </Typography>
        <Divider orientation="vertical" flexItem sx={{ mx: 1.5, bgcolor: 'rgba(255,255,255,0.2)' }} />
        <Typography variant="body2" sx={{ color: '#A5ADBA', mr: 0.5 }}>
          Status:
        </Typography>
        <Chip
          label={agentHealthy ? 'Connected' : 'Disconnected'}
          size="small"
          className={`status-chip ${agentHealthy ? 'online' : 'offline'}`}
        />
      </Box>

      <Box className="header-right" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        {/* Future: user avatar, settings icon */}
      </Box>
    </Box>
  );
}
