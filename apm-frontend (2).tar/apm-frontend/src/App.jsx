import React, { useState, useCallback, useEffect } from 'react';
import { Box, Divider } from '@mui/material';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import RightPanel from './components/RightPanel';
import useChat from './hooks/useChat';
import useSessions from './hooks/useSessions';
import useHealthCheck from './hooks/useHealthCheck';

export default function App() {
  const [inputValue, setInputValue] = useState('');
  const [activePanel, setActivePanel] = useState(null);
  const [panelData, setPanelData] = useState(null);

  const {
    messages, isStreaming, streamingStatus, currentSkill,
    panelEvent, sendMessage, cancelStream, clearMessages, setPanelEvent,
  } = useChat();

  const {
    sessions, activeSessionId, createSession, switchSession,
    deleteSession, refreshSessions,
  } = useSessions();

  const { tools, agentHealthy } = useHealthCheck();

  const ensureSession = useCallback(() => {
    if (!activeSessionId) return createSession();
    return activeSessionId;
  }, [activeSessionId, createSession]);

  const handleSend = useCallback(() => {
    const text = inputValue.trim();
    if (!text) return;
    const sessionId = ensureSession();
    const userId = localStorage.getItem('apm_user_id') || 'default';
    const token = localStorage.getItem('apm_jira_token') || '';
    sendMessage(text, sessionId, userId, token);
    setInputValue('');
    setTimeout(() => refreshSessions(), 1000);
  }, [inputValue, ensureSession, sendMessage, refreshSessions]);

  const handleNewChat = useCallback(() => {
    createSession();
    clearMessages();
    setInputValue('');
  }, [createSession, clearMessages]);

  const handleSwitchSession = useCallback((sessionId) => {
    switchSession(sessionId);
    clearMessages();
  }, [switchSession, clearMessages]);

  const handleDeleteSession = useCallback((sessionId) => {
    deleteSession(sessionId);
    if (sessionId === activeSessionId) clearMessages();
  }, [deleteSession, activeSessionId, clearMessages]);

  const handleSuggestionClick = useCallback((text) => {
    setInputValue(text);
    const sessionId = ensureSession();
    const userId = localStorage.getItem('apm_user_id') || 'default';
    const token = localStorage.getItem('apm_jira_token') || '';
    sendMessage(text, sessionId, userId, token);
    setTimeout(() => refreshSessions(), 1000);
  }, [ensureSession, sendMessage, refreshSessions]);

  const handlePanelOpen = useCallback((panelType, data = null) => {
    setActivePanel(panelType);
    setPanelData(data);
  }, []);

  const handlePanelClose = useCallback(() => {
    setActivePanel(null);
    setPanelData(null);
  }, []);

  useEffect(() => {
    if (panelEvent) {
      setActivePanel(panelEvent.panelType);
      setPanelData(panelEvent.data);
      setPanelEvent(null);
    }
  }, [panelEvent, setPanelEvent]);

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <Header agentHealthy={agentHealthy} currentProject={null} />
      <Divider />

      <Box sx={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <Sidebar
          activePanel={activePanel}
          onPanelOpen={handlePanelOpen}
          onPanelClose={handlePanelClose}
          sessions={sessions}
          activeSessionId={activeSessionId}
          onNewChat={handleNewChat}
          onSwitchSession={handleSwitchSession}
          onDeleteSession={handleDeleteSession}
          currentProject={null}
        />

        {/* Chat — always visible, flexes to fill available space */}
        <Box sx={{
          flex: activePanel ? '0 0 50%' : '1 1 100%',
          minWidth: 380,
          transition: 'flex 0.2s ease',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}>
          <ChatView
            messages={messages}
            isStreaming={isStreaming}
            streamingStatus={streamingStatus}
            inputValue={inputValue}
            onInputChange={setInputValue}
            onSend={handleSend}
            onSuggestionClick={handleSuggestionClick}
          />
        </Box>

        {/* Right panel — opens when nav item clicked or agent triggers it */}
        {activePanel && (
          <Box sx={{
            flex: '1 1 50%',
            minWidth: 360,
            overflow: 'hidden',
          }}>
            <RightPanel
              panelType={activePanel}
              data={panelData}
              onClose={handlePanelClose}
            />
          </Box>
        )}
      </Box>
    </Box>
  );
}
