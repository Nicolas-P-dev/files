import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: { main: '#26890D', dark: '#046A38', light: '#86BC25' },
    secondary: { main: '#0076A8', dark: '#005587', light: '#0097A9' },
    error: { main: '#DA291C' },
    warning: { main: '#ED8B00' },
    success: { main: '#26890D' },
    background: { default: '#f5f7f9', paper: '#ffffff' },
    text: { primary: '#000000', secondary: '#63666A', disabled: '#A5ADBA' },
    grey: { 200: '#E6E6E6', 300: '#D0D0CE', 500: '#97999B', 700: '#53565A' },
  },
  typography: {
    fontFamily: "'Open Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    subtitle1: { fontWeight: 600 },
    subtitle2: { fontWeight: 600 },
  },
  shape: { borderRadius: 8 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { textTransform: 'none', fontWeight: 600 },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 500 },
      },
    },
  },
});

export default theme;
