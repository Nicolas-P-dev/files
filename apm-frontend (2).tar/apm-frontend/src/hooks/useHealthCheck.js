import { useState, useEffect, useCallback } from 'react';

export default function useHealthCheck(intervalMs = 30000) {
  const [tools, setTools] = useState({});
  const [agentHealthy, setAgentHealthy] = useState(false);

  const check = useCallback(async () => {
    try {
      const resp = await fetch('/health');
      setAgentHealthy(resp.ok);
    } catch { setAgentHealthy(false); }

    try {
      const resp = await fetch('/health/mcp');
      if (resp.ok) setTools(await resp.json());
    } catch { /* mcp not available */ }
  }, []);

  useEffect(() => {
    check();
    const id = setInterval(check, intervalMs);
    return () => clearInterval(id);
  }, [check, intervalMs]);

  return { tools, agentHealthy, refresh: check };
}
