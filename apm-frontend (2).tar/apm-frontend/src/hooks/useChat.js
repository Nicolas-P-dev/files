import { useState, useRef, useCallback } from 'react';

export default function useChat() {
  const [messages, setMessages] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingStatus, setStreamingStatus] = useState('');
  const [currentSkill, setCurrentSkill] = useState(null);
  const [panelEvent, setPanelEvent] = useState(null);
  const abortRef = useRef(null);

  const sendMessage = useCallback(async (text, sessionId, userId = 'default', token = '') => {
    if (!text.trim() || isStreaming) return;

    setMessages(prev => [...prev, { role: 'user', content: text }]);
    setIsStreaming(true);
    setStreamingStatus('');
    setCurrentSkill(null);
    setMessages(prev => [...prev, { role: 'assistant', content: '', isStreaming: true }]);

    const controller = new AbortController();
    abortRef.current = controller;
    let accumulated = '';

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, session_id: sessionId, user_id: userId, token }),
        signal: controller.signal,
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          let event;
          try { event = JSON.parse(line.slice(6).trim()); }
          catch { continue; }

          switch (event.type) {
            case 'token':
              accumulated += event.content;
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) updated[updated.length - 1] = { ...last, content: accumulated };
                return updated;
              });
              break;

            case 'status':
              setStreamingStatus(event.message);
              break;

            case 'done':
              setCurrentSkill(event.skill);
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) updated[updated.length - 1] = { ...last, isStreaming: false, skill: event.skill };
                return updated;
              });
              break;

            case 'panel':
              setPanelEvent({ panelType: event.panel_type, data: event.data });
              break;

            case 'error':
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last?.isStreaming) updated[updated.length - 1] = { ...last, isStreaming: false, content: `Error: ${event.message}`, isError: true };
                return updated;
              });
              break;
          }
        }
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        setMessages(prev => {
          const updated = [...prev];
          const last = updated[updated.length - 1];
          if (last?.isStreaming) updated[updated.length - 1] = { ...last, isStreaming: false, content: `Connection error: ${err.message}`, isError: true };
          return updated;
        });
      }
    } finally {
      setIsStreaming(false);
      setStreamingStatus('');
      abortRef.current = null;
    }
  }, [isStreaming]);

  const cancelStream = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
    setStreamingStatus('');
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setCurrentSkill(null);
    setPanelEvent(null);
  }, []);

  return { messages, isStreaming, streamingStatus, currentSkill, panelEvent, sendMessage, cancelStream, clearMessages, setPanelEvent };
}
