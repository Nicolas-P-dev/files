import { useState, useCallback, useEffect } from 'react';

function generateSessionId() {
  return `s_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export default function useSessions() {
  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);

  const fetchSessions = useCallback(async () => {
    try {
      const resp = await fetch('/api/sessions');
      if (resp.ok) setSessions(await resp.json());
    } catch { /* endpoint may not exist yet */ }
  }, []);

  useEffect(() => { fetchSessions(); }, [fetchSessions]);

  const createSession = useCallback(() => {
    const id = generateSessionId();
    setActiveSessionId(id);
    return id;
  }, []);

  const switchSession = useCallback((sessionId) => {
    setActiveSessionId(sessionId);
  }, []);

  const deleteSession = useCallback(async (sessionId) => {
    try {
      await fetch(`/api/sessions/${sessionId}`, { method: 'DELETE' });
      setSessions(prev => prev.filter(s => s.session_id !== sessionId));
      if (activeSessionId === sessionId) setActiveSessionId(null);
    } catch { /* silent */ }
  }, [activeSessionId]);

  return { sessions, activeSessionId, createSession, switchSession, deleteSession, refreshSessions: fetchSessions };
}
