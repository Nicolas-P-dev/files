"use client";

import React, { useState, useEffect, useContext } from "react";
import {
  Typography,
  Box,
  Button,
  Paper,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Tooltip,
  IconButton,
  Collapse,
  TextField,
  InputAdornment,
} from "@mui/material";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import SearchIcon from "@mui/icons-material/Search";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import CircularLoader from "@/ui/circularLoader";
import ChatPanel from "@/components/ChatPanel";
import { backend_url } from "@/config";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

interface FieldData {
  id: string;
  fieldName: string;
  value: string | number;
  explanation: string;
  sourceFiles: string[];
  sourceFields: string[];
  category: string;
}

const loadingMessages = ["Preparing the report for download..."];

export default function AttributionsPage() {
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [hasProcessedData, setHasProcessedData] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [parsedFields, setParsedFields] = useState<FieldData[]>([]);
  const { logs: agentLogs, logsLoading, fetchAgentLogs } = useContext(AgentLogsContext);

  // Categories for tabs
  const categories = ["All", "Assets", "Liabilities", "Equity", "P&L", "Cash Flow"];

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchCurrentDebtor();
  }, []);

  // Parse agent logs into flat table structure
  useEffect(() => {
    if (agentLogs && typeof agentLogs === "object") {
      const fields: FieldData[] = [];
      
      const parseObject = (obj: any, path: string = "", category: string = "Other") => {
        Object.entries(obj).forEach(([key, value]: [string, any]) => {
          // Determine category from path
          let cat = category;
          const lowerPath = path.toLowerCase();
          if (lowerPath.includes("asset")) cat = "Assets";
          else if (lowerPath.includes("liabilit")) cat = "Liabilities";
          else if (lowerPath.includes("equity")) cat = "Equity";
          else if (lowerPath.includes("p&l") || lowerPath.includes("profit") || lowerPath.includes("loss") || lowerPath.includes("income")) cat = "P&L";
          else if (lowerPath.includes("cash")) cat = "Cash Flow";

          if (typeof value === "object" && value !== null) {
            // Check if this is a field with Value/Explanation structure
            if (value["Field Value"] !== undefined || value.Value !== undefined || value.value !== undefined) {
              const fieldValue = value["Field Value"] ?? value.Value ?? value.value;
              const explanation = value.Explanation ?? value.explanation ?? "";
              const sourceFiles = value["Source Files"] ?? value.Sources ?? value.sources ?? [];
              const sourceFields = value["Source Fields"] ?? value.source_fields ?? [];

              fields.push({
                id: `${path}/${key}`,
                fieldName: key,
                value: fieldValue,
                explanation: explanation,
                sourceFiles: Array.isArray(sourceFiles) ? sourceFiles : [sourceFiles],
                sourceFields: Array.isArray(sourceFields) ? sourceFields : [sourceFields],
                category: cat,
              });
            } else {
              // Recurse into nested objects
              parseObject(value, `${path}/${key}`, cat);
            }
          }
        });
      };

      parseObject(agentLogs);
      setParsedFields(fields);
    }
  }, [agentLogs]);

  const handleRefreshLogs = async () => {
    await fetchAgentLogs();
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${backend_url}/download_report`);

      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_Filled_Template.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      console.error("Download error:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleRowExpand = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  const expandAll = () => {
    setExpandedRows(new Set(filteredFields.map(f => f.id)));
  };

  const collapseAll = () => {
    setExpandedRows(new Set());
  };

  // Filter fields based on category and search
  const filteredFields = parsedFields.filter(field => {
    const categoryMatch = activeTab === 0 || field.category === categories[activeTab];
    const searchMatch = searchQuery === "" || 
      field.fieldName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(field.value).toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && searchMatch;
  });

  // Parse source file string to extract document name and page
  const parseSourceFile = (source: string) => {
    const pageMatch = source.match(/\[Page_num:\s*(\d+)\]/i);
    const page = pageMatch ? pageMatch[1] : null;
    const docName = source.replace(/\s*\[Page_num:\s*\d+\]/i, "").trim();
    return { docName, page };
  };

  return (
    <Box
      sx={{
        display: "flex",
        height: "100vh",
        bgcolor: "#F5F7F9",
        overflow: "hidden",
      }}
    >
      {/* Left Panel - Attributions Table */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          p: 3,
          pr: 1.5,
        }}
      >
        {/* Header */}
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
            <Box>
              <Typography variant="h5" sx={{ fontWeight: 700, color: "#1A1C1E", mb: 0.5 }}>
                Attributions
              </Typography>
              <Typography variant="body2" sx={{ color: "#6B778C" }}>
                Review extracted fields with source documents and explanations
              </Typography>
            </Box>
            {currentDebtor && (
              <Chip
                label={currentDebtor}
                sx={{
                  bgcolor: "rgba(134, 188, 37, 0.1)",
                  color: "#26890D",
                  fontWeight: 600,
                }}
              />
            )}
          </Box>

          {/* Search and Actions */}
          <Box sx={{ display: "flex", gap: 2, alignItems: "center", mb: 2 }}>
            <TextField
              size="small"
              placeholder="Search fields..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: "#A5ADBA", fontSize: 20 }} />
                  </InputAdornment>
                ),
              }}
              sx={{
                flex: 1,
                maxWidth: 300,
                "& .MuiOutlinedInput-root": {
                  bgcolor: "#fff",
                  borderRadius: 2,
                },
              }}
            />
            <Button
              size="small"
              onClick={expandAll}
              sx={{ textTransform: "none", color: "#26890D" }}
            >
              Expand All
            </Button>
            <Button
              size="small"
              onClick={collapseAll}
              sx={{ textTransform: "none", color: "#6B778C" }}
            >
              Collapse All
            </Button>
            <Tooltip title="Refresh data">
              <IconButton onClick={handleRefreshLogs} disabled={logsLoading} size="small">
                <RefreshIcon />
              </IconButton>
            </Tooltip>
          </Box>

          {/* Category Tabs */}
          <Tabs
            value={activeTab}
            onChange={(_, newValue) => setActiveTab(newValue)}
            sx={{
              bgcolor: "#fff",
              borderRadius: 2,
              p: 0.5,
              "& .MuiTab-root": {
                textTransform: "none",
                fontWeight: 500,
                fontSize: "0.85rem",
                minHeight: 40,
                "&.Mui-selected": {
                  color: "#26890D",
                  fontWeight: 600,
                },
              },
              "& .MuiTabs-indicator": {
                bgcolor: "#86BC25",
                height: 3,
                borderRadius: 2,
              },
            }}
          >
            {categories.map((cat) => (
              <Tab 
                key={cat} 
                label={
                  <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    {cat}
                    <Chip
                      size="small"
                      label={cat === "All" 
                        ? parsedFields.length 
                        : parsedFields.filter(f => f.category === cat).length}
                      sx={{
                        height: 20,
                        fontSize: "0.7rem",
                        bgcolor: "rgba(0,0,0,0.06)",
                      }}
                    />
                  </Box>
                } 
              />
            ))}
          </Tabs>
        </Box>

        {/* Table */}
        <Paper
          elevation={0}
          sx={{
            flex: 1,
            overflow: "hidden",
            borderRadius: 2,
            border: "1px solid rgba(0,0,0,0.06)",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {logsLoading ? (
            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "center", flex: 1 }}>
              <CircularLoader open={logsLoading} />
            </Box>
          ) : !hasProcessedData || parsedFields.length === 0 ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                flex: 1,
                color: "#6B778C",
              }}
            >
              <DescriptionOutlinedIcon sx={{ fontSize: 48, color: "#D0D0CE", mb: 2 }} />
              <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
                No extraction data available
              </Typography>
              <Typography variant="body2" sx={{ color: "#A5ADBA" }}>
                Process documents in Configurations to view attributions
              </Typography>
            </Box>
          ) : (
            <TableContainer sx={{ flex: 1 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ width: 40, bgcolor: "#F5F7F9", fontWeight: 600 }}></TableCell>
                    <TableCell sx={{ bgcolor: "#F5F7F9", fontWeight: 600 }}>Field Name</TableCell>
                    <TableCell sx={{ bgcolor: "#F5F7F9", fontWeight: 600 }}>Value</TableCell>
                    <TableCell sx={{ bgcolor: "#F5F7F9", fontWeight: 600 }}>Source</TableCell>
                    <TableCell sx={{ bgcolor: "#F5F7F9", fontWeight: 600, width: 100 }}>Page</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredFields.map((field) => {
                    const isExpanded = expandedRows.has(field.id);
                    const firstSource = field.sourceFiles[0] || "";
                    const { docName, page } = parseSourceFile(firstSource);

                    return (
                      <React.Fragment key={field.id}>
                        <TableRow
                          hover
                          onClick={() => toggleRowExpand(field.id)}
                          sx={{ 
                            cursor: "pointer",
                            bgcolor: isExpanded ? "rgba(134, 188, 37, 0.04)" : "inherit",
                            "&:hover": { bgcolor: "rgba(134, 188, 37, 0.08)" },
                          }}
                        >
                          <TableCell sx={{ py: 1.5 }}>
                            <IconButton size="small">
                              {isExpanded ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                            </IconButton>
                          </TableCell>
                          <TableCell sx={{ py: 1.5 }}>
                            <Typography variant="body2" sx={{ fontWeight: 500 }}>
                              {field.fieldName}
                            </Typography>
                          </TableCell>
                          <TableCell sx={{ py: 1.5 }}>
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                fontWeight: 600, 
                                color: "#26890D",
                                fontFamily: "monospace",
                              }}
                            >
                              {typeof field.value === "number" 
                                ? field.value.toLocaleString() 
                                : field.value}
                            </Typography>
                          </TableCell>
                          <TableCell sx={{ py: 1.5 }}>
                            <Tooltip title={docName}>
                              <Chip
                                size="small"
                                label={docName.length > 30 ? docName.substring(0, 30) + "..." : docName}
                                sx={{
                                  height: 24,
                                  bgcolor: "rgba(0, 124, 176, 0.1)",
                                  color: "#007CB0",
                                  fontSize: "0.75rem",
                                  maxWidth: 200,
                                }}
                              />
                            </Tooltip>
                          </TableCell>
                          <TableCell sx={{ py: 1.5 }}>
                            {page && (
                              <Chip
                                size="small"
                                label={`p. ${page}`}
                                sx={{
                                  height: 22,
                                  bgcolor: "rgba(38, 137, 13, 0.1)",
                                  color: "#26890D",
                                  fontSize: "0.75rem",
                                  fontWeight: 600,
                                }}
                              />
                            )}
                          </TableCell>
                        </TableRow>
                        
                        {/* Expanded Details Row */}
                        <TableRow>
                          <TableCell colSpan={5} sx={{ py: 0, borderBottom: isExpanded ? undefined : "none" }}>
                            <Collapse in={isExpanded} timeout="auto" unmountOnExit>
                              <Box sx={{ py: 2, px: 2, bgcolor: "#FAFBFC", borderRadius: 1, my: 1 }}>
                                {/* Explanation */}
                                <Typography variant="caption" sx={{ color: "#6B778C", fontWeight: 600, display: "block", mb: 0.5 }}>
                                  EXPLANATION
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 2, lineHeight: 1.6 }}>
                                  {field.explanation || "No explanation available"}
                                </Typography>

                                {/* Source Fields */}
                                {field.sourceFields.length > 0 && (
                                  <>
                                    <Typography variant="caption" sx={{ color: "#6B778C", fontWeight: 600, display: "block", mb: 0.5 }}>
                                      SOURCE FIELDS
                                    </Typography>
                                    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5, mb: 2 }}>
                                      {field.sourceFields.map((sf, idx) => (
                                        <Chip
                                          key={idx}
                                          size="small"
                                          label={sf}
                                          sx={{
                                            height: 22,
                                            bgcolor: "rgba(0,0,0,0.06)",
                                            fontSize: "0.75rem",
                                          }}
                                        />
                                      ))}
                                    </Box>
                                  </>
                                )}

                                {/* All Source Files */}
                                {field.sourceFiles.length > 0 && (
                                  <>
                                    <Typography variant="caption" sx={{ color: "#6B778C", fontWeight: 600, display: "block", mb: 0.5 }}>
                                      SOURCE FILES
                                    </Typography>
                                    <Box sx={{ display: "flex", flexDirection: "column", gap: 0.5 }}>
                                      {field.sourceFiles.map((sf, idx) => {
                                        const parsed = parseSourceFile(sf);
                                        return (
                                          <Box key={idx} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                                            <DescriptionOutlinedIcon sx={{ fontSize: 14, color: "#007CB0" }} />
                                            <Typography variant="body2" sx={{ color: "#007CB0" }}>
                                              {parsed.docName}
                                            </Typography>
                                            {parsed.page && (
                                              <Chip
                                                size="small"
                                                label={`Page ${parsed.page}`}
                                                sx={{
                                                  height: 20,
                                                  bgcolor: "rgba(38, 137, 13, 0.1)",
                                                  color: "#26890D",
                                                  fontSize: "0.7rem",
                                                }}
                                              />
                                            )}
                                          </Box>
                                        );
                                      })}
                                    </Box>
                                  </>
                                )}
                              </Box>
                            </Collapse>
                          </TableCell>
                        </TableRow>
                      </React.Fragment>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Paper>
      </Box>

      {/* Right Panel - Chat (Fixed) */}
      <Box
        sx={{
          width: 380,
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          p: 3,
          pl: 1.5,
          position: "sticky",
          top: 0,
        }}
      >
        <ChatPanel
          title="Fortuna Assistant"
          placeholder="Ask about extractions..."
          disabled={!hasProcessedData}
          disabledMessage="Process documents to enable the assistant"
          agentLogs={agentLogs}
        />
      </Box>

      {/* Fixed Download Button */}
      <Box
        sx={{
          position: "fixed",
          bottom: 24,
          right: 420,
          zIndex: 1000,
        }}
      >
        <Tooltip title={currentDebtor ? "Download Excel report" : "No data to download"}>
          <span>
            <Button
              variant="contained"
              onClick={handleDownload}
              disabled={!currentDebtor || loading}
              startIcon={<DownloadIcon />}
              sx={{
                bgcolor: "#1a1a1a",
                color: "#fff",
                fontWeight: 600,
                px: 3,
                py: 1.25,
                borderRadius: 2,
                boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
                "&:hover": {
                  bgcolor: "#2d2d2d",
                },
                "&:disabled": {
                  bgcolor: "#E6E6E6",
                  color: "#A5ADBA",
                },
              }}
            >
              Download Report
            </Button>
          </span>
        </Tooltip>
      </Box>

      {loading && <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />}
    </Box>
  );
}
