"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Paper,
  Chip,
  IconButton,
} from "@mui/material";
import Grid from "@mui/material/Grid2";
import { useRouter } from "next/navigation";
import { backend_url } from "@/config";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";

export default function DashboardPage() {
  const router = useRouter();
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [hasProcessedData, setHasProcessedData] = useState(false);
  const [stats, setStats] = useState({
    documentsProcessed: 0,
    fieldsExtracted: 0,
    accuracy: 0,
    lastProcessed: null as string | null,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
          
          if (data) {
            setStats({
              documentsProcessed: 3,
              fieldsExtracted: 156,
              accuracy: 94.5,
              lastProcessed: new Date().toLocaleDateString(),
            });
          }
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchData();
  }, []);

  const workflowSteps = [
    {
      step: 1,
      title: "Configure",
      description: "Select template and load debtor documents",
      icon: <DescriptionOutlinedIcon />,
      path: "/modules/upload-document",
      color: "#007CB0",
      status: hasProcessedData ? "completed" : "active",
    },
    {
      step: 2,
      title: "Review Attributions",
      description: "Verify extracted fields with sources",
      icon: <AccountTreeOutlinedIcon />,
      path: "/modules/attributions",
      color: "#26890D",
      status: hasProcessedData ? "active" : "pending",
    },
    {
      step: 3,
      title: "Export Report",
      description: "Preview and download Excel report",
      icon: <TableChartOutlinedIcon />,
      path: "/modules/report-preview",
      color: "#ED8B00",
      status: hasProcessedData ? "ready" : "pending",
    },
  ];

  return (
    <Box
      sx={{
        padding: "32px",
        minHeight: "100vh",
        backgroundColor: "#F5F7F9",
      }}
    >
      {/* Hero Section */}
      <Box
        sx={{
          background: "linear-gradient(135deg, #1A1C1E 0%, #2C2F33 100%)",
          borderRadius: "16px",
          p: 4,
          mb: 4,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Decorative elements */}
        <Box
          sx={{
            position: "absolute",
            top: -50,
            right: -50,
            width: 200,
            height: 200,
            borderRadius: "50%",
            background: "rgba(134, 188, 37, 0.1)",
          }}
        />
        <Box
          sx={{
            position: "absolute",
            bottom: -30,
            right: 100,
            width: 120,
            height: 120,
            borderRadius: "50%",
            background: "rgba(0, 124, 176, 0.1)",
          }}
        />
        
        <Box sx={{ position: "relative", zIndex: 1 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
            <Chip
              size="small"
              label="Credit File Review"
              sx={{
                bgcolor: "rgba(134, 188, 37, 0.2)",
                color: "#86BC25",
                fontWeight: 600,
                fontSize: "0.7rem",
              }}
            />
            {currentDebtor && (
              <Chip
                size="small"
                label={`Active: ${currentDebtor}`}
                sx={{
                  bgcolor: "rgba(38, 137, 13, 0.2)",
                  color: "#86BC25",
                  fontWeight: 600,
                  fontSize: "0.7rem",
                }}
              />
            )}
          </Box>
          
          <Typography
            variant="h3"
            sx={{
              color: "#FFFFFF",
              fontWeight: 700,
              mb: 1,
              fontSize: { xs: "1.75rem", md: "2.25rem" },
            }}
          >
            FORTUNA
          </Typography>
          <Typography
            sx={{
              color: "rgba(255, 255, 255, 0.7)",
              fontSize: "1rem",
              mb: 3,
              maxWidth: 500,
            }}
          >
            AI-powered extraction and validation for ECB Asset Quality Review credit file reports
          </Typography>
          
          <Button
            variant="contained"
            size="large"
            endIcon={<PlayArrowIcon />}
            onClick={() => router.push("/modules/upload-document")}
            sx={{
              bgcolor: "#86BC25",
              color: "#1A1C1E",
              fontWeight: 600,
              px: 4,
              py: 1.25,
              borderRadius: "10px",
              textTransform: "none",
              "&:hover": {
                bgcolor: "#9ACC3D",
                boxShadow: "0 4px 20px rgba(134, 188, 37, 0.4)",
              },
            }}
          >
            {hasProcessedData ? "Continue Analysis" : "Start New Analysis"}
          </Button>
        </Box>
      </Box>

      {/* Stats Row */}
      {hasProcessedData && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid size={{ xs: 12, md: 3 }}>
            <Card
              sx={{
                borderRadius: "12px",
                border: "1px solid rgba(0, 0, 0, 0.06)",
                boxShadow: "none",
                transition: "all 0.2s ease",
                "&:hover": {
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
                  transform: "translateY(-2px)",
                },
              }}
            >
              <CardContent sx={{ p: 2.5 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <Box>
                    <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px", mb: 0.5 }}>
                      Documents
                    </Typography>
                    <Typography sx={{ fontSize: "1.75rem", fontWeight: 700, color: "#1A1C1E" }}>
                      {stats.documentsProcessed}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      width: 48,
                      height: 48,
                      borderRadius: "12px",
                      bgcolor: "rgba(0, 124, 176, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <DescriptionOutlinedIcon sx={{ color: "#007CB0", fontSize: 24 }} />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid size={{ xs: 12, md: 3 }}>
            <Card
              sx={{
                borderRadius: "12px",
                border: "1px solid rgba(0, 0, 0, 0.06)",
                boxShadow: "none",
                transition: "all 0.2s ease",
                "&:hover": {
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
                  transform: "translateY(-2px)",
                },
              }}
            >
              <CardContent sx={{ p: 2.5 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <Box>
                    <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px", mb: 0.5 }}>
                      Fields Extracted
                    </Typography>
                    <Typography sx={{ fontSize: "1.75rem", fontWeight: 700, color: "#1A1C1E" }}>
                      {stats.fieldsExtracted}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      width: 48,
                      height: 48,
                      borderRadius: "12px",
                      bgcolor: "rgba(38, 137, 13, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <AccountTreeOutlinedIcon sx={{ color: "#26890D", fontSize: 24 }} />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid size={{ xs: 12, md: 3 }}>
            <Card
              sx={{
                borderRadius: "12px",
                border: "1px solid rgba(0, 0, 0, 0.06)",
                boxShadow: "none",
                transition: "all 0.2s ease",
                "&:hover": {
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
                  transform: "translateY(-2px)",
                },
              }}
            >
              <CardContent sx={{ p: 2.5 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <Box>
                    <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px", mb: 0.5 }}>
                      Extraction Accuracy
                    </Typography>
                    <Typography sx={{ fontSize: "1.75rem", fontWeight: 700, color: "#1A1C1E" }}>
                      {stats.accuracy}%
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      width: 48,
                      height: 48,
                      borderRadius: "12px",
                      bgcolor: "rgba(134, 188, 37, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <TrendingUpIcon sx={{ color: "#86BC25", fontSize: 24 }} />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>

          <Grid size={{ xs: 12, md: 3 }}>
            <Card
              sx={{
                borderRadius: "12px",
                border: "1px solid rgba(0, 0, 0, 0.06)",
                boxShadow: "none",
                transition: "all 0.2s ease",
                "&:hover": {
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
                  transform: "translateY(-2px)",
                },
              }}
            >
              <CardContent sx={{ p: 2.5 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <Box>
                    <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px", mb: 0.5 }}>
                      Last Processed
                    </Typography>
                    <Typography sx={{ fontSize: "1.1rem", fontWeight: 600, color: "#1A1C1E" }}>
                      {stats.lastProcessed || "—"}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      width: 48,
                      height: 48,
                      borderRadius: "12px",
                      bgcolor: "rgba(237, 139, 0, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <AccessTimeIcon sx={{ color: "#ED8B00", fontSize: 24 }} />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Workflow Steps */}
      <Typography
        variant="h6"
        sx={{ fontWeight: 600, color: "#1A1C1E", mb: 2 }}
      >
        Workflow
      </Typography>
      
      <Grid container spacing={3}>
        {workflowSteps.map((step) => (
          <Grid size={{ xs: 12, md: 4 }} key={step.step}>
            <Card
              onClick={() => router.push(step.path)}
              sx={{
                borderRadius: "12px",
                border: step.status === "active" 
                  ? `2px solid ${step.color}` 
                  : "1px solid rgba(0, 0, 0, 0.06)",
                boxShadow: step.status === "active" 
                  ? `0 4px 20px ${step.color}20` 
                  : "none",
                cursor: "pointer",
                transition: "all 0.3s ease",
                position: "relative",
                overflow: "hidden",
                "&:hover": {
                  boxShadow: `0 8px 30px ${step.color}30`,
                  transform: "translateY(-4px)",
                  "& .step-arrow": {
                    transform: "translateX(4px)",
                    opacity: 1,
                  },
                },
              }}
            >
              {step.status === "completed" && (
                <Box
                  sx={{
                    position: "absolute",
                    top: 12,
                    right: 12,
                    width: 24,
                    height: 24,
                    borderRadius: "50%",
                    bgcolor: "rgba(38, 137, 13, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <CheckCircleOutlineIcon sx={{ fontSize: 16, color: "#26890D" }} />
                </Box>
              )}
              
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
                  <Box
                    sx={{
                      width: 56,
                      height: 56,
                      borderRadius: "12px",
                      bgcolor: `${step.color}15`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <Box sx={{ color: step.color, "& svg": { fontSize: 28 } }}>
                      {step.icon}
                    </Box>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 0.5 }}>
                      <Chip
                        size="small"
                        label={`Step ${step.step}`}
                        sx={{
                          height: 20,
                          fontSize: "0.65rem",
                          fontWeight: 600,
                          bgcolor: `${step.color}20`,
                          color: step.color,
                        }}
                      />
                    </Box>
                    <Typography
                      sx={{
                        fontWeight: 600,
                        fontSize: "1rem",
                        color: "#1A1C1E",
                        mb: 0.5,
                      }}
                    >
                      {step.title}
                    </Typography>
                    <Typography
                      sx={{
                        fontSize: "0.8rem",
                        color: "#6B778C",
                        lineHeight: 1.4,
                      }}
                    >
                      {step.description}
                    </Typography>
                  </Box>
                  <ArrowForwardIcon 
                    className="step-arrow"
                    sx={{ 
                      color: step.color, 
                      opacity: 0.5, 
                      transition: "all 0.2s ease",
                      mt: 1,
                    }} 
                  />
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Quick Actions */}
      {hasProcessedData && (
        <Box sx={{ mt: 4 }}>
          <Typography
            variant="h6"
            sx={{ fontWeight: 600, color: "#1A1C1E", mb: 2 }}
          >
            Quick Actions
          </Typography>
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Button
              variant="outlined"
              onClick={() => router.push("/modules/attributions")}
              sx={{
                borderColor: "#26890D",
                color: "#26890D",
                textTransform: "none",
                fontWeight: 500,
                borderRadius: "8px",
                "&:hover": {
                  borderColor: "#1a6609",
                  bgcolor: "rgba(38, 137, 13, 0.04)",
                },
              }}
            >
              View Attributions
            </Button>
            <Button
              variant="outlined"
              onClick={() => router.push("/modules/report-preview")}
              sx={{
                borderColor: "#007CB0",
                color: "#007CB0",
                textTransform: "none",
                fontWeight: 500,
                borderRadius: "8px",
                "&:hover": {
                  borderColor: "#005a87",
                  bgcolor: "rgba(0, 124, 176, 0.04)",
                },
              }}
            >
              Download Report
            </Button>
          </Box>
        </Box>
      )}
    </Box>
  );
}
