import { AppRouterCacheProvider } from "@mui/material-nextjs/v13-appRouter";
import App from "@/app/(main)/app";
import "@/app/globals.css";

export const metadata = {
  title: "FORTUNA | Deloitte aiStudio",
  description: "AI-powered Credit File Review automation for ECB Asset Quality Reviews",
};

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/icon.ico" sizes="any" />
        <meta name="theme-color" content="#86BC25" />
      </head>
      <body>
        <AppRouterCacheProvider>
          <App>{children}</App>
        </AppRouterCacheProvider>
      </body>
    </html>
  );
}
