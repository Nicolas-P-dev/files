"use client";

import React, { createContext, useState, useEffect, useCallback, ReactNode } from "react";
import { backend_url } from "@/config";

interface AgentLogsContextType {
  logs: Record<string, any>;
  logsLoading: boolean;
  hasDebtor: boolean;
  fetchAgentLogs: () => Promise<void>;
  clearLogs: () => void;
}

export const AgentLogsContext = createContext<AgentLogsContextType>({
  logs: {},
  logsLoading: false,
  hasDebtor: false,
  fetchAgentLogs: async () => {},
  clearLogs: () => {},
});

interface AgentLogsProviderProps {
  children: ReactNode;
}

export const AgentLogsProvider: React.FC<AgentLogsProviderProps> = ({ children }) => {
  const [logs, setLogs] = useState<Record<string, any>>({});
  const [logsLoading, setLogsLoading] = useState(false);
  const [hasDebtor, setHasDebtor] = useState(false);

  const fetchAgentLogs = useCallback(async () => {
    setLogsLoading(true);

    try {
      // Check if debtor is selected
      const debtorCheckRoute = `${backend_url}/get_current_debtor`;
      const debtorResponse = await fetch(debtorCheckRoute, { method: "GET" });

      if (!debtorResponse.ok) {
        console.log("No debtor selected yet, skipping agent logs fetch");
        setLogsLoading(false);
        setHasDebtor(false);
        return;
      }

      setHasDebtor(true);

      // Fetch agent logs
      const apiRoute = `${backend_url}/get_agent_logs`;
      const response = await fetch(apiRoute, { method: "GET" });

      if (!response.ok) {
        console.error("Failed to fetch agent logs:", response.statusText);
        setLogsLoading(false);
        return;
      }

      const data = await response.json();
      console.log("Fetched agent logs from server");

      if (data.status === "no_debtor") {
        console.log("No debtor selected, cannot fetch logs");
        setLogs({});
      } else {
        setLogs(data);
        // Cache in localStorage for persistence
        try {
          localStorage.setItem("agentLogs", JSON.stringify(data));
        } catch (e) {
          console.warn("Could not cache agent logs:", e);
        }
      }
    } catch (error) {
      console.error("Error fetching agent logs:", error);
      
      // Try to restore from cache on error
      try {
        const cached = localStorage.getItem("agentLogs");
        if (cached) {
          const cachedLogs = JSON.parse(cached);
          setLogs(cachedLogs);
          console.log("Restored agent logs from cache");
        } else {
          setLogs({});
        }
      } catch (e) {
        setLogs({});
      }
    } finally {
      setLogsLoading(false);
    }
  }, []);

  const clearLogs = useCallback(() => {
    setLogs({});
    try {
      localStorage.removeItem("agentLogs");
    } catch (e) {
      console.warn("Could not clear cached logs:", e);
    }
  }, []);

  // Initial fetch on mount
  useEffect(() => {
    fetchAgentLogs();
  }, [fetchAgentLogs]);

  // Try to restore from cache on mount
  useEffect(() => {
    try {
      const cached = localStorage.getItem("agentLogs");
      if (cached && Object.keys(logs).length === 0) {
        const cachedLogs = JSON.parse(cached);
        if (cachedLogs && typeof cachedLogs === "object" && Object.keys(cachedLogs).length > 0) {
          setLogs(cachedLogs);
          console.log("Restored agent logs from cache on mount");
        }
      }
    } catch (e) {
      console.warn("Could not restore cached logs:", e);
    }
  }, []);

  return (
    <AgentLogsContext.Provider
      value={{
        logs,
        logsLoading,
        hasDebtor,
        fetchAgentLogs,
        clearLogs,
      }}
    >
      {children}
    </AgentLogsContext.Provider>
  );
};
