"use client";

import React, { useState, useEffect } from "react";
import { Box } from "@mui/material";
import Sidebar from "./Sidebar";
import { backend_url } from "@/config";

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        
        if (!response.ok) {
          if (response.status === 404) {
            setCurrentDebtor(null);
            return;
          }
          throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        setCurrentDebtor(data);
      } catch (error) {
        console.error("Error fetching current debtor:", error);
        setCurrentDebtor(null);
      }
    };

    fetchCurrentDebtor();

    // Poll for debtor changes every 5 seconds
    const interval = setInterval(fetchCurrentDebtor, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "#F5F7F9" }}>
      {/* Sidebar Navigation */}
      <Sidebar currentDebtor={currentDebtor} />

      {/* Main Content Area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          marginLeft: "280px", // Match sidebar width
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

export default MainLayout;
