"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import HistoryIcon from "@mui/icons-material/History";
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import SourceOutlinedIcon from "@mui/icons-material/SourceOutlined";
import SwapHorizIcon from "@mui/icons-material/SwapHoriz";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";

interface SidebarProps {
  currentDebtor: string | null;
}

const Sidebar: React.FC<SidebarProps> = ({ currentDebtor }) => {
  const pathname = usePathname();
  const [helpOpen, setHelpOpen] = useState(false);

  // Main workflow navigation
  const workflowItems = [
    {
      label: "Dashboard",
      path: "/",
      icon: <DashboardOutlinedIcon />,
      enabled: true,
    },
    {
      label: "Configurations",
      path: "/modules/upload-document",
      icon: <SettingsIcon />,
      enabled: true,
    },
    {
      label: "Attributions",
      path: "/modules/attributions",
      icon: <SourceOutlinedIcon />,
      enabled: true,
      badge: currentDebtor ? "Ready" : null,
    },
    {
      label: "Report Preview",
      path: "/modules/report-preview",
      icon: <TableChartOutlinedIcon />,
      enabled: true,
    },
  ];

  // Data management section
  const dataItems = [
    {
      label: "Data Exchanges",
      path: "/modules/data-exchanges",
      icon: <SwapHorizIcon />,
      enabled: true,
    },
    {
      label: "Saved Documents",
      path: "/modules/saved-documents",
      icon: <BookmarkBorderIcon />,
      enabled: false,
    },
    {
      label: "History",
      path: "/modules/history",
      icon: <HistoryIcon />,
      enabled: false,
    },
  ];

  const isSelected = (path: string) => {
    if (path === "/" && pathname === "/") return true;
    if (path !== "/" && pathname?.startsWith(path)) return true;
    return false;
  };

  const NavItem = ({ item }: { item: typeof workflowItems[0] }) => (
    <ListItem disablePadding sx={{ mb: 0.5 }}>
      {item.enabled ? (
        <Link href={item.path} style={{ textDecoration: "none", width: "100%" }}>
          <ListItemButton
            selected={isSelected(item.path)}
            sx={{
              borderRadius: 2,
              py: 1.25,
              px: 2,
              mx: 1,
              "&.Mui-selected": {
                bgcolor: "rgba(134, 188, 37, 0.15)",
                borderLeft: "3px solid #86BC25",
                "& .MuiListItemIcon-root": { color: "#86BC25" },
                "& .MuiListItemText-primary": {
                  color: "#FFFFFF",
                  fontWeight: 600,
                },
              },
              "&:hover": {
                bgcolor: "rgba(255, 255, 255, 0.08)",
              },
            }}
          >
            <ListItemIcon
              sx={{
                minWidth: 40,
                color: isSelected(item.path) ? "#86BC25" : "rgba(255,255,255,0.7)",
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.label}
              sx={{
                "& .MuiListItemText-primary": {
                  color: "rgba(255,255,255,0.9)",
                  fontSize: "0.9rem",
                  fontWeight: isSelected(item.path) ? 600 : 400,
                },
              }}
            />
            {item.badge && (
              <Badge
                badgeContent={item.badge}
                sx={{
                  "& .MuiBadge-badge": {
                    bgcolor: "#86BC25",
                    color: "#000",
                    fontSize: "0.65rem",
                    fontWeight: 600,
                    height: 20,
                    minWidth: 20,
                  },
                }}
              />
            )}
          </ListItemButton>
        </Link>
      ) : (
        <ListItemButton
          disabled
          sx={{
            borderRadius: 2,
            py: 1.25,
            px: 2,
            mx: 1,
            opacity: 0.4,
          }}
        >
          <ListItemIcon sx={{ minWidth: 40, color: "rgba(255,255,255,0.4)" }}>
            {item.icon}
          </ListItemIcon>
          <ListItemText
            primary={item.label}
            secondary="Coming soon"
            sx={{
              "& .MuiListItemText-primary": {
                color: "rgba(255,255,255,0.5)",
                fontSize: "0.9rem",
              },
              "& .MuiListItemText-secondary": {
                color: "rgba(255,255,255,0.3)",
                fontSize: "0.7rem",
              },
            }}
          />
        </ListItemButton>
      )}
    </ListItem>
  );

  return (
    <>
      <Box
        sx={{
          width: 280,
          height: "100vh",
          background: "linear-gradient(180deg, #000000 0%, #1a1a1a 100%)",
          color: "#FFFFFF",
          display: "flex",
          flexDirection: "column",
          position: "fixed",
          left: 0,
          top: 0,
          zIndex: 1200,
          borderRight: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        {/* Logo and Branding - LARGER */}
        <Box sx={{ pt: 3, px: 3, pb: 2.5 }}>
          <Image
            src="/Deloitte_Logo.png"
            width={140}
            height={36}
            alt="Deloitte Logo"
            style={{ marginBottom: "16px" }}
          />
          <Box sx={{ display: "flex", alignItems: "baseline", gap: 1.5 }}>
            <Typography
              sx={{
                fontWeight: 500,
                color: "rgba(255,255,255,0.6)",
                textTransform: "uppercase",
                letterSpacing: "0.15em",
                fontSize: "0.75rem",
              }}
            >
              aiStudio
            </Typography>
            <Typography
              variant="h5"
              sx={{
                fontWeight: 700,
                color: "#FFFFFF",
                fontSize: "1.5rem",
                letterSpacing: "0.05em",
              }}
            >
              FORTUNA
            </Typography>
          </Box>
        </Box>

        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2.5 }} />

        {/* Current Debtor Status */}
        <Box sx={{ px: 2.5, py: 2 }}>
          <Typography
            variant="overline"
            sx={{
              color: "rgba(255,255,255,0.5)",
              letterSpacing: "0.1em",
              fontSize: "0.65rem",
              fontWeight: 600,
            }}
          >
            Active Debtor
          </Typography>
          <Box
            sx={{
              mt: 1,
              p: 1.5,
              borderRadius: 2,
              bgcolor: currentDebtor
                ? "rgba(134, 188, 37, 0.12)"
                : "rgba(255, 255, 255, 0.04)",
              border: currentDebtor
                ? "1px solid rgba(134, 188, 37, 0.3)"
                : "1px solid rgba(255, 255, 255, 0.1)",
            }}
          >
            <Typography
              sx={{
                color: currentDebtor ? "#86BC25" : "rgba(255,255,255,0.4)",
                fontWeight: currentDebtor ? 600 : 400,
                fontSize: "0.85rem",
              }}
            >
              {currentDebtor || "No debtor selected"}
            </Typography>
            {currentDebtor && (
              <Typography
                sx={{ color: "rgba(134, 188, 37, 0.7)", fontSize: "0.7rem", mt: 0.25 }}
              >
                Ready for processing
              </Typography>
            )}
          </Box>
        </Box>

        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2.5 }} />

        {/* Workflow Navigation */}
        <Box sx={{ py: 2 }}>
          <Typography
            variant="overline"
            sx={{
              color: "rgba(255,255,255,0.5)",
              letterSpacing: "0.1em",
              fontSize: "0.65rem",
              fontWeight: 600,
              px: 3,
              display: "block",
              mb: 1,
            }}
          >
            Workflow
          </Typography>
          <List component="nav" disablePadding>
            {workflowItems.map((item) => (
              <NavItem key={item.label} item={item} />
            ))}
          </List>
        </Box>

        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2.5 }} />

        {/* Data Management */}
        <Box sx={{ py: 2 }}>
          <Typography
            variant="overline"
            sx={{
              color: "rgba(255,255,255,0.5)",
              letterSpacing: "0.1em",
              fontSize: "0.65rem",
              fontWeight: 600,
              px: 3,
              display: "block",
              mb: 1,
            }}
          >
            Data
          </Typography>
          <List component="nav" disablePadding>
            {dataItems.map((item) => (
              <NavItem key={item.label} item={item} />
            ))}
          </List>
        </Box>

        {/* Spacer */}
        <Box sx={{ flex: 1 }} />

        {/* Bottom Section - Help & Version */}
        <Box sx={{ mt: "auto" }}>
          <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2.5 }} />
          
          {/* Help & Docs Button */}
          <List component="nav" sx={{ px: 1, py: 1.5 }}>
            <ListItem disablePadding>
              <ListItemButton
                onClick={() => setHelpOpen(true)}
                sx={{
                  borderRadius: 2,
                  py: 1,
                  px: 2,
                  mx: 1,
                  "&:hover": { bgcolor: "rgba(255, 255, 255, 0.06)" },
                }}
              >
                <ListItemIcon sx={{ minWidth: 40, color: "rgba(255,255,255,0.6)" }}>
                  <HelpOutlineIcon />
                </ListItemIcon>
                <ListItemText
                  primary="Help & Docs"
                  sx={{
                    "& .MuiListItemText-primary": {
                      color: "rgba(255,255,255,0.7)",
                      fontSize: "0.85rem",
                    },
                  }}
                />
              </ListItemButton>
            </ListItem>
          </List>
          
          {/* Version footer */}
          <Box sx={{ px: 3, py: 2, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <Typography
              sx={{ color: "rgba(255,255,255,0.3)", fontSize: "0.7rem" }}
            >
              FORTUNA v1.0.0 • CFR Automation
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Help Dialog */}
      <Dialog 
        open={helpOpen} 
        onClose={() => setHelpOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ fontWeight: 600 }}>
          Help & Documentation
        </DialogTitle>
        <DialogContent>
          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, color: "#26890D" }}>
            Getting Started
          </Typography>
          <Typography variant="body2" sx={{ mb: 2, color: "#6B778C" }}>
            1. Go to <strong>Configurations</strong> and select a template and debtor<br />
            2. Review and process the loaded documents<br />
            3. View extracted data in <strong>Attributions</strong> with full source references<br />
            4. Download your completed report from <strong>Report Preview</strong>
          </Typography>
          
          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, color: "#26890D" }}>
            Understanding Attributions
          </Typography>
          <Typography variant="body2" sx={{ mb: 2, color: "#6B778C" }}>
            Each extracted field shows:<br />
            • <strong>Value</strong>: The extracted data<br />
            • <strong>Source</strong>: Document name and page number<br />
            • <strong>Explanation</strong>: How the value was derived
          </Typography>

          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, color: "#26890D" }}>
            Support
          </Typography>
          <Typography variant="body2" sx={{ color: "#6B778C" }}>
            For technical support or questions, contact the aiStudio team.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button 
            onClick={() => setHelpOpen(false)}
            variant="contained"
            sx={{ 
              bgcolor: "#86BC25", 
              color: "#000",
              "&:hover": { bgcolor: "#9acd32" }
            }}
          >
            Got it
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default Sidebar;
