"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  IconButton,
  Paper,
  InputAdornment,
  Avatar,
  CircularProgress,
  Chip,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  sources?: Array<{ doc: string; page: string }>;
}

interface ChatPanelProps {
  title?: string;
  placeholder?: string;
  disabled?: boolean;
  disabledMessage?: string;
  agentLogs?: Record<string, any>;
}

const ChatPanel: React.FC<ChatPanelProps> = ({
  title = "Fortuna Assistant",
  placeholder = "Ask about extractions...",
  disabled = false,
  disabledMessage = "Process documents first to enable chat",
  agentLogs,
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Generate contextual response based on query and agent logs
  const generateResponse = (query: string): Message => {
    const lowerQuery = query.toLowerCase();
    let response = "";
    let sources: Array<{ doc: string; page: string }> = [];

    // Check if we have agent logs
    const hasLogs = agentLogs && Object.keys(agentLogs).length > 0;

    // Try to find relevant data in agent logs
    if (hasLogs) {
      // Search through agent logs for relevant field
      const searchInLogs = (obj: any, searchTerms: string[]): any => {
        for (const [key, value] of Object.entries(obj)) {
          const keyLower = key.toLowerCase();
          if (searchTerms.some(term => keyLower.includes(term))) {
            return { key, value };
          }
          if (typeof value === "object" && value !== null && !value["Field Value"]) {
            const found = searchInLogs(value, searchTerms);
            if (found) return found;
          }
        }
        return null;
      };

      // Asset queries
      if (lowerQuery.includes("asset") || lowerQuery.includes("property") || lowerQuery.includes("plant")) {
        const found = searchInLogs(agentLogs, ["asset", "property", "plant", "equipment"]);
        if (found) {
          const fieldData = found.value;
          if (fieldData["Field Value"] !== undefined) {
            response = `**${found.key}**\n\n`;
            response += `**Value:** ${typeof fieldData["Field Value"] === "number" ? fieldData["Field Value"].toLocaleString() : fieldData["Field Value"]}\n\n`;
            if (fieldData.Explanation) {
              response += `**Explanation:** ${fieldData.Explanation}\n\n`;
            }
            if (fieldData["Source Files"]) {
              response += `**Sources:** ${fieldData["Source Files"].join(", ")}`;
              sources = fieldData["Source Files"].map((s: string) => {
                const pageMatch = s.match(/Page_num:\s*(\d+)/);
                return { doc: s.replace(/\s*\[Page_num:.*\]/, ""), page: pageMatch?.[1] || "" };
              });
            }
          } else {
            response = `I found data about **${found.key}**. This section contains multiple fields. You can see all the extracted values in the Attributions table on the left. Click on any row to see the full details including source documents and page numbers.`;
          }
        } else {
          response = "I found asset-related data in the extractions. Check the **Assets** tab in the Attributions table to see all extracted asset fields with their values, sources, and explanations.";
        }
      }
      // Liability queries
      else if (lowerQuery.includes("liabilit") || lowerQuery.includes("debt") || lowerQuery.includes("payable")) {
        const found = searchInLogs(agentLogs, ["liabilit", "debt", "payable", "borrowing"]);
        if (found && found.value["Field Value"] !== undefined) {
          const fieldData = found.value;
          response = `**${found.key}**\n\n`;
          response += `**Value:** ${typeof fieldData["Field Value"] === "number" ? fieldData["Field Value"].toLocaleString() : fieldData["Field Value"]}\n\n`;
          if (fieldData.Explanation) response += `**Explanation:** ${fieldData.Explanation}`;
        } else {
          response = "I found liability-related data. Check the **Liabilities** tab in the Attributions table to see all extracted liability fields.";
        }
      }
      // Equity queries
      else if (lowerQuery.includes("equity") || lowerQuery.includes("capital") || lowerQuery.includes("retained")) {
        response = "Equity data has been extracted from the financial statements. Check the **Equity** tab in the Attributions table to see share capital, retained earnings, and other equity components with their source references.";
      }
      // P&L queries
      else if (lowerQuery.includes("p&l") || lowerQuery.includes("profit") || lowerQuery.includes("loss") || lowerQuery.includes("revenue") || lowerQuery.includes("income")) {
        response = "Profit & Loss data is available in the extractions. Check the **P&L** tab to see revenue, expenses, and profit figures with their source documents.";
      }
      // Cash flow queries
      else if (lowerQuery.includes("cash") || lowerQuery.includes("flow")) {
        response = "Cash flow data has been extracted. Check the **Cash Flow** tab to see operating, investing, and financing activities.";
      }
      // Source/attribution queries
      else if (lowerQuery.includes("source") || lowerQuery.includes("where") || lowerQuery.includes("document") || lowerQuery.includes("page")) {
        response = "Each extracted field includes full source attribution. In the Attributions table:\n\n• **Source column** shows the document name\n• **Page column** shows the exact page number\n• **Click any row** to expand and see the full explanation and all source files\n\nThis ensures complete audit traceability.";
      }
      // How it works queries
      else if (lowerQuery.includes("how") && (lowerQuery.includes("work") || lowerQuery.includes("extract"))) {
        response = "FORTUNA uses specialized AI agents to extract data:\n\n1. **Document Processing** - PDFs are analyzed and text is extracted\n2. **Field Extraction** - AI agents identify relevant values for each template field\n3. **Attribution** - Each value is linked to its source document and page\n4. **Validation** - Cross-references are checked for consistency\n\nYou can verify any extraction by checking the source document directly.";
      }
      // Count/summary queries
      else if (lowerQuery.includes("how many") || lowerQuery.includes("count") || lowerQuery.includes("total")) {
        // Count fields in logs
        let count = 0;
        const countFields = (obj: any) => {
          for (const value of Object.values(obj)) {
            if (typeof value === "object" && value !== null) {
              if ((value as any)["Field Value"] !== undefined) count++;
              else countFields(value);
            }
          }
        };
        countFields(agentLogs);
        response = `I found **${count} fields** extracted from the documents. You can browse them by category using the tabs (Assets, Liabilities, Equity, P&L, Cash Flow) or search for specific fields.`;
      }
      // Default with data
      else {
        response = `I have access to the extracted data. Here's what I can help you with:\n\n• **Ask about specific fields** - "What is the Plant value?" or "Show me the equity data"\n• **Ask about sources** - "Where did this value come from?"\n• **Ask about methodology** - "How does the extraction work?"\n\nYou can also browse the Attributions table and click on any row to see full details.`;
      }
    } else {
      // No data available
      response = "I don't have access to extracted data yet. Please process documents in the Configurations page first, then return here to explore the attributions.";
    }

    return {
      id: `assistant_${Date.now()}`,
      role: "assistant",
      content: response,
      timestamp: new Date(),
      sources: sources.length > 0 ? sources : undefined,
    };
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || disabled || isLoading) return;

    const userMessage: Message = {
      id: `user_${Date.now()}`,
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const query = inputValue.trim();
    setInputValue("");
    setIsLoading(true);

    // Simulate brief delay for natural feel
    setTimeout(() => {
      const response = generateResponse(query);
      setMessages((prev) => [...prev, response]);
      setIsLoading(false);
    }, 500);
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        border: "1px solid rgba(0, 0, 0, 0.08)",
        borderRadius: 3,
        overflow: "hidden",
        bgcolor: "#FFFFFF",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 2.5,
          py: 2,
          bgcolor: "#1A1C1E",
          color: "#FFFFFF",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 32,
              height: 32,
              borderRadius: 1.5,
              bgcolor: "#86BC25",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
              fontSize: "0.9rem",
              color: "#000",
            }}
          >
            F
          </Box>
          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
            {title}
          </Typography>
        </Box>
        <Chip
          label="Level 1"
          size="small"
          sx={{
            height: 22,
            bgcolor: "rgba(134, 188, 37, 0.2)",
            color: "#86BC25",
            fontSize: "0.7rem",
            fontWeight: 600,
          }}
        />
      </Box>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: "auto",
          p: 2,
          bgcolor: "#FAFBFC",
          display: "flex",
          flexDirection: "column",
          gap: 2,
        }}
      >
        {disabled ? (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              textAlign: "center",
              color: "#6B778C",
            }}
          >
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 2,
                bgcolor: "#E6E6E6",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <Typography sx={{ fontSize: 28, fontWeight: 700, color: "#A5ADBA" }}>F</Typography>
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 500, mb: 0.5 }}>
              {disabledMessage}
            </Typography>
            <Typography variant="caption" sx={{ color: "#A5ADBA" }}>
              Complete document processing to enable the assistant
            </Typography>
          </Box>
        ) : messages.length === 0 ? (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              textAlign: "center",
              color: "#6B778C",
            }}
          >
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 2,
                bgcolor: "rgba(134, 188, 37, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <Typography sx={{ fontSize: 28, fontWeight: 700, color: "#86BC25" }}>F</Typography>
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 500, mb: 1 }}>
              Ask me about the extracted data
            </Typography>
            <Typography variant="caption" sx={{ color: "#A5ADBA", maxWidth: 250 }}>
              Try: "What assets were extracted?" or "How many fields are there?"
            </Typography>
          </Box>
        ) : (
          <>
            {messages.map((message) => (
              <Box
                key={message.id}
                sx={{
                  display: "flex",
                  flexDirection: message.role === "user" ? "row-reverse" : "row",
                  gap: 1.5,
                  alignItems: "flex-start",
                }}
              >
                <Avatar
                  sx={{
                    width: 32,
                    height: 32,
                    bgcolor: message.role === "user" ? "#26890D" : "#1A1C1E",
                    fontSize: "0.8rem",
                    fontWeight: 600,
                  }}
                >
                  {message.role === "user" ? <PersonOutlineIcon sx={{ fontSize: 18 }} /> : "F"}
                </Avatar>
                <Box sx={{ maxWidth: "85%" }}>
                  <Box
                    sx={{
                      p: 2,
                      borderRadius: 2,
                      bgcolor: message.role === "user" ? "#26890D" : "#FFFFFF",
                      color: message.role === "user" ? "#FFFFFF" : "#1A1C1E",
                      border: message.role === "user" ? "none" : "1px solid rgba(0, 0, 0, 0.06)",
                      boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{
                        lineHeight: 1.6,
                        fontSize: "0.85rem",
                        whiteSpace: "pre-line",
                        "& strong": { fontWeight: 600 },
                      }}
                      dangerouslySetInnerHTML={{
                        __html: message.content
                          .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
                          .replace(/\n/g, "<br />"),
                      }}
                    />
                  </Box>
                  {message.sources && message.sources.length > 0 && (
                    <Box sx={{ display: "flex", gap: 0.5, mt: 1, flexWrap: "wrap" }}>
                      {message.sources.map((source, idx) => (
                        <Chip
                          key={idx}
                          label={`${source.doc}${source.page ? ` • p.${source.page}` : ""}`}
                          size="small"
                          sx={{
                            height: 22,
                            bgcolor: "rgba(0, 124, 176, 0.1)",
                            color: "#007CB0",
                            fontSize: "0.7rem",
                          }}
                        />
                      ))}
                    </Box>
                  )}
                </Box>
              </Box>
            ))}

            {isLoading && (
              <Box sx={{ display: "flex", gap: 1.5, alignItems: "flex-start" }}>
                <Avatar sx={{ width: 32, height: 32, bgcolor: "#1A1C1E", fontSize: "0.8rem", fontWeight: 600 }}>
                  F
                </Avatar>
                <Box
                  sx={{
                    p: 2,
                    borderRadius: 2,
                    bgcolor: "#FFFFFF",
                    border: "1px solid rgba(0, 0, 0, 0.06)",
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <CircularProgress size={16} sx={{ color: "#86BC25" }} />
                  <Typography variant="body2" sx={{ color: "#6B778C" }}>
                    Analyzing...
                  </Typography>
                </Box>
              </Box>
            )}

            <div ref={messagesEndRef} />
          </>
        )}
      </Box>

      {/* Input Area */}
      <Box
        sx={{
          p: 2,
          bgcolor: "#FFFFFF",
          borderTop: "1px solid rgba(0, 0, 0, 0.06)",
        }}
      >
        <TextField
          fullWidth
          size="small"
          placeholder={disabled ? "Chat disabled" : placeholder}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={disabled || isLoading}
          multiline
          maxRows={3}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  onClick={handleSendMessage}
                  disabled={disabled || isLoading || !inputValue.trim()}
                  size="small"
                  sx={{
                    bgcolor: inputValue.trim() && !disabled ? "#86BC25" : "transparent",
                    color: inputValue.trim() && !disabled ? "#000" : "#D0D0CE",
                    "&:hover": {
                      bgcolor: inputValue.trim() && !disabled ? "#9acd32" : "transparent",
                    },
                  }}
                >
                  <SendIcon fontSize="small" />
                </IconButton>
              </InputAdornment>
            ),
            sx: {
              borderRadius: 2,
              bgcolor: "#F5F7F9",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "rgba(0,0,0,0.1)",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                borderColor: "rgba(0,0,0,0.2)",
              },
              "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                borderColor: "#86BC25",
              },
            },
          }}
        />
      </Box>
    </Paper>
  );
};

export default ChatPanel;
