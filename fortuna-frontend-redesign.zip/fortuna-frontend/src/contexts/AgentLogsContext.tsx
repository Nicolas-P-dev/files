import React, { createContext, useState, useEffect } from "react";
import { backend_url } from "../config";

interface AgentLogsContextType {
  logs: Record<string, any>;
  logsLoading: boolean;
  hasDebtor: boolean;
  fetchAgentLogs: () => Promise<void>;
}

export const AgentLogsContext = createContext<AgentLogsContextType>({
  logs: {},
  logsLoading: false,
  hasDebtor: false,
  fetchAgentLogs: async () => {},
});

interface AgentLogsProviderProps {
  children: React.ReactNode;
}

export const AgentLogsProvider: React.FC<AgentLogsProviderProps> = ({ children }) => {
  const [logs, setLogs] = useState<Record<string, any>>({});
  const [logsLoading, setLogsLoading] = useState(false);
  const [hasDebtor, setHasDebtor] = useState(false);

  const fetchAgentLogs = async () => {
    setLogsLoading(true);

    try {
      const debtorCheckRoute = `${backend_url}/get_current_debtor`;
      const debtorResponse = await fetch(debtorCheckRoute, { method: "GET" });

      if (!debtorResponse.ok) {
        console.log("No debtor selected yet, skipping agent logs fetch");
        setLogsLoading(false);
        setHasDebtor(false);
        return;
      }

      setHasDebtor(true);

      const apiRoute = `${backend_url}/get_agent_logs`;
      const response = await fetch(apiRoute, { method: "GET" });

      if (!response.ok) {
        console.error("Failed to fetch agent logs:", response.statusText);
        setLogsLoading(false);
        return;
      }

      const data = await response.json();
      console.log("Fetched agent logs from server", data);

      if (data.status === "no_debtor") {
        console.log("No debtor selected, cannot fetch logs");
        setLogs({});
      } else {
        setLogs(data);
        localStorage.setItem("agentLogs", JSON.stringify(data));
        console.log("Saved agent logs in cache");
      }
    } catch (error) {
      console.error("Error fetching agent logs:", error);
      setLogs({});
    } finally {
      setLogsLoading(false);
    }
  };

  useEffect(() => {
    // Try to load from cache first
    const cached = localStorage.getItem("agentLogs");
    if (cached) {
      try {
        const parsedCache = JSON.parse(cached);
        if (parsedCache && typeof parsedCache === "object") {
          setLogs(parsedCache);
        }
      } catch (e) {
        console.log("Failed to parse cached logs");
      }
    }

    // Then fetch fresh data
    fetchAgentLogs();
  }, []);

  return (
    <AgentLogsContext.Provider value={{ logs, logsLoading, hasDebtor, fetchAgentLogs }}>
      {children}
    </AgentLogsContext.Provider>
  );
};
