"use client";

import React from "react";
import { Alert, Snackbar } from "@mui/material";

interface AlertBoxProps {
  message: string;
  severity?: "error" | "warning" | "info" | "success";
  onClose?: () => void;
}

const AlertBox: React.FC<AlertBoxProps> = ({
  message,
  severity = "error",
  onClose,
}) => {
  const [open, setOpen] = React.useState(true);

  const handleClose = () => {
    setOpen(false);
    onClose?.();
  };

  return (
    <Snackbar
      open={open}
      autoHideDuration={6000}
      onClose={handleClose}
      anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
    >
      <Alert
        onClose={handleClose}
        severity={severity}
        variant="filled"
        sx={{
          borderRadius: "10px",
          fontWeight: 500,
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
        }}
      >
        {message}
      </Alert>
    </Snackbar>
  );
};

export default AlertBox;
