"use client";

import React from "react";
import {
  Backdrop,
  CircularProgress,
  Box,
  Typography,
} from "@mui/material";

interface CircularLoaderProps {
  open: boolean;
  loadingMessage?: string;
}

const CircularLoader: React.FC<CircularLoaderProps> = ({
  open,
  loadingMessage = "Processing...",
}) => {
  return (
    <Backdrop
      sx={{
        color: "#fff",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: "rgba(26, 28, 30, 0.85)",
        backdropFilter: "blur(4px)",
      }}
      open={open}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 3,
        }}
      >
        <Box sx={{ position: "relative" }}>
          <CircularProgress
            size={56}
            thickness={3}
            sx={{
              color: "#86BC25",
            }}
          />
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: 32,
              height: 32,
              borderRadius: "8px",
              bgcolor: "#86BC25",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography sx={{ color: "#1A1C1E", fontWeight: 700, fontSize: "0.75rem" }}>
              F
            </Typography>
          </Box>
        </Box>
        <Box sx={{ textAlign: "center" }}>
          <Typography
            variant="body1"
            sx={{
              color: "#FFFFFF",
              fontWeight: 500,
              mb: 0.5,
            }}
          >
            {loadingMessage}
          </Typography>
          <Typography
            variant="body2"
            sx={{
              color: "rgba(255, 255, 255, 0.6)",
              fontSize: "0.8rem",
            }}
          >
            This may take a few minutes
          </Typography>
        </Box>
      </Box>
    </Backdrop>
  );
};

export default CircularLoader;
