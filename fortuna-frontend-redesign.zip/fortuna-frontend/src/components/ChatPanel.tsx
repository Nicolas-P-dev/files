"use client";

import React, { useState, useRef, useEffect, useContext } from "react";
import {
  Box,
  Typography,
  TextField,
  IconButton,
  Paper,
  InputAdornment,
  Avatar,
  CircularProgress,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import QuestionAnswerOutlinedIcon from "@mui/icons-material/QuestionAnswerOutlined";
import { backend_url } from "@/config";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface ChatPanelProps {
  title?: string;
  placeholder?: string;
  welcomeMessage?: string;
  disabled?: boolean;
  disabledMessage?: string;
}

const ChatPanel: React.FC<ChatPanelProps> = ({
  title = "Report Assistant",
  placeholder = "Ask about field extractions...",
  welcomeMessage = "I can help you understand how the report was generated. Ask me about specific field values, their source documents, or the extraction methodology.",
  disabled = false,
  disabledMessage = "Process documents first to enable chat",
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { logs: agentLogs } = useContext(AgentLogsContext);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Add welcome message on mount
    if (messages.length === 0 && !disabled) {
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: welcomeMessage,
          timestamp: new Date(),
        },
      ]);
    }
  }, [disabled, welcomeMessage, messages.length]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || disabled || isLoading) return;

    const userMessage: Message = {
      id: `user_${Date.now()}`,
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    const query = inputValue.trim();
    setInputValue("");
    setIsLoading(true);

    try {
      // Call the backend chat endpoint for Level #1: Understanding how report was generated
      const response = await fetch(`${backend_url}/chat_query`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: query,
          context: agentLogs ? JSON.stringify(agentLogs).substring(0, 5000) : "",
        }),
      });

      let assistantContent = "";

      if (response.ok) {
        const data = await response.json();
        assistantContent = data.response || data.answer || "I've analyzed the extraction data. Could you please be more specific about what you'd like to know?";
      } else {
        // Fallback to intelligent local response based on agent logs
        assistantContent = generateLocalResponse(query, agentLogs);
      }

      const assistantMessage: Message = {
        id: `assistant_${Date.now()}`,
        role: "assistant",
        content: assistantContent,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      // Fallback response
      const assistantMessage: Message = {
        id: `assistant_${Date.now()}`,
        role: "assistant",
        content: generateLocalResponse(query, agentLogs),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateLocalResponse = (query: string, logs: any): string => {
    const lowerQuery = query.toLowerCase();
    
    if (!logs || Object.keys(logs).length === 0) {
      return "No extraction data is currently available. Please process documents first to generate the report data.";
    }

    // Check for specific field queries
    if (lowerQuery.includes("source") || lowerQuery.includes("where")) {
      return "Each field in the Attribution panel shows its source document and page number. Click on any field to see the exact location where the value was extracted from.";
    }

    if (lowerQuery.includes("asset") || lowerQuery.includes("liabilit")) {
      const sections = Object.keys(logs);
      const relevantSections = sections.filter(s => 
        s.toLowerCase().includes("asset") || s.toLowerCase().includes("liabilit")
      );
      if (relevantSections.length > 0) {
        return `I found the following relevant sections in the extraction: ${relevantSections.join(", ")}. You can explore these in the Attribution panel on the left. Each entry shows the extracted value, source document, and explanation.`;
      }
    }

    if (lowerQuery.includes("how") && lowerQuery.includes("extract")) {
      return "The extraction process uses AI agents to analyze each document. For each field, the system: 1) Identifies relevant sections in the documents, 2) Extracts the value using context-aware AI, 3) Records the source page and document, 4) Provides an explanation of why this value was selected. You can see all this information in the Attribution panel.";
    }

    if (lowerQuery.includes("value") || lowerQuery.includes("amount")) {
      return "Field values are displayed in the Attribution panel. Each value includes: the extracted amount, source document name, page number reference, and the AI's explanation for the extraction. Click any field to see detailed attribution information.";
    }

    return "I can help you understand the report extraction. You can ask about: specific field sources, extraction methodology, how values were determined, or explore the Attribution panel on the left to see detailed source information for each field.";
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        border: "1px solid rgba(0, 0, 0, 0.08)",
        borderRadius: "12px",
        overflow: "hidden",
        bgcolor: "#FFFFFF",
      }}
    >
      {/* Header - Professional, no AI icon */}
      <Box
        sx={{
          px: 2,
          py: 1.5,
          bgcolor: "#FAFBFC",
          borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
          display: "flex",
          alignItems: "center",
          gap: 1.5,
        }}
      >
        <Box
          sx={{
            width: 28,
            height: 28,
            borderRadius: "6px",
            bgcolor: "rgba(38, 137, 13, 0.1)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <QuestionAnswerOutlinedIcon sx={{ fontSize: 16, color: "#26890D" }} />
        </Box>
        <Box>
          <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: "0.8rem", color: "#1A1C1E" }}>
            {title}
          </Typography>
          <Typography sx={{ fontSize: "0.65rem", color: "#6B778C" }}>
            Ask about extraction sources
          </Typography>
        </Box>
      </Box>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: "auto",
          p: 2,
          bgcolor: "#FAFBFC",
          display: "flex",
          flexDirection: "column",
          gap: 2,
        }}
      >
        {disabled ? (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              textAlign: "center",
              color: "#53565A",
            }}
          >
            <Box
              sx={{
                width: 48,
                height: 48,
                borderRadius: "12px",
                bgcolor: "rgba(0, 0, 0, 0.04)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                mb: 2,
              }}
            >
              <QuestionAnswerOutlinedIcon sx={{ fontSize: 24, color: "#D0D0CE" }} />
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 500, mb: 0.5 }}>
              {disabledMessage}
            </Typography>
            <Typography variant="caption" sx={{ color: "#A5ADBA" }}>
              Complete document processing to enable
            </Typography>
          </Box>
        ) : (
          <>
            {messages.map((message) => (
              <Box
                key={message.id}
                sx={{
                  display: "flex",
                  flexDirection: message.role === "user" ? "row-reverse" : "row",
                  gap: 1.5,
                  alignItems: "flex-start",
                }}
              >
                <Avatar
                  sx={{
                    width: 28,
                    height: 28,
                    bgcolor: message.role === "user" ? "#26890D" : "#F5F7F9",
                    border: message.role === "user" ? "none" : "1px solid rgba(0, 0, 0, 0.08)",
                  }}
                >
                  {message.role === "user" ? (
                    <PersonOutlineIcon sx={{ fontSize: 16, color: "#FFFFFF" }} />
                  ) : (
                    <QuestionAnswerOutlinedIcon sx={{ fontSize: 14, color: "#26890D" }} />
                  )}
                </Avatar>
                <Box
                  sx={{
                    maxWidth: "85%",
                    p: 1.5,
                    borderRadius: "12px",
                    bgcolor: message.role === "user" ? "#26890D" : "#FFFFFF",
                    color: message.role === "user" ? "#FFFFFF" : "#1A1C1E",
                    border: message.role === "user" ? "none" : "1px solid rgba(0, 0, 0, 0.06)",
                    boxShadow: message.role === "user"
                      ? "0 2px 8px rgba(38, 137, 13, 0.15)"
                      : "0 1px 3px rgba(0, 0, 0, 0.04)",
                  }}
                >
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      lineHeight: 1.6, 
                      fontSize: "0.8rem",
                      whiteSpace: "pre-wrap",
                    }}
                  >
                    {message.content}
                  </Typography>
                </Box>
              </Box>
            ))}

            {isLoading && (
              <Box sx={{ display: "flex", gap: 1.5, alignItems: "flex-start" }}>
                <Avatar
                  sx={{
                    width: 28,
                    height: 28,
                    bgcolor: "#F5F7F9",
                    border: "1px solid rgba(0, 0, 0, 0.08)",
                  }}
                >
                  <QuestionAnswerOutlinedIcon sx={{ fontSize: 14, color: "#26890D" }} />
                </Avatar>
                <Box
                  sx={{
                    p: 1.5,
                    borderRadius: "12px",
                    bgcolor: "#FFFFFF",
                    border: "1px solid rgba(0, 0, 0, 0.06)",
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  }}
                >
                  <CircularProgress size={14} sx={{ color: "#26890D" }} />
                  <Typography variant="body2" sx={{ color: "#6B778C", fontSize: "0.8rem" }}>
                    Analyzing...
                  </Typography>
                </Box>
              </Box>
            )}

            <div ref={messagesEndRef} />
          </>
        )}
      </Box>

      {/* Input Area */}
      <Box sx={{ p: 2, bgcolor: "#FFFFFF", borderTop: "1px solid rgba(0, 0, 0, 0.06)" }}>
        <TextField
          fullWidth
          size="small"
          placeholder={disabled ? "Chat disabled" : placeholder}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={disabled || isLoading}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  onClick={handleSendMessage}
                  disabled={disabled || isLoading || !inputValue.trim()}
                  size="small"
                  sx={{
                    bgcolor: inputValue.trim() ? "#26890D" : "transparent",
                    color: inputValue.trim() ? "#FFFFFF" : "#D0D0CE",
                    "&:hover": {
                      bgcolor: inputValue.trim() ? "#1a6609" : "transparent",
                    },
                    "&:disabled": { 
                      bgcolor: "transparent",
                      color: "#D0D0CE" 
                    },
                    width: 28,
                    height: 28,
                  }}
                >
                  <SendIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </InputAdornment>
            ),
            sx: {
              borderRadius: "10px",
              bgcolor: disabled ? "#F5F5F5" : "#FAFBFC",
              fontSize: "0.8rem",
              "& .MuiOutlinedInput-notchedOutline": {
                borderColor: "rgba(0, 0, 0, 0.08)",
              },
            },
          }}
        />
      </Box>
    </Paper>
  );
};

export default ChatPanel;
