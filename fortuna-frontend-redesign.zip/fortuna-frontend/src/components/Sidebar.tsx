"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Collapse,
  Tooltip,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import FolderOutlinedIcon from "@mui/icons-material/FolderOutlined";
import HistoryIcon from "@mui/icons-material/History";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";

interface SidebarProps {
  currentDebtor: string | null;
}

const Sidebar: React.FC<SidebarProps> = ({ currentDebtor }) => {
  const pathname = usePathname();
  const [documentsOpen, setDocumentsOpen] = useState(true);

  const mainNavItems = [
    {
      label: "Dashboard",
      path: "/",
      icon: <DashboardOutlinedIcon sx={{ fontSize: 20 }} />,
      enabled: true,
    },
    {
      label: "Configurations",
      path: "/modules/upload-document",
      icon: <SettingsIcon sx={{ fontSize: 20 }} />,
      enabled: true,
    },
    {
      label: "Attributions",
      path: "/modules/report-planning",
      icon: <AccountTreeOutlinedIcon sx={{ fontSize: 20 }} />,
      enabled: true,
    },
    {
      label: "Report Preview",
      path: "/modules/report-generation",
      icon: <TableChartOutlinedIcon sx={{ fontSize: 20 }} />,
      enabled: true,
    },
  ];

  const documentsItems = [
    {
      label: "Saved Documents",
      path: "/modules/saved-documents",
      icon: <BookmarkBorderIcon sx={{ fontSize: 18 }} />,
      enabled: false,
    },
    {
      label: "Project Folders",
      path: "/modules/project-folders",
      icon: <FolderOutlinedIcon sx={{ fontSize: 18 }} />,
      enabled: false,
    },
    {
      label: "Recent Files",
      path: "/modules/recent-files",
      icon: <HistoryIcon sx={{ fontSize: 18 }} />,
      enabled: false,
    },
  ];

  const isSelected = (path: string) => pathname === path;

  return (
    <Box
      sx={{
        width: 240,
        height: "100vh",
        position: "fixed",
        left: 0,
        top: 0,
        bgcolor: "#1A1C1E",
        display: "flex",
        flexDirection: "column",
        borderRight: "1px solid rgba(255, 255, 255, 0.06)",
      }}
    >
      {/* Header - Smaller branding */}
      <Box sx={{ px: 2.5, py: 2.5 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 1.5 }}>
          <Box
            sx={{
              width: 32,
              height: 32,
              bgcolor: "#86BC25",
              borderRadius: "6px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography sx={{ color: "#1A1C1E", fontWeight: 700, fontSize: "0.75rem" }}>
              F
            </Typography>
          </Box>
          <Box>
            <Typography
              variant="subtitle2"
              sx={{ color: "#FFFFFF", fontWeight: 600, lineHeight: 1.2 }}
            >
              FORTUNA
            </Typography>
            <Typography
              sx={{ color: "#6B778C", fontSize: "0.65rem", letterSpacing: "0.5px" }}
            >
              aiStudio
            </Typography>
          </Box>
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Current Debtor Card */}
      <Box sx={{ px: 2, py: 2 }}>
        <Typography
          sx={{
            color: "#6B778C",
            fontSize: "0.65rem",
            textTransform: "uppercase",
            letterSpacing: "0.8px",
            mb: 1,
            fontWeight: 600,
          }}
        >
          Active Debtor
        </Typography>
        <Box
          sx={{
            bgcolor: currentDebtor ? "rgba(134, 188, 37, 0.12)" : "rgba(255, 255, 255, 0.04)",
            borderRadius: "8px",
            p: 1.5,
            border: currentDebtor
              ? "1px solid rgba(134, 188, 37, 0.3)"
              : "1px solid rgba(255, 255, 255, 0.08)",
            transition: "all 0.2s ease",
          }}
        >
          <Typography
            sx={{
              color: currentDebtor ? "#86BC25" : "#6B778C",
              fontSize: "0.8rem",
              fontWeight: currentDebtor ? 600 : 400,
              fontStyle: currentDebtor ? "normal" : "italic",
            }}
          >
            {currentDebtor || "No debtor selected"}
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Main Navigation */}
      <Box sx={{ flex: 1, py: 1.5, overflow: "auto" }}>
        <Typography
          sx={{
            color: "#6B778C",
            fontSize: "0.65rem",
            textTransform: "uppercase",
            letterSpacing: "0.8px",
            px: 2.5,
            py: 1,
            fontWeight: 600,
          }}
        >
          Workflow
        </Typography>
        <List component="nav" sx={{ px: 1 }}>
          {mainNavItems.map((item, index) => (
            <ListItem key={item.label} disablePadding sx={{ mb: 0.25 }}>
              <Tooltip
                title={!item.enabled ? "Coming soon" : ""}
                placement="right"
              >
                <Box sx={{ width: "100%" }}>
                  {item.enabled ? (
                    <Link href={item.path} style={{ textDecoration: "none", width: "100%" }}>
                      <ListItemButton
                        selected={isSelected(item.path)}
                        sx={{
                          borderRadius: "8px",
                          py: 1,
                          px: 1.5,
                          minHeight: 40,
                          "&.Mui-selected": {
                            bgcolor: "rgba(134, 188, 37, 0.15)",
                            "& .MuiListItemIcon-root": { color: "#86BC25" },
                            "& .MuiListItemText-primary": {
                              color: "#FFFFFF",
                              fontWeight: 600,
                            },
                            "&:hover": {
                              bgcolor: "rgba(134, 188, 37, 0.2)",
                            },
                          },
                          "&:hover": {
                            bgcolor: "rgba(255, 255, 255, 0.06)",
                          },
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: 28,
                            height: 28,
                            borderRadius: "6px",
                            bgcolor: isSelected(item.path)
                              ? "rgba(134, 188, 37, 0.2)"
                              : "transparent",
                            mr: 1.5,
                          }}
                        >
                          <Box sx={{ color: isSelected(item.path) ? "#86BC25" : "#A5ADBA" }}>
                            {item.icon}
                          </Box>
                        </Box>
                        <ListItemText
                          primary={item.label}
                          sx={{
                            "& .MuiListItemText-primary": {
                              color: isSelected(item.path) ? "#FFFFFF" : "#A5ADBA",
                              fontSize: "0.8rem",
                              fontWeight: isSelected(item.path) ? 600 : 400,
                            },
                          }}
                        />
                        <Box
                          sx={{
                            width: 20,
                            height: 20,
                            borderRadius: "4px",
                            bgcolor: isSelected(item.path)
                              ? "#86BC25"
                              : "rgba(255, 255, 255, 0.08)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: "0.65rem",
                            fontWeight: 600,
                            color: isSelected(item.path) ? "#1A1C1E" : "#6B778C",
                          }}
                        >
                          {index + 1}
                        </Box>
                      </ListItemButton>
                    </Link>
                  ) : (
                    <ListItemButton
                      disabled
                      sx={{
                        borderRadius: "8px",
                        py: 1,
                        px: 1.5,
                        minHeight: 40,
                        opacity: 0.5,
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: 40, color: "#6B778C" }}>
                        {item.icon}
                      </ListItemIcon>
                      <ListItemText
                        primary={item.label}
                        sx={{
                          "& .MuiListItemText-primary": {
                            color: "#6B778C",
                            fontSize: "0.8rem",
                          },
                        }}
                      />
                    </ListItemButton>
                  )}
                </Box>
              </Tooltip>
            </ListItem>
          ))}
        </List>

        {/* Documents Section - Collapsible */}
        <Box sx={{ mt: 2 }}>
          <ListItemButton
            onClick={() => setDocumentsOpen(!documentsOpen)}
            sx={{
              mx: 1,
              borderRadius: "8px",
              py: 0.75,
              px: 1.5,
              "&:hover": {
                bgcolor: "rgba(255, 255, 255, 0.06)",
              },
            }}
          >
            <Typography
              sx={{
                color: "#6B778C",
                fontSize: "0.65rem",
                textTransform: "uppercase",
                letterSpacing: "0.8px",
                fontWeight: 600,
                flex: 1,
              }}
            >
              Documents
            </Typography>
            {documentsOpen ? (
              <ExpandLess sx={{ color: "#6B778C", fontSize: 18 }} />
            ) : (
              <ExpandMore sx={{ color: "#6B778C", fontSize: 18 }} />
            )}
          </ListItemButton>
          <Collapse in={documentsOpen} timeout="auto" unmountOnExit>
            <List component="div" disablePadding sx={{ px: 1 }}>
              {documentsItems.map((item) => (
                <ListItem key={item.label} disablePadding sx={{ mb: 0.25 }}>
                  <Tooltip title="Coming soon" placement="right">
                    <ListItemButton
                      disabled
                      sx={{
                        borderRadius: "8px",
                        py: 0.75,
                        px: 1.5,
                        pl: 3,
                        minHeight: 36,
                        opacity: 0.4,
                      }}
                    >
                      <ListItemIcon sx={{ minWidth: 32, color: "#6B778C" }}>
                        {item.icon}
                      </ListItemIcon>
                      <ListItemText
                        primary={item.label}
                        sx={{
                          "& .MuiListItemText-primary": {
                            color: "#6B778C",
                            fontSize: "0.75rem",
                          },
                        }}
                      />
                    </ListItemButton>
                  </Tooltip>
                </ListItem>
              ))}
            </List>
          </Collapse>
        </Box>
      </Box>

      {/* Bottom Section */}
      <Box sx={{ mt: "auto" }}>
        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />
        <List component="nav" sx={{ px: 1, py: 1.5 }}>
          <ListItem disablePadding>
            <Tooltip title="Coming soon" placement="right">
              <ListItemButton
                disabled
                sx={{
                  borderRadius: "8px",
                  py: 0.75,
                  px: 1.5,
                  minHeight: 36,
                  opacity: 0.5,
                  "&:hover": { bgcolor: "rgba(255, 255, 255, 0.06)" },
                }}
              >
                <ListItemIcon sx={{ minWidth: 36, color: "#6B778C" }}>
                  <HelpOutlineIcon sx={{ fontSize: 18 }} />
                </ListItemIcon>
                <ListItemText
                  primary="Help & Docs"
                  sx={{
                    "& .MuiListItemText-primary": {
                      color: "#6B778C",
                      fontSize: "0.75rem",
                    },
                  }}
                />
              </ListItemButton>
            </Tooltip>
          </ListItem>
        </List>

        {/* Version info */}
        <Box sx={{ px: 2.5, py: 1.5, borderTop: "1px solid rgba(255, 255, 255, 0.06)" }}>
          <Typography sx={{ color: "#53565A", fontSize: "0.65rem" }}>
            v0.1.0 • aiStudio Preview
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default Sidebar;
