"use client";

import React from "react";
import { Box, Typography, Chip } from "@mui/material";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  currentDebtor?: string | null;
  showDebtorBadge?: boolean;
  actions?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  currentDebtor,
  showDebtorBadge = false,
  actions,
}) => {
  return (
    <Box sx={{ mb: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <Box>
          <Typography
            variant="h4"
            sx={{
              fontWeight: 700,
              color: "#1A1C1E",
              mb: subtitle ? 0.5 : 0,
              letterSpacing: "-0.02em",
            }}
          >
            {title}
          </Typography>
          {subtitle && (
            <Typography
              variant="body2"
              sx={{
                color: "#53565A",
                maxWidth: 500,
              }}
            >
              {subtitle}
            </Typography>
          )}
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          {showDebtorBadge && (
            <Chip
              size="small"
              label={currentDebtor ? currentDebtor : "No debtor"}
              sx={{
                bgcolor: currentDebtor ? "rgba(134, 188, 37, 0.12)" : "rgba(0, 0, 0, 0.04)",
                color: currentDebtor ? "#26890D" : "#6B778C",
                fontWeight: currentDebtor ? 600 : 400,
                border: currentDebtor
                  ? "1px solid rgba(38, 137, 13, 0.2)"
                  : "1px solid rgba(0, 0, 0, 0.08)",
                "& .MuiChip-label": {
                  px: 1.5,
                  py: 0.25,
                },
              }}
            />
          )}
          {actions}
        </Box>
      </Box>
    </Box>
  );
};

export default PageHeader;
