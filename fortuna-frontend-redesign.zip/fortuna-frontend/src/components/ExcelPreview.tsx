"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  CircularProgress,
  Chip,
  IconButton,
  Tooltip,
} from "@mui/material";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import FullscreenExitIcon from "@mui/icons-material/FullscreenExit";
import RefreshIcon from "@mui/icons-material/Refresh";
import { backend_url } from "@/config";

interface SheetData {
  name: string;
  data: any[][];
  headers?: string[];
}

interface ExcelPreviewProps {
  reportReady: boolean;
  onFullscreen?: () => void;
  isFullscreen?: boolean;
}

const ExcelPreview: React.FC<ExcelPreviewProps> = ({ 
  reportReady, 
  onFullscreen,
  isFullscreen = false 
}) => {
  const [sheets, setSheets] = useState<SheetData[]>([]);
  const [activeSheet, setActiveSheet] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPreviewData = async () => {
    if (!reportReady) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${backend_url}/get_report_preview`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch preview data");
      }
      
      const data = await response.json();
      
      if (data.sheets && Array.isArray(data.sheets)) {
        setSheets(data.sheets);
      } else if (data.data) {
        // Single sheet fallback
        setSheets([{ name: "Financial Statements", data: data.data }]);
      }
    } catch (err) {
      console.error("Preview fetch error:", err);
      // Generate mock preview for demo
      setSheets(generateMockFinancialData());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (reportReady) {
      fetchPreviewData();
    }
  }, [reportReady]);

  const generateMockFinancialData = (): SheetData[] => {
    return [
      {
        name: "Balance Sheet",
        headers: ["Category", "Field", "2023", "2022", "Source", "Page"],
        data: [
          ["Assets", "Total Current Assets", "€ 12,450,000", "€ 11,230,000", "Annual Report", "p.45"],
          ["Assets", "Cash & Equivalents", "€ 3,200,000", "€ 2,890,000", "Annual Report", "p.45"],
          ["Assets", "Accounts Receivable", "€ 5,100,000", "€ 4,750,000", "Annual Report", "p.46"],
          ["Assets", "Inventory", "€ 4,150,000", "€ 3,590,000", "Annual Report", "p.46"],
          ["Assets", "Total Non-Current Assets", "€ 28,750,000", "€ 26,400,000", "Annual Report", "p.47"],
          ["Liabilities", "Total Current Liabilities", "€ 8,200,000", "€ 7,650,000", "Annual Report", "p.48"],
          ["Liabilities", "Accounts Payable", "€ 4,100,000", "€ 3,800,000", "Annual Report", "p.48"],
          ["Liabilities", "Total Non-Current Liabilities", "€ 15,300,000", "€ 14,200,000", "Annual Report", "p.49"],
          ["Equity", "Total Equity", "€ 17,700,000", "€ 15,780,000", "Annual Report", "p.50"],
        ],
      },
      {
        name: "Income Statement",
        headers: ["Category", "Field", "2023", "2022", "Source", "Page"],
        data: [
          ["Revenue", "Total Revenue", "€ 45,200,000", "€ 41,800,000", "Annual Report", "p.32"],
          ["Revenue", "Net Sales", "€ 44,100,000", "€ 40,500,000", "Annual Report", "p.32"],
          ["Costs", "Cost of Goods Sold", "€ 27,500,000", "€ 25,800,000", "Annual Report", "p.33"],
          ["Costs", "Operating Expenses", "€ 8,200,000", "€ 7,600,000", "Annual Report", "p.34"],
          ["Profit", "Gross Profit", "€ 17,700,000", "€ 16,000,000", "Annual Report", "p.35"],
          ["Profit", "Operating Income", "€ 9,500,000", "€ 8,400,000", "Annual Report", "p.35"],
          ["Profit", "Net Income", "€ 6,800,000", "€ 5,900,000", "Annual Report", "p.36"],
        ],
      },
      {
        name: "Cash Flow",
        headers: ["Category", "Field", "2023", "2022", "Source", "Page"],
        data: [
          ["Operating", "Net Cash from Operations", "€ 9,200,000", "€ 8,100,000", "Annual Report", "p.52"],
          ["Operating", "Depreciation", "€ 2,100,000", "€ 1,950,000", "Annual Report", "p.52"],
          ["Investing", "Capital Expenditures", "€ (4,500,000)", "€ (3,800,000)", "Annual Report", "p.53"],
          ["Investing", "Net Cash from Investing", "€ (4,200,000)", "€ (3,500,000)", "Annual Report", "p.53"],
          ["Financing", "Debt Repayment", "€ (2,100,000)", "€ (1,800,000)", "Annual Report", "p.54"],
          ["Financing", "Net Cash from Financing", "€ (1,800,000)", "€ (1,500,000)", "Annual Report", "p.54"],
          ["Summary", "Net Change in Cash", "€ 3,200,000", "€ 3,100,000", "Annual Report", "p.55"],
        ],
      },
    ];
  };

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setActiveSheet(newValue);
  };

  const currentSheet = sheets[activeSheet];

  if (!reportReady) {
    return (
      <Paper
        elevation={0}
        sx={{
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          border: "1px solid rgba(0, 0, 0, 0.08)",
          borderRadius: "12px",
          bgcolor: "#FAFBFC",
        }}
      >
        <Box
          sx={{
            width: 56,
            height: 56,
            borderRadius: "12px",
            bgcolor: "rgba(0, 0, 0, 0.04)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            mb: 2,
          }}
        >
          <TableChartOutlinedIcon sx={{ fontSize: 28, color: "#D0D0CE" }} />
        </Box>
        <Typography variant="body2" sx={{ fontWeight: 500, color: "#53565A", mb: 0.5 }}>
          No Report Available
        </Typography>
        <Typography variant="caption" sx={{ color: "#A5ADBA" }}>
          Process documents to generate the financial report
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper
      elevation={0}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        border: "1px solid rgba(0, 0, 0, 0.08)",
        borderRadius: "12px",
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 2,
          py: 1.5,
          bgcolor: "#FAFBFC",
          borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 28,
              height: 28,
              borderRadius: "6px",
              bgcolor: "rgba(38, 137, 13, 0.1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <TableChartOutlinedIcon sx={{ fontSize: 16, color: "#26890D" }} />
          </Box>
          <Box>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: "0.8rem", color: "#1A1C1E" }}>
              Financial Statements Preview
            </Typography>
            <Typography sx={{ fontSize: "0.65rem", color: "#6B778C" }}>
              Excel report data
            </Typography>
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 0.5 }}>
          <Tooltip title="Refresh preview">
            <IconButton 
              size="small" 
              onClick={fetchPreviewData}
              disabled={loading}
              sx={{ color: "#6B778C" }}
            >
              <RefreshIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Tooltip>
          {onFullscreen && (
            <Tooltip title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}>
              <IconButton size="small" onClick={onFullscreen} sx={{ color: "#6B778C" }}>
                {isFullscreen ? (
                  <FullscreenExitIcon sx={{ fontSize: 18 }} />
                ) : (
                  <FullscreenIcon sx={{ fontSize: 18 }} />
                )}
              </IconButton>
            </Tooltip>
          )}
        </Box>
      </Box>

      {/* Sheet Tabs */}
      {sheets.length > 1 && (
        <Box sx={{ borderBottom: "1px solid rgba(0, 0, 0, 0.06)" }}>
          <Tabs
            value={activeSheet}
            onChange={handleTabChange}
            variant="scrollable"
            scrollButtons="auto"
            sx={{
              minHeight: 40,
              "& .MuiTab-root": {
                minHeight: 40,
                py: 0,
                px: 2,
                fontSize: "0.75rem",
              },
            }}
          >
            {sheets.map((sheet, index) => (
              <Tab key={index} label={sheet.name} />
            ))}
          </Tabs>
        </Box>
      )}

      {/* Table Content */}
      <Box sx={{ flex: 1, overflow: "auto" }}>
        {loading ? (
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
            }}
          >
            <CircularProgress size={32} sx={{ color: "#26890D" }} />
          </Box>
        ) : error ? (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              p: 3,
            }}
          >
            <Typography color="error" variant="body2">
              {error}
            </Typography>
          </Box>
        ) : currentSheet ? (
          <TableContainer sx={{ maxHeight: "100%" }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {(currentSheet.headers || currentSheet.data[0] || []).map((header, idx) => (
                    <TableCell
                      key={idx}
                      sx={{
                        fontWeight: 600,
                        bgcolor: "#F5F7F9",
                        color: "#1A1C1E",
                        fontSize: "0.75rem",
                        borderBottom: "2px solid rgba(0, 0, 0, 0.1)",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {header}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {(currentSheet.headers ? currentSheet.data : currentSheet.data.slice(1)).map((row, rowIdx) => (
                  <TableRow
                    key={rowIdx}
                    sx={{
                      "&:nth-of-type(odd)": { bgcolor: "#FAFBFC" },
                      "&:hover": { bgcolor: "rgba(38, 137, 13, 0.04)" },
                    }}
                  >
                    {row.map((cell: any, cellIdx: number) => (
                      <TableCell
                        key={cellIdx}
                        sx={{
                          fontSize: "0.75rem",
                          color: cellIdx === 0 ? "#26890D" : "#1A1C1E",
                          fontWeight: cellIdx === 0 ? 600 : 400,
                          borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {cellIdx === row.length - 1 && typeof cell === "string" && cell.startsWith("p.") ? (
                          <Chip
                            size="small"
                            label={cell}
                            sx={{
                              height: 20,
                              fontSize: "0.65rem",
                              bgcolor: "rgba(0, 124, 176, 0.1)",
                              color: "#007CB0",
                            }}
                          />
                        ) : (
                          cell
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : null}
      </Box>
    </Paper>
  );
};

export default ExcelPreview;
