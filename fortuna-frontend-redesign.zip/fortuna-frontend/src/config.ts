// Backend URL configuration
export const backend_url = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
