import { ThemeProvider } from "@mui/material/styles";
import theme from "@/app/theme";

export const metadata = {
  title: "FORTUNA | aiStudio",
  description: "AI-powered Credit File Review report generation",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><link rel="icon" href="/icon.ico" sizes="any" /></head>
      <body><ThemeProvider theme={theme}>{children}</ThemeProvider></body>
    </html>
  );
}
