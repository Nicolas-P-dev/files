"use client";
import { redirect } from "next/navigation";
export default function RootPage() {
  redirect("/modules/upload-document");
  return null;
}
