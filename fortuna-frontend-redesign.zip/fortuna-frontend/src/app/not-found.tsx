"use client";
import { Box, Typography, Button } from "@mui/material";
import Link from "next/link";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";

export default function NotFound() {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "100vh", textAlign: "center", p: 4, bgcolor: "#F5F7F9" }}>
      <Box sx={{ width: 80, height: 80, borderRadius: "16px", bgcolor: "rgba(38, 137, 13, 0.1)", display: "flex", alignItems: "center", justifyContent: "center", mb: 3 }}>
        <Typography sx={{ fontSize: "2rem", fontWeight: 700, color: "#26890D" }}>404</Typography>
      </Box>
      <Typography variant="h5" sx={{ fontWeight: 600, color: "#1A1C1E", mb: 1 }}>Page Not Found</Typography>
      <Typography variant="body1" sx={{ color: "#53565A", mb: 4, maxWidth: 400 }}>The page you are looking for does not exist.</Typography>
      <Link href="/modules/upload-document" passHref>
        <Button variant="contained" color="primary" startIcon={<HomeOutlinedIcon />} sx={{ textTransform: "none", fontWeight: 600, px: 4, borderRadius: "8px" }}>Return to Home</Button>
      </Link>
    </Box>
  );
}
