"use client";

import React, { useState, useEffect } from "react";
import { Box, Button, Paper, Typography, Chip, Tabs, Tab } from "@mui/material";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import PageHeader from "@/components/PageHeader";
import ExcelPreview from "@/components/ExcelPreview";
import ChatPanel from "@/components/ChatPanel";
import { backend_url } from "@/config";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";

export default function ReportPreviewPage() {
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [hasProcessedData, setHasProcessedData] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
        } else {
          setCurrentDebtor(null);
          setHasProcessedData(false);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
        setCurrentDebtor(null);
        setHasProcessedData(false);
      }
    };
    fetchCurrentDebtor();
  }, []);

  const handleDownload = async () => {
    try {
      setIsDownloading(true);
      const response = await fetch(`${backend_url}/download_report`);

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_CFR_Report.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      console.error("Download error:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Box
      sx={{
        padding: "24px 32px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F5F7F9",
      }}
    >
      <PageHeader
        title="Report Preview"
        subtitle="Preview the generated Excel report with financial statements data"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Info Cards */}
      {hasProcessedData && (
        <Box sx={{ display: "flex", gap: 2, mb: 3 }}>
          <Paper
            elevation={0}
            sx={{
              flex: 1,
              px: 2.5,
              py: 2,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: "8px",
                bgcolor: "rgba(38, 137, 13, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <TableChartOutlinedIcon sx={{ color: "#26890D", fontSize: 20 }} />
            </Box>
            <Box>
              <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Report Format
              </Typography>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 0.25 }}>
                <Chip
                  size="small"
                  label="Excel (.xlsx)"
                  sx={{
                    height: 22,
                    fontSize: "0.7rem",
                    bgcolor: "rgba(38, 137, 13, 0.1)",
                    color: "#26890D",
                    fontWeight: 600,
                  }}
                />
              </Box>
            </Box>
          </Paper>

          <Paper
            elevation={0}
            sx={{
              flex: 1,
              px: 2.5,
              py: 2,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: "8px",
                bgcolor: "rgba(0, 124, 176, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <DescriptionOutlinedIcon sx={{ color: "#007CB0", fontSize: 20 }} />
            </Box>
            <Box>
              <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Contents
              </Typography>
              <Typography sx={{ fontSize: "0.8rem", fontWeight: 500, color: "#1A1C1E", mt: 0.25 }}>
                Balance Sheet, Income Statement, Cash Flow
              </Typography>
            </Box>
          </Paper>
        </Box>
      )}

      {/* Main Content */}
      <Box
        sx={{
          display: "flex",
          gap: "16px",
          height: "calc(100vh - 300px)",
          minHeight: "450px",
        }}
      >
        <PanelGroup direction="horizontal" autoSaveId="preview-panels">
          {/* Excel Preview Panel */}
          <Panel defaultSize={65} minSize={40}>
            <ExcelPreview reportReady={hasProcessedData} />
          </Panel>

          {/* Resize Handle */}
          <PanelResizeHandle
            style={{
              width: "12px",
              background: "transparent",
              cursor: "col-resize",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: "3px",
                height: "40px",
                bgcolor: "#E6E6E6",
                borderRadius: "2px",
                transition: "all 0.2s",
                "&:hover": {
                  bgcolor: "#26890D",
                  height: "60px",
                },
              }}
            />
          </PanelResizeHandle>

          {/* Chat Panel */}
          <Panel defaultSize={35} minSize={25}>
            <ChatPanel
              title="Report Assistant"
              placeholder="Ask about the financial data..."
              welcomeMessage="I can help you understand the data in this report. Ask me about specific values, how they were calculated, or their sources in the original documents."
              disabled={!hasProcessedData}
              disabledMessage="Process documents to enable preview"
            />
          </Panel>
        </PanelGroup>
      </Box>

      {/* Download Button - Bottom Right as per David's feedback */}
      {hasProcessedData && (
        <Box
          sx={{
            position: "fixed",
            bottom: 32,
            right: 32,
            zIndex: 1000,
          }}
        >
          <Button
            variant="contained"
            color="primary"
            onClick={handleDownload}
            disabled={!currentDebtor || isDownloading}
            startIcon={<DownloadOutlinedIcon />}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              borderRadius: "10px",
              boxShadow: "0 4px 14px rgba(38, 137, 13, 0.35)",
              px: 3,
              py: 1.25,
              "&:hover": {
                boxShadow: "0 6px 20px rgba(38, 137, 13, 0.45)",
              },
            }}
          >
            {isDownloading ? "Downloading..." : "Download Report"}
          </Button>
        </Box>
      )}
    </Box>
  );
}
