"use client";

import React, { useState, useEffect, useContext } from "react";
import { Typography, Box, Button, Paper, Chip, IconButton, Tooltip } from "@mui/material";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import PageHeader from "@/components/PageHeader";
import ChatPanel from "@/components/ChatPanel";
import CircularLoader from "@/ui/circularLoader";
import AttributionViewer from "./AttributionViewer";
import { backend_url } from "@/config";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";
import OpenInFullIcon from "@mui/icons-material/OpenInFull";
import CloseFullscreenIcon from "@mui/icons-material/CloseFullscreen";

const loadingMessages = ["Preparing the report for download..."];

export default function AttributionsPage() {
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [hasProcessedData, setHasProcessedData] = useState(false);
  const [isWorkspaceFullscreen, setIsWorkspaceFullscreen] = useState(false);
  const { logs: agentLogs, logsLoading } = useContext(AgentLogsContext);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
        } else {
          setCurrentDebtor(null);
          setHasProcessedData(false);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
        setCurrentDebtor(null);
        setHasProcessedData(false);
      }
    };
    fetchCurrentDebtor();
  }, []);

  // Count attribution entries
  const getAttributionCount = () => {
    if (!agentLogs || typeof agentLogs !== 'object') return 0;
    let count = 0;
    const countEntries = (obj: any) => {
      if (typeof obj !== 'object' || obj === null) return;
      Object.values(obj).forEach((value: any) => {
        if (typeof value === 'object' && value !== null) {
          if (value.value !== undefined || value.sources !== undefined) {
            count++;
          } else {
            countEntries(value);
          }
        }
      });
    };
    countEntries(agentLogs);
    return count;
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${backend_url}/download_report`);

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_CFR_Report.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
      setLoading(false);
    } catch (error) {
      console.error("Download error:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [loading]);

  return (
    <Box
      sx={{
        padding: "24px 32px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F5F7F9",
      }}
    >
      <PageHeader
        title="Attributions"
        subtitle="Review extracted field values with their sources, page numbers, and explanations"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Stats Row */}
      {hasProcessedData && (
        <Box sx={{ display: "flex", gap: 2, mb: 3 }}>
          <Paper
            elevation={0}
            sx={{
              flex: 1,
              px: 2.5,
              py: 2,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: "8px",
                bgcolor: "rgba(38, 137, 13, 0.1)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <AccountTreeOutlinedIcon sx={{ color: "#26890D", fontSize: 20 }} />
            </Box>
            <Box>
              <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                Extracted Fields
              </Typography>
              <Typography sx={{ fontSize: "1.25rem", fontWeight: 700, color: "#1A1C1E" }}>
                {getAttributionCount()}
              </Typography>
            </Box>
          </Paper>

          <Paper
            elevation={0}
            sx={{
              px: 2.5,
              py: 2,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <Button
              variant="contained"
              color="primary"
              onClick={handleDownload}
              disabled={!currentDebtor || loading}
              startIcon={<DownloadOutlinedIcon />}
              sx={{
                textTransform: "none",
                fontWeight: 600,
                borderRadius: "8px",
                boxShadow: "none",
                px: 3,
                "&:hover": {
                  boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
                },
              }}
            >
              Download Report (.xlsx)
            </Button>
          </Paper>
        </Box>
      )}

      <Box
        sx={{
          display: "flex",
          gap: "16px",
          height: "calc(100vh - 280px)",
          minHeight: "500px",
        }}
      >
        <PanelGroup direction="horizontal" autoSaveId="attribution-panels">
          {/* Main Workspace Panel */}
          <Panel defaultSize={65} minSize={40}>
            <Paper
              elevation={0}
              sx={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                border: "1px solid rgba(0, 0, 0, 0.08)",
                borderRadius: "12px",
                overflow: "hidden",
              }}
            >
              {/* Workspace Header */}
              <Box
                sx={{
                  px: 2.5,
                  py: 2,
                  borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
                  bgcolor: "#FAFBFC",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                  <Box
                    sx={{
                      width: 28,
                      height: 28,
                      borderRadius: "6px",
                      bgcolor: "rgba(38, 137, 13, 0.1)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <AccountTreeOutlinedIcon sx={{ fontSize: 16, color: "#26890D" }} />
                  </Box>
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 600, color: "#1A1C1E" }}>
                      Extraction Details
                    </Typography>
                    <Typography sx={{ fontSize: "0.7rem", color: "#6B778C" }}>
                      Field values with sources and explanations
                    </Typography>
                  </Box>
                </Box>
                <Tooltip title={isWorkspaceFullscreen ? "Exit fullscreen" : "Fullscreen"}>
                  <IconButton
                    size="small"
                    onClick={() => setIsWorkspaceFullscreen(!isWorkspaceFullscreen)}
                    sx={{ color: "#6B778C" }}
                  >
                    {isWorkspaceFullscreen ? (
                      <CloseFullscreenIcon sx={{ fontSize: 18 }} />
                    ) : (
                      <OpenInFullIcon sx={{ fontSize: 18 }} />
                    )}
                  </IconButton>
                </Tooltip>
              </Box>

              {/* Attribution Content */}
              <Box sx={{ flex: 1, overflow: "auto", p: 2.5 }}>
                {logsLoading ? (
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                    }}
                  >
                    <CircularLoader open={true} />
                  </Box>
                ) : currentDebtor && agentLogs && Object.keys(agentLogs).length > 0 ? (
                  <AttributionViewer data={agentLogs} />
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      color: "#53565A",
                    }}
                  >
                    <Box
                      sx={{
                        width: 56,
                        height: 56,
                        borderRadius: "12px",
                        bgcolor: "rgba(0, 0, 0, 0.04)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        mb: 2,
                      }}
                    >
                      <AccountTreeOutlinedIcon sx={{ fontSize: 28, color: "#D0D0CE" }} />
                    </Box>
                    <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
                      No extraction data available
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Process documents in Configurations to view attributions
                    </Typography>
                  </Box>
                )}
              </Box>
            </Paper>
          </Panel>

          {/* Resize Handle */}
          <PanelResizeHandle
            style={{
              width: "12px",
              background: "transparent",
              cursor: "col-resize",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: "3px",
                height: "40px",
                bgcolor: "#E6E6E6",
                borderRadius: "2px",
                transition: "all 0.2s",
                "&:hover": {
                  bgcolor: "#26890D",
                  height: "60px",
                },
              }}
            />
          </PanelResizeHandle>

          {/* Chat Panel */}
          <Panel defaultSize={35} minSize={25}>
            <ChatPanel
              title="Report Assistant"
              placeholder="Ask about extraction sources..."
              welcomeMessage="I can help you understand how the report was generated. Ask me about specific field values, their source documents, page numbers, or the extraction methodology used."
              disabled={!hasProcessedData}
              disabledMessage="Process documents to enable chat"
            />
          </Panel>
        </PanelGroup>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}
    </Box>
  );
}
