"use client";

import React, { useState } from "react";
import {
  Typography,
  Box,
  Table,
  TableCell,
  TableBody,
  TableRow,
  TableHead,
  Chip,
  Paper,
  IconButton,
  Collapse,
  Tooltip,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

interface AttributionViewerProps {
  data: Record<string, any>;
}

interface FieldEntry {
  fieldName: string;
  value: any;
  source?: string;
  page?: string | number;
  explanation?: string;
}

const AttributionViewer: React.FC<AttributionViewerProps> = ({ data }) => {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  // Initialize all sections as expanded by default
  React.useEffect(() => {
    const initialExpanded: Record<string, boolean> = {};
    Object.keys(data).forEach((key) => {
      initialExpanded[key] = true; // All sections expanded by default
    });
    setExpandedSections(initialExpanded);
  }, [data]);

  const toggleSection = (sectionKey: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [sectionKey]: !prev[sectionKey],
    }));
  };

  // Extract field entries from nested data structure
  const extractFields = (obj: any, prefix: string = ""): FieldEntry[] => {
    const fields: FieldEntry[] = [];

    if (typeof obj !== "object" || obj === null) return fields;

    Object.entries(obj).forEach(([key, value]: [string, any]) => {
      if (typeof value === "object" && value !== null) {
        // Check if this is a field entry (has value, source, or explanation)
        if (value.value !== undefined || value.Value !== undefined) {
          fields.push({
            fieldName: key,
            value: value.value || value.Value || "—",
            source: value.source || value.Source || value.sources || "—",
            page: value.page || value.Page || value.page_number || "—",
            explanation: value.explanation || value.Explanation || value.reasoning || "",
          });
        } else {
          // Recurse into nested objects
          const nestedFields = extractFields(value, key);
          fields.push(...nestedFields);
        }
      }
    });

    return fields;
  };

  // Format value for display
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) return "—";
    if (Array.isArray(value)) {
      return value.map((v) => formatValue(v)).join(", ");
    }
    if (typeof value === "object") {
      return JSON.stringify(value);
    }
    return String(value);
  };

  const renderSection = (sectionKey: string, sectionData: any) => {
    const isExpanded = expandedSections[sectionKey] !== false;
    const fields = extractFields(sectionData);

    // Get subsection names if they exist
    const subsections = Object.entries(sectionData).filter(
      ([_, value]) => typeof value === "object" && value !== null && !value.value && !value.Value
    );

    return (
      <Paper
        key={sectionKey}
        elevation={0}
        sx={{
          mb: 2,
          borderRadius: "10px",
          border: "1px solid rgba(0, 0, 0, 0.06)",
          overflow: "hidden",
        }}
      >
        {/* Section Header */}
        <Box
          onClick={() => toggleSection(sectionKey)}
          sx={{
            px: 2.5,
            py: 1.5,
            bgcolor: "#FAFBFC",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: isExpanded ? "1px solid rgba(0, 0, 0, 0.06)" : "none",
            "&:hover": {
              bgcolor: "#F5F7F9",
            },
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: "0.85rem",
                color: "#1A1C1E",
              }}
            >
              {sectionKey}
            </Typography>
            <Chip
              size="small"
              label={`${fields.length} fields`}
              sx={{
                height: 20,
                fontSize: "0.65rem",
                bgcolor: "rgba(38, 137, 13, 0.08)",
                color: "#26890D",
              }}
            />
          </Box>
          <IconButton size="small" sx={{ color: "#6B778C" }}>
            {isExpanded ? (
              <ExpandLessIcon sx={{ fontSize: 20 }} />
            ) : (
              <ExpandMoreIcon sx={{ fontSize: 20 }} />
            )}
          </IconButton>
        </Box>

        {/* Section Content */}
        <Collapse in={isExpanded}>
          <Box sx={{ p: 0 }}>
            {/* If there are subsections, render them */}
            {subsections.length > 0 ? (
              subsections.map(([subKey, subData]) => (
                <Box key={subKey} sx={{ borderBottom: "1px solid rgba(0, 0, 0, 0.04)" }}>
                  <Box
                    sx={{
                      px: 2.5,
                      py: 1,
                      bgcolor: "rgba(0, 124, 176, 0.04)",
                    }}
                  >
                    <Typography
                      sx={{
                        fontWeight: 600,
                        fontSize: "0.75rem",
                        color: "#007CB0",
                        textTransform: "uppercase",
                        letterSpacing: "0.5px",
                      }}
                    >
                      {subKey}
                    </Typography>
                  </Box>
                  {renderFieldsTable(extractFields(subData as any))}
                </Box>
              ))
            ) : (
              renderFieldsTable(fields)
            )}
          </Box>
        </Collapse>
      </Paper>
    );
  };

  const renderFieldsTable = (fields: FieldEntry[]) => {
    if (fields.length === 0) {
      return (
        <Box sx={{ p: 2, textAlign: "center" }}>
          <Typography variant="body2" color="textSecondary">
            No field data available
          </Typography>
        </Box>
      );
    }

    return (
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: "0.7rem",
                color: "#6B778C",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                bgcolor: "#FAFBFC",
                borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                width: "25%",
              }}
            >
              Field
            </TableCell>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: "0.7rem",
                color: "#6B778C",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                bgcolor: "#FAFBFC",
                borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                width: "25%",
              }}
            >
              Value
            </TableCell>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: "0.7rem",
                color: "#6B778C",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                bgcolor: "#FAFBFC",
                borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                width: "20%",
              }}
            >
              Source
            </TableCell>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: "0.7rem",
                color: "#6B778C",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                bgcolor: "#FAFBFC",
                borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                width: "10%",
              }}
            >
              Page
            </TableCell>
            <TableCell
              sx={{
                fontWeight: 600,
                fontSize: "0.7rem",
                color: "#6B778C",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
                bgcolor: "#FAFBFC",
                borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                width: "20%",
              }}
            >
              Explanation
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {fields.map((field, idx) => (
            <TableRow
              key={idx}
              sx={{
                "&:nth-of-type(odd)": { bgcolor: "rgba(0, 0, 0, 0.01)" },
                "&:hover": { bgcolor: "rgba(38, 137, 13, 0.03)" },
              }}
            >
              <TableCell
                sx={{
                  fontSize: "0.8rem",
                  fontWeight: 500,
                  color: "#26890D",
                  borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                }}
              >
                {field.fieldName}
              </TableCell>
              <TableCell
                sx={{
                  fontSize: "0.8rem",
                  color: "#1A1C1E",
                  fontWeight: 500,
                  borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                }}
              >
                {formatValue(field.value)}
              </TableCell>
              <TableCell
                sx={{
                  fontSize: "0.75rem",
                  color: "#53565A",
                  borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                }}
              >
                <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                  <DescriptionOutlinedIcon sx={{ fontSize: 14, color: "#A5ADBA" }} />
                  {formatValue(field.source)}
                </Box>
              </TableCell>
              <TableCell
                sx={{
                  fontSize: "0.75rem",
                  borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                }}
              >
                {field.page !== "—" ? (
                  <Chip
                    size="small"
                    label={`p.${field.page}`}
                    sx={{
                      height: 20,
                      fontSize: "0.65rem",
                      bgcolor: "rgba(0, 124, 176, 0.1)",
                      color: "#007CB0",
                    }}
                  />
                ) : (
                  <Typography sx={{ fontSize: "0.75rem", color: "#A5ADBA" }}>—</Typography>
                )}
              </TableCell>
              <TableCell
                sx={{
                  fontSize: "0.75rem",
                  color: "#6B778C",
                  borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
                }}
              >
                {field.explanation ? (
                  <Tooltip title={field.explanation} placement="top-start">
                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5, cursor: "help" }}>
                      <InfoOutlinedIcon sx={{ fontSize: 14, color: "#A5ADBA" }} />
                      <Typography
                        sx={{
                          fontSize: "0.75rem",
                          color: "#6B778C",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                          maxWidth: 150,
                        }}
                      >
                        {field.explanation}
                      </Typography>
                    </Box>
                  </Tooltip>
                ) : (
                  <Typography sx={{ fontSize: "0.75rem", color: "#A5ADBA" }}>—</Typography>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  if (!data || Object.keys(data).length === 0) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100%",
          color: "#53565A",
        }}
      >
        <Typography variant="body1" sx={{ fontWeight: 500, mb: 1 }}>
          No attribution data available
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Process documents to generate extraction attributions
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      {Object.entries(data).map(([key, value]) => renderSection(key, value))}
    </Box>
  );
};

export default AttributionViewer;
