"use client";

import React, { useEffect, useState, useContext } from "react";
import {
  Typography,
  Button,
  Box,
  TextField,
  FormControl,
  Select,
  MenuItem,
  Chip,
  Card,
  CardContent,
  IconButton,
  Tooltip,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { DataGrid, GridColDef, GridRowSelectionModel } from "@mui/x-data-grid";
import { styled } from "@mui/material/styles";
import AlertBox from "@/ui/alert";
import { backend_url } from "@/config";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";

export interface DocumentListData {
  DEBTOR_ID: string;
  FILE_NAME: string;
  FILE_EXTENSION: string;
  FILE_PATH: string;
  DOC_DESCRIPTION: string;
  FILE_UPLOAD_DATE: string;
  DOC_ID: number;
  DOC_CLASS_NAME: string;
  DOC_CLASS_NAME_EN: string;
  FILE_SIZE_KB: number;
  ROW_INDEX: number;
  PROCESSING_STATE: number;
}

interface DocumentsListProps {
  DocumentsInformation: DocumentListData[];
  TableLoading: boolean;
  DocumentTypeOptions: string[];
  DebtorIdValue: string;
}

const StyledDataGrid = styled(DataGrid)(() => ({
  border: "none",
  borderRadius: "0",
  "& .MuiDataGrid-columnHeaders": {
    backgroundColor: "#FAFBFC",
    borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
  },
  "& .MuiDataGrid-columnHeaderTitle": {
    fontWeight: 600,
    color: "#1A1C1E",
    fontSize: "0.75rem",
  },
  "& .MuiDataGrid-cell": {
    padding: "8px 16px",
    borderRight: "none",
    fontSize: "0.8rem",
  },
  "& .MuiDataGrid-row": {
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.03)",
    },
  },
  "& .MuiDataGrid-row.Mui-selected": {
    backgroundColor: "rgba(38, 137, 13, 0.06)",
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.1)",
    },
  },
  "& .MuiCheckbox-root.Mui-checked": {
    color: "#26890D",
  },
  "& .MuiDataGrid-footerContainer": {
    borderTop: "1px solid rgba(0, 0, 0, 0.08)",
  },
}));

const DocumentsList: React.FC<DocumentsListProps> = ({
  DocumentsInformation,
  DocumentTypeOptions,
  TableLoading,
  DebtorIdValue,
}) => {
  const [docRows, setDocRows] = useState<DocumentListData[]>([]);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [rowSelectionModel, setRowSelectionModel] = useState<GridRowSelectionModel>([]);
  const router = useRouter();
  const { fetchAgentLogs } = useContext(AgentLogsContext);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);

  const loadingMessages = [
    "Processing your request...",
    "Fetching data from the server...",
    "Extracting the relevant information...",
    "Planning the report generation steps...",
    "Executing the report generation agents...",
    "Finalizing the report generation...",
    "Almost there, just a few more minutes...",
  ];

  useEffect(() => {
    if (DocumentsInformation) {
      setDocRows(DocumentsInformation);
      if (DocumentsInformation.length > 0) {
        const selectedRows = DocumentsInformation.filter(
          (element) => element.PROCESSING_STATE === 1
        ).map((element) => element.ROW_INDEX);
        setRowSelectionModel(selectedRows);
      }
    }
  }, [DocumentsInformation]);

  const columns: GridColDef[] = [
    {
      field: "ROW_INDEX",
      headerName: "#",
      width: 50,
      valueGetter: (value: number) => value + 1,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "FILE_NAME",
      headerName: "File Name",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => {
        const name = params.value?.split(".")[0] || params.value;
        return (
          <Typography sx={{ fontSize: "0.8rem", fontWeight: 500, color: "#1A1C1E" }}>
            {name}
          </Typography>
        );
      },
    },
    {
      field: "FILE_EXTENSION",
      headerName: "Type",
      width: 70,
      renderCell: (params) => (
        <Chip
          label={params.value?.toUpperCase()}
          size="small"
          sx={{
            height: 22,
            fontSize: "0.65rem",
            fontWeight: 600,
            bgcolor:
              params.value === "pdf"
                ? "rgba(218, 41, 28, 0.1)"
                : params.value === "xlsx"
                ? "rgba(38, 137, 13, 0.1)"
                : "rgba(0, 124, 176, 0.1)",
            color:
              params.value === "pdf"
                ? "#DA291C"
                : params.value === "xlsx"
                ? "#26890D"
                : "#007CB0",
          }}
        />
      ),
      headerAlign: "center",
      align: "center",
    },
    {
      field: "FILE_PATH",
      headerName: "Location",
      flex: 1.2,
      minWidth: 200,
      valueGetter: (value: string) => {
        const regex = /Debtors_Data[\\\/][^\\\/]+[\\\/](.*)/;
        const match = value?.match(regex);
        return match ? match[1] : value;
      },
      renderCell: (params) => (
        <Typography sx={{ fontSize: "0.75rem", color: "#6B778C" }}>
          {params.value}
        </Typography>
      ),
    },
    {
      field: "DOC_CLASS_NAME",
      headerName: "Document Type",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <FormControl fullWidth size="small">
              <Select
                value={params.row.DOC_CLASS_NAME || ""}
                onChange={(event) =>
                  handleUpdateRow(params.id as number, event.target.value as string)
                }
                MenuProps={{
                  PaperProps: {
                    style: { maxHeight: 240, width: 250 },
                  },
                }}
                sx={{ fontSize: "0.75rem" }}
              >
                <MenuItem value="" disabled>
                  Select type
                </MenuItem>
                {DocumentTypeOptions.map((option: string, index: number) => (
                  <MenuItem value={option} key={index} sx={{ fontSize: "0.75rem" }}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          );
        }
        return (
          <Chip
            label={params.value || "Unclassified"}
            size="small"
            sx={{
              height: 24,
              fontSize: "0.7rem",
              fontWeight: 500,
              bgcolor: params.value ? "rgba(38, 137, 13, 0.08)" : "rgba(0, 0, 0, 0.04)",
              color: params.value ? "#26890D" : "#6B778C",
            }}
          />
        );
      },
    },
    {
      field: "DOC_DESCRIPTION",
      headerName: "Description",
      flex: 1.5,
      minWidth: 200,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <TextField
              fullWidth
              size="small"
              defaultValue={params.value}
              onChange={(event) =>
                handleUpdateRowDescription(params.id as number, event.target.value)
              }
              onKeyDown={(event) => event.stopPropagation()}
              sx={{ "& input": { fontSize: "0.75rem" } }}
            />
          );
        }
        return (
          <Typography sx={{ fontSize: "0.75rem", color: "#53565A" }}>
            {params.value || "—"}
          </Typography>
        );
      },
    },
  ];

  const updateProcessingState = (
    rows: DocumentListData[],
    selectedIndices: GridRowSelectionModel
  ) => {
    return rows.map((row) => ({
      ...row,
      PROCESSING_STATE: selectedIndices.includes(row.ROW_INDEX) ? 1 : 0,
    }));
  };

  const pollAgentProcessingStatus = async (jobId: string): Promise<boolean> => {
    const maxAttempts = 120;
    let attempts = 0;

    const checkStatus = async (): Promise<boolean> => {
      try {
        const response = await fetch(
          `${backend_url}/agent_processing_status/${jobId}`
        );

        if (!response.ok) {
          throw new Error("Failed to check processing status");
        }

        const status = await response.json();
        console.log("Agent processing status:", status);

        if (status.status === "completed") {
          return true;
        } else if (status.status === "failed") {
          setAlertMessage(`Processing failed: ${status.message || "Unknown error"}`);
          return false;
        }

        attempts++;
        if (attempts >= maxAttempts) {
          setAlertMessage("Processing is taking longer than expected");
          return false;
        }

        await new Promise((resolve) => setTimeout(resolve, 10000));
        return checkStatus();
      } catch (error) {
        console.error("Error checking status:", error);
        return false;
      }
    };

    return checkStatus();
  };

  const handleProcessDocuments = async () => {
    const updatedRows = updateProcessingState(docRows, rowSelectionModel);

    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(updatedRows));

    const updateApiRoute = `${backend_url}/update_document_metadata`;
    const agentApiRoute = `${backend_url}/start_agent_processing`;

    try {
      setLoading(true);
      setAlertMessage(null);

      const updateResponse = await fetch(updateApiRoute, {
        method: "POST",
        body: formData,
      });

      if (!updateResponse.ok) {
        throw new Error("Failed to update document metadata");
      }

      const agentResponse = await fetch(agentApiRoute, { method: "POST" });

      if (!agentResponse.ok) {
        throw new Error("Failed to start agent processing");
      }

      const agentResult = await agentResponse.json();
      console.log("Agent processing started:", agentResult);

      await new Promise((resolve) => setTimeout(resolve, 2000));
      const success = await pollAgentProcessingStatus(agentResult.job_id);

      setLoading(false);

      if (success) {
        await fetchAgentLogs();
        router.push("/modules/report-planning");
      }
    } catch (error) {
      setLoading(false);
      setAlertMessage("Error processing documents, please try again");
      console.error("Error:", error);
    }
  };

  const toggleEdit = () => setIsEditing(!isEditing);

  const handleSaveChanges = async () => {
    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(docRows));
    const apiRoute = `${backend_url}/update_document_metadata`;

    try {
      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to save changes");
      }

      console.log("Changes saved successfully");
    } catch (error) {
      console.error("Error saving changes:", error);
    }
  };

  const handleUpdateRow = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_CLASS_NAME: value } : row
      )
    );
  };

  const handleUpdateRowDescription = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_DESCRIPTION: value } : row
      )
    );
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 20000);

    return () => clearInterval(interval);
  }, [loading, loadingMessages.length]);

  if (!DocumentsInformation || DocumentsInformation.length === 0) {
    return null;
  }

  return (
    <Card
      sx={{
        borderRadius: "12px",
        border: "1px solid rgba(0, 0, 0, 0.06)",
        boxShadow: "none",
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 3,
          py: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
          bgcolor: "#FFFFFF",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 32,
              height: 32,
              borderRadius: "8px",
              bgcolor: "rgba(0, 124, 176, 0.1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <TableChartOutlinedIcon sx={{ fontSize: 18, color: "#007CB0" }} />
          </Box>
          <Box>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, color: "#1A1C1E" }}>
              Document List
            </Typography>
            <Typography variant="body2" sx={{ color: "#6B778C", fontSize: "0.75rem" }}>
              Documents categorized with extracted information • Review before processing
            </Typography>
          </Box>
        </Box>

        <Tooltip title={isEditing ? "Save changes" : "Edit document types"}>
          <IconButton
            onClick={() => {
              if (isEditing) {
                handleSaveChanges();
              }
              toggleEdit();
            }}
            disabled={docRows.length === 0}
            sx={{
              bgcolor: isEditing ? "rgba(38, 137, 13, 0.1)" : "rgba(0, 0, 0, 0.04)",
              color: isEditing ? "#26890D" : "#53565A",
              "&:hover": {
                bgcolor: isEditing ? "rgba(38, 137, 13, 0.15)" : "rgba(0, 0, 0, 0.08)",
              },
            }}
          >
            {isEditing ? <SaveOutlinedIcon sx={{ fontSize: 20 }} /> : <EditOutlinedIcon sx={{ fontSize: 20 }} />}
          </IconButton>
        </Tooltip>
      </Box>

      {/* Data Grid - Always visible, not collapsed */}
      <Box sx={{ height: 420, width: "100%" }}>
        <StyledDataGrid
          loading={TableLoading}
          rows={docRows}
          columns={columns}
          getRowId={(row) => row.ROW_INDEX}
          getRowHeight={() => "auto"}
          checkboxSelection
          disableRowSelectionOnClick
          onRowSelectionModelChange={setRowSelectionModel}
          rowSelectionModel={rowSelectionModel}
          slotProps={{
            loadingOverlay: {
              variant: "linear-progress",
              noRowsVariant: "linear-progress",
            },
          }}
          initialState={{
            pagination: { paginationModel: { pageSize: 10 } },
          }}
          pageSizeOptions={[10, 25, 50]}
          sx={{
            "& .MuiDataGrid-cell": {
              py: 1.5,
            },
          }}
        />
      </Box>

      {/* Footer Actions */}
      <Box
        sx={{
          px: 3,
          py: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderTop: "1px solid rgba(0, 0, 0, 0.06)",
          bgcolor: "#FAFBFC",
        }}
      >
        <Typography variant="body2" sx={{ color: "#6B778C", fontSize: "0.8rem" }}>
          <strong>{rowSelectionModel.length}</strong> of {docRows.length} documents selected for processing
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={handleProcessDocuments}
          disabled={
            TableLoading ||
            docRows.length === 0 ||
            isEditing ||
            rowSelectionModel.length === 0
          }
          sx={{
            textTransform: "none",
            fontWeight: 600,
            px: 4,
            borderRadius: "8px",
            boxShadow: "none",
            "&:hover": {
              boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
            },
          }}
        >
          Process Selected Documents
        </Button>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}

      {alertMessage && <AlertBox message={alertMessage} severity="error" />}
    </Card>
  );
};

export default DocumentsList;
