"use client";

import React, { useState, useEffect } from "react";
import { Box, Typography, Card, CardContent, Chip } from "@mui/material";
import PageHeader from "@/components/PageHeader";
import TemplateSelections from "./templateSelections";
import DocumentsList from "./documentsList";
import { backend_url } from "@/config";
import FolderOutlinedIcon from "@mui/icons-material/FolderOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";

export default function ConfigurationsPage() {
  const [documentsInformation, setDocumentsInformation] = useState<any>(null);
  const [tableLoading, setTableLoading] = useState(false);
  const [documentTypeOptions, setDocumentTypeOptions] = useState<any>([]);
  const [debtorIdValue, setDebtorIdValue] = useState<string>("None");
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchCurrentDebtor();
  }, []);

  const docCount = documentsInformation?.length || 0;
  const classifiedCount = documentsInformation?.filter((d: any) => d.DOC_CLASS_NAME)?.length || 0;

  return (
    <Box
      sx={{
        padding: "24px 32px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F5F7F9",
      }}
    >
      <PageHeader
        title="Configurations"
        subtitle="Select a template and debtor to load and process documents for analysis"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Stats Cards */}
      {documentsInformation && documentsInformation.length > 0 && (
        <Box sx={{ display: "flex", gap: 2, mb: 3 }}>
          <Card
            sx={{
              flex: 1,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              boxShadow: "none",
            }}
          >
            <CardContent sx={{ py: 2, px: 2.5, "&:last-child": { pb: 2 } }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <Box
                  sx={{
                    width: 36,
                    height: 36,
                    borderRadius: "8px",
                    bgcolor: "rgba(0, 124, 176, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <DescriptionOutlinedIcon sx={{ color: "#007CB0", fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    Documents Loaded
                  </Typography>
                  <Typography sx={{ fontSize: "1.25rem", fontWeight: 700, color: "#1A1C1E" }}>
                    {docCount}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>

          <Card
            sx={{
              flex: 1,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              boxShadow: "none",
            }}
          >
            <CardContent sx={{ py: 2, px: 2.5, "&:last-child": { pb: 2 } }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <Box
                  sx={{
                    width: 36,
                    height: 36,
                    borderRadius: "8px",
                    bgcolor: "rgba(38, 137, 13, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <CheckCircleOutlineIcon sx={{ color: "#26890D", fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    Classified
                  </Typography>
                  <Typography sx={{ fontSize: "1.25rem", fontWeight: 700, color: "#1A1C1E" }}>
                    {classifiedCount} / {docCount}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>

          <Card
            sx={{
              flex: 1,
              borderRadius: "12px",
              border: "1px solid rgba(0, 0, 0, 0.06)",
              boxShadow: "none",
            }}
          >
            <CardContent sx={{ py: 2, px: 2.5, "&:last-child": { pb: 2 } }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                <Box
                  sx={{
                    width: 36,
                    height: 36,
                    borderRadius: "8px",
                    bgcolor: "rgba(237, 139, 0, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <FolderOutlinedIcon sx={{ color: "#ED8B00", fontSize: 20 }} />
                </Box>
                <Box>
                  <Typography sx={{ fontSize: "0.7rem", color: "#6B778C", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    File Types
                  </Typography>
                  <Box sx={{ display: "flex", gap: 0.5, mt: 0.5 }}>
                    {Array.from(new Set(documentsInformation?.map((d: any) => d.FILE_EXTENSION?.toUpperCase()) || [])).slice(0, 3).map((ext: any) => (
                      <Chip
                        key={ext}
                        label={ext}
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: "0.65rem",
                          bgcolor: "rgba(0, 0, 0, 0.04)",
                          color: "#53565A",
                        }}
                      />
                    ))}
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Box>
      )}

      {/* Template Selection Card */}
      <Card
        sx={{
          borderRadius: "12px",
          border: "1px solid rgba(0, 0, 0, 0.06)",
          boxShadow: "none",
          mb: 3,
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <TemplateSelections
            setDocumentsInformation={setDocumentsInformation}
            setDocumentTypeOptions={setDocumentTypeOptions}
          />
        </CardContent>
      </Card>

      {/* Documents List */}
      <DocumentsList
        DocumentsInformation={documentsInformation}
        DocumentTypeOptions={documentTypeOptions}
        TableLoading={tableLoading}
        DebtorIdValue={debtorIdValue}
      />
    </Box>
  );
}
