"use client";

import React, { useState, useEffect, ChangeEvent } from "react";
import {
  Box,
  Typography,
  Button,
  FormControl,
  MenuItem,
  TextField,
} from "@mui/material";
import Grid from "@mui/material/Grid2";
import AlertBox from "@/ui/alert";
import { backend_url } from "@/config";
import CircularLoader from "@/ui/circularLoader";
import FolderOpenOutlinedIcon from "@mui/icons-material/FolderOpenOutlined";

interface TemplateSelectionsProps {
  setDocumentsInformation: (documents: unknown) => void;
  setDocumentTypeOptions: (options: unknown) => void;
}

const TemplateSelections: React.FC<TemplateSelectionsProps> = ({
  setDocumentsInformation,
  setDocumentTypeOptions,
}) => {
  const [debtorPortfolioValue, setDebtorPortfolioValue] = useState<string>("None");
  const [debtorPortfolioArray, setDebtorPortfolioArray] = useState<ReadonlyArray<string>>([]);
  const [debtorIdValue, setDebtorIdValue] = useState<string>("None");
  const [debtorIdArray, setDebtorIdArray] = useState<ReadonlyArray<string>>([]);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleTemplateChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.value !== "None") {
      setDebtorPortfolioValue(event.target.value);
    }
  };

  const handleDebtorIdChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.value !== "None") {
      setDebtorIdValue(event.target.value);
    }
  };

  useEffect(() => {
    if (debtorIdArray.length === 0) {
      getDebtorIdList();
    }
  }, [debtorIdArray.length]);

  const getDebtorIdList = async () => {
    const apiRoute = `${backend_url}/get_debtor_info`;
    try {
      setLoading(true);
      setAlertMessage(null);
      const response = await fetch(apiRoute, {
        method: "GET",
      });

      if (!response.ok) {
        setLoading(false);
        setAlertMessage("Something went wrong, please try again later");
        throw new Error("Upload failed");
      }

      const result = await response.json();
      setLoading(false);
      console.log("Received debtor template list:", result);
      setDebtorPortfolioArray(result.Debtor_Portfolio);
      setDebtorIdArray(result.Debtor_Id);
    } catch (error) {
      setLoading(false);
      setAlertMessage("Error occurred while retrieving debtor template list");
      console.error("Error retrieving debtor template list:", error);
    }
  };

  const handleSubmitDocuments = async () => {
    const formData = new FormData();
    const debtorId = debtorIdValue.split("_")[0];
    formData.append("debtor_id", debtorId);
    formData.append("debtor_portfolio", debtorPortfolioValue);

    const apiRoute = `${backend_url}/get_docs_list`;
    try {
      setLoading(true);
      setAlertMessage(null);
      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        setLoading(false);
        setAlertMessage("Something went wrong, please try again later");
        throw new Error("Upload failed");
      }

      const result = await response.json();
      setLoading(false);
      console.log("Received documents information:", result);
      const translateStringToJson = JSON.parse(result[1]);
      const translateStringArrayToJson = JSON.parse(result[0]);
      const documentTypeEn = translateStringArrayToJson.map(
        (obj: any) => obj.DOC_CLASS_NAME_EN
      );
      setDocumentsInformation(translateStringToJson);
      setDocumentTypeOptions(documentTypeEn);
    } catch (error) {
      setLoading(false);
      setAlertMessage("Error occurred while retrieving documents information");
      console.error("Error retrieving documents information:", error);
    }
  };

  return (
    <Box>
      <Box sx={{ display: "flex", alignItems: "center", gap: 1.5, mb: 3 }}>
        <Box
          sx={{
            width: 32,
            height: 32,
            borderRadius: "8px",
            bgcolor: "rgba(38, 137, 13, 0.1)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <FolderOpenOutlinedIcon sx={{ fontSize: 18, color: "#26890D" }} />
        </Box>
        <Box>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, color: "#1A1C1E" }}>
            Select Template & Debtor
          </Typography>
          <Typography variant="body2" sx={{ color: "#6B778C", fontSize: "0.75rem" }}>
            Choose a portfolio template and debtor to load their documents
          </Typography>
        </Box>
      </Box>

      <Grid container spacing={3} alignItems="flex-end">
        <Grid size={{ xs: 12, md: 4 }}>
          <Box>
            <Typography
              sx={{
                fontSize: "0.75rem",
                fontWeight: 600,
                mb: 1,
                color: "#53565A",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
              }}
            >
              Template
            </Typography>
            <FormControl fullWidth>
              <TextField
                select
                size="small"
                id="portfolio-select"
                value={debtorPortfolioValue}
                onChange={handleTemplateChange}
                placeholder="Select a template"
                SelectProps={{
                  MenuProps: {
                    PaperProps: {
                      style: {
                        maxHeight: 5 * 48,
                        width: "auto",
                      },
                    },
                  },
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    backgroundColor: "#FFFFFF",
                    borderRadius: "8px",
                  },
                }}
              >
                <MenuItem value="None" disabled>
                  Select a template
                </MenuItem>
                {debtorPortfolioArray.map((template: string) => (
                  <MenuItem
                    value={template}
                    key={template}
                    disabled={template !== "BE- Large corporates (non real estate)"}
                    sx={{
                      color:
                        template !== "BE- Large corporates (non real estate)"
                          ? "text.disabled"
                          : "inherit",
                    }}
                  >
                    {template}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Box>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Box>
            <Typography
              sx={{
                fontSize: "0.75rem",
                fontWeight: 600,
                mb: 1,
                color: "#53565A",
                textTransform: "uppercase",
                letterSpacing: "0.5px",
              }}
            >
              Debtor
            </Typography>
            <FormControl fullWidth>
              <TextField
                select
                size="small"
                id="debtor-select"
                value={debtorIdValue}
                onChange={handleDebtorIdChange}
                placeholder="Select a debtor"
                SelectProps={{
                  MenuProps: {
                    PaperProps: {
                      style: {
                        maxHeight: 5 * 48,
                        width: "auto",
                      },
                    },
                  },
                }}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    backgroundColor: "#FFFFFF",
                    borderRadius: "8px",
                  },
                }}
              >
                <MenuItem value="None" disabled>
                  Select a debtor
                </MenuItem>
                {debtorIdArray.map((debtor: string) => (
                  <MenuItem value={debtor} key={debtor}>
                    {debtor}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Box>
        </Grid>

        <Grid size={{ xs: 12, md: 4 }}>
          <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={handleSubmitDocuments}
            disabled={debtorIdValue === "None" || debtorPortfolioValue === "None"}
            sx={{
              height: 40,
              textTransform: "none",
              fontWeight: 600,
              borderRadius: "8px",
              boxShadow: "none",
              "&:hover": {
                boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
              },
            }}
          >
            Load Documents
          </Button>
        </Grid>
      </Grid>

      {alertMessage && (
        <Box sx={{ mt: 2 }}>
          <AlertBox message={alertMessage} severity="error" />
        </Box>
      )}

      {loading && <CircularLoader open={loading} />}
    </Box>
  );
};

export default TemplateSelections;
