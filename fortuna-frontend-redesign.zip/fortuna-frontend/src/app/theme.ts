"use client";

import { Open_Sans } from "next/font/google";
import { createTheme } from "@mui/material/styles";

const opensans = Open_Sans({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

const theme = createTheme({
  typography: {
    fontFamily: opensans.style.fontFamily,
    fontSize: 13,
    h3: { fontWeight: 700 },
    h4: { fontWeight: 700, fontSize: "1.5rem" },
    h5: { fontWeight: 600, fontSize: "1.25rem" },
    h6: { fontWeight: 600, fontSize: "1rem" },
    subtitle1: { fontWeight: 600, fontSize: "0.9rem" },
    body1: { lineHeight: 1.6, fontSize: "0.875rem" },
    body2: { lineHeight: 1.5, fontSize: "0.8125rem" },
  },
  palette: {
    primary: { main: "#26890D", light: "#86BC25", dark: "#1a6609", contrastText: "#FFFFFF" },
    secondary: { main: "#007CB0", light: "#D0D0CE" },
    error: { main: "#DA291C" },
    warning: { main: "#ED8B00" },
    success: { main: "#86BC25" },
    grey: {
      50: "#FAFBFC", 100: "#F5F7F9", 200: "#E6E6E6", 300: "#D0D0CE",
      400: "#A5ADBA", 500: "#6B778C", 600: "#53565A", 700: "#3f444a",
      800: "#2C2F33", 900: "#1A1C1E",
    },
    background: { default: "#F5F7F9", paper: "#FFFFFF" },
    text: { primary: "#1A1C1E", secondary: "#53565A" },
  },
  shape: { borderRadius: 8 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { textTransform: "none", fontWeight: 600, borderRadius: 6, transition: "all 0.2s ease" },
        contained: { boxShadow: "none", "&:hover": { boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)" } },
        outlined: { borderWidth: "1.5px", "&:hover": { borderWidth: "1.5px" } },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: { borderRadius: 12, boxShadow: "0 1px 4px rgba(0, 0, 0, 0.06)", border: "1px solid rgba(0, 0, 0, 0.06)" },
      },
    },
    MuiPaper: { styleOverrides: { root: { backgroundImage: "none" } } },
    MuiChip: { styleOverrides: { root: { fontWeight: 500, borderRadius: 6 }, sizeSmall: { height: 24 } } },
    MuiAccordion: {
      styleOverrides: {
        root: {
          borderRadius: "12px !important", "&:before": { display: "none" },
          boxShadow: "0 1px 4px rgba(0, 0, 0, 0.06)", border: "1px solid rgba(0, 0, 0, 0.06)", overflow: "hidden",
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 8, transition: "all 0.2s ease",
            "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "#26890D" },
          },
        },
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: "none",
          "& .MuiDataGrid-cell:focus": { outline: "none" },
          "& .MuiDataGrid-row.Mui-selected": { backgroundColor: "rgba(38, 137, 13, 0.08)", "&:hover": { backgroundColor: "rgba(38, 137, 13, 0.12)" } },
          "& .MuiDataGrid-columnHeaders": { backgroundColor: "#F5F7F9" },
        },
      },
    },
  },
});

export default theme;
