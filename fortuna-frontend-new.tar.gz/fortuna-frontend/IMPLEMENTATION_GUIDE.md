# Fortuna Frontend Transformation - Implementation Guide

## Overview

This guide explains how to implement the new Fortuna frontend based on APM's "Old UI" design pattern. The new design features a sidebar navigation, main content area with page-specific content, and an optional chat panel.

---

## File Structure

```
src/
├── app/
│   ├── (main)/
│   │   ├── app.tsx                    # Main app wrapper with providers (MODIFIED)
│   │   ├── layout.tsx                 # Root layout with AppRouterCacheProvider (MODIFIED)
│   │   ├── page.tsx                   # Root page - redirects to configurations (MODIFIED)
│   │   └── modules/
│   │       ├── upload-document/
│   │       │   ├── page.tsx           # Configurations page (MODIFIED)
│   │       │   ├── documentsList.tsx  # Document list component (MODIFIED)
│   │       │   └── templateSelections.tsx  # Template selector component (MODIFIED)
│   │       ├── report-planning/
│   │       │   ├── page.tsx           # Report Generation page with chat (MODIFIED)
│   │       │   └── agentLogs.tsx      # Recursive accordion for logs (MODIFIED)
│   │       └── report-generation/
│   │           └── page.tsx           # KEEP EXISTING - Report preview page
│   ├── globals.css                    # Global CSS styles (MODIFIED)
│   ├── icon.ico                       # KEEP EXISTING
│   ├── layout.tsx                     # Base HTML layout (MODIFIED)
│   ├── not-found.tsx                  # 404 page (MODIFIED)
│   ├── page.tsx                       # KEEP EXISTING - root redirect
│   ├── theme.ts                       # MUI theme configuration (MODIFIED)
│   └── types.ts                       # KEEP EXISTING - TypeScript interfaces
├── components/                        # NEW FOLDER
│   ├── Sidebar.tsx                    # NEW: Sidebar navigation
│   ├── MainLayout.tsx                 # NEW: Layout wrapper
│   ├── PageHeader.tsx                 # NEW: Reusable page header
│   └── ChatPanel.tsx                  # NEW: Chat panel (backend TODO)
├── contexts/
│   └── AgentLogsContext.js            # Agent logs state management (MODIFIED)
├── ui/
│   ├── alert.tsx                      # Enhanced alert component (MODIFIED)
│   ├── circularLoader.tsx             # Loading overlay component (MODIFIED)
│   ├── navbar.tsx                     # DELETE THIS FILE
│   └── previewFile.tsx                # KEEP EXISTING
└── config.js                          # Backend URL configuration (KEEP EXISTING)
```

---

## Installation Steps

### Step 1: Backup Current Code
```bash
cp -r /path/to/fortuna/frontend /path/to/backup/frontend-backup
```

### Step 2: Create New Components Folder
```bash
mkdir -p src/components
```

### Step 3: Add New Components

Copy these NEW files to `src/components/`:
- `Sidebar.tsx`
- `MainLayout.tsx`
- `PageHeader.tsx`
- `ChatPanel.tsx`

### Step 4: Replace Modified Files

Replace these EXISTING files:
- `src/app/(main)/app.tsx`
- `src/app/(main)/layout.tsx`
- `src/app/(main)/page.tsx`
- `src/app/(main)/modules/upload-document/page.tsx`
- `src/app/(main)/modules/upload-document/templateSelections.tsx`
- `src/app/(main)/modules/upload-document/documentsList.tsx`
- `src/app/(main)/modules/report-planning/page.tsx`
- `src/app/(main)/modules/report-planning/agentLogs.tsx`
- `src/app/globals.css`
- `src/app/layout.tsx`
- `src/app/not-found.tsx`
- `src/app/theme.ts`
- `src/ui/alert.tsx`
- `src/ui/circularLoader.tsx`
- `src/contexts/AgentLogsContext.js`

### Step 5: Delete Old Navbar
```bash
rm src/ui/navbar.tsx
```

### Step 6: Keep These Files Unchanged
- `src/app/(main)/modules/report-generation/page.tsx`
- `src/app/types.ts`
- `src/app/icon.ico`
- `src/ui/previewFile.tsx`
- `src/config.js`

### Step 7: Run the Application
```bash
npm install
npm run dev
```

---

## What Changed

### New Components (4 files)

| Component | Purpose |
|-----------|---------|
| `Sidebar.tsx` | Black sidebar with logo, debtor display, and navigation |
| `MainLayout.tsx` | Wraps all pages with sidebar and main content area |
| `PageHeader.tsx` | Consistent page headers with title, subtitle, and debtor badge |
| `ChatPanel.tsx` | Chat interface for report discussion (backend not connected) |

### Modified Components (15 files)

| Component | Changes |
|-----------|---------|
| `app.tsx` | Now uses MainLayout instead of Navbar |
| `(main)/layout.tsx` | Updated imports |
| `(main)/page.tsx` | Simplified redirect |
| `upload-document/page.tsx` | Uses PageHeader, inline MUI styles |
| `upload-document/templateSelections.tsx` | Cleaner form layout |
| `upload-document/documentsList.tsx` | Improved DataGrid styling |
| `report-planning/page.tsx` | Added ChatPanel, inline MUI styles |
| `report-planning/agentLogs.tsx` | TypeScript types, improved styling |
| `globals.css` | Simplified global styles |
| `layout.tsx` | Updated metadata |
| `not-found.tsx` | Better 404 page |
| `theme.ts` | Enhanced MUI theme |
| `alert.tsx` | Auto-dismiss functionality |
| `circularLoader.tsx` | Better visual design |
| `AgentLogsContext.js` | Minor cleanup |

### Deleted Files (1 file)

| File | Reason |
|------|--------|
| `navbar.tsx` | Replaced by Sidebar.tsx |

### Kept Unchanged (5 files)

| File | Reason |
|------|--------|
| `report-generation/page.tsx` | Existing page, added to navigation |
| `types.ts` | TypeScript interfaces |
| `icon.ico` | Favicon |
| `previewFile.tsx` | File preview component |
| `config.js` | Backend configuration |

---

## Backend Endpoints (Unchanged)

All existing backend endpoints remain the same:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/get_current_debtor` | GET | Get currently selected debtor |
| `/get_debtor_info` | GET | Get debtor portfolio/ID lists |
| `/get_docs_list` | POST | Get documents for selected debtor |
| `/process_document_list` | POST | Submit documents for processing |
| `/start_agent_processing` | POST | Trigger agent processing job |
| `/agent_processing_status/{jobId}` | GET | Poll processing status |
| `/update_document_metadata` | POST | Save document metadata edits |
| `/download_report` | GET | Download generated Excel report |
| `/get_agent_logs` | GET | Fetch agent execution logs |

---

## Navigation Structure

The sidebar now includes these navigation items:

| Item | Route | Status |
|------|-------|--------|
| Configurations | `/modules/upload-document` | Active |
| Report Generation | `/modules/report-planning` | Active |
| Report Preview | `/modules/report-generation` | Active |
| Saved Reports | `/modules/saved-reports` | Disabled (Coming soon) |
| History | `/modules/history` | Disabled (Coming soon) |
| Settings | — | Disabled |
| Help & Support | — | Disabled |

---

## TODO Items

The following items are marked for future implementation:

1. **ChatPanel Backend Connection**
   - File: `src/components/ChatPanel.tsx`
   - The chat panel UI is complete but not connected to a backend endpoint

2. **Saved Reports Page**
   - Create `/modules/saved-reports/page.tsx` when ready

3. **History Page**
   - Create `/modules/history/page.tsx` when ready

---

## Testing Checklist

Before demo, verify these work:

- [ ] App loads with new sidebar
- [ ] Navigation between all three pages works
- [ ] Current debtor shows in sidebar (after selection)
- [ ] Template and debtor dropdowns populate
- [ ] Document list loads after selection
- [ ] Edit mode in document list works
- [ ] Save changes in document list works
- [ ] Process documents triggers agent processing
- [ ] Redirect to Report Generation page after processing
- [ ] Agent logs accordion displays
- [ ] Expand/collapse buttons work
- [ ] Download report button works
- [ ] Chat panel displays (disabled state) before processing
- [ ] Chat panel enabled after processing
- [ ] Report Preview page still works

---

## Visual Reference

```
┌──────────────────────────────────────────────────────────────┐
│ ┌─────────┐ ┌──────────────────────────┐ ┌────────────────┐ │
│ │         │ │                          │ │                │ │
│ │ SIDEBAR │ │     MAIN CONTENT         │ │  CHAT PANEL    │ │
│ │ (260px) │ │                          │ │  (optional)    │ │
│ │         │ │  ┌────────────────────┐  │ │                │ │
│ │ • Logo  │ │  │ Page Header        │  │ │                │ │
│ │ • Title │ │  └────────────────────┘  │ │                │ │
│ │ • Debtor│ │                          │ │                │ │
│ │ • Nav   │ │  [Page Content]          │ │                │ │
│ │         │ │                          │ │                │ │
│ └─────────┘ └──────────────────────────┘ └────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

Colors:
- Sidebar: Black (#000000)
- Main content background: Light gray (#F5F7F9)
- Content cards: White (#FFFFFF)
- Primary accent: Deloitte Green (#26890D)
- Text: Black (#000000) and Gray (#53565A)
