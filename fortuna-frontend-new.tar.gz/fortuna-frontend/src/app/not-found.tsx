"use client";

import { Box, Typography, Button } from "@mui/material";
import Link from "next/link";

export default function NotFound() {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "100vh",
        textAlign: "center",
        padding: 4,
        backgroundColor: "#F5F7F9",
      }}
    >
      <Typography
        variant="h1"
        sx={{
          fontSize: "6rem",
          fontWeight: 700,
          color: "#D0D0CE",
          mb: 2,
        }}
      >
        404
      </Typography>
      <Typography
        variant="h5"
        sx={{
          fontWeight: 600,
          color: "#000000",
          mb: 1,
        }}
      >
        Page Not Found
      </Typography>
      <Typography
        variant="body1"
        sx={{
          color: "#53565A",
          mb: 4,
        }}
      >
        The page you are looking for does not exist or has been moved.
      </Typography>
      <Link href="/modules/upload-document" passHref>
        <Button
          variant="contained"
          color="primary"
          sx={{
            textTransform: "none",
            fontWeight: 600,
            px: 4,
          }}
        >
          Return to Home
        </Button>
      </Link>
    </Box>
  );
}
