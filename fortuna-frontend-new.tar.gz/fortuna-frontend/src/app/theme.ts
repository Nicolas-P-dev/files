"use client";

import { Open_Sans } from "next/font/google";
import { createTheme } from "@mui/material/styles";

const opensans = Open_Sans({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

const theme = createTheme({
  typography: {
    fontFamily: opensans.style.fontFamily,
    fontSize: 13,
    h4: {
      fontWeight: 700,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
    subtitle1: {
      fontWeight: 600,
    },
    body1: {
      lineHeight: 1.6,
    },
    body2: {
      lineHeight: 1.5,
    },
  },
  palette: {
    primary: {
      main: "#26890D",
      light: "#86BC25",
      dark: "#1a6609",
      contrastText: "#FFFFFF",
    },
    secondary: {
      main: "#007CB0",
      light: "#D0D0CE",
    },
    error: {
      main: "#DA291C",
    },
    warning: {
      main: "#ED8B00",
    },
    success: {
      main: "#86BC25",
    },
    grey: {
      100: "#F5F7F9",
      200: "#E6E6E6",
      300: "#D0D0CE",
      400: "#A5ADBA",
      500: "#6B778C",
      600: "#53565A",
      700: "#3f444a",
    },
    background: {
      default: "#F5F7F9",
      paper: "#FFFFFF",
    },
    text: {
      primary: "#000000",
      secondary: "#53565A",
    },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          borderRadius: 6,
        },
        contained: {
          boxShadow: "none",
          "&:hover": {
            boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.08)",
        },
      },
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          padding: 16,
          "&:last-child": {
            paddingBottom: 16,
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
        },
      },
    },
    MuiAccordion: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          "&:before": {
            display: "none",
          },
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.08)",
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 6,
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          borderRadius: 6,
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          backgroundColor: "#26890D",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 500,
          "&.Mui-selected": {
            color: "#26890D",
          },
        },
      },
      defaultProps: {
        disableRipple: true,
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: "none",
          "& .MuiDataGrid-cell:focus": {
            outline: "none",
          },
          "& .MuiDataGrid-row.Mui-selected": {
            backgroundColor: "rgba(38, 137, 13, 0.08)",
            "&:hover": {
              backgroundColor: "rgba(38, 137, 13, 0.12)",
            },
          },
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        track: {
          opacity: 0.3,
          backgroundColor: "#53565A",
        },
        thumb: {
          backgroundColor: "#007CB0",
        },
      },
    },
  },
});

export default theme;
