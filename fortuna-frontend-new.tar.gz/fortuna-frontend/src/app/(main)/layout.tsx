import { AppRouterCacheProvider } from "@mui/material-nextjs/v13-appRouter";
import App from "@/app/(main)/app";
import "@/app/globals.css";

export const metadata = {
  title: "FORTUNA | aiStudio",
  description: "AI Agents for automated generation of CFR (Credit File Review) reports.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/icon.ico" sizes="any" />
      </head>
      <body>
        <AppRouterCacheProvider>
          <App>{children}</App>
        </AppRouterCacheProvider>
      </body>
    </html>
  );
}
