"use client";

import React, { useEffect, useState, useContext } from "react";
import {
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Box,
  TextField,
  FormControl,
  Select,
  MenuItem,
  Chip,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { DataGrid, GridColDef, GridRowSelectionModel } from "@mui/x-data-grid";
import Grid from "@mui/material/Grid2";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { styled } from "@mui/material/styles";
import AlertBox from "@/ui/alert";
import { backend_url } from "@/config";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

export interface DocumentListData {
  DEBTOR_ID: string;
  FILE_NAME: string;
  FILE_EXTENSION: string;
  FILE_PATH: string;
  DOC_DESCRIPTION: string;
  FILE_UPLOAD_DATE: string;
  DOC_ID: number;
  DOC_CLASS_NAME: string;
  DOC_CLASS_NAME_EN: string;
  FILE_SIZE_KB: number;
  ROW_INDEX: number;
  PROCESSING_STATE: number;
}

interface DocumentsListProps {
  DocumentsInformation: DocumentListData[];
  TableLoading: boolean;
  DocumentTypeOptions: string[];
  DebtorIdValue: string;
}

const StyledDataGrid = styled(DataGrid)(() => ({
  border: "1px solid rgba(0, 0, 0, 0.08)",
  borderRadius: "8px",
  "& .MuiDataGrid-columnHeaders": {
    backgroundColor: "#F5F7F9",
    borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
  },
  "& .MuiDataGrid-columnHeaderTitle": {
    fontWeight: 600,
    color: "#000000",
  },
  "& .MuiDataGrid-cell": {
    padding: "8px 16px",
    borderRight: "1px solid rgba(0, 0, 0, 0.04)",
  },
  "& .MuiDataGrid-row": {
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.04)",
    },
  },
  "& .MuiDataGrid-row.Mui-selected": {
    backgroundColor: "rgba(38, 137, 13, 0.08)",
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.12)",
    },
  },
  "& .MuiCheckbox-root.Mui-checked": {
    color: "#26890D",
  },
  "& .row-status-success": {
    backgroundColor: "rgba(134, 188, 37, 0.08)",
  },
  "& .row-status-error": {
    backgroundColor: "rgba(218, 41, 28, 0.08)",
  },
  "& .row-status-pending": {
    backgroundColor: "rgba(237, 139, 0, 0.08)",
  },
}));

const DocumentsList: React.FC<DocumentsListProps> = ({
  DocumentsInformation,
  DocumentTypeOptions,
  TableLoading,
  DebtorIdValue,
}) => {
  const [docRows, setDocRows] = useState<DocumentListData[]>([]);
  const [expandedAccordion, setExpandedAccordion] = useState<boolean>(true);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [rowSelectionModel, setRowSelectionModel] = useState<GridRowSelectionModel>([]);
  const router = useRouter();
  const { fetchAgentLogs } = useContext(AgentLogsContext);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);

  const loadingMessages = [
    "Processing your request...",
    "Fetching data from the server...",
    "Extracting the relevant information...",
    "Planning the report generation steps...",
    "Executing the report generation agents...",
    "Finalizing the report generation...",
    "Almost there, just a few more minutes...",
  ];

  useEffect(() => {
    if (DocumentsInformation) {
      setDocRows(DocumentsInformation);
      if (DocumentsInformation.length > 0) {
        const selectedRows = DocumentsInformation.filter(
          (element) => element.PROCESSING_STATE === 1
        ).map((element) => element.ROW_INDEX);
        setRowSelectionModel(selectedRows);
      }
    }
  }, [DocumentsInformation]);

  const columns: GridColDef[] = [
    {
      field: "ROW_INDEX",
      headerName: "#",
      width: 60,
      valueGetter: (value: number) => value + 1,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "FILE_NAME",
      headerName: "File Name",
      flex: 1,
      minWidth: 150,
      valueGetter: (value: string) => value.split(".")[0],
    },
    {
      field: "FILE_EXTENSION",
      headerName: "Type",
      width: 80,
      valueGetter: (value: string) => value.toUpperCase(),
      headerAlign: "center",
      align: "center",
    },
    {
      field: "FILE_PATH",
      headerName: "Location",
      flex: 1.5,
      minWidth: 200,
      valueGetter: (value: string) => {
        const regex = /Debtors_Data[\\\/][^\\\/]+[\\\/](.*)/;
        const match = value.match(regex);
        return match ? match[1] : value;
      },
    },
    {
      field: "DOC_CLASS_NAME",
      headerName: "Document Type",
      flex: 1,
      minWidth: 180,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <FormControl fullWidth size="small">
              <Select
                value={params.row.DOC_CLASS_NAME || ""}
                onChange={(event) =>
                  handleUpdateRow(params.id as number, event.target.value as string)
                }
                MenuProps={{
                  PaperProps: {
                    style: { maxHeight: 240, width: 250 },
                  },
                }}
              >
                <MenuItem value="" disabled>
                  Select type
                </MenuItem>
                {DocumentTypeOptions.map((option: string, index: number) => (
                  <MenuItem value={option} key={index}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          );
        }
        return (
          <Chip
            label={params.value || "Unclassified"}
            size="small"
            sx={{
              bgcolor: params.value ? "rgba(38, 137, 13, 0.1)" : "rgba(0, 0, 0, 0.05)",
              color: params.value ? "#26890D" : "#53565A",
              fontWeight: 500,
            }}
          />
        );
      },
    },
    {
      field: "DOC_DESCRIPTION",
      headerName: "Description",
      flex: 1.5,
      minWidth: 200,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <TextField
              fullWidth
              size="small"
              defaultValue={params.value}
              onChange={(event) =>
                handleUpdateRowDescription(params.id as number, event.target.value)
              }
              onKeyDown={(event) => event.stopPropagation()}
            />
          );
        }
        return params.value || "—";
      },
    },
    {
      field: "FILE_UPLOAD_DATE",
      headerName: "Processed",
      width: 160,
      valueGetter: (value: string) => {
        if (!value) return "—";
        return value.split(".")[0].replace("T", " ");
      },
      headerAlign: "center",
    },
  ];

  const updateProcessingState = (
    rows: DocumentListData[],
    selectedIndices: GridRowSelectionModel
  ) => {
    return rows.map((row) => ({
      ...row,
      PROCESSING_STATE: selectedIndices.includes(row.ROW_INDEX) ? 1 : 0,
    }));
  };

  const pollAgentProcessingStatus = async (jobId: string): Promise<boolean> => {
    const maxAttempts = 120;
    let attempts = 0;

    const checkStatus = async (): Promise<boolean> => {
      try {
        const response = await fetch(
          `${backend_url}/agent_processing_status/${jobId}`
        );

        if (!response.ok) {
          throw new Error("Failed to check processing status");
        }

        const status = await response.json();
        console.log("Agent processing status:", status);

        if (status.status === "completed") {
          return true;
        } else if (status.status === "failed") {
          setAlertMessage(`Processing failed: ${status.message || "Unknown error"}`);
          return false;
        }

        attempts++;
        if (attempts >= maxAttempts) {
          setAlertMessage("Processing is taking longer than expected");
          return false;
        }

        await new Promise((resolve) => setTimeout(resolve, 10000));
        return checkStatus();
      } catch (error) {
        console.error("Error checking status:", error);
        attempts++;
        if (attempts < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, 10000));
          return checkStatus();
        }
        setAlertMessage("Could not verify processing status");
        return false;
      }
    };

    return checkStatus();
  };

  const handleProcessDocuments = async () => {
    const updatedRows = updateProcessingState(docRows, rowSelectionModel);

    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(updatedRows));
    const apiRoute = `${backend_url}/process_document_list`;

    try {
      setLoading(true);
      setAlertMessage(null);

      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const result = await response.json();
      console.log("Documents submitted:", result);

      const agentResponse = await fetch(`${backend_url}/start_agent_processing`, {
        method: "POST",
      });

      if (!agentResponse.ok) {
        throw new Error("Failed to start agent processing");
      }

      const agentResult = await agentResponse.json();
      console.log("Agent processing started:", agentResult);

      await new Promise((resolve) => setTimeout(resolve, 2000));
      const success = await pollAgentProcessingStatus(agentResult.job_id);

      setLoading(false);

      if (success) {
        router.push("/modules/report-planning");
      }
    } catch (error) {
      setLoading(false);
      setAlertMessage("Error processing documents, please try again");
      console.error("Error:", error);
    }
  };

  const toggleEdit = () => setIsEditing(!isEditing);

  const handleSaveChanges = async () => {
    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(docRows));
    const apiRoute = `${backend_url}/update_document_metadata`;

    try {
      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to save changes");
      }

      console.log("Changes saved successfully");
    } catch (error) {
      console.error("Error saving changes:", error);
    }
  };

  const handleUpdateRow = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_CLASS_NAME: value } : row
      )
    );
  };

  const handleUpdateRowDescription = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_DESCRIPTION: value } : row
      )
    );
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 20000);

    return () => clearInterval(interval);
  }, [loading, loadingMessages.length]);

  if (!DocumentsInformation || DocumentsInformation.length === 0) {
    return null;
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Accordion
        expanded={expandedAccordion}
        onChange={() => setExpandedAccordion(!expandedAccordion)}
        sx={{
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.08)",
          borderRadius: "8px !important",
          "&:before": { display: "none" },
          overflow: "hidden",
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          sx={{
            bgcolor: "#FFFFFF",
            borderBottom: expandedAccordion ? "1px solid rgba(0, 0, 0, 0.08)" : "none",
          }}
        >
          <Box>
            <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
              Document List
            </Typography>
            <Typography variant="body2" color="textSecondary">
              Document types and descriptions have been auto-populated. Review before
              processing.
            </Typography>
          </Box>
        </AccordionSummary>

        <AccordionDetails sx={{ p: 0, bgcolor: "#FFFFFF" }}>
          <Box sx={{ p: 2, display: "flex", justifyContent: "flex-end" }}>
            <Button
              variant="outlined"
              onClick={() => {
                if (isEditing) {
                  handleSaveChanges();
                }
                toggleEdit();
              }}
              disabled={docRows.length === 0}
              sx={{
                textTransform: "none",
                fontWeight: 500,
                borderColor: "#26890D",
                color: "#26890D",
                "&:hover": {
                  borderColor: "#1a6609",
                  bgcolor: "rgba(38, 137, 13, 0.04)",
                },
              }}
            >
              {isEditing ? "Save Changes" : "Edit Table"}
            </Button>
          </Box>

          <Box sx={{ height: 500, width: "100%" }}>
            <StyledDataGrid
              loading={TableLoading}
              rows={docRows}
              columns={columns}
              getRowId={(row) => row.ROW_INDEX}
              getRowHeight={() => "auto"}
              checkboxSelection
              disableRowSelectionOnClick
              onRowSelectionModelChange={setRowSelectionModel}
              rowSelectionModel={rowSelectionModel}
              slotProps={{
                loadingOverlay: {
                  variant: "linear-progress",
                  noRowsVariant: "linear-progress",
                },
              }}
              initialState={{
                pagination: { paginationModel: { pageSize: 25 } },
              }}
              pageSizeOptions={[25, 50, 100]}
              sx={{ border: "none" }}
            />
          </Box>
        </AccordionDetails>
      </Accordion>

      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2, gap: 2 }}>
        <Typography variant="body2" sx={{ alignSelf: "center", color: "#53565A" }}>
          {rowSelectionModel.length} of {docRows.length} documents selected
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={handleProcessDocuments}
          disabled={
            TableLoading ||
            docRows.length === 0 ||
            isEditing ||
            rowSelectionModel.length === 0
          }
          sx={{
            textTransform: "none",
            fontWeight: 600,
            px: 4,
            boxShadow: "none",
            "&:hover": {
              boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
            },
          }}
        >
          Process Documents
        </Button>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}

      {alertMessage && <AlertBox message={alertMessage} severity="error" />}
    </Box>
  );
};

export default DocumentsList;
