"use client";

import React, { useState, useEffect } from "react";
import { Typography, Box, Button, Paper } from "@mui/material";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import PageHeader from "@/components/PageHeader";
import ChatPanel from "@/components/ChatPanel";
import CircularLoader from "@/ui/circularLoader";
import AgentAccordionwithButton from "./agentLogs";
import { backend_url } from "@/config";

const loadingMessages = ["Preparing the report for download..."];

export default function ReportPlanningPage() {
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [isAccordionOpen, setIsAccordionOpen] = useState(false);
  const [hasProcessedData, setHasProcessedData] = useState(false);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
        } else {
          setCurrentDebtor(null);
          setHasProcessedData(false);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
        setCurrentDebtor(null);
        setHasProcessedData(false);
      }
    };
    fetchCurrentDebtor();
  }, []);

  const handleAccordionOpenClick = () => {
    setIsAccordionOpen(!isAccordionOpen);
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${backend_url}/download_report`);

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_Filled_Template.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
      setLoading(false);
    } catch (error) {
      console.error("Download error:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [loading]);

  return (
    <Box
      sx={{
        padding: "24px 32px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F5F7F9",
      }}
    >
      <PageHeader
        title="Report Generation"
        subtitle="Review the agent processing results and download the generated report"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
        actions={
          <Button
            variant="contained"
            color="primary"
            onClick={handleDownload}
            disabled={!currentDebtor}
            sx={{
              textTransform: "none",
              fontWeight: 600,
              boxShadow: "none",
              "&:hover": {
                boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
              },
            }}
          >
            Download Report (.xlsx)
          </Button>
        }
      />

      <Box
        sx={{
          display: "flex",
          gap: "16px",
          height: "calc(100vh - 200px)",
          minHeight: "500px",
        }}
      >
        <PanelGroup direction="horizontal" autoSaveId="report-panels">
          {/* Main Workspace Panel */}
          <Panel defaultSize={65} minSize={40}>
            <Paper
              elevation={0}
              sx={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                border: "1px solid rgba(0, 0, 0, 0.08)",
                borderRadius: 2,
                overflow: "hidden",
              }}
            >
              <Box
                sx={{
                  px: 2.5,
                  py: 2,
                  borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
                  bgcolor: "#FAFAFA",
                }}
              >
                <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                  Workspace
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Navigate through the audit trail using the expand and collapse
                  buttons
                </Typography>
              </Box>

              <Box sx={{ flex: 1, overflow: "auto", p: 2 }}>
                {currentDebtor ? (
                  <AgentAccordionwithButton onClick={handleAccordionOpenClick} />
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      color: "#53565A",
                    }}
                  >
                    <Typography variant="body1" sx={{ fontWeight: 500, mb: 1 }}>
                      No data available
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Process documents in Configurations to view agent logs
                    </Typography>
                  </Box>
                )}
              </Box>
            </Paper>
          </Panel>

          {/* Resize Handle */}
          <PanelResizeHandle
            style={{
              width: "8px",
              background: "transparent",
              cursor: "col-resize",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: "2px",
                height: "40px",
                bgcolor: "#D0D0CE",
                borderRadius: "1px",
                transition: "background-color 0.2s",
                "&:hover": {
                  bgcolor: "#26890D",
                },
              }}
            />
          </PanelResizeHandle>

          {/* Chat Panel */}
          <Panel defaultSize={35} minSize={25}>
            <ChatPanel
              title="Report Assistant"
              placeholder="Ask about the report..."
              welcomeMessage="I can help you understand the generated report. Ask me questions about the extracted data, processing steps, or specific findings."
              disabled={!hasProcessedData}
              disabledMessage="Process documents to enable chat"
            />
          </Panel>
        </PanelGroup>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}
    </Box>
  );
}
