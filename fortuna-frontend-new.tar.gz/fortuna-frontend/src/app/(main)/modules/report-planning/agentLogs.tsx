"use client";

import React, { useState, useContext, createContext } from "react";
import {
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Table,
  TableCell,
  TableBody,
  TableRow,
  TableHead,
  Tooltip,
  Box,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

interface ExpandContextType {
  manualExpanded: Record<string, boolean>;
  setManualExpanded: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  setCurrentExpandedLevel: React.Dispatch<React.SetStateAction<number>>;
}

const ExpandContext = createContext<ExpandContextType | null>(null);

interface RecursiveAccordionProps {
  data: Record<string, any>;
  level: number;
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
}

function RecursiveAccordion({ data, level, onClick, path = [] }: RecursiveAccordionProps) {
  const context = useContext(ExpandContext);
  if (!context) return null;

  const { manualExpanded, setManualExpanded, setCurrentExpandedLevel } = context;

  const keyWords = ["current liabilities", "non-current liabilities", "current assets", "equity"];
  const currentPath = path.join("/");

  const handleToggle = (key: string) => {
    const newPath = `${currentPath}/${key}`;
    setManualExpanded((prev) => ({
      ...prev,
      [newPath]: !prev[newPath],
    }));

    const newLevel = path.length;
    setCurrentExpandedLevel(newLevel);
    onClick(null, [...path, key]);
  };

  if (level >= 4) {
    const tableColumns: string[] = [];
    const firstItem = Object.values(data)[0];

    if (typeof firstItem === "object" && firstItem !== null) {
      tableColumns.push(...Object.keys(firstItem));

      return (
        <Box sx={{ overflowX: "auto" }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Field Name</TableCell>
                {tableColumns.map((column, columnIndex) => (
                  <TableCell key={columnIndex} sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>
                    {column}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.entries(data).map(([rowKey, rowValue]: [string, any], rowIndex) => (
                <TableRow key={rowIndex}>
                  <TableCell
                    onClick={() => {
                      if (keyWords.includes(rowKey.toLowerCase())) {
                        onClick(rowIndex, [...path, rowKey]);
                      }
                    }}
                    sx={{
                      cursor: keyWords.includes(rowKey.toLowerCase()) ? "pointer" : "default",
                      color: keyWords.includes(rowKey.toLowerCase()) ? "#26890D" : "inherit",
                      fontWeight: keyWords.includes(rowKey.toLowerCase()) ? 500 : 400,
                    }}
                  >
                    {rowKey}
                  </TableCell>
                  {tableColumns.map((column) => (
                    <TableCell key={column} sx={{ whiteSpace: "pre-line" }}>
                      {(() => {
                        const cellValue = rowValue[column];
                        if (Array.isArray(cellValue)) {
                          return cellValue
                            .map((item) => `• ${String(item).replace(/['"[\]]/g, "")}`)
                            .join("\n");
                        } else if (typeof cellValue === "object" && cellValue !== null) {
                          return Object.values(cellValue)
                            .map((item) => `• ${String(item).replace(/['"[\]]/g, "")}`)
                            .join("\n");
                        } else {
                          return String(cellValue).replace(/['"[\]]/g, "");
                        }
                      })()}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      );
    }
  }

  return (
    <Box>
      {Object.entries(data).map(([key, value], i) =>
        typeof value === "object" && value !== null ? (
          <Accordion
            key={i}
            expanded={manualExpanded[`${currentPath}/${key}`] || false}
            onChange={() => handleToggle(key)}
            sx={{
              ml: 0,
              mb: 1,
              boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
              borderRadius: "6px !important",
              "&:before": { display: "none" },
              transition: "all 0.2s ease",
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              sx={{
                minHeight: 48,
                "& .MuiAccordionSummary-content": { my: 1 },
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 600 }}>
                {key}
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ pt: 0 }}>
              <RecursiveAccordion
                data={value}
                level={level + 1}
                onClick={onClick}
                path={[...path, key]}
              />
            </AccordionDetails>
          </Accordion>
        ) : (
          <Typography key={i} variant="body2" sx={{ py: 0.5 }} onClick={() => onClick(i, [...path, key])}>
            <strong>{key}:</strong> {JSON.stringify(value)}
          </Typography>
        )
      )}
    </Box>
  );
}

interface AgentAccordionWithButtonProps {
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
}

export default function AgentAccordionwithButton({ onClick, path = [] }: AgentAccordionWithButtonProps) {
  const [currentExpandedLevel, setCurrentExpandedLevel] = useState(-1);
  const [manualExpanded, setManualExpanded] = useState<Record<string, boolean>>({});
  const { logs: AgentLogs, logsLoading } = useContext(AgentLogsContext);

  if (logsLoading) {
    return <CircularLoader open={logsLoading} />;
  }

  const handleExpandAllNextLevel = () => {
    setCurrentExpandedLevel((prevLevel) => {
      const nextLevel = prevLevel + 1;
      const isLastLevel = nextLevel >= 4;

      setManualExpanded((prev) => {
        const updateState = (
          logs: Record<string, any>,
          currentPath: string[],
          level: number,
          currentLevel = 0
        ): Record<string, boolean> => {
          const newState: Record<string, boolean> = {};

          Object.entries(logs).forEach(([key, value]) => {
            const newPath = `${currentPath.join("/")}/${key}`;
            if (currentLevel === level || level === -1) {
              newState[newPath] = true;
            }
            if (typeof value === "object" && value !== null) {
              Object.assign(
                newState,
                updateState(value, [...currentPath, key], level, currentLevel + 1)
              );
            }
          });

          return newState;
        };

        return {
          ...prev,
          ...updateState(AgentLogs, path, isLastLevel ? -1 : nextLevel),
        };
      });

      return isLastLevel ? prevLevel : nextLevel;
    });
  };

  const handleCollapseCurrentLevel = () => {
    setManualExpanded((prev) => {
      const updateState = (
        logs: Record<string, any>,
        currentPath: string[],
        level: number,
        currentLevel = 0
      ): Record<string, boolean> => {
        const newState: Record<string, boolean> = {};

        Object.entries(logs).forEach(([key, value]) => {
          const newPath = `${currentPath.join("/")}/${key}`;
          if (currentLevel === level) {
            newState[newPath] = false;
          }
          if (typeof value === "object" && value !== null) {
            Object.assign(
              newState,
              updateState(value, [...currentPath, key], level, currentLevel + 1)
            );
          }
        });

        return newState;
      };

      return {
        ...prev,
        ...updateState(AgentLogs, path, currentExpandedLevel),
      };
    });

    setCurrentExpandedLevel((prev) => Math.max(prev - 1, 0));
  };

  const CustomTooltip = styled(({ className, ...props }: any) => (
    <Tooltip {...props} classes={{ tooltip: className }} />
  ))(() => ({
    "&.MuiTooltip-tooltip": {
      fontSize: "0.75rem",
      padding: "6px 10px",
      backgroundColor: "#000000",
      color: "#FFFFFF",
      borderRadius: "4px",
    },
  }));

  return (
    <Box>
      <Box sx={{ display: "flex", gap: 1, mb: 2 }}>
        <CustomTooltip title="Expand one level">
          <Button
            onClick={handleExpandAllNextLevel}
            variant="outlined"
            size="small"
            sx={{
              minWidth: 40,
              borderColor: "#26890D",
              color: "#26890D",
              fontWeight: 700,
              "&:hover": {
                borderColor: "#1a6609",
                bgcolor: "rgba(38, 137, 13, 0.04)",
              },
            }}
          >
            +
          </Button>
        </CustomTooltip>
        <CustomTooltip title="Collapse one level">
          <Button
            onClick={handleCollapseCurrentLevel}
            variant="outlined"
            size="small"
            sx={{
              minWidth: 40,
              borderColor: "#26890D",
              color: "#26890D",
              fontWeight: 700,
              "&:hover": {
                borderColor: "#1a6609",
                bgcolor: "rgba(38, 137, 13, 0.04)",
              },
            }}
          >
            −
          </Button>
        </CustomTooltip>
      </Box>

      <ExpandContext.Provider
        value={{ manualExpanded, setManualExpanded, setCurrentExpandedLevel }}
      >
        <RecursiveAccordion data={AgentLogs} level={0} onClick={onClick} />
      </ExpandContext.Provider>
    </Box>
  );
}
