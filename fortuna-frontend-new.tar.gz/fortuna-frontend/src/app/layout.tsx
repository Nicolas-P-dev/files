import { ThemeProvider } from "@mui/material/styles";
import theme from "@/app/theme";

export const metadata = {
  title: "FORTUNA | aiStudio",
  description: "AI Agents for automated generation of CFR (Credit File Review) reports.",
};

interface RootLayoutProps {
  children: React.ReactNode;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/icon.ico" sizes="any" />
      </head>
      <body>
        <ThemeProvider theme={theme}>{children}</ThemeProvider>
      </body>
    </html>
  );
}
