import React, { useState, useEffect } from "react";
import { Alert, Snackbar, AlertColor } from "@mui/material";

interface AlertProps {
  severity: AlertColor;
  message: string;
  autoHideDuration?: number;
  onClose?: () => void;
}

const AlertBox: React.FC<AlertProps> = ({
  message,
  severity,
  autoHideDuration = 6000,
  onClose,
}) => {
  const [open, setOpen] = useState(true);

  useEffect(() => {
    setOpen(true);
  }, [message]);

  const handleClose = (
    event?: React.SyntheticEvent | Event,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
    if (onClose) {
      onClose();
    }
  };

  return (
    <Snackbar
      open={open}
      autoHideDuration={autoHideDuration}
      onClose={handleClose}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      sx={{
        "& .MuiSnackbar-root": {
          top: "80px",
        },
      }}
    >
      <Alert
        onClose={handleClose}
        severity={severity}
        variant="filled"
        sx={{
          width: "100%",
          minWidth: "300px",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
          "& .MuiAlert-icon": {
            fontSize: "22px",
          },
          "& .MuiAlert-message": {
            fontSize: "0.875rem",
            fontWeight: 500,
          },
        }}
      >
        {message}
      </Alert>
    </Snackbar>
  );
};

export default AlertBox;
