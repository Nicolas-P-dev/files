"use client";

import React from "react";
import { Box, Typography, Chip, Divider } from "@mui/material";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  currentDebtor?: string | null;
  showDebtorBadge?: boolean;
  actions?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  currentDebtor,
  showDebtorBadge = true,
  actions,
}) => {
  return (
    <Box sx={{ mb: 3 }}>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          mb: 2,
        }}
      >
        <Box>
          <Typography
            variant="h4"
            sx={{
              fontWeight: 700,
              color: "#000000",
              mb: 0.5,
            }}
          >
            {title}
          </Typography>
          {subtitle && (
            <Typography
              variant="body2"
              sx={{
                color: "#53565A",
              }}
            >
              {subtitle}
            </Typography>
          )}
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          {showDebtorBadge && (
            <Chip
              label={currentDebtor ? `Debtor: ${currentDebtor}` : "No debtor selected"}
              sx={{
                bgcolor: currentDebtor
                  ? "rgba(38, 137, 13, 0.1)"
                  : "rgba(0, 0, 0, 0.05)",
                color: currentDebtor ? "#26890D" : "#53565A",
                fontWeight: currentDebtor ? 600 : 400,
                border: currentDebtor
                  ? "1px solid rgba(38, 137, 13, 0.3)"
                  : "1px solid rgba(0, 0, 0, 0.1)",
                "& .MuiChip-label": {
                  px: 1.5,
                },
              }}
            />
          )}
          {actions}
        </Box>
      </Box>
      <Divider sx={{ bgcolor: "rgba(0, 0, 0, 0.1)" }} />
    </Box>
  );
};

export default PageHeader;
