"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpIcon from "@mui/icons-material/Help";
import LogoutIcon from "@mui/icons-material/Logout";
import DescriptionIcon from "@mui/icons-material/Description";
import AssessmentIcon from "@mui/icons-material/Assessment";
import FolderIcon from "@mui/icons-material/Folder";
import HistoryIcon from "@mui/icons-material/History";

interface SidebarProps {
  currentDebtor: string | null;
}

const Sidebar: React.FC<SidebarProps> = ({ currentDebtor }) => {
  const pathname = usePathname();

  const navigationItems = [
    {
      label: "Configurations",
      path: "/modules/upload-document",
      icon: <SettingsIcon />,
      enabled: true,
    },
    {
      label: "Report Generation",
      path: "/modules/report-planning",
      icon: <AssessmentIcon />,
      enabled: true,
    },
    {
      label: "Report Preview",
      path: "/modules/report-generation",
      icon: <DescriptionIcon />,
      enabled: true,
    },
    {
      label: "Saved Reports",
      path: "/modules/saved-reports",
      icon: <FolderIcon />,
      enabled: false,
    },
    {
      label: "History",
      path: "/modules/history",
      icon: <HistoryIcon />,
      enabled: false,
    },
  ];

  const isSelected = (path: string) => pathname === path;

  return (
    <Box
      sx={{
        width: 260,
        height: "100vh",
        backgroundColor: "#000000",
        color: "#FFFFFF",
        display: "flex",
        flexDirection: "column",
        position: "fixed",
        left: 0,
        top: 0,
        zIndex: 1200,
      }}
    >
      {/* Logo and App Title Section */}
      <Box sx={{ pt: 4, px: 3, mb: 2 }}>
        <Image
          src="/Deloitte_Logo.png"
          width={140}
          height={35}
          alt="Deloitte Logo"
          style={{ marginBottom: "16px" }}
        />
        <Typography
          variant="h6"
          sx={{
            fontWeight: 500,
            color: "#FFFFFF",
            mb: 0.5,
          }}
        >
          aiStudio
        </Typography>
        <Typography
          variant="h5"
          sx={{
            fontWeight: 600,
            color: "#FFFFFF",
            mb: 1,
          }}
        >
          FORTUNA
        </Typography>
        <Typography
          variant="body2"
          sx={{
            color: "#A5ADBA",
            lineHeight: 1.5,
          }}
        >
          AI Agents for automated generation of CFR (Credit File Review) reports.
        </Typography>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.15)", mx: 2 }} />

      {/* Current Debtor Display */}
      <Box sx={{ px: 2, py: 2 }}>
        <Typography
          variant="caption"
          sx={{
            color: "#A5ADBA",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            mb: 1,
            display: "block",
          }}
        >
          Current Debtor
        </Typography>
        <Box
          sx={{
            bgcolor: currentDebtor
              ? "rgba(38, 137, 13, 0.15)"
              : "rgba(255, 255, 255, 0.05)",
            p: 1.5,
            borderRadius: 1,
            border: currentDebtor
              ? "1px solid rgba(38, 137, 13, 0.4)"
              : "1px solid rgba(255, 255, 255, 0.1)",
          }}
        >
          <Typography
            variant="body2"
            sx={{
              color: currentDebtor ? "#26890D" : "#A5ADBA",
              fontWeight: currentDebtor ? 600 : 400,
              fontStyle: currentDebtor ? "normal" : "italic",
            }}
          >
            {currentDebtor || "No debtor selected"}
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.15)", mx: 2 }} />

      {/* Main Navigation */}
      <Box sx={{ flex: 1, py: 1 }}>
        <Typography
          variant="caption"
          sx={{
            color: "#A5ADBA",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            px: 3,
            py: 1,
            display: "block",
          }}
        >
          Navigation
        </Typography>
        <List component="nav" sx={{ px: 1 }}>
          {navigationItems.map((item) => (
            <ListItem key={item.label} disablePadding sx={{ mb: 0.5 }}>
              {item.enabled ? (
                <Link
                  href={item.path}
                  style={{ textDecoration: "none", width: "100%" }}
                >
                  <ListItemButton
                    selected={isSelected(item.path)}
                    sx={{
                      borderRadius: 1,
                      "&.Mui-selected": {
                        bgcolor: "rgba(38, 137, 13, 0.2)",
                        "& .MuiListItemIcon-root": { color: "#26890D" },
                        "& .MuiListItemText-primary": {
                          color: "#FFFFFF",
                          fontWeight: 600,
                        },
                      },
                      "&:hover": {
                        bgcolor: "rgba(255, 255, 255, 0.08)",
                      },
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 40,
                        color: isSelected(item.path) ? "#26890D" : "#FFFFFF",
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={item.label}
                      sx={{
                        "& .MuiListItemText-primary": {
                          color: "#FFFFFF",
                          fontSize: "0.9rem",
                        },
                      }}
                    />
                  </ListItemButton>
                </Link>
              ) : (
                <ListItemButton
                  disabled
                  sx={{
                    borderRadius: 1,
                    opacity: 0.5,
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 40, color: "#A5ADBA" }}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    secondary="Coming soon"
                    sx={{
                      "& .MuiListItemText-primary": {
                        color: "#A5ADBA",
                        fontSize: "0.9rem",
                      },
                      "& .MuiListItemText-secondary": {
                        color: "#6B778C",
                        fontSize: "0.75rem",
                      },
                    }}
                  />
                </ListItemButton>
              )}
            </ListItem>
          ))}
        </List>
      </Box>

      {/* Bottom Section - Settings and Help */}
      <Box sx={{ mt: "auto" }}>
        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.15)", mx: 2 }} />
        <List component="nav" sx={{ px: 1, py: 1 }}>
          <ListItem disablePadding>
            <ListItemButton
              disabled
              sx={{
                borderRadius: 1,
                opacity: 0.5,
                "&:hover": { bgcolor: "rgba(255, 255, 255, 0.08)" },
              }}
            >
              <ListItemIcon sx={{ minWidth: 40, color: "#A5ADBA" }}>
                <SettingsIcon />
              </ListItemIcon>
              <ListItemText
                primary="Settings"
                sx={{
                  "& .MuiListItemText-primary": {
                    color: "#A5ADBA",
                    fontSize: "0.9rem",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
          <ListItem disablePadding>
            <ListItemButton
              disabled
              sx={{
                borderRadius: 1,
                opacity: 0.5,
                "&:hover": { bgcolor: "rgba(255, 255, 255, 0.08)" },
              }}
            >
              <ListItemIcon sx={{ minWidth: 40, color: "#A5ADBA" }}>
                <HelpIcon />
              </ListItemIcon>
              <ListItemText
                primary="Help & Support"
                sx={{
                  "& .MuiListItemText-primary": {
                    color: "#A5ADBA",
                    fontSize: "0.9rem",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        </List>
      </Box>
    </Box>
  );
};

export default Sidebar;
