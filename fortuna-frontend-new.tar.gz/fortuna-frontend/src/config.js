// Backend API Configuration
// Switch between environments by commenting/uncommenting the appropriate line

// Local Development
export const backend_url = "http://localhost:8080";

// L40S Server
// export const backend_url = "https://dedca2085.atrema.deloitte.com:8080";

// Azure Deployment
// export const backend_url = "https://rg-aistudio-fortuna-backend.proudforest-7e484fd7.germanywestcentral.azurecontainerapps.io";
